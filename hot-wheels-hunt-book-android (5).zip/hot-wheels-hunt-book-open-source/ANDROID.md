# Building the Android APK

This turns the Hunt Book into a standalone Android app. Nothing runs on a
server: the same actions from `server/src/actions.ts` run inside the app,
on SQLite (WebAssembly) saved to the phone, with photos/videos/music kept
in the app's own storage.

## Easiest: build it in the cloud (no Android Studio)

1. Put this folder in a GitHub repo (private is fine).
2. Open the repo's **Actions** tab, pick **Build Android APK**, press **Run workflow**.
3. When it finishes (about 5–10 minutes), open the run and download the
   **hot-wheels-hunt-book-apk** artifact. Unzip it to get `app-debug.apk`.
4. Copy the APK to your phone and open it. Allow "install unknown apps"
   for your file manager or browser when Android asks.

## Or build on your own computer

Needs Bun, Node 22+, JDK 21 and the Android SDK (Android Studio installs it).

```bash
bun install
bun run build:android          # bundle -> client/dist-android/
node scripts/prepare-android.mjs   # adds android/, camera permission, icon
cd android && ./gradlew assembleDebug
# APK: android/app/build/outputs/apk/debug/app-debug.apk
```

## What is different from the desktop version

- Data lives in the app (IndexedDB). **Uninstalling the app deletes it** —
  use Backup & Settings → Download everything now and then. Backups and
  CSV/ZIP exports open the Android share sheet so you can save them to Files or Drive.
- The two "supplied backup / songs" import buttons report "not found"
  (they read files from a computer). Restoring a backup `.json` from the
  file picker works as before.
- Chat uses its built-in fallback replies (no AI model), same as the
  standalone build.
- `bun run start` (the desktop server) still works unchanged.

## Notes

- This is a **debug** APK, fine for your own phone. A Play Store release
  needs a signing key and `./gradlew bundleRelease`.
- The app id is `com.huntbook.hotwheels` (`capacitor.config.json`);
  changing it later makes Android treat it as a different app.
- `assets/icon.png` was upscaled from the 256px `icon.webp`; a bigger
  source image gives a sharper launcher icon.

## Customizing

Names, icon, colors, cars, tags and filters are plain files in
`customize/` — see `customize/README.md`. To change them from your phone
without re-uploading the zip, put the edited files (`app.json`,
`lists.json`, `my-cars.csv`, `cars.csv`, `icon.png`) at the top level of
your GitHub repo; the workflow in `.github/workflows/build-apk.yml`
(or the phone-friendly `build.yml`) uses them instead of the zip's copies.

## Importing castings from allhotwheels.com

In the Android app, Backup & Settings → **Import castings from
allhotwheels.com** scans the site's public Browse pages (one page about
every 1.5 seconds, text only), lists each casting once, and adds the ones
not already in your checklist (matched by name, ignoring case and
punctuation). Scanning again refreshes the castings an earlier scan added
(no duplicates); built-in checklist cars and cars you added by hand are
never duplicated or changed, so your owned marks and game tags stay. A full scan is roughly 1,500 pages (about 40 minutes);
pause and resume any time. Progress is saved, so closing the app is fine.

- The site address and pause length are constants at the top of
  `client/src/ahw-import.ts` (`SOURCE_SITE`, `REQUEST_DELAY_MS`).
- It only works in the Android app; a web page can't read another site's
  pages. Imported cars are normal custom cars (you can edit or delete them).
- If the site changes its layout, the scan stops with a message instead
  of importing wrong data.
- Please keep the pause polite. The site's terms ask users not to
  overload it, and the data is the site's community catalog.

## Updating the app from your GitHub repo

Every run of the **Build Android APK** workflow also publishes a GitHub
Release (named after the build stamp in `client/src/build-stamp.ts`) with
two files: `app-debug.apk` and `bundle.json`. In the app, Settings ->
**Check GitHub for updates**:

1. Enter the repo as `owner/name` once. For a **private** repo also paste a
   fine-grained personal access token with read access to the repo's
   *Contents* (stored only on the phone).
2. Tap **Check GitHub for updates**. If the release is newer than the build
   on the phone, tap **Update now**, then **Restart into the new build**.
   Your collection, photos and settings are not touched.
3. If a new build fails to start, the next launch goes back to the previous
   build by itself and does not retry the broken one.

Rules for new builds:

- Bump `SPLASH_BUILD_STAMP` in `client/src/build-stamp.ts` (v53, v54, ...)
  in every build you want phones to pick up; the release is named after it.
- If a change needs a new native permission or plugin, also bump
  `SHELL_VERSION`. The app then offers the APK from the release page
  instead of loading it in-app.
- All builds are signed with `scripts/hunt-book.keystore`, so an APK
  installs over the old app and keeps its data. (Debug-grade key, fine for
  a personal phone; do not use it for the Play Store.)
- The first install of this version cannot go over an older APK that was
  signed with a different random key: back up (Download everything now),
  uninstall, install, then restore.
