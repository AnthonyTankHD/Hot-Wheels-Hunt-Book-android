// Build identity. Bump SPLASH_BUILD_STAMP in every build that republishes
// the client; the first number (v52) is what the in-app updater compares.
// Format: v<number>-<yyyy>-<mm>-<dd>-<short-name>
export const SPLASH_BUILD_STAMP = "v52-2026-11-13-github-updates";

// Version of the native Android shell (the installed APK itself). Bump it
// only when the native side changes (new Capacitor plugin, permissions).
// A GitHub update whose shell number differs is not loaded in-app; the
// updater offers the APK download instead.
export const SHELL_VERSION = 1;
