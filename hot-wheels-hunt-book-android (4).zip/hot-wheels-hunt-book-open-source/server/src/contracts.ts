// Privileged-contract descriptors (request/response shapes only).
//
// Split out of privileged.ts so the on-device (Android) bundle can
// import the descriptors without pulling in node:fs / node:child_process,
// which only the Bun server's handlers need.

import { definePrivilegedContracts, z } from "./sdk";

// All privileged contracts live in this one definePrivilegedContracts
// call. In the standalone build the handlers in this file run in the
// same process (see server/src/server.ts), instead of in a separate
// privileged bundle as they did on Muse.
export const hostContracts = definePrivilegedContracts({
  // The one full backup file Anthony supplied on 2026-11-04. Action
  // code cannot read host files, so this privileged handler reads it
  // and hands the text to the import action, which does all
  // validation and merging. Nothing is written here.
  readSuppliedBackup: {
    request: z.object({}),
    response: z.object({
      found: z.boolean(),
      json: z.string(),
      sha256: z.string(),
    }),
    timeoutMs: 60000,
  },
  // One of the 7 songs Anthony sent on 2026-11-04 for the Music
  // playlist. Returns the MP3 audio (converted from FLAC for
  // Adrenaline) plus the file's own embedded cover art, as base64.
  readSuppliedSong: {
    request: z.object({
      songId: z.enum([
        "adrenaline",
        "battle-cry",
        "elevated",
        "party-monsters",
        "pray-for-riddim",
        "teku-ising",
        "x-up",
      ]),
    }),
    response: z.object({
      found: z.boolean(),
      name: z.string(),
      audioBase64: z.string(),
      audioSize: z.number(),
      coverBase64: z.string().nullable(),
      coverMimeType: z.string().nullable(),
      coverSize: z.number(),
      error: z.string(),
    }),
    timeoutMs: 180000,
  },
});
