import { definePrivilegedHandlers } from "./sdk";
import { hostContracts } from "./contracts";
import { execFile } from "node:child_process";
import { createHash } from "node:crypto";
import { mkdtemp, readFile, rm } from "node:fs/promises";
import { join as joinPath } from "node:path";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { promisify } from "node:util";

const execFileAsync = promisify(execFile);

export { hostContracts };

// The 7 songs Anthony sent on 2026-11-04 for the Music playlist. The
// display name is the file's own title/artist tags (read with ffprobe
// before shipping), in "Title — Artist" form, so the single `name`
// column carries both. The enum above is the only input: no other
// host file can be read through this contract.
const SUPPLIED_SONGS = {
  adrenaline: {
    file: "2-20_Adrenaline_0_dztz.flac",
    name: "Adrenaline — Jack Wall",
    convertToMp3: true,
  },
  "battle-cry": {
    file: "All_Elite_Wrestling_-_Battle_Cry__Kenny_Omega_Theme__1_iaql.mp3",
    name: "Battle Cry (Kenny Omega Theme) — All Elite Wrestling",
    convertToMp3: false,
  },
  elevated: {
    file: "It_Lives__It_Breathes_-_Elevated_2_roxn.mp3",
    name: "Elevated — It Lives, It Breathes",
    convertToMp3: false,
  },
  "party-monsters": {
    file: "Kottonmouth_Kings__Tech_N9ne_-_Party_Monsters_3_r567.mp3",
    name: "Party Monsters — Kottonmouth Kings & Tech N9ne",
    convertToMp3: false,
  },
  "pray-for-riddim": {
    file: "Virtual_Riot_-_Pray_For_Riddim_4_8xmt.mp3",
    name: "Pray For Riddim — Virtual Riot",
    convertToMp3: false,
  },
  "teku-ising": {
    file: "TV-FM_-_TEKU-ISING__Shirako_Takamoto_Theme___Hot_Wheels_Acceleracers__5_l11h.mp3",
    name: "TEKU-ISING (Shirako Takamoto Theme) [Hot Wheels Acceleracers] — TV-FM",
    convertToMp3: false,
  },
  "x-up": {
    file: "Excision___The_Frim_-_X_Up_feat_Messinian_6_mwlc.mp3",
    name: "X Up feat Messinian — Excision & The Frim",
    convertToMp3: false,
  },
} as const;

type SongId = keyof typeof SUPPLIED_SONGS;

async function runFfmpeg(args: string[]): Promise<void> {
  // ffmpeg lives on PATH on the builder host; fall back to the usual
  // absolute path if the bare name is not found in this runtime.
  try {
    await execFileAsync("ffmpeg", args);
  } catch (err) {
    const code = (err as { code?: unknown } | null)?.code;
    if (code === "ENOENT") {
      await execFileAsync("/usr/bin/ffmpeg", args);
      return;
    }
    throw err;
  }
}

function detectCoverMimeType(bytes: Buffer): string | null {
  if (bytes.length >= 3 && bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff) return "image/jpeg";
  if (
    bytes.length >= 8 &&
    bytes[0] === 0x89 &&
    bytes[1] === 0x50 &&
    bytes[2] === 0x4e &&
    bytes[3] === 0x47
  )
    return "image/png";
  if (bytes.length >= 6 && bytes[0] === 0x47 && bytes[1] === 0x49 && bytes[2] === 0x46 && bytes[3] === 0x38)
    return "image/gif";
  if (
    bytes.length >= 12 &&
    bytes[0] === 0x52 &&
    bytes[1] === 0x49 &&
    bytes[2] === 0x46 &&
    bytes[3] === 0x46 &&
    bytes[8] === 0x57 &&
    bytes[9] === 0x45 &&
    bytes[10] === 0x42 &&
    bytes[11] === 0x50
  )
    return "image/webp";
  return null;
}

export const hostHandlers = definePrivilegedHandlers(hostContracts, {
  readSuppliedBackup: async () => {
    // Standalone: the backup is read from ./supplied/ in the project
    // folder (see README.md). It is NOT shipped with the source — it
    // is Anthony's personal collection data.
    const suppliedDir =
      process.env.HUNT_BOOK_SUPPLIED_DIR ?? joinPath(process.cwd(), "supplied");
    const candidates = [joinPath(suppliedDir, "hunt-book-backup-2026-11-04_12_llek.json")];
    for (const path of candidates) {
      try {
        const text = await readFile(path, "utf8");
        return {
          found: true,
          json: text,
          sha256: createHash("sha256").update(text, "utf8").digest("hex"),
        };
      } catch {
        // Try the next candidate; report not-found only if all fail.
      }
    }
    return { found: false, json: "", sha256: "" };
  },

  readSuppliedSong: async ({ songId }) => {
    const song: (typeof SUPPLIED_SONGS)[SongId] = SUPPLIED_SONGS[songId];
    const empty = {
      found: false,
      name: song.name,
      audioBase64: "",
      audioSize: 0,
      coverBase64: null as string | null,
      coverMimeType: null as string | null,
      coverSize: 0,
      error: "",
    };
    // Standalone: songs are read from ./supplied/ in the project
    // folder (see README.md). They are NOT shipped with the source.
    const suppliedDir =
      process.env.HUNT_BOOK_SUPPLIED_DIR ?? joinPath(process.cwd(), "supplied");
    const candidates = [joinPath(suppliedDir, song.file)];
    let inputPath: string | null = null;
    for (const path of candidates) {
      try {
        await readFile(path);
        inputPath = path;
        break;
      } catch {
        // Try the next candidate; report not-found only if all fail.
      }
    }
    if (!inputPath) {
      return { ...empty, error: `The supplied song file (${song.file}) was not found, so nothing was imported for it.` };
    }
    const dir = await mkdtemp(join(tmpdir(), "hunt-book-song-"));
    try {
      // Cover art: extract the file's own attached picture (the APIC
      // frame in an MP3, the PICTURE block in the FLAC) byte-for-byte
      // with ffmpeg, so no tag parsing is needed here. A file with no
      // picture simply yields no cover; that never blocks the song.
      let coverBase64: string | null = null;
      let coverMime: string | null = null;
      let coverSize = 0;
      const coverPath = join(dir, "cover.bin");
      try {
        // -f image2 is required: the temp file has a .bin name, so
        // ffmpeg cannot guess an output format from its extension.
        await runFfmpeg(["-y", "-v", "error", "-i", inputPath, "-map", "0:v:0", "-frames:v", "1", "-c", "copy", "-f", "image2", coverPath]);
        const coverBytes = await readFile(coverPath);
        const mime = detectCoverMimeType(coverBytes);
        // Same 2.2 MB cap the in-app picker extractor uses, so one
        // oversized picture cannot swallow the upload cap.
        if (mime && coverBytes.length > 0 && coverBytes.length <= 2_200_000) {
          coverBase64 = coverBytes.toString("base64");
          coverMime = mime;
          coverSize = coverBytes.length;
        }
      } catch {
        // No attached picture (or an unreadable one): song without cover.
      }
      // Audio: MP3s enter byte-for-byte (no re-encode); the FLAC is
      // converted to 192 kbps MP3, keeping its title/artist tags, so
      // the player — which only accepts MP3 — can play it.
      let audioBytes: Buffer;
      if (song.convertToMp3) {
        const outPath = join(dir, "song.mp3");
        try {
          await runFfmpeg([
            "-y",
            "-v",
            "error",
            "-i",
            inputPath,
            "-vn",
            "-codec:a",
            "libmp3lame",
            "-b:a",
            "192k",
            "-map_metadata",
            "0",
            outPath,
          ]);
        } catch (err) {
          return { ...empty, error: `The Adrenaline FLAC could not be converted to MP3 (${err instanceof Error ? err.message : "ffmpeg failed"}), so it was not imported.` };
        }
        audioBytes = await readFile(outPath);
      } else {
        audioBytes = await readFile(inputPath);
      }
      if (audioBytes.length === 0) {
        return { ...empty, error: `The supplied song file (${song.file}) is empty, so nothing was imported for it.` };
      }
      return {
        found: true,
        name: song.name,
        audioBase64: audioBytes.toString("base64"),
        audioSize: audioBytes.length,
        coverBase64,
        coverMimeType: coverMime,
        coverSize,
        error: "",
      };
    } finally {
      await rm(dir, { recursive: true, force: true });
    }
  },
});
