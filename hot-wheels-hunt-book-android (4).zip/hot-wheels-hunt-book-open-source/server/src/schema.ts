import { integer, primaryKey, sqliteTable, text } from "drizzle-orm/sqlite-core";

export const carState = sqliteTable("car_state", {
  carKey: text("car_key").primaryKey(),
  owned: integer("owned").notNull().default(0),
  // Anthony's Favorites list: a car can only be a favorite while it is
  // owned (enforced in setCarState — unowning a car clears the flag),
  // so the list is always drawn from his owned cars only.
  isFavorite: integer("is_favorite").notNull().default(0),
  isTh: integer("is_th").notNull().default(0),
  isSth: integer("is_sth").notNull().default(0),
  count: integer("count").notNull().default(0),
  note: text("note").notNull().default(""),
  ownedAt: integer("owned_at", { mode: "timestamp_ms" }),
  thAt: integer("th_at", { mode: "timestamp_ms" }),
  updatedAt: integer("updated_at", { mode: "timestamp_ms" })
    .notNull()
    .$defaultFn(() => new Date()),
});

export const customCars = sqliteTable("custom_cars", {
  carKey: text("car_key").primaryKey(),
  name: text("name").notNull(),
  details: text("details").notNull().default(""),
  tags: text("tags").notNull().default(""),
  createdAt: integer("created_at", { mode: "timestamp_ms" })
    .notNull()
    .$defaultFn(() => new Date()),
});

export const photos = sqliteTable("photos", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  carKey: text("car_key"),
  blobKey: text("blob_key").notNull(),
  contentType: text("content_type").notNull(),
  // Small preview thumbnail of the same photo (max ~360 px, made by the
  // client from the photo itself), stored as its own blob like the
  // track covers. The Cars list tiles show the thumbnail so the list
  // loads fast; the full photo still opens from the car sheet. Null
  // until a thumbnail has been made for the photo; tiles then fall
  // back to the full photo URL.
  thumbBlobKey: text("thumb_blob_key"),
  thumbContentType: text("thumb_content_type"),
  // Order of this photo within its car's photo list. The lowest position
  // is the cover photo (the original app's first photo, `img`); adding a
  // photo appends it, and "Make cover photo" moves a photo to position 0.
  position: integer("position").notNull().default(0),
  createdAt: integer("created_at", { mode: "timestamp_ms" })
    .notNull()
    .$defaultFn(() => new Date()),
});

// Songs Anthony picks with the file picker in Music. Only the blob key
// is stored; the audio bytes live in blob storage like photos/videos.
// `position` is playlist order: a newly picked song appends at the end.
export const tracks = sqliteTable("tracks", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  name: text("name").notNull(),
  blobKey: text("blob_key").notNull(),
  contentType: text("content_type").notNull(),
  // Cover art extracted from the MP3's embedded ID3 picture frame when
  // the song was picked, stored as its own blob like the audio. Null
  // when the file had no embedded cover; the client then shows the
  // default flame/music placeholder instead of a broken image.
  coverBlobKey: text("cover_blob_key"),
  coverContentType: text("cover_content_type"),
  position: integer("position").notNull().default(0),
  createdAt: integer("created_at", { mode: "timestamp_ms" })
    .notNull()
    .$defaultFn(() => new Date()),
});

export const videos = sqliteTable("videos", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  carKey: text("car_key"),
  blobKey: text("blob_key").notNull(),
  name: text("name").notNull().default(""),
  contentType: text("content_type").notNull(),
  createdAt: integer("created_at", { mode: "timestamp_ms" })
    .notNull()
    .$defaultFn(() => new Date()),
});

export const links = sqliteTable("links", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  url: text("url").notNull(),
  label: text("label").notNull(),
  carKey: text("car_key"),
  createdAt: integer("created_at", { mode: "timestamp_ms" })
    .notNull()
    .$defaultFn(() => new Date()),
});

export const targets = sqliteTable("targets", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  month: text("month").notNull(),
  text: text("text").notNull(),
  carKey: text("car_key"),
  done: integer("done").notNull().default(0),
  createdAt: integer("created_at", { mode: "timestamp_ms" })
    .notNull()
    .$defaultFn(() => new Date()),
});

export const planDays = sqliteTable(
  "plan_days",
  {
    month: text("month").notNull(),
    day: integer("day").notNull(),
    isHunt: integer("is_hunt").notNull().default(0),
    note: text("note").notNull().default(""),
  },
  (t) => [primaryKey({ columns: [t.month, t.day] })],
);

export const monthPlans = sqliteTable("month_plans", {
  month: text("month").primaryKey(),
  budget: text("budget").notNull().default(""),
  spent: text("spent").notNull().default(""),
});

// Hunt-prep checklist for one hunt day. The item texts themselves are a
// fixed generic list in the client (HUNT_CHECKLIST_ITEMS); only the
// checked state is stored, keyed by planner month + day + item index, so
// checking an item for Nov 14 never affects any other hunt day and an
// unchecked item stays unchecked (a stored 0 row) rather than vanishing.
export const huntChecklist = sqliteTable(
  "hunt_checklist",
  {
    month: text("month").notNull(),
    day: integer("day").notNull(),
    idx: integer("idx").notNull(),
    checked: integer("checked").notNull().default(0),
  },
  (t) => [primaryKey({ columns: [t.month, t.day, t.idx] })],
);

export const profile = sqliteTable("profile", {
  id: integer("id").primaryKey(),
  name: text("name").notNull().default(""),
  bio: text("bio").notNull().default(""),
  favorite: text("favorite").notNull().default(""),
  photoBlobKey: text("photo_blob_key"),
  photoContentType: text("photo_content_type"),
});

export const pledge = sqliteTable("pledge", {
  idx: integer("idx").primaryKey(),
  checked: integer("checked").notNull().default(0),
});

export const visits = sqliteTable("visits", {
  date: text("date").primaryKey(),
});

export const meta = sqliteTable("meta", {
  key: text("key").primaryKey(),
  value: text("value").notNull().default(""),
});

// Points & Rewards: every points change is one row here — earns are
// positive, Rewards Shop spends are negative. Lifetime points (which
// set the level and never go down) are the sum of the positive rows;
// the spendable balance is the sum of all rows. kind is one of:
// seed (the one-time retroactive starting points), car, copy, th,
// sth, photo, target, daily, shop.
export const pointsLog = sqliteTable("points_log", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  kind: text("kind").notNull(),
  label: text("label").notNull().default(""),
  points: integer("points").notNull(),
  carKey: text("car_key"),
  createdAt: integer("created_at", { mode: "timestamp_ms" })
    .notNull()
    .$defaultFn(() => new Date()),
});

// Rewards Shop purchases: one row per shop item bought with spendable
// points. Level unlocks are not stored here — they are derived from
// lifetime points, so they can never be lost by spending.
export const shopPurchases = sqliteTable("shop_purchases", {
  itemKey: text("item_key").primaryKey(),
  createdAt: integer("created_at", { mode: "timestamp_ms" })
    .notNull()
    .$defaultFn(() => new Date()),
});

export const chatMessages = sqliteTable("chat_messages", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  role: text("role", { enum: ["user", "assistant"] }).notNull(),
  content: text("content").notNull().default(""),
  carKey: text("car_key"),
  // Which bot spoke an assistant row: "manager" (Hot Wheels Manager,
  // the default for all pre-existing history) or "fun" (Hot Wheels Guru).
  // User rows store "manager" via the column default and ignore it.
  bot: text("bot", { enum: ["manager", "fun"] }).notNull().default("manager"),
  createdAt: integer("created_at", { mode: "timestamp_ms" })
    .notNull()
    .$defaultFn(() => new Date()),
});
