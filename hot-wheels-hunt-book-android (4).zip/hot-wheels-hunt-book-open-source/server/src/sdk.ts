// Local replacement for the Muse-only `@hatch/space-sdk` server surface.
//
// The original source imported `defineAction`, `z`, `Ctx`, `SpaceDb` and
// the privileged-contract helpers from `@hatch/space-sdk`, a package that
// only exists inside Muse (it is installed from a local file path, not
// from npm). This module provides the same small surface with plain
// Zod + Drizzle types, so the app builds and runs anywhere Bun runs.
//
// What this does NOT do: it does not talk to Muse, it does not provide
// model inference, and it does not provide hosted blob storage — those
// are supplied by `server/src/server.ts` (local SQLite + local files)
// and documented in README.md.

import { z } from "zod";
import type { BaseSQLiteDatabase } from "drizzle-orm/sqlite-core";

export { z };

/** Brand carried on every action definition, mirroring the SDK. */
export const ACTION_BRAND = "hot-wheels-hunt-book/action/v1";

/** Brand carried on every privileged-contract descriptor. */
export const PRIVILEGED_CONTRACT_BRAND =
  "hot-wheels-hunt-book/privileged-contract/v1";

/** Thrown when a structured (schema-validated) reply is invalid. */
export class InferenceSchemaError extends Error {
  __brand = "@hatch/space-sdk/InferenceSchemaError/v1";
  issues: unknown[];
  constructor(issues: unknown[]) {
    super(
      `Inference output failed schema validation (${issues.length} issue${issues.length === 1 ? "" : "s"})`,
    );
    this.name = "InferenceSchemaError";
    this.issues = issues;
  }
  static is(value: unknown): value is InferenceSchemaError {
    if (value instanceof InferenceSchemaError) return true;
    return (
      typeof value === "object" &&
      value !== null &&
      "__brand" in value &&
      (value as { __brand?: unknown }).__brand ===
        "@hatch/space-sdk/InferenceSchemaError/v1" &&
      "issues" in value &&
      Array.isArray((value as { issues?: unknown }).issues)
    );
  }
}

// Driver-agnostic synchronous SQLite database: the Bun server passes a
// bun:sqlite-backed drizzle db, the Android build passes a sql.js one.
export type SpaceDb<TSchema extends Record<string, unknown>> =
  BaseSQLiteDatabase<"sync", any, TSchema>;

export interface BlobHead {
  sizeBytes: number;
  contentType?: string;
}

export interface Blobs {
  put(key: string, bytes: Uint8Array, opts?: { contentType?: string }): Promise<void>;
  getUrl(key: string): Promise<string>;
  head(key: string): Promise<BlobHead | null>;
  delete(key: string): Promise<void>;
}

export interface Inference {
  complete<T extends z.ZodTypeAny>(
    prompt: string,
    opts: { schema: T; system?: string },
  ): Promise<z.infer<T>>;
}

export interface PrivilegedContract<
  Req extends z.ZodTypeAny = z.ZodTypeAny,
  Res extends z.ZodTypeAny = z.ZodTypeAny,
> {
  __brand: string;
  name: string;
  request: Req;
  response: Res;
  timeoutMs?: number;
}

export interface Ctx {
  /** No viewer in the standalone build: single-user, local app, so
      this is always undefined. The shape is kept so the owner guard
      in actions.ts (written for Muse's viewer) still type-checks. */
  viewer?: { isOwner?: boolean; source?: string };
  db<TSchema extends Record<string, unknown>>(): SpaceDb<TSchema>;
  blobs: Blobs;
  inference: Inference;
  executePrivileged<
    Req extends z.ZodTypeAny,
    Res extends z.ZodTypeAny,
  >(
    contract: PrivilegedContract<Req, Res>,
    args: z.infer<Req>,
  ): Promise<z.infer<Res>>;
  invalidateQueries(): void;
}

export type ActionSpec<
  Req extends z.ZodTypeAny = z.ZodTypeAny,
  Res extends z.ZodTypeAny = z.ZodTypeAny,
> = {
  description?: string;
  request: Req;
  response: Res;
  privileged?: PrivilegedContract[];
  handler: (ctx: Ctx, args: z.infer<Req>) => Promise<z.infer<Res>>;
};

export type ActionDefinition<
  Req extends z.ZodTypeAny = z.ZodTypeAny,
  Res extends z.ZodTypeAny = z.ZodTypeAny,
> = ActionSpec<Req, Res> & { __brand: string };

export function defineAction<
  Req extends z.ZodTypeAny,
  Res extends z.ZodTypeAny,
>(spec: ActionSpec<Req, Res>): ActionDefinition<Req, Res> {
  return { ...spec, __brand: ACTION_BRAND };
}

/** Loose action shape for the dispatch table: handler args are `any`
    here (each concrete action keeps its own inferred args type), so
    every `defineAction(...)` result is assignable to it. */
export type AnyActionDefinition = {
  __brand: string;
  description?: string;
  request: z.ZodTypeAny;
  response: z.ZodTypeAny;
  privileged?: PrivilegedContract<z.ZodTypeAny, z.ZodTypeAny>[];
  handler: (ctx: Ctx, args: any) => Promise<any>;
};

export type ActionsModule = Record<string, AnyActionDefinition>;

export function definePrivilegedContracts<
  T extends Record<string, { request: z.ZodTypeAny; response: z.ZodTypeAny; timeoutMs?: number }>,
>(
  specs: T,
): { [K in keyof T]: PrivilegedContract<T[K]["request"], T[K]["response"]> } {
  const contracts = {} as {
    [K in keyof T]: PrivilegedContract<T[K]["request"], T[K]["response"]>;
  };
  for (const [name, spec] of Object.entries(specs)) {
    contracts[name as keyof T] = {
      __brand: PRIVILEGED_CONTRACT_BRAND,
      name,
      request: spec.request,
      response: spec.response,
      ...(spec.timeoutMs !== undefined ? { timeoutMs: spec.timeoutMs } : {}),
    } as (typeof contracts)[keyof T];
  }
  return contracts;
}

export function definePrivilegedHandlers<
  TContracts extends Record<string, PrivilegedContract<z.ZodTypeAny, z.ZodTypeAny>>,
>(
  contracts: TContracts,
  handlers: {
    [K in keyof TContracts]?: (
      args: z.infer<TContracts[K]["request"]>,
    ) => Promise<z.infer<TContracts[K]["response"]>>;
  },
): {
  format: string;
  entries: {
    contract: PrivilegedContract<z.ZodTypeAny, z.ZodTypeAny>;
    handler: (args: any) => Promise<unknown>;
  }[];
} {
  const entries: {
    contract: PrivilegedContract<z.ZodTypeAny, z.ZodTypeAny>;
    handler: (args: any) => Promise<unknown>;
  }[] = [];
  for (const [key, handler] of Object.entries(handlers)) {
    if (handler === undefined) continue;
    const contract = contracts[key];
    if (!contract) {
      throw new Error(`privileged handler '${key}' does not have a contract descriptor`);
    }
    entries.push({
      contract,
      handler: handler as (args: any) => Promise<unknown>,
    });
  }
  return { format: "hot-wheels-hunt-book-privileged-handlers-v1", entries };
}
