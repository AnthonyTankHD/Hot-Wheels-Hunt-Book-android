// Standalone server for the open-source Hot Wheels Hunt Book.
//
// Run with `bun run start` (or `bun run server/src/server.ts`).
// It serves the built client (`client/dist/`, built by `bun run build`)
// and the action API the client calls:
//
//   POST /actions   { "action": "getState", "args": {} }  -> { "data": ... }
//   GET  /blobs/<key>                                     -> a stored photo / song / video
//
// Data lives locally, next to the project — nothing leaves the machine:
//   data/hunt-book.db   SQLite database (Drizzle schema in server/src/schema.ts,
//                       migrations in drizzle/, applied on startup)
//   data/blobs/         uploaded photos, videos, music and covers, one file
//                       per blob key (plus a small .meta.json with its type)
//
// Environment:
//   PORT                  Port to listen on (default 3000)
//   HOST                  Bind address (default 0.0.0.0)
//   HUNT_BOOK_DB          Database file (default data/hunt-book.db)
//   HUNT_BOOK_BLOBS       Blob folder (default data/blobs)
//   HUNT_BOOK_SUPPLIED_DIR  Folder holding the optional supplied backup /
//                           song files for importSuppliedBackup /
//                           importSuppliedSongs (default ./supplied)

import { Database } from "bun:sqlite";
import { drizzle, type BunSQLiteDatabase } from "drizzle-orm/bun-sqlite";
import { migrate } from "drizzle-orm/bun-sqlite/migrator";
import { existsSync, mkdirSync, readdirSync, readFileSync, statSync, unlinkSync, writeFileSync } from "node:fs";
import { join, resolve, sep } from "node:path";
import { Actions } from "./actions";
import { hostHandlers } from "./privileged";
import * as schema from "./schema";
import type { BlobHead, Blobs, Ctx, Inference } from "./sdk";

const ROOT = resolve(import.meta.dir, "..", "..");
const DB_PATH = process.env.HUNT_BOOK_DB ?? join(ROOT, "data", "hunt-book.db");
const BLOBS_DIR = process.env.HUNT_BOOK_BLOBS ?? join(ROOT, "data", "blobs");
const DIST_DIR = join(ROOT, "client", "dist");
const PORT = Number(process.env.PORT ?? 3000);
const HOST = process.env.HOST ?? "0.0.0.0";

mkdirSync(BLOBS_DIR, { recursive: true });

// --- Database -------------------------------------------------------------
const sqlite = new Database(DB_PATH);
const db: BunSQLiteDatabase<typeof schema> = drizzle(sqlite, { schema });

// Apply the drizzle migrations in order (drizzle/0001..0011, tracked by
// drizzle/meta/_journal.json). On a fresh database this creates all
// 18 tables; on an existing one it applies only what is missing.
try {
  migrate(db, { migrationsFolder: join(ROOT, "drizzle") });
} catch (err) {
  // Fall back to running the migration SQL files directly, in order.
  console.warn("drizzle migrate() failed, applying SQL files directly:", err);
  const files = readdirSync(join(ROOT, "drizzle"))
    .filter((f) => /^\d+_.*\.sql$/.test(f))
    .sort();
  for (const file of files) {
    try {
      sqlite.exec(readFileSync(join(ROOT, "drizzle", file), "utf8"));
    } catch (e) {
      // Re-running a migration that already applied is expected to fail
      // on "already exists" — ignore those, surface anything else.
      if (!/already exists/i.test(String(e))) throw e;
    }
  }
}

// --- Local blob storage ---------------------------------------------------
// One file per blob key under BLOBS_DIR, plus a `<key>.meta.json` holding
// the content type put() was given. Keys come only from the server's own
// database rows and generated names, never from client input.

function blobPath(key: string): string {
  const safe = key.split("/").filter((part) => part !== "" && part !== "." && part !== "..");
  return join(BLOBS_DIR, ...safe);
}

function blobMetaPath(key: string): string {
  return `${blobPath(key)}.meta.json`;
}

const blobs: Blobs = {
  async put(key, bytes, opts) {
    const path = blobPath(key);
    mkdirSync(join(path, ".."), { recursive: true });
    writeFileSync(path, bytes);
    writeFileSync(
      blobMetaPath(key),
      JSON.stringify({ contentType: opts?.contentType ?? "application/octet-stream" }),
    );
  },
  async getUrl(key) {
    // Throws when the file is gone, exactly like the hosted version did:
    // callers treat a missing blob as "no photo" instead of bricking.
    if (!existsSync(blobPath(key))) {
      throw new Error(`blob not found: ${key}`);
    }
    return `/blobs/${key.split("/").map(encodeURIComponent).join("/")}`;
  },
  async head(key): Promise<BlobHead | null> {
    const path = blobPath(key);
    if (!existsSync(path)) return null;
    let contentType: string | undefined;
    try {
      contentType = JSON.parse(readFileSync(blobMetaPath(key), "utf8")).contentType;
    } catch {
      contentType = undefined;
    }
    return { sizeBytes: statSync(path).size, contentType };
  },
  async delete(key) {
    const path = blobPath(key);
    if (existsSync(path)) unlinkSync(path);
    if (existsSync(blobMetaPath(key))) unlinkSync(blobMetaPath(key));
  },
};

// --- Model inference ------------------------------------------------------
// The in-app chat (Hot Wheels Manager / Hot Wheels Guru) was powered by
// Muse's model in the original app. There is no model bundled with this
// source and no API key configured, so inference is unavailable here.
// Throwing (instead of inventing a reply) makes sendChatMessage fall
// back to its grounded, no-guessing reply — the message is still saved,
// nothing is marked or changed, and the chat stays honest about it.
// To wire a real model in, implement `complete()` here (see README.md).
const inference: Inference = {
  async complete() {
    throw new Error(
      "AI chat is not available in the standalone build — no model is configured. " +
        "The chat falls back to a grounded summary reply; see README.md to wire one in.",
    );
  },
};

// --- Privileged host reads ------------------------------------------------
// In the original app these read Anthony's supplied backup / song files
// from his computer through a separate privileged bundle. Here the same
// handlers run in-process, reading ./supplied/ (see server/src/privileged.ts).
const privilegedHandlers = new Map(
  hostHandlers.entries.map((e) => [e.contract.name, e.handler]),
);

function makeCtx(): Ctx {
  return {
    viewer: undefined,
    db: () => db as never,
    blobs,
    inference,
    async executePrivileged(contract, args) {
      const handler = privilegedHandlers.get(contract.name);
      if (!handler) {
        throw new Error(`no privileged handler for ${contract.name}`);
      }
      const parsedArgs = contract.request.parse(args);
      const result = await handler(parsedArgs);
      return contract.response.parse(result) as never;
    },
    invalidateQueries() {
      // No-op standalone: the client refetches after each mutation.
    },
  };
}

// --- HTTP server ----------------------------------------------------------

const server = Bun.serve({
  port: PORT,
  hostname: HOST,
  async fetch(req) {
    const url = new URL(req.url);

    // Action API: POST /actions { action, args } -> { data } | { error }
    if (url.pathname === "/actions" && req.method === "POST") {
      let body: { action?: unknown; args?: unknown };
      try {
        body = (await req.json()) as typeof body;
      } catch {
        return Response.json({ error: "request body must be JSON" }, { status: 400 });
      }
      const name = typeof body.action === "string" ? body.action : "";
      const action = (Actions as Record<string, { request: { parse: (v: unknown) => unknown }; response: { parse: (v: unknown) => unknown }; handler: (ctx: Ctx, args: never) => Promise<unknown> }>)[name];
      if (!action) {
        return Response.json({ error: `unknown action: ${name}` }, { status: 404 });
      }
      try {
        const args = action.request.parse(body.args ?? {});
        const result = await action.handler(makeCtx(), args as never);
        let data: unknown = result;
        try {
          data = action.response.parse(result);
        } catch {
          // Response-shape drift must not break a successful write;
          // return the handler's result as-is and log the mismatch.
          console.warn(`action ${name}: response did not match its schema, returning raw result`);
        }
        return Response.json({ data });
      } catch (err) {
        const message = err instanceof Error ? err.message : String(err);
        console.error(`action ${name} failed:`, message);
        return Response.json({ error: message }, { status: 500 });
      }
    }

    // Blob files: GET /blobs/<key>
    if (url.pathname.startsWith("/blobs/")) {
      const key = decodeURIComponent(url.pathname.slice("/blobs/".length));
      const path = blobPath(key);
      if (!path.startsWith(BLOBS_DIR + sep) || !existsSync(path)) {
        return new Response("blob not found", { status: 404 });
      }
      let contentType = "application/octet-stream";
      try {
        contentType = JSON.parse(readFileSync(blobMetaPath(key), "utf8")).contentType ?? contentType;
      } catch {
        // Keep the default.
      }
      return new Response(Bun.file(path), { headers: { "content-type": contentType } });
    }

    // Static client: files from client/dist, SPA fallback to index.html.
    const distIndex = join(DIST_DIR, "index.html");
    if (!existsSync(distIndex)) {
      return new Response(
        "Client not built yet — run `bun run build` first, then `bun run start`.",
        { status: 500 },
      );
    }
    let filePath = join(DIST_DIR, decodeURIComponent(url.pathname.slice(1)));
    if (url.pathname === "/" || !existsSync(filePath) || statSync(filePath).isDirectory()) {
      filePath = distIndex;
    }
    if (!filePath.startsWith(DIST_DIR)) {
      return new Response("not found", { status: 404 });
    }
    return new Response(Bun.file(filePath));
  },
});

console.log(`Hot Wheels Hunt Book (standalone) listening on http://${server.hostname}:${server.port}`);
console.log(`Database: ${DB_PATH}`);
console.log(`Blobs:    ${BLOBS_DIR}`);
console.log(`Client:   ${DIST_DIR}`);
