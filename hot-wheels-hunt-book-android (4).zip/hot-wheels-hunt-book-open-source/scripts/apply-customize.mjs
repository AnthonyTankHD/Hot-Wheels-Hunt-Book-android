// Applies everything in customize/ to the project.
//
//   node scripts/apply-customize.mjs      (or: bun run customize)
//
// Reads:
//   customize/app.json      app name, app id, icon background, brand colors
//   customize/cars.csv      the full car list (one row per car)
//   customize/my-cars.csv   your own extra cars (same columns), added after cars.csv
//   customize/lists.json    tags, filter buttons, game totals, quotes, pledge
//   customize/icon.png      the launcher icon (used by the Android build)
//
// Writes (generated — do not edit these by hand):
//   server/src/catalog.ts, client/src/catalog.ts
//   client/src/customize.generated.css
//   capacitor.config.json, and the <title> of both index.html files
//
// Runs automatically at the start of `bun run build` and
// `bun run build:android`.

import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const at = (...p) => join(root, ...p);

function fail(message) {
  throw new Error(`customize: ${message}`);
}

function writeIfChanged(path, text) {
  if (existsSync(path) && readFileSync(path, "utf8") === text) return;
  writeFileSync(path, text);
}

function readJson(name) {
  const path = at("customize", name);
  if (!existsSync(path)) fail(`missing customize/${name}`);
  try {
    return JSON.parse(readFileSync(path, "utf8"));
  } catch (err) {
    fail(`customize/${name} is not valid JSON (${err instanceof Error ? err.message : err}). ` +
      "Check for a missing comma, quote or bracket.");
  }
}

// --- CSV (RFC 4180: quotes, commas and line breaks inside quotes) ---------
function parseCsv(text) {
  const rows = [];
  let row = [];
  let field = "";
  let quoted = false;
  const src = text.replace(/^\uFEFF/, "");
  for (let i = 0; i < src.length; i++) {
    const ch = src[i];
    if (quoted) {
      if (ch === '"') {
        if (src[i + 1] === '"') { field += '"'; i++; } else quoted = false;
      } else field += ch;
    } else if (ch === '"') quoted = true;
    else if (ch === ",") { row.push(field); field = ""; }
    else if (ch === "\n" || ch === "\r") {
      if (ch === "\r" && src[i + 1] === "\n") i++;
      row.push(field); field = "";
      rows.push(row); row = [];
    } else field += ch;
  }
  if (field !== "" || row.length > 0) { row.push(field); rows.push(row); }
  return rows.filter((r) => r.some((c) => c.trim() !== ""));
}

// --- app.json ---------------------------------------------------------------
const app = readJson("app.json");
const HEX = /^#[0-9a-fA-F]{6}$/;
const appName = String(app.appName ?? "").trim();
if (!appName) fail('customize/app.json needs an "appName"');
const appId = String(app.appId ?? "").trim();
if (!/^[a-zA-Z][a-zA-Z0-9_]*(\.[a-zA-Z][a-zA-Z0-9_]*)+$/.test(appId)) {
  fail('customize/app.json "appId" must look like com.yourname.huntbook (letters, numbers, dots)');
}
const iconBackground = String(app.iconBackground ?? "#0b3d91");
if (!HEX.test(iconBackground)) fail('"iconBackground" must be a color like #0b3d91');

const DEFAULT_COLORS = { background: "#1a7bff", accent: "#e0191f", navy: "#14204a", yellow: "#ffd400" };
const CSS_VARS = { background: "--bg", accent: "--accent", navy: "--navy", yellow: "--yellow" };
const colors = { ...DEFAULT_COLORS, ...(app.colors ?? {}) };
const cssLines = [];
for (const [name, value] of Object.entries(colors)) {
  if (!(name in CSS_VARS)) fail(`unknown color "${name}" — use background, accent, navy or yellow`);
  if (!HEX.test(String(value))) fail(`color "${name}" must look like #1a7bff`);
  // Only emit colors you changed, so untouched colors keep their
  // separate light/dark shades.
  if (String(value).toLowerCase() !== DEFAULT_COLORS[name]) {
    cssLines.push(`  ${CSS_VARS[name]}: ${String(value).toLowerCase()};`);
  }
}
writeIfChanged(
  at("client", "src", "customize.generated.css"),
  "/* GENERATED from customize/app.json by scripts/apply-customize.mjs — do not edit. */\n" +
    (cssLines.length
      ? `:root,\n:root[data-theme="light"],\n:root[data-theme="dark"] {\n${cssLines.join("\n")}\n}\n`
      : ""),
);

writeIfChanged(
  at("capacitor.config.json"),
  JSON.stringify(
    { appId, appName, webDir: "client/dist-android", server: { androidScheme: "https" } },
    null,
    2,
  ) + "\n",
);

for (const file of [["client", "index.html"], ["client", "android", "index.html"]]) {
  const path = at(...file);
  if (!existsSync(path)) continue;
  const html = readFileSync(path, "utf8");
  const escaped = appName.replace(/&/g, "&amp;").replace(/</g, "&lt;");
  writeIfChanged(path, html.replace(/<title>[\s\S]*?<\/title>/, `<title>${escaped}</title>`));
}

// --- lists.json -------------------------------------------------------------
const lists = readJson("lists.json");
const tags = lists.tags ?? {};
const hiddenTags = lists.hiddenTags ?? {};
const wordToCode = new Map();
const knownWords = [];
for (const [code, def] of Object.entries(tags)) {
  if (code.length !== 1) fail(`tag code "${code}" in lists.json must be a single character`);
  if (!def || typeof def.label !== "string" || typeof def.style !== "string") {
    fail(`tag "${code}" in lists.json needs a "label" and a "style"`);
  }
  wordToCode.set(def.label.toLowerCase(), code);
  knownWords.push(def.label);
}
for (const [code, word] of Object.entries(hiddenTags)) {
  if (code.length !== 1) fail(`hidden tag code "${code}" in lists.json must be a single character`);
  wordToCode.set(String(word).toLowerCase(), code);
  knownWords.push(String(word));
}

// --- cars -------------------------------------------------------------------
function readCars(name, required) {
  const path = at("customize", name);
  if (!existsSync(path)) {
    if (required) fail(`missing customize/${name}`);
    return [];
  }
  const rows = parseCsv(readFileSync(path, "utf8"));
  const head = (rows[0] ?? []).map((h) => h.trim().toLowerCase());
  const col = (n) => head.indexOf(n);
  if (col("name") < 0 || col("tags") < 0) fail(`customize/${name} needs a header row with: name, tags, details, key`);
  const cars = [];
  rows.slice(1).forEach((r, i) => {
    const line = i + 2;
    const cell = (n) => (col(n) < 0 ? "" : (r[col(n)] ?? "").trim());
    const n = cell("name");
    if (!n) fail(`customize/${name} line ${line}: the car has no name`);
    const words = cell("tags").split(/[\s,;|]+/).filter(Boolean);
    let t = "";
    for (const w of words) {
      const code = wordToCode.get(w.toLowerCase());
      if (code === undefined) {
        fail(`customize/${name} line ${line} ("${n}"): unknown tag "${w}". ` +
          `Known tags: ${knownWords.join(", ")}. ` +
          "Add new ones in customize/lists.json.");
      }
      t += code;
    }
    // A car's key is what its owned/photo/plan data is saved under.
    // Leave it blank for new cars; it is made from the name.
    const k = cell("key") || n.toLowerCase().replace(/[^a-z0-9]/g, "");
    if (!k) fail(`customize/${name} line ${line} ("${n}"): could not make a key from this name — add a "key" value`);
    const car = { n, k, t };
    const x = cell("details");
    if (x) car.x = x;
    cars.push(car);
  });
  return cars;
}

const cars = [...readCars("cars.csv", true), ...readCars("my-cars.csv", false)];
const seen = new Map();
for (const c of cars) {
  if (seen.has(c.k)) fail(`two cars share the key "${c.k}" ("${seen.get(c.k)}" and "${c.n}"). Give one a different "key".`);
  seen.set(c.k, c.n);
}

// --- catalog.ts -------------------------------------------------------------
const filters = lists.filters ?? [];
if (!Array.isArray(filters) || filters.some((f) => !Array.isArray(f) || f.length !== 2)) {
  fail('"filters" in lists.json must be a list of ["code", "Button label"] pairs');
}
const legend = Object.fromEntries(Object.entries(tags).map(([code, d]) => [code, [d.label, d.style]]));
const j = (v) => JSON.stringify(v, null, 2);

const catalogTs = `// GENERATED by scripts/apply-customize.mjs from customize/ — do not edit by hand.
// Edit customize/cars.csv, customize/my-cars.csv and customize/lists.json,
// then run \`bun run customize\` (the build does this for you).
// { n: name, k: key, t: tag codes, x?: details }. Tag codes decode via TAG_LEGEND.
export interface CatalogCar { n: string; k: string; t: string; x?: string }

export const CATALOG: CatalogCar[] = [
${cars.map((c) => "  " + JSON.stringify(c) + ",").join("\n")}
];

// Complete game rosters; game progress is measured against these totals.
export const GAME_ROSTER_TOTALS: Record<string, number> = ${j(lists.gameRosterTotals ?? {})};

// Per-game DLC filter codes (game tag + its DLC marker).
export const GAME_DLC_FILTERS: Record<string, string> = ${j(lists.gameDlcFilters ?? {})};

export const TAG_LEGEND: Record<string, [string, string]> = ${j(legend)};

export const FILTERS: [string, string][] = ${j(filters)};

export const QUOTES: string[] = ${j(lists.quotes ?? [])};

export const PLEDGE_LINES: string[] = ${j(lists.pledgeLines ?? [])};

export const TAG_CLASS: Record<string, string> = { p1: 'tag-u1', p2: 'tag-u2', pD: 'tag-dlc', pF: 'tag-fc', pR: 'tag-rush', pY: 'tag-year', pC: 'tag-custom' };
`;
writeIfChanged(at("server", "src", "catalog.ts"), catalogTs);
writeIfChanged(
  at("client", "src", "catalog.ts"),
  '// The client uses the same generated catalog as the server.\nexport * from "../../server/src/catalog";\n',
);

console.log(`customize: ${cars.length} cars, ${filters.length} filters, app "${appName}" (${appId})`);
