# Customize your Hunt Book

Everything you can change lives in this folder. Edit a file, then rebuild
the app (the GitHub "Build Android APK" run does it for you). You never
touch the code.

| File | What it changes |
|---|---|
| `app.json` | App name under the icon, app ID, icon background color, and the app's main colors (background, accent, navy, yellow). Leave a color out to keep it. |
| `icon.png` | The launcher icon. Use a square PNG, ideally 1024×1024. |
| `my-cars.csv` | **Your own extra cars.** Easiest place to add cars, especially on a phone. |
| `cars.csv` | The full built-in car list (about 5,000 cars). Best edited on a computer or in a spreadsheet app. |
| `lists.json` | Tags (the little pills), filter buttons, game totals, the quotes, and the hunt pledge. |

## Adding a car

Add one line to `my-cars.csv` (the first line is the header, leave it):

```
name,tags,details,key
Twin Mill,U2 2026 FC,Found at Walmart,
```

- **name**: what the car is called.
- **tags**: words separated by spaces, from the list in `lists.json`
  (for example `U1`, `U2`, `DLC`, `FC`, `RUSH`, `2024`, `STH`, `Showcase`,
  `Mainline`, and the hidden `U1-DLC`, `U2-DLC`, `RUSH-DLC`).
- **details**: optional note shown on the car. Wrap it in quotes if it
  contains a comma.
- **key**: leave blank. It is made from the name, and it is what your
  owned/photo/plan data is saved under, so don't change it on existing cars.

## Adding a tag or a filter button

In `lists.json`, add an entry to `tags` with a one-character code, a
`label` (the word you type in the tags column) and a `style`
(p1 p2 pD pF pR pY pC pick the pill color). Add a `filters` line
`["code", "Button label"]` to get a filter button for it. Keep the first
six filters (all, miss, own, fav, th, unv).

## If a build fails with "customize: ..."

The message says which file and line is wrong (an unknown tag, a missing
comma in a JSON file, two cars with the same key). Fix that line and run
the build again.

## Rebuild on a computer

```
bun run customize      # applies this folder to the code
bun run build:android  # or: bun run build
```
