// Client bundle for the on-device (Android / Capacitor) build.
//
//   bun run build:android   ->  client/dist-android/
//
// Same production bundle as build.mjs, but the entry is
// client/android/index.html (-> src/main-android.tsx), which runs the
// actions inside the WebView instead of calling a server. The SQLite
// engine (sql.js: sql-wasm.js + sql-wasm.wasm) is copied next to the
// bundle and loaded at runtime.

import { cpSync, existsSync, mkdirSync, rmSync } from "node:fs";
import { basename, join } from "node:path";
import tailwindPlugin from "bun-plugin-tailwind";

await import("../scripts/gen-migrations.mjs");

// Apply customize/ (names, colors, cars, lists) before bundling.
await import("../scripts/apply-customize.mjs");

const ENTRY = "./client/android/index.html";
const OUTDIR = "./client/dist-android";

rmSync(OUTDIR, { recursive: true, force: true });

const result = await Bun.build({
  entrypoints: [ENTRY],
  outdir: OUTDIR,
  minify: true,
  define: {
    "process.env.NODE_ENV": JSON.stringify("production"),
  },
  naming: {
    asset: "assets/[name]-[hash].[ext]",
    chunk: "assets/[name]-[hash].[ext]",
    entry: "[name].[ext]",
  },
  plugins: [tailwindPlugin],
});

if (!result.success) {
  for (const log of result.logs) console.error(log);
  throw new Error("android client build failed; see logged diagnostics");
}

// Same asset-URL re-prefix as build.mjs (Bun emits bare ./name-hash.ext).
const assetFiles = result.outputs
  .filter((output) => output.kind === "asset")
  .map((output) => basename(output.path));

for (const output of result.outputs) {
  if (!/\.(js|css|html)$/.test(output.path)) continue;
  let text = await output.text();
  let changed = false;
  for (const name of assetFiles) {
    const bare = `./${name}`;
    if (text.includes(bare)) {
      text = text.split(bare).join(`./assets/${name}`);
      changed = true;
    }
  }
  if (changed) await Bun.write(output.path, text);
}

// SQLite engine for the WebView.
const sqlDist = "./node_modules/sql.js/dist";
mkdirSync(OUTDIR, { recursive: true });
for (const file of ["sql-wasm.js", "sql-wasm.wasm"]) {
  const from = join(sqlDist, file);
  if (!existsSync(from)) throw new Error(`missing ${from} — run bun install`);
  cpSync(from, join(OUTDIR, file));
}

if (!existsSync(join(OUTDIR, "index.html"))) {
  throw new Error("android build produced no index.html");
}
console.log(`android client build ok: ${result.outputs.length} outputs in ${OUTDIR}`);
