// Client bundle for the standalone open-source build.
//
// Plain Bun.build of `client/index.html` to `client/dist/` — the same
// production-mode React bundle the Muse pipeline produced (minify,
// NODE_ENV=production, Tailwind plugin, `assets/[name]-[hash].[ext]`
// asset naming), without any Muse build driver.
//
// Bun writes imported assets to `assets/<name>-<hash>.<ext>` but emits
// the JS/CSS import URL as a bare `./<name>-<hash>.<ext>` — without the
// `assets/` directory prefix. Re-prefix only the bare imported-asset
// URLs to `./assets/...` (idempotent; chunk refs already carry `assets/`).

import { basename } from "node:path";
import tailwindPlugin from "bun-plugin-tailwind";

// Apply customize/ (names, colors, cars, lists) before bundling.
await import("../scripts/apply-customize.mjs");

const ENTRY = "./client/index.html";
const OUTDIR = "./client/dist";

const result = await Bun.build({
  entrypoints: [ENTRY],
  outdir: OUTDIR,
  minify: true,
  define: {
    "process.env.NODE_ENV": JSON.stringify("production"),
  },
  naming: {
    asset: "assets/[name]-[hash].[ext]",
    chunk: "assets/[name]-[hash].[ext]",
    entry: "[name].[ext]",
  },
  plugins: [tailwindPlugin],
});

if (!result.success) {
  for (const log of result.logs) {
    console.error(log);
  }
  throw new Error("client build failed; see logged diagnostics");
}

const assetFiles = result.outputs
  .filter((output) => output.kind === "asset")
  .map((output) => basename(output.path));

for (const output of result.outputs) {
  if (!/\.(js|css|html)$/.test(output.path)) continue;
  let text = await output.text();
  let changed = false;
  for (const name of assetFiles) {
    const bare = `./${name}`;
    if (text.includes(bare)) {
      text = text.split(bare).join(`./assets/${name}`);
      changed = true;
    }
  }
  if (changed) {
    await Bun.write(output.path, text);
  }
}

console.log(`client build ok: ${result.outputs.length} outputs in ${OUTDIR}`);
