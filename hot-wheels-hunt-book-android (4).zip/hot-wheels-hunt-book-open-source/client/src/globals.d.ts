declare module "*.css";
declare module "*.png";
declare module "*.jpg";
declare module "*.jpeg";
declare module "*.mp3";
declare module "*.htm" {
  const url: string;
  export default url;
}
