// The client uses the same generated catalog as the server.
export * from "../../server/src/catalog";
