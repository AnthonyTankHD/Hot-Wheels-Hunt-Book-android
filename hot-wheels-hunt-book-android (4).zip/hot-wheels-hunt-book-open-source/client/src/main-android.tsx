// Entry point for the Android (Capacitor) build. `./local/install`
// must come first: it switches the action client to the on-device
// runtime. Everything else is the normal app.
import "./local/install";
import "./main";
