// Typed RPC client. Types come straight from `server/src/actions.ts` — no
// codegen. `createActionClient` returns a proxy that POSTs `{action, args}`
// to `./actions` and returns the typed response.
//
// `import type { Actions }` is type-only by design: the client bundle never
// pulls in any server runtime (bun:sqlite, file APIs, etc.).

import type { Actions } from "../../server/src/actions";
import { createActionClient } from "./sdk-client";

export const api = createActionClient<typeof Actions>();

export type { ApiRequest, ApiResponse } from "./sdk-client";
