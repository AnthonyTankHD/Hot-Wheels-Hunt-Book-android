// Settings panel: scan allhotwheels.com and add the castings that are not
// in the checklist yet. Android app only (see ./ahw-import.ts).

import { useEffect, useRef, useState } from "react";
import { api } from "./api";
import {
  SOURCE_SITE,
  REQUEST_DELAY_MS,
  clearScan,
  loadScan,
  newScan,
  runScan,
  saveScan,
  scanAvailable,
  toImportCar,
  type ScanHandle,
  type ScanState,
} from "./ahw-import";

type Props = {
  onToast: (message: string) => void;
  onRefresh: () => void;
};

export function AhwImportPanel(props: Props) {
  const [scan, setScan] = useState<ScanState | null>(() => loadScan());
  const [running, setRunning] = useState(false);
  const [note, setNote] = useState("");
  const [error, setError] = useState("");
  const [adding, setAdding] = useState(false);
  const [addNote, setAddNote] = useState("");
  const [overwriteHand, setOverwriteHand] = useState(false);
  const handle = useRef<ScanHandle>({ stopped: false });

  // Stop politely if the panel goes away mid-scan.
  useEffect(() => {
    const h = handle.current;
    return () => {
      h.stopped = true;
    };
  }, []);

  if (!scanAvailable()) {
    return (
      <div className="build-update">
        <p className="text-sm font-bold text-[var(--text)]">Import castings from allhotwheels.com</p>
        <p className="mt-1 text-sm text-[var(--dim)]">This works in the Android app only.</p>
      </div>
    );
  }

  const found = scan ? Object.keys(scan.castings).length : 0;
  const yearsLeft = scan ? scan.years.length : 0;

  async function start(fresh: boolean) {
    setError("");
    setAddNote("");
    const state = fresh || !scan ? newScan() : scan;
    if (fresh) clearScan();
    saveScan(state);
    handle.current = { stopped: false };
    setScan({ ...state });
    setRunning(true);
    try {
      const final = await runScan(state, handle.current, (s, n) => {
        setScan({ ...s });
        setNote(n);
      });
      setScan({ ...final });
      setNote(final.done ? "Scan finished." : "Paused.");
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
      setScan({ ...state });
    } finally {
      setRunning(false);
    }
  }

  function pause() {
    handle.current.stopped = true;
    setNote("Pausing after this page…");
  }

  async function addToChecklist() {
    if (!scan) return;
    setAdding(true);
    setError("");
    try {
      const cars = Object.values(scan.castings).map(toImportCar);
      let added = 0;
      let updated = 0;
      let skipped = 0;
      for (let i = 0; i < cars.length; i += 500) {
        setAddNote(`Adding… ${Math.min(i + 500, cars.length)} of ${cars.length}`);
        const res = await api.importCastings({ cars: cars.slice(i, i + 500), overwriteHandAdded: overwriteHand });
        added += res.added;
        updated += res.updated;
        skipped += res.skipped;
      }
      setAddNote(
        `Added ${added} new, refreshed ${updated} existing, left ${skipped} alone (${overwriteHand ? "already in your built-in checklist" : "already in your built-in checklist or added by hand"}). No duplicates.`,
      );
      props.onToast(`Added ${added}, refreshed ${updated}`);
      props.onRefresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      setAdding(false);
    }
  }

  return (
    <div className="build-update">
      <p className="text-sm font-bold text-[var(--text)]">Import castings from allhotwheels.com</p>
      <p className="mt-1 text-sm text-[var(--dim)]">
        Reads the public Browse pages at {SOURCE_SITE}, one page about every {(REQUEST_DELAY_MS / 1000).toFixed(1)} seconds,
        and lists each casting once. Text only — no photos or prices. A full scan is roughly 1,500 pages (about 40 minutes), so
        keep the app open; you can pause and pick up later. Running it again refreshes the castings an earlier scan added instead of duplicating them; built-in checklist cars are never duplicated or changed, and ones you added by hand are only overwritten if you tick the box below.
      </p>
      <div className="mt-2 flex flex-wrap gap-2">
        {!running && (
          <button type="button" className="hw-btn px-4 py-3 text-sm font-bold" disabled={adding} onClick={() => void start(false)}>
            {scan && !scan.done && scan.requests > 0 ? "▶ Resume scan" : "🔎 Start scan"}
          </button>
        )}
        {running && (
          <button type="button" className="hw-btn hw-btn-alt px-4 py-3 text-sm font-bold" onClick={pause}>
            ⏸ Pause
          </button>
        )}
        {scan && scan.requests > 0 && !running && (
          <button type="button" className="hw-btn hw-btn-alt px-4 py-3 text-sm font-bold" disabled={adding} onClick={() => void start(true)}>
            Start over
          </button>
        )}
      </div>
      {scan && scan.requests > 0 && (
        <p className="mt-2 text-sm text-[var(--dim)]" role="status">
          {found} castings found · {scan.requests} pages read · {yearsLeft} year{yearsLeft === 1 ? "" : "s"} left
          {note ? ` · ${note}` : ""}
        </p>
      )}
      {scan && found > 0 && !running && (
        <div className="mt-2">
          <label className="mb-2 flex items-start gap-2 text-sm text-[var(--dim)]">
            <input type="checkbox" className="mt-1" checked={overwriteHand} disabled={adding} onChange={(e) => setOverwriteHand(e.target.checked)} />
            <span>Also overwrite cars I added by hand that have the same name (replaces their details and tags; owned marks and photos stay).</span>
          </label>
          <button type="button" className="hw-btn px-4 py-3 text-sm font-bold" disabled={adding} onClick={() => void addToChecklist()}>
            {adding ? "Adding…" : `➕ Add ${found} castings to my checklist`}
          </button>
          {!scan.done && (
            <p className="mt-1 text-sm text-[var(--dim)]">The scan isn&apos;t finished yet — you can add what it found so far and resume later.</p>
          )}
        </div>
      )}
      {addNote && <p className="mt-2 text-sm font-semibold text-[var(--green)]" role="status">{addNote}</p>}
      {error && <p className="mt-2 text-sm font-semibold text-[var(--accent)]" role="alert">{error}</p>}
    </div>
  );
}
