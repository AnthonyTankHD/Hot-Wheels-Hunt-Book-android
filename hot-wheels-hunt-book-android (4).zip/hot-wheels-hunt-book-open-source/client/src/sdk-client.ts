// Local replacement for the browser-side `@hatch/space-sdk/client` surface.
//
// The original source imported `createActionClient`, `spaceQueryClient`,
// `SafeAreaTopScrim`, `fileToBase64` and `bytesToBase64` from
// `@hatch/space-sdk/client`, a package that only exists inside Muse.
// This module provides the same small surface with plain fetch +
// TanStack Query, so the app builds and runs anywhere.
//
// The action client speaks the same wire protocol the server in
// `server/src/server.ts` serves: POST `./actions` with
// `{ action, args, actionCallId }`, and `{ data }` / `{ error }` back.

import { createElement, type CSSProperties, type ReactNode } from "react";
import { QueryClient } from "@tanstack/react-query";
import type { z } from "zod";

export class SpaceActionError extends Error {
  status: number;
  retryAfterMs?: number;
  retrySafe: boolean;
  code?: string;
  constructor(message: string, status: number, retryAfterMs?: number, retrySafe = false, code?: string) {
    super(message);
    this.name = "SpaceActionError";
    this.status = status;
    this.retryAfterMs = retryAfterMs;
    this.retrySafe = retrySafe;
    this.code = code;
  }
}

const PERMANENT_ACTION_STATUSES = new Set([400, 401, 403, 404, 409, 413, 415, 422]);
const MAX_ACTION_RETRIES = 3;

function shouldRetryAction(failureCount: number, error: unknown): boolean {
  if (error instanceof SpaceActionError && PERMANENT_ACTION_STATUSES.has(error.status)) {
    return false;
  }
  return error instanceof SpaceActionError && error.retrySafe && failureCount < MAX_ACTION_RETRIES;
}

function actionRetryDelay(failureCount: number, error: unknown): number {
  const ceiling = Math.min(30_000, 1_000 * 2 ** failureCount);
  const floor =
    error instanceof SpaceActionError && error.retryAfterMs != null
      ? Math.min(30_000, Math.max(0, error.retryAfterMs))
      : 0;
  return floor + Math.random() * ceiling;
}

/** Shared TanStack Query client for the standalone app. */
export const spaceQueryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: shouldRetryAction,
      retryDelay: actionRetryDelay,
      staleTime: 30_000,
      refetchOnWindowFocus: false,
    },
  },
});

/** One action definition, as produced by `defineAction` on the server. */
export type ActionDefinitionLike = {
  request: z.ZodTypeAny;
  response: z.ZodTypeAny;
  handler: (ctx: any, args: any) => Promise<any>;
};

export type ActionClient<T extends Record<string, ActionDefinitionLike>> = {
  [K in keyof T]: (
    args: z.infer<T[K]["request"]>,
  ) => Promise<z.infer<T[K]["response"]>>;
};

export type ApiRequest<T, K extends keyof T> =
  T[K] extends (args: infer A) => Promise<unknown> ? A : never;

export type ApiResponse<T, K extends keyof T> =
  T[K] extends (args: never) => Promise<infer R> ? R : never;

function createActionCallId(): string {
  if (typeof globalThis.crypto?.randomUUID === "function") {
    return globalThis.crypto.randomUUID();
  }
  return `hunt-book-action-${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`;
}

/**
 * Typed RPC client. Returns a proxy: `api.getState({})` POSTs
 * `{ action: "getState", args: {} }` to `./actions` and returns `data`.
 */
export function createActionClient<T extends Record<string, ActionDefinitionLike>>(
  options: { endpoint?: string } = {},
): ActionClient<T> {
  const endpoint = options.endpoint ?? "./actions";
  return new Proxy({} as ActionClient<T>, {
    get(_target, name) {
      if (typeof name !== "string") return undefined;
      if (name === "then" || name === "catch" || name === "finally") return undefined;
      return async (args: unknown) => {
        // Android build: actions run inside the app (see ./local/runtime)
        // instead of POSTing to a server.
        const local = (globalThis as {
          __HH_LOCAL__?: (action: string, args: unknown) => Promise<unknown>;
        }).__HH_LOCAL__;
        if (local) {
          try {
            return await local(name, args ?? {});
          } catch (err) {
            throw new SpaceActionError(err instanceof Error ? err.message : String(err), 500);
          }
        }
        const actionCallId = createActionCallId();
        const response = await fetch(endpoint, {
          method: "POST",
          headers: {
            "content-type": "application/json",
            "x-request-id": actionCallId,
          },
          body: JSON.stringify({ action: name, args: args ?? {}, actionCallId }),
        });
        const body = (await response.json().catch(() => null)) as
          | { data?: unknown; error?: string | { message?: string } }
          | null;
        if (!response.ok || (body && typeof body === "object" && "error" in body && body.error)) {
          const message =
            typeof body?.error === "string"
              ? body.error
              : (body?.error as { message?: string } | undefined)?.message ??
                `action ${name} failed: ${response.status}`;
          throw new SpaceActionError(message, response.status);
        }
        return body?.data;
      };
    },
  });
}

// --- File / base64 helpers (same behaviour as the SDK's) -----------------

export function bytesToBase64(bytes: Uint8Array): string {
  const native = bytes as Uint8Array & { toBase64?: () => string };
  if (typeof native.toBase64 === "function") {
    return native.toBase64();
  }
  const chunkSize = 0x8000;
  let binary = "";
  for (let i = 0; i < bytes.length; i += chunkSize) {
    const chunk = bytes.subarray(i, i + chunkSize);
    binary += String.fromCharCode.apply(null, chunk as unknown as number[]);
  }
  return btoa(binary);
}

export async function fileToBase64(
  file: File | Blob,
): Promise<{ dataBase64: string; mimeType: string }> {
  const bytes = new Uint8Array(await file.arrayBuffer());
  return {
    dataBase64: bytesToBase64(bytes),
    mimeType: file.type || "application/octet-stream",
  };
}

// --- Safe-area top scrim --------------------------------------------------
// Fixed top safe-area protection for phones without a top-extending
// header. Covers the device status-bar inset with a fading gradient.

const TOP_SAFE_AREA_SCRIM_HEIGHT =
  "calc(var(--twsa-safe-area-inset-top) + min(2rem, var(--twsa-safe-area-inset-top)))";
const TOP_SAFE_AREA_INSET_HEIGHT = "var(--twsa-safe-area-inset-top)";
const TOP_SAFE_AREA_GRADIENT_MASK =
  "linear-gradient(to bottom, rgba(0, 0, 0, 1) 0%, rgba(0, 0, 0, 0.99) 10%, rgba(0, 0, 0, 0.96) 20%, rgba(0, 0, 0, 0.90) 30%, rgba(0, 0, 0, 0.80) 40%, rgba(0, 0, 0, 0.67) 50%, rgba(0, 0, 0, 0.52) 60%, rgba(0, 0, 0, 0.36) 70%, rgba(0, 0, 0, 0.20) 80%, rgba(0, 0, 0, 0.08) 90%, rgba(0, 0, 0, 0) 100%)";

export function SafeAreaTopScrim({
  variant = "gradient",
  backgroundColor,
  zIndex = 40,
  className,
  style,
  ...props
}: {
  variant?: "gradient" | "inset" | "blur";
  backgroundColor?: string;
  zIndex?: number;
  className?: string;
  style?: CSSProperties;
  children?: ReactNode;
  [key: string]: unknown;
}) {
  const resolvedBackgroundColor = backgroundColor ?? style?.backgroundColor ?? "var(--bg)";
  const managedStyle: CSSProperties = {
    ...style,
    position: "fixed",
    top: 0,
    left: 0,
    right: 0,
    zIndex,
    pointerEvents: "none",
    height: variant === "gradient" ? TOP_SAFE_AREA_SCRIM_HEIGHT : TOP_SAFE_AREA_INSET_HEIGHT,
    backgroundColor: resolvedBackgroundColor,
  };
  if (variant === "gradient") {
    managedStyle.maskImage = TOP_SAFE_AREA_GRADIENT_MASK;
    managedStyle.WebkitMaskImage = TOP_SAFE_AREA_GRADIENT_MASK;
  } else if (variant === "blur") {
    managedStyle.backdropFilter = (style?.backdropFilter as string | undefined) ?? "blur(12px)";
    managedStyle.WebkitBackdropFilter =
      (style?.WebkitBackdropFilter as string | undefined) ?? "blur(12px)";
  }
  return createElement("div", {
    ...props,
    "aria-hidden": (props as { "aria-hidden"?: boolean })["aria-hidden"] ?? true,
    className,
    style: managedStyle,
  });
}
