// On-device storage for the Android build: IndexedDB.
//
//   store "meta"  -> the SQLite database file (key "sqlite-db")
//   store "blobs" -> photos, videos, songs and covers, one record per key
//
// The Bun server keeps these on disk (data/hunt-book.db, data/blobs/);
// inside the Android WebView IndexedDB plays the same role.

import type { BlobHead, Blobs } from "../../../server/src/sdk";

const DB_NAME = "hunt-book-local-v1";

export type StoreName = "meta" | "blobs";

let dbPromise: Promise<IDBDatabase> | null = null;

function openDb(): Promise<IDBDatabase> {
  if (!dbPromise) {
    dbPromise = new Promise<IDBDatabase>((resolve, reject) => {
      const req = indexedDB.open(DB_NAME, 1);
      req.onupgradeneeded = () => {
        const d = req.result;
        if (!d.objectStoreNames.contains("meta")) d.createObjectStore("meta");
        if (!d.objectStoreNames.contains("blobs")) d.createObjectStore("blobs");
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error ?? new Error("could not open on-device storage"));
    });
  }
  return dbPromise;
}

export async function idbGet(store: StoreName, key: string): Promise<unknown> {
  const db = await openDb();
  return new Promise<unknown>((resolve, reject) => {
    const req = db.transaction(store, "readonly").objectStore(store).get(key);
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error ?? new Error("storage read failed"));
  });
}

export async function idbPut(store: StoreName, key: string, value: unknown): Promise<void> {
  const db = await openDb();
  return new Promise<void>((resolve, reject) => {
    const tx = db.transaction(store, "readwrite");
    tx.objectStore(store).put(value, key);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error ?? new Error("storage write failed"));
    tx.onabort = () => reject(tx.error ?? new Error("storage write aborted"));
  });
}

export async function idbDelete(store: StoreName, key: string): Promise<void> {
  const db = await openDb();
  return new Promise<void>((resolve, reject) => {
    const tx = db.transaction(store, "readwrite");
    tx.objectStore(store).delete(key);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error ?? new Error("storage delete failed"));
    tx.onabort = () => reject(tx.error ?? new Error("storage delete aborted"));
  });
}

type BlobRecord = { blob: Blob; contentType: string; sizeBytes: number };

function isBlobRecord(value: unknown): value is BlobRecord {
  return (
    typeof value === "object" &&
    value !== null &&
    (value as { blob?: unknown }).blob instanceof Blob
  );
}

// Object URLs are cached per key so a photo shown many times is only
// turned into a URL once. A key that is overwritten or deleted has its
// URL revoked.
const urlCache = new Map<string, string>();

function dropUrl(key: string): void {
  const url = urlCache.get(key);
  if (url) {
    URL.revokeObjectURL(url);
    urlCache.delete(key);
  }
}

export const blobs: Blobs = {
  async put(key, bytes, opts) {
    const contentType = opts?.contentType ?? "application/octet-stream";
    const record: BlobRecord = {
      blob: new Blob([bytes], { type: contentType }),
      contentType,
      sizeBytes: bytes.byteLength,
    };
    await idbPut("blobs", key, record);
    dropUrl(key);
  },
  async getUrl(key) {
    // Throws when the blob is gone, like the server version: callers
    // treat a missing blob as "no photo" instead of failing.
    const cached = urlCache.get(key);
    if (cached) return cached;
    const record = await idbGet("blobs", key);
    if (!isBlobRecord(record)) throw new Error(`blob not found: ${key}`);
    const url = URL.createObjectURL(record.blob);
    urlCache.set(key, url);
    return url;
  },
  async head(key): Promise<BlobHead | null> {
    const record = await idbGet("blobs", key);
    if (!isBlobRecord(record)) return null;
    return { sizeBytes: record.sizeBytes, contentType: record.contentType };
  },
  async delete(key) {
    dropUrl(key);
    await idbDelete("blobs", key);
  },
};
