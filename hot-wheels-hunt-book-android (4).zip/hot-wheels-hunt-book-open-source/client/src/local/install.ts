// Side-effect module for the Android build: wires the app to the
// on-device runtime before anything renders.
//
//  - `__HH_LOCAL__` makes the action client call the in-WebView actions
//    instead of POSTing to a server (see createActionClient).
//  - `Buffer` is a tiny base64 shim: actions.ts only ever calls
//    `Buffer.from(base64, "base64")`.
//  - downloads go through the Android share sheet.
//  - persistent storage is requested so Android doesn't evict the book.

import { installDownloadHandler } from "./downloads";
import { dispatch, warmUp } from "./runtime";

function base64ToBytes(b64: string): Uint8Array {
  const bin = atob(b64.replace(/\s+/g, ""));
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}

const g = globalThis as Record<string, unknown>;

if (typeof g["Buffer"] === "undefined") {
  g["Buffer"] = {
    from(value: string, encoding?: string): Uint8Array {
      if (encoding !== "base64") throw new Error("Buffer shim only supports base64");
      return base64ToBytes(value);
    },
  };
}

g["__HH_LOCAL__"] = dispatch;

installDownloadHandler();

void warmUp().catch((err) => {
  console.error("on-device database failed to start:", err);
});

try {
  void navigator.storage?.persist?.();
} catch {
  // Best effort only.
}
