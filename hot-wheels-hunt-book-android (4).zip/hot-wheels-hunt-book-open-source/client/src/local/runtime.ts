// On-device replacement for the Bun server (Android build).
//
// The same `Actions` from server/src/actions.ts run here, inside the
// WebView, against:
//   - SQLite compiled to WebAssembly (sql.js) through Drizzle, with the
//     database file saved to IndexedDB after every change, and
//   - IndexedDB blob storage (./blobstore.ts) for photos/videos/music.
//
// `dispatch(name, args)` is what `POST /actions` does on the server:
// validate args, run the handler, validate the response.

import { drizzle, type SQLJsDatabase } from "drizzle-orm/sql-js";
import type { Database as SqlJsDatabase, SqlJsStatic } from "sql.js";
import { Actions } from "../../../server/src/actions";
import * as schema from "../../../server/src/schema";
import type { Ctx } from "../../../server/src/sdk";
import { blobs, idbGet, idbPut } from "./blobstore";
import { MIGRATIONS } from "./migrations";

const DB_KEY = "sqlite-db";

// Actions that never write; everything else saves the database after it
// runs so a change survives the app being closed right away.
const READ_ONLY_ACTIONS = new Set(["getState", "exportBackup", "getChatHistory"]);

type InitSqlJs = (config?: { locateFile?: (file: string) => string }) => Promise<SqlJsStatic>;

type LoadedDb = {
  sqlite: SqlJsDatabase;
  db: SQLJsDatabase<typeof schema>;
};

function loadScript(src: string): Promise<void> {
  return new Promise<void>((resolve, reject) => {
    const el = document.createElement("script");
    el.src = src;
    el.onload = () => resolve();
    el.onerror = () => reject(new Error(`could not load ${src}`));
    document.head.appendChild(el);
  });
}

function applyMigrations(sqlite: SqlJsDatabase): void {
  const res = sqlite.exec("PRAGMA user_version");
  const current = Number(res[0]?.values[0]?.[0] ?? 0);
  for (let i = current; i < MIGRATIONS.length; i++) {
    const sql = MIGRATIONS[i];
    if (sql === undefined) continue;
    sqlite.exec(sql);
    sqlite.exec(`PRAGMA user_version = ${i + 1}`);
  }
}

async function load(): Promise<LoadedDb> {
  let init = (globalThis as { initSqlJs?: InitSqlJs }).initSqlJs;
  if (!init) {
    await loadScript("./sql-wasm.js");
    init = (globalThis as { initSqlJs?: InitSqlJs }).initSqlJs;
  }
  if (!init) throw new Error("the SQLite engine (sql-wasm.js) did not load");
  const SQL = await init({ locateFile: (file) => `./${file}` });
  const saved = await idbGet("meta", DB_KEY);
  const sqlite = saved instanceof Uint8Array ? new SQL.Database(saved) : new SQL.Database();
  applyMigrations(sqlite);
  const db = drizzle(sqlite, { schema });
  // First launch (or a fresh install): save the empty, migrated book.
  if (!(saved instanceof Uint8Array)) await idbPut("meta", DB_KEY, sqlite.export());
  return { sqlite, db };
}

let loading: Promise<LoadedDb> | null = null;

/** Starts loading the database; safe to call more than once. */
export function warmUp(): Promise<LoadedDb> {
  if (!loading) loading = load();
  return loading;
}

let persistChain: Promise<void> = Promise.resolve();

function persist(sqlite: SqlJsDatabase): Promise<void> {
  persistChain = persistChain
    .then(() => idbPut("meta", DB_KEY, sqlite.export()))
    .catch((err) => {
      console.error("could not save the Hunt Book database:", err);
    });
  return persistChain;
}

// The two actions that read files from the developer's own computer
// (the supplied backup and songs) have nothing to read on a phone, so
// they answer "not found" — the same honest answer the server gives.
const PRIVILEGED_STUBS: Record<string, () => Promise<unknown>> = {
  readSuppliedBackup: async () => ({ found: false, json: "", sha256: "" }),
  readSuppliedSong: async () => ({
    found: false,
    name: "",
    audioBase64: "",
    audioSize: 0,
    coverBase64: null,
    coverMimeType: null,
    coverSize: 0,
    error: "Supplied songs are not available in the Android app.",
  }),
};

function makeCtx(db: LoadedDb["db"]): Ctx {
  return {
    viewer: undefined,
    db: () => db as never,
    blobs,
    inference: {
      async complete() {
        throw new Error(
          "AI chat is not available in the on-device build — the chat falls back to a grounded summary reply.",
        );
      },
    },
    async executePrivileged(contract, args) {
      const stub = PRIVILEGED_STUBS[contract.name];
      if (!stub) throw new Error(`no privileged handler for ${contract.name}`);
      contract.request.parse(args);
      return contract.response.parse(await stub()) as never;
    },
    invalidateQueries() {
      // No-op: the client refetches after each mutation.
    },
  };
}

type AnyAction = {
  request: { parse: (v: unknown) => unknown };
  response: { parse: (v: unknown) => unknown };
  handler: (ctx: Ctx, args: never) => Promise<unknown>;
};

const ACTION_TABLE = Actions as unknown as Record<string, AnyAction | undefined>;

export async function dispatch(name: string, args: unknown): Promise<unknown> {
  const action = ACTION_TABLE[name];
  if (!action) throw new Error(`unknown action: ${name}`);
  const { sqlite, db } = await warmUp();
  const parsedArgs = action.request.parse(args ?? {});
  try {
    const result = await action.handler(makeCtx(db), parsedArgs as never);
    let data: unknown = result;
    try {
      data = action.response.parse(result);
    } catch {
      // Same rule as the server: response-shape drift must not break a
      // successful write, so return the handler's result as-is.
      console.warn(`action ${name}: response did not match its schema, returning raw result`);
    }
    // Mirror the server's JSON wire format (drops undefined fields etc.)
    return data === undefined ? data : JSON.parse(JSON.stringify(data));
  } finally {
    if (!READ_ONLY_ACTIONS.has(name)) await persist(sqlite);
  }
}
