// Saving files from inside the Android WebView.
//
// The app saves backups, spreadsheets and zips by clicking an
// `<a download>` pointing at an object URL. Android's WebView ignores
// that, so on the native app we catch the click, write the bytes to the
// app's cache folder and open the Android share sheet ("Save to Files",
// Drive, Messages, ...). In a normal browser nothing here runs.

import { Capacitor } from "@capacitor/core";
import { Directory, Filesystem } from "@capacitor/filesystem";
import { Share } from "@capacitor/share";
import { bytesToBase64 } from "../sdk-client";

function safeName(name: string): string {
  const cleaned = name.replace(/[\\/:*?"<>|]+/g, "_").trim();
  return cleaned || "hunt-book-file";
}

async function saveViaShareSheet(href: string, filename: string): Promise<void> {
  const blob = await (await fetch(href)).blob();
  const data = bytesToBase64(new Uint8Array(await blob.arrayBuffer()));
  const name = safeName(filename);
  const written = await Filesystem.writeFile({ path: name, data, directory: Directory.Cache });
  await Share.share({ title: name, url: written.uri, dialogTitle: "Save or share" });
}

export function installDownloadHandler(): void {
  if (!Capacitor.isNativePlatform()) return;
  document.addEventListener(
    "click",
    (event) => {
      const target = event.target;
      if (!(target instanceof Element)) return;
      const anchor = target.closest("a[download]");
      if (!(anchor instanceof HTMLAnchorElement)) return;
      const href = anchor.href;
      if (!href.startsWith("blob:") && !href.startsWith("data:")) return;
      event.preventDefault();
      event.stopPropagation();
      saveViaShareSheet(href, anchor.getAttribute("download") || "hunt-book-file").catch((err) => {
        console.error("could not save file:", err);
        window.alert("Could not save that file: " + (err instanceof Error ? err.message : String(err)));
      });
    },
    true,
  );
}
