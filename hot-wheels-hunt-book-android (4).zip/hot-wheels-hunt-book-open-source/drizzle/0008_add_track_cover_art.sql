ALTER TABLE tracks ADD COLUMN cover_blob_key TEXT;
--> statement-breakpoint
ALTER TABLE tracks ADD COLUMN cover_content_type TEXT;
