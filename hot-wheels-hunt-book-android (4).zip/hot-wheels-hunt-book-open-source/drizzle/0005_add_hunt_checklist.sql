CREATE TABLE hunt_checklist (
  month TEXT NOT NULL,
  day INTEGER NOT NULL,
  idx INTEGER NOT NULL,
  checked INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (month, day, idx)
);
