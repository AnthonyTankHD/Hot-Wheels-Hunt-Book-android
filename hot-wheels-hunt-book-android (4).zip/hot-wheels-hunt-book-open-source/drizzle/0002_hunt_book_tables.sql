DROP TABLE IF EXISTS entries;
--> statement-breakpoint
CREATE TABLE car_state (
  car_key TEXT PRIMARY KEY,
  owned INTEGER NOT NULL DEFAULT 0,
  is_th INTEGER NOT NULL DEFAULT 0,
  is_sth INTEGER NOT NULL DEFAULT 0,
  count INTEGER NOT NULL DEFAULT 0,
  note TEXT NOT NULL DEFAULT '',
  owned_at INTEGER,
  th_at INTEGER,
  updated_at INTEGER NOT NULL
);
--> statement-breakpoint
CREATE TABLE custom_cars (
  car_key TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  details TEXT NOT NULL DEFAULT '',
  tags TEXT NOT NULL DEFAULT '',
  created_at INTEGER NOT NULL
);
--> statement-breakpoint
CREATE TABLE photos (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  car_key TEXT,
  blob_key TEXT NOT NULL,
  content_type TEXT NOT NULL,
  created_at INTEGER NOT NULL
);
--> statement-breakpoint
CREATE TABLE videos (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  car_key TEXT,
  blob_key TEXT NOT NULL,
  name TEXT NOT NULL DEFAULT '',
  content_type TEXT NOT NULL,
  created_at INTEGER NOT NULL
);
--> statement-breakpoint
CREATE TABLE links (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  url TEXT NOT NULL,
  label TEXT NOT NULL,
  car_key TEXT,
  created_at INTEGER NOT NULL
);
--> statement-breakpoint
CREATE TABLE targets (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  month TEXT NOT NULL,
  text TEXT NOT NULL,
  car_key TEXT,
  done INTEGER NOT NULL DEFAULT 0,
  created_at INTEGER NOT NULL
);
--> statement-breakpoint
CREATE TABLE plan_days (
  month TEXT NOT NULL,
  day INTEGER NOT NULL,
  is_hunt INTEGER NOT NULL DEFAULT 0,
  note TEXT NOT NULL DEFAULT '',
  PRIMARY KEY (month, day)
);
--> statement-breakpoint
CREATE TABLE month_plans (
  month TEXT PRIMARY KEY,
  budget TEXT NOT NULL DEFAULT '',
  spent TEXT NOT NULL DEFAULT ''
);
--> statement-breakpoint
CREATE TABLE profile (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL DEFAULT '',
  bio TEXT NOT NULL DEFAULT '',
  favorite TEXT NOT NULL DEFAULT '',
  photo_blob_key TEXT,
  photo_content_type TEXT
);
--> statement-breakpoint
CREATE TABLE pledge (
  idx INTEGER PRIMARY KEY,
  checked INTEGER NOT NULL DEFAULT 0
);
--> statement-breakpoint
CREATE TABLE visits (
  date TEXT PRIMARY KEY
);
--> statement-breakpoint
CREATE TABLE meta (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL DEFAULT ''
);
