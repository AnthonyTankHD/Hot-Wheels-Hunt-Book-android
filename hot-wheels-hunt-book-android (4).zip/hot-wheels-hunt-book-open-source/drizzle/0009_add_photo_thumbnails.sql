ALTER TABLE photos ADD COLUMN thumb_blob_key TEXT;
--> statement-breakpoint
ALTER TABLE photos ADD COLUMN thumb_content_type TEXT;
