ALTER TABLE `car_state` ADD COLUMN `is_favorite` integer DEFAULT 0 NOT NULL;
