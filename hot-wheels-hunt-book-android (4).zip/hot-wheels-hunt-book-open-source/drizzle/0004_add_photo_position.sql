ALTER TABLE photos ADD COLUMN position INTEGER NOT NULL DEFAULT 0;
--> statement-breakpoint
UPDATE photos SET position = id;
