ALTER TABLE chat_messages ADD COLUMN bot TEXT NOT NULL DEFAULT 'manager';
