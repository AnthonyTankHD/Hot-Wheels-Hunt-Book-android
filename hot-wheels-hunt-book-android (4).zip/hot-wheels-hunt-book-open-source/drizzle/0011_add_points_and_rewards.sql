CREATE TABLE `points_log` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`kind` text NOT NULL,
	`label` text DEFAULT '' NOT NULL,
	`points` integer NOT NULL,
	`car_key` text,
	`created_at` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `shop_purchases` (
	`item_key` text PRIMARY KEY NOT NULL,
	`created_at` integer NOT NULL
);
