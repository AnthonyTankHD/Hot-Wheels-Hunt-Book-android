// Small shared pieces for the Music screens.
import { useEffect, useRef, useState } from "react";
import type { ReactNode } from "react";
import { nativeArt, type LibTrack } from "./native";
import type { DzTrack, TrackMeta } from "./store";
import type { QItem } from "./player";

export function fmtTime(sec: number): string {
  if (!Number.isFinite(sec) || sec < 0) return "0:00";
  const s = Math.floor(sec);
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;
}

export function localToQ(t: LibTrack, meta?: TrackMeta): QItem {
  return {
    key: `l${t.id}`,
    title: t.title,
    artist: t.artist && t.artist !== "<unknown>" ? t.artist : "Unknown artist",
    album: t.album,
    localId: t.id,
    localUri: t.uri,
    albumId: t.albumId,
    cover: meta?.dz?.cover,
    dzId: meta?.dz?.id,
    link: meta?.dz ? `https://www.deezer.com/track/${meta.dz.id}` : undefined,
    durationSec: t.durationMs / 1000,
  };
}
export function dzToQ(d: DzTrack): QItem {
  return {
    key: `d${d.id}`,
    title: d.title,
    artist: d.artist,
    album: d.album,
    dzId: d.id,
    cover: d.cover,
    link: d.link,
    durationSec: d.durationSec,
    previewUrl: d.preview,
    previewAt: d.preview ? Date.now() : undefined,
  };
}

export interface Row {
  key: string;
  title: string;
  sub: string;
  cover?: string;
  uri?: string;
  albumId?: string;
  id?: string;
  durationSec?: number;
  badge?: string;
  q: QItem;
  onMenu?: () => void;
}

/** Cover picture that loads only when it scrolls into view. */
export function ArtImg(props: { cover?: string; uri?: string; albumId?: string; id?: string; className?: string }) {
  const ref = useRef<HTMLDivElement | null>(null);
  const [src, setSrc] = useState<string | null>(null);
  const [seen, setSeen] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el || seen) return;
    if (typeof IntersectionObserver === "undefined") {
      setSeen(true);
      return;
    }
    const io = new IntersectionObserver((entries) => {
      if (entries.some((e) => e.isIntersecting)) {
        setSeen(true);
        io.disconnect();
      }
    });
    io.observe(el);
    return () => io.disconnect();
  }, [seen]);
  useEffect(() => {
    if (!seen) return;
    let alive = true;
    if (props.uri && props.id) {
      void nativeArt({ uri: props.uri, albumId: props.albumId ?? "0", id: props.id }).then((p) => {
        if (alive) setSrc(p ?? props.cover ?? null);
      });
    } else {
      setSrc(props.cover ?? null);
    }
    return () => {
      alive = false;
    };
  }, [seen, props.uri, props.id, props.albumId, props.cover]);
  return (
    <div ref={ref} className={`mh-art ${props.className ?? ""}`}>
      {src ? <img src={src} alt="" loading="lazy" onError={() => setSrc(null)} /> : <span aria-hidden="true">🎵</span>}
    </div>
  );
}

export function SongRow(props: { row: Row; active: boolean; onPlay: () => void }) {
  const { row } = props;
  return (
    <li className={`mh-row${props.active ? " mh-row-on" : ""}`}>
      <button type="button" className="mh-row-main" onClick={props.onPlay}>
        <ArtImg cover={row.cover} uri={row.uri} albumId={row.albumId} id={row.id} />
        <span className="mh-row-text">
          <span className="mh-row-title">{row.title}</span>
          <span className="mh-row-sub">
            {row.badge ? <b className="mh-badge">{row.badge}</b> : null}
            {row.sub}
          </span>
        </span>
        <span className="mh-row-time">{row.durationSec ? fmtTime(row.durationSec) : ""}</span>
      </button>
      {row.onMenu && (
        <button type="button" className="mh-row-more" aria-label={`More for ${row.title}`} onClick={row.onMenu}>
          ⋮
        </button>
      )}
    </li>
  );
}

export const ROW_H = 62; // fixed row height (px), see .mh-row in music.css

/**
 * Long song lists: only the rows near the screen exist in the page (a
 * 10,000-song library would otherwise put thousands of rows and pictures
 * into it). Works with the page's own scrolling.
 */
export function RowList(props: { rows: Row[]; currentKey: string; onPlayAt: (index: number) => void; empty?: ReactNode }) {
  const ref = useRef<HTMLUListElement | null>(null);
  const n = props.rows.length;
  const [range, setRange] = useState<[number, number]>([0, Math.min(n, 30)]);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    let raf = 0;
    const calc = () => {
      raf = 0;
      const top = el.getBoundingClientRect().top;
      const vh = window.innerHeight || 800;
      const s = Math.max(0, Math.floor(-top / ROW_H) - 10);
      const e = Math.min(n, Math.max(s + 1, Math.ceil((vh - top) / ROW_H) + 10));
      setRange((r) => (r[0] === s && r[1] === e ? r : [s, e]));
    };
    const on = () => {
      if (!raf) raf = requestAnimationFrame(calc);
    };
    calc();
    document.addEventListener("scroll", on, { capture: true, passive: true });
    window.addEventListener("resize", on);
    return () => {
      document.removeEventListener("scroll", on, { capture: true } as EventListenerOptions);
      window.removeEventListener("resize", on);
      if (raf) cancelAnimationFrame(raf);
    };
  }, [n, props.rows]);
  if (n === 0) return <>{props.empty ?? <p className="mut mt-3">Nothing here yet.</p>}</>;
  const [from, to] = [Math.min(range[0], n), Math.min(range[1], n)];
  return (
    <ul ref={ref} className="mh-list" style={{ paddingTop: from * ROW_H, paddingBottom: (n - to) * ROW_H }}>
      {props.rows.slice(from, to).map((r, i) => (
        <SongRow key={r.key} row={r} active={r.q.key === props.currentKey} onPlay={() => props.onPlayAt(from + i)} />
      ))}
    </ul>
  );
}
