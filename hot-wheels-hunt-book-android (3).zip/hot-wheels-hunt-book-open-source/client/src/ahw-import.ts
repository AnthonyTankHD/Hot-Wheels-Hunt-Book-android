// Scan allhotwheels.com for castings (Android app only).
//
// The scan reads the site's public "Browse" pages (24 cars per page, one
// year at a time), collapses the ~37,000 releases down to one entry per
// casting name, and hands the new ones to the `importCastings` action.
// Only text is read: no photos, prices, accounts or marketplace pages.
//
// Being a good guest: one request at a time, a pause between requests,
// a plain User-Agent, and a back-off (or stop) if the site says "slow
// down" (429/503) or refuses (403).
//
// Requests go through Capacitor's native HTTP client because a web page
// inside the app is not allowed to read another site's pages (CORS).

import { Capacitor, CapacitorHttp } from "@capacitor/core";

/** The site the scan reads from. */
export const SOURCE_SITE = "https://allhotwheels.com";
/** Pause between page requests (milliseconds), plus up to 40% random extra. */
export const REQUEST_DELAY_MS = 1500;
/** First and last release year the site lists (1968 is its oldest). */
export const FIRST_YEAR = 1968;

const USER_AGENT = "HuntBookApp/1.0 (personal collection checklist; polite one-at-a-time reader)";
const PAGE_SIZE = 24;
const STORAGE_KEY = "hunt-book-ahw-scan-v1";

export function scanAvailable(): boolean {
  return Capacitor.isNativePlatform();
}

// --- pure helpers (no network, no DOM) -------------------------------------

export type Release = {
  name: string;
  year: number;
  segment: string;
  sku: string;
  sth: boolean;
  th: boolean;
};

export type Casting = {
  name: string;
  firstYear: number;
  lastYear: number;
  releases: number;
  years: number[];
  mainline: boolean;
  sth: boolean;
};

export function squash(name: string): string {
  return name.toLowerCase().replace(/[^a-z0-9]/g, "");
}

/** Year tags in the checklist: a = 2015 ... m = 2027. */
function yearTag(year: number): string {
  return year >= 2015 && year <= 2027 ? String.fromCharCode("a".charCodeAt(0) + (year - 2015)) : "";
}

export function addRelease(map: Record<string, Casting>, r: Release): void {
  const key = squash(r.name);
  if (!key) return;
  const c = map[key];
  if (!c) {
    map[key] = {
      name: r.name,
      firstYear: r.year,
      lastYear: r.year,
      releases: 1,
      years: [r.year],
      mainline: r.segment === "mainline",
      sth: r.sth,
    };
    return;
  }
  c.releases += 1;
  c.firstYear = Math.min(c.firstYear, r.year);
  c.lastYear = Math.max(c.lastYear, r.year);
  if (!c.years.includes(r.year)) c.years.push(r.year);
  c.mainline = c.mainline || r.segment === "mainline";
  c.sth = c.sth || r.sth;
}

export function toImportCar(c: Casting): { name: string; tags: string; details: string } {
  const tags = new Set<string>();
  for (const y of c.years) {
    const t = yearTag(y);
    if (t) tags.add(t);
  }
  if (c.mainline) tags.add("M");
  if (c.sth) tags.add("S");
  const span = c.firstYear === c.lastYear ? `${c.firstYear}` : `${c.firstYear}–${c.lastYear}`;
  return {
    name: c.name,
    tags: [...tags].join(""),
    details: `Imported from allhotwheels.com · ${c.releases} release${c.releases === 1 ? "" : "s"} (${span})`,
  };
}

function titleFromSlug(slug: string): string {
  return slug
    .split("-")
    .filter(Boolean)
    .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
    .join(" ");
}

// --- page parsing (needs a DOM, which the app's WebView has) ---------------

export type BrowsePage = {
  releases: Release[];
  total: number | null;
  /** Builds the URL of page N from the site's own pagination links. */
  pageUrl: ((page: number) => string) | null;
};

const CAR_PATH = /\/car\/(\d{4})\/([^/?#]+)\/([^/?#]+)\/([^/?#]+)/;

export function parseBrowsePage(html: string, pageUrlBase: string): BrowsePage {
  const doc = new DOMParser().parseFromString(html, "text/html");
  const releases: Release[] = [];
  const seen = new Set<string>();

  for (const a of Array.from(doc.querySelectorAll<HTMLAnchorElement>('a[href*="/car/"]'))) {
    const m = CAR_PATH.exec(a.getAttribute("href") ?? "");
    if (!m) continue;
    const [, yearText, segment, sku, slug] = m;
    if (!yearText || !segment || !sku || !slug) continue;
    const id = `${yearText}/${segment}/${sku}/${slug}`;
    if (seen.has(id)) continue;
    seen.add(id);

    // The card is the closest ancestor that holds a heading with the name.
    let card: Element | null = a;
    let heading: Element | null = null;
    for (let i = 0; i < 6 && card; i++) {
      heading = card.querySelector("h2, h3, h4");
      if (heading) break;
      card = card.parentElement;
    }
    const name = (heading?.textContent ?? "").trim() || titleFromSlug(decodeURIComponent(slug));
    const alts = card ? Array.from(card.querySelectorAll("img")).map((img) => (img.getAttribute("alt") ?? "").toLowerCase()) : [];
    releases.push({
      name,
      year: Number(yearText),
      segment,
      sku,
      sth: alts.includes("super treasure hunt"),
      th: alts.includes("treasure hunt"),
    });
  }

  const bodyText = doc.body?.textContent ?? "";
  const totalMatch = /Showing\s+\d+\s*[–-]\s*\d+\s+of\s+([\d,]+)/.exec(bodyText);
  const total = totalMatch?.[1] ? Number(totalMatch[1].replace(/,/g, "")) : null;

  // Learn the page-number parameter from the site's own "2" link.
  let pageUrl: ((page: number) => string) | null = null;
  for (const a of Array.from(doc.querySelectorAll<HTMLAnchorElement>("a[href]"))) {
    if ((a.textContent ?? "").trim() !== "2") continue;
    try {
      const u = new URL(a.getAttribute("href") ?? "", pageUrlBase);
      const param = [...u.searchParams.entries()].find(([, v]) => v === "2")?.[0];
      if (!param) continue;
      pageUrl = (page: number) => {
        const next = new URL(u.toString());
        next.searchParams.set(param, String(page));
        return next.toString();
      };
      break;
    } catch {
      // Not a usable link; keep looking.
    }
  }
  return { releases, total, pageUrl };
}

// --- network ----------------------------------------------------------------

class ScanStop extends Error {}

const sleep = (ms: number) => new Promise<void>((r) => setTimeout(r, ms));

async function fetchPage(url: string, signal: { stopped: boolean }): Promise<string> {
  for (let attempt = 0; attempt < 4; attempt++) {
    if (signal.stopped) throw new ScanStop("stopped");
    const res = await CapacitorHttp.get({
      url,
      headers: { "User-Agent": USER_AGENT, Accept: "text/html" },
      connectTimeout: 15000,
      readTimeout: 30000,
      responseType: "text",
    });
    if (res.status === 200 && typeof res.data === "string") return res.data;
    if (res.status === 403) throw new Error("The site refused the request (403). The scan has stopped.");
    if (res.status === 429 || res.status === 503 || res.status >= 500) {
      const retryAfter = Number(res.headers?.["Retry-After"] ?? res.headers?.["retry-after"] ?? 0);
      await sleep(Math.max(retryAfter * 1000, 30000 * (attempt + 1)));
      continue;
    }
    throw new Error(`The site answered ${res.status} for ${url}`);
  }
  throw new Error("The site kept asking to slow down. Try again later.");
}

// --- the scan -----------------------------------------------------------------

export type ScanState = {
  /** Years still to scan, newest first. */
  years: number[];
  /** Year being scanned and the next page to read in it. */
  page: number;
  castings: Record<string, Casting>;
  requests: number;
  releasesSeen: number;
  done: boolean;
};

export function newScan(): ScanState {
  const latest = new Date().getFullYear() + 1;
  const years: number[] = [];
  for (let y = latest; y >= FIRST_YEAR; y--) years.push(y);
  return { years, page: 1, castings: {}, requests: 0, releasesSeen: 0, done: false };
}

export function loadScan(): ScanState | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? (JSON.parse(raw) as ScanState) : null;
  } catch {
    return null;
  }
}

export function saveScan(state: ScanState): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch {
    // Storage full: the scan still works, it just can't be resumed.
  }
}

export function clearScan(): void {
  try {
    localStorage.removeItem(STORAGE_KEY);
  } catch {
    // Nothing to clear.
  }
}

export type ScanHandle = { stopped: boolean };

/**
 * Runs (or resumes) a scan until it finishes, fails or `handle.stopped`
 * is set. `onProgress` is called after every page. Resolves with the
 * final state; throws on a real error (state is saved before throwing).
 */
export async function runScan(
  state: ScanState,
  handle: ScanHandle,
  onProgress: (s: ScanState, note: string) => void,
): Promise<ScanState> {
  let pageUrl: ((page: number) => string) | null = null;
  let totalPages = 1;
  let sinceSave = 0;
  try {
    while (state.years.length > 0 && !handle.stopped) {
      const year = state.years[0] as number;
      const base = `${SOURCE_SITE}/browse?years=${year}`;
      if (state.page > 1 && !pageUrl) {
        // Resuming in the middle of a year: read page 1 only to learn the
        // page links (its cars were already counted before the pause).
        const first = parseBrowsePage(await fetchPage(base, handle), base);
        state.requests += 1;
        totalPages = first.total ? Math.max(1, Math.ceil(first.total / PAGE_SIZE)) : 1;
        pageUrl = first.pageUrl;
        if (!pageUrl) {
          throw new Error(`Could not find the "next page" links for ${year}, so the scan stopped. The site may have changed.`);
        }
        await sleep(REQUEST_DELAY_MS);
      }
      const url = state.page === 1 || !pageUrl ? base : pageUrl(state.page);
      const html = await fetchPage(url, handle);
      state.requests += 1;
      const parsed = parseBrowsePage(html, base);
      if (state.page === 1) {
        totalPages = parsed.total ? Math.max(1, Math.ceil(parsed.total / PAGE_SIZE)) : 1;
        pageUrl = parsed.pageUrl;
        if (totalPages > 1 && !pageUrl) {
          throw new Error(`Could not find the "next page" links for ${year}, so the scan stopped. The site may have changed.`);
        }
      }
      for (const r of parsed.releases) addRelease(state.castings, r);
      state.releasesSeen += parsed.releases.length;

      if (state.page >= totalPages || parsed.releases.length === 0) {
        state.years.shift();
        state.page = 1;
        pageUrl = null;
      } else {
        state.page += 1;
      }
      sinceSave += 1;
      if (sinceSave >= 5) {
        saveScan(state);
        sinceSave = 0;
      }
      onProgress(state, `Year ${year}, page ${Math.min(state.page, totalPages)} of ${totalPages}`);
      await sleep(REQUEST_DELAY_MS * (1 + Math.random() * 0.4));
    }
    if (state.years.length === 0) state.done = true;
    return state;
  } catch (err) {
    if (!(err instanceof ScanStop)) throw err;
    return state;
  } finally {
    saveScan(state);
  }
}
