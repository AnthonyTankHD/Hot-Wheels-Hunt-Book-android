// A small on-device log of what the music player and the app's lifecycle are
// doing, shown in the full player under "Log". It exists to find out why a
// song stops by itself: every pause is recorded with who asked for it.
import { useSyncExternalStore } from "react";

const lines: string[] = [];
let version = 0;
const listeners = new Set<() => void>();

function stamp(): string {
  const t = new Date();
  const p = (n: number, w = 2) => String(n).padStart(w, "0");
  return `${p(t.getMinutes())}:${p(t.getSeconds())}.${p(t.getMilliseconds(), 3)}`;
}

export function hwLog(msg: string): void {
  lines.push(`${stamp()} ${msg}`);
  if (lines.length > 400) lines.shift();
  version += 1;
  listeners.forEach((l) => l());
}
export function clearHwLog(): void {
  lines.length = 0;
  version += 1;
  listeners.forEach((l) => l());
}
export function useHwLog(): string {
  useSyncExternalStore(
    (cb) => {
      listeners.add(cb);
      return () => listeners.delete(cb);
    },
    () => version,
  );
  return lines.join("\n");
}

let installed = false;
/** Records every time the page is hidden, shown, frozen, or loses focus. */
export function installLifecycleLog(): void {
  if (installed || typeof document === "undefined") return;
  installed = true;
  const state = () => `hidden=${document.hidden} focus=${document.hasFocus()}`;
  document.addEventListener("visibilitychange", () => hwLog(`visibilitychange -> ${document.visibilityState} (${state()})`));
  window.addEventListener("pagehide", () => hwLog("pagehide"));
  window.addEventListener("pageshow", () => hwLog("pageshow"));
  document.addEventListener("freeze", () => hwLog("freeze"));
  document.addEventListener("resume", () => hwLog("resume"));
  window.addEventListener("blur", () => hwLog("window blur"));
  window.addEventListener("focus", () => hwLog("window focus"));
  hwLog(`log started (${state()})`);
}
