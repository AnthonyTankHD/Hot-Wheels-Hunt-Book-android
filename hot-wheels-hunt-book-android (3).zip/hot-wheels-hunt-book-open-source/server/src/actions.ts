import { defineAction, InferenceSchemaError, z, type ActionsModule, type Ctx, type SpaceDb } from "./sdk";
import { hostContracts } from "./contracts";
import { and, asc, desc, eq, or } from "drizzle-orm";
import * as schema from "./schema";
import { CATALOG, GAME_ROSTER_TOTALS, PLEDGE_LINES, QUOTES } from "./catalog";

type Db = SpaceDb<typeof schema>;

// Guest-access classification (platform v27, applied 2026-11-10): the
// Hunt Book is Anthony's private collection — every action reads or
// writes his own records, there are no collaborative operations, and
// every action is owner-only in intent. The guard denies any
// identified viewer who is not the owner (a peer viewer or a non-owner
// share recipient). A missing viewer is NOT denied: verified live on
// 2026-11-10, the owner's own agent channel (artifact action calls —
// the car watcher, chat-driven collection management, and this app's
// post-edit verification) invokes actions with no ctx.viewer at all,
// so treating an absent viewer as a guest would lock the owner and
// his agent out of the book entirely. Those invocations only exist on
// the owner's local daemon; a shared page always carries a viewer for
// anyone signed in, and the VM-capability actions below additionally
// refuse to run their inference / privileged calls on a shared page
// for any viewer. The denial is an error the client surfaces as an
// owner-required screen (state load) or a failed action with the
// entered values kept — never as saved state.
function requireOwner(ctx: Ctx): void {
  if (ctx.viewer !== undefined && ctx.viewer.isOwner !== true) {
    throw new Error(
      "owner_required: this Hunt Book is private to its owner — sign in as the owner to use it.",
    );
  }
}

// Model inference and privileged host reads are VM capabilities the
// shared runtime cannot run for any viewer, the signed-in owner
// included. Actions that need them check this on a shared page
// (a Cloudflare viewer) and report the capability as unavailable
// instead of attempting the call; local calls are unaffected.
function vmCapabilityUnavailable(ctx: Ctx): boolean {
  return ctx.viewer?.source === "cloudflare";
}

const chicagoFmt = new Intl.DateTimeFormat("en-CA", {
  timeZone: "America/Chicago",
  year: "numeric",
  month: "2-digit",
  day: "2-digit",
});

function todayKey(now = new Date()): string {
  return chicagoFmt.format(now);
}

function monthKey(now = new Date()): string {
  return todayKey(now).slice(0, 7);
}

function dayOfYear(now = new Date()): number {
  const [y = 1970, m = 1, d = 1] = todayKey(now).split("-").map(Number);
  const start = Date.UTC(y, 0, 1);
  const day = Date.UTC(y, (m ?? 1) - 1, d ?? 1);
  return Math.floor((day - start) / 86_400_000) + 1;
}

function sortKey(name: string): string {
  return name.replace(/^[^A-Za-z0-9]+/, "").toLowerCase();
}

function compareCars(a: { n: string }, b: { n: string }): number {
  const x = sortKey(a.n);
  const y = sortKey(b.n);
  const dx = /^\d/.test(x);
  const dy = /^\d/.test(y);
  if (dx !== dy) return dx ? -1 : 1;
  return x < y ? -1 : x > y ? 1 : 0;
}

function streaks(dates: string[], today: string): { current: number; best: number } {
  const set = new Set(dates);
  const parse = (s: string) => {
    const [y = 1970, m = 1, d = 1] = s.split("-").map(Number);
    return Date.UTC(y, (m ?? 1) - 1, d ?? 1);
  };
  const step = (s: string, delta: number) => {
    const t = parse(s) + delta * 86_400_000;
    return new Date(t).toISOString().slice(0, 10);
  };
  let cursor = set.has(today) ? today : step(today, -1);
  let current = 0;
  while (set.has(cursor)) {
    current += 1;
    cursor = step(cursor, -1);
  }
  const sorted = [...set].sort();
  let best = 0;
  let run = 0;
  let prev: string | null = null;
  for (const d of sorted) {
    run = prev !== null && step(prev, 1) === d ? run + 1 : 1;
    best = Math.max(best, run);
    prev = d;
  }
  return { current, best };
}

const BADGES = [
  { id: "own1", icon: "🥇", name: "First Find", desc: "Own your first car", goal: 1, kind: "owned" },
  { id: "own10", icon: "🔟", name: "Getting Started", desc: "Own 10 cars", goal: 10, kind: "owned" },
  { id: "own25", icon: "🏁", name: "Pit Crew", desc: "Own 25 cars", goal: 25, kind: "owned" },
  { id: "own50", icon: "⚡", name: "Fast Lane", desc: "Own 50 cars", goal: 50, kind: "owned" },
  { id: "own100", icon: "💯", name: "Century Club", desc: "Own 100 cars", goal: 100, kind: "owned" },
  { id: "own250", icon: "🏆", name: "Speed Demon", desc: "Own 250 cars", goal: 250, kind: "owned" },
  { id: "own500", icon: "👑", name: "Garage Legend", desc: "Own 500 cars", goal: 500, kind: "owned" },
  { id: "own1000", icon: "🚀", name: "Hall of Fame", desc: "Own 1,000 cars", goal: 1000, kind: "owned" },
  { id: "th1", icon: "⭐", name: "Treasure Hunter", desc: "Find a Treasure Hunt", goal: 1, kind: "th" },
  { id: "th5", icon: "🌟", name: "Chase Master", desc: "Find 5 Treasure Hunts", goal: 5, kind: "th" },
  { id: "sth1", icon: "🔥", name: "Super Hunter", desc: "Mark a Super Treasure Hunt", goal: 1, kind: "sth" },
  { id: "ph10", icon: "📷", name: "Photographer", desc: "Add 10 photos", goal: 10, kind: "photos" },
  { id: "ph50", icon: "🖼️", name: "Gallery Pro", desc: "Add 50 photos", goal: 50, kind: "photos" },
  { id: "fan25", icon: "🦄", name: "Fantasy Fan", desc: "Own 25 Fantasy castings", goal: 25, kind: "fantasy" },
  { id: "stk3", icon: "🔥", name: "3-Day Streak", desc: "Open the app 3 days in a row", goal: 3, kind: "streak" },
  { id: "stk7", icon: "📅", name: "Week Warrior", desc: "7-day streak", goal: 7, kind: "streak" },
  { id: "stk30", icon: "🗓️", name: "Monthly Racer", desc: "30-day streak", goal: 30, kind: "streak" },
] as const;

/* ---------------- Points, levels, and the Rewards Shop ----------------
   Earning rules (agreed with Anthony): a new distinct car owned is
   10, each extra copy of an owned car is 2, a Treasure Hunt adds 50,
   a Super Treasure Hunt adds 100, a photo adds 5, finding a hunt
   target (marking a target car owned) adds 25, and a daily visit
   adds 5. Two counters are kept from the one points log: lifetime
   points (sum of earns; sets the level and never goes down) and the
   spendable balance (earns minus shop spends). */

const POINT_VALUES = {
  newCar: 10,
  extraCopy: 2,
  th: 50,
  sth: 100,
  photo: 5,
  target: 25,
  daily: 5,
} as const;

// The level ladder. Reaching a level's lifetime total unlocks its
// profile title and its badge automatically, and some levels also
// unlock a profile-photo frame. Unlocks are derived from lifetime
// points, never stored, so spending can never take one away.
const LEVELS = [
  { level: 1, name: "Rookie", icon: "🌱", at: 0 },
  { level: 2, name: "Collector", icon: "🧲", at: 250 },
  { level: 3, name: "Hunter", icon: "🎯", at: 750 },
  { level: 4, name: "Speed Demon", icon: "⚡", at: 1500 },
  { level: 5, name: "Garage Legend", icon: "🏆", at: 3000 },
  { level: 6, name: "Hall of Fame", icon: "👑", at: 5500 },
  { level: 7, name: "Hot Wheels Legend", icon: "🔥", at: 10000 },
] as const;

type LevelDef = (typeof LEVELS)[number];

function levelFor(lifetime: number): { current: LevelDef; next: LevelDef | null } {
  let current: LevelDef = LEVELS[0] as LevelDef;
  let next: LevelDef | null = null;
  for (const l of LEVELS) {
    if (lifetime >= l.at) current = l;
    else {
      next = l;
      break;
    }
  }
  return { current, next };
}

// Frames unlocked by reaching a level (keyed by level number). The
// frameClass names live in theme.css and style the profile photo.
const LEVEL_FRAMES: Record<number, { id: string; name: string; frameClass: string }> = {
  3: { id: "frame-flame", name: "Flame Frame", frameClass: "frame-flame" },
  4: { id: "frame-blue", name: "Blue Streak Frame", frameClass: "frame-blue" },
  5: { id: "frame-gold", name: "Gold Frame", frameClass: "frame-gold" },
  7: { id: "frame-legend", name: "Legend Flame Frame", frameClass: "frame-legend" },
};

// The Rewards Shop catalog: in-app unlocks bought with spendable
// points only (no real money). Titles and frames can be equipped on
// the profile once owned; badges are collectible unlocks.
const SHOP_ITEMS = [
  { id: "title-peg-hunter", kind: "title", name: "Peg Hunter", icon: "🎯", cost: 150, frameClass: null },
  { id: "title-case-breaker", kind: "title", name: "Case Breaker", icon: "📦", cost: 300, frameClass: null },
  { id: "title-wheel-whisperer", kind: "title", name: "Wheel Whisperer", icon: "🛞", cost: 500, frameClass: null },
  { id: "title-diecast-royalty", kind: "title", name: "Die-cast Royalty", icon: "👑", cost: 800, frameClass: null },
  { id: "frame-electric-blue", kind: "frame", name: "Electric Blue Frame", icon: "💙", cost: 600, frameClass: "frame-electric" },
  { id: "frame-inferno", kind: "frame", name: "Inferno Flame Frame", icon: "🔥", cost: 900, frameClass: "frame-inferno" },
  { id: "frame-24k-gold", kind: "frame", name: "24K Gold Frame", icon: "🌟", cost: 1200, frameClass: "frame-24k" },
  { id: "badge-super-collector", kind: "badge", name: "Super Collector Badge", icon: "🌟", cost: 250, frameClass: null },
  { id: "badge-rocket", kind: "badge", name: "Rocket Collector Badge", icon: "🚀", cost: 450, frameClass: null },
  { id: "badge-unicorn", kind: "badge", name: "Unicorn Spotter Badge", icon: "🦄", cost: 700, frameClass: null },
  { id: "badge-diamond", kind: "badge", name: "Diamond Hunter Badge", icon: "💎", cost: 1000, frameClass: null },
] as const;

type ShopItem = (typeof SHOP_ITEMS)[number];

const pointsAwardSchema = z.object({
  awarded: z.number(),
  balance: z.number(),
  lifetime: z.number(),
  level: z.number(),
  levelName: z.string(),
  leveledUp: z.boolean(),
});

type PointsAward = z.infer<typeof pointsAwardSchema>;

const okPointsResponse = z.object({ ok: z.literal(true), points: pointsAwardSchema });

async function pointsTotals(db: Db): Promise<{ lifetime: number; balance: number }> {
  const rows = await db.select({ points: schema.pointsLog.points }).from(schema.pointsLog);
  let lifetime = 0;
  let balance = 0;
  for (const r of rows) {
    balance += r.points;
    if (r.points > 0) lifetime += r.points;
  }
  return { lifetime, balance };
}

// One-time retroactive starting points, computed from the collection
// exactly as it stands when the points system first runs: distinct
// owned cars, extra copies, Treasure Hunts, the Super Treasure Hunt,
// and photos, at the agreed rates. The guard is the log itself: the
// seed is written only while the log is still empty and the
// collection is not, so it can never double-count points that were
// earned live, and a backup restored into an empty book still gets
// its retroactive points on the next load.
async function ensurePointsSeeded(db: Db): Promise<void> {
  const existing = await db
    .select({ id: schema.pointsLog.id })
    .from(schema.pointsLog)
    .limit(1);
  if (existing.length > 0) return;
  const stateRows = await db.select().from(schema.carState);
  const photoRows = await db.select({ id: schema.photos.id }).from(schema.photos);
  const ownedRows = stateRows.filter((r) => r.owned === 1);
  const distinct = ownedRows.length;
  const copies = ownedRows.reduce((sum, r) => sum + Math.max(1, r.count), 0);
  const extras = Math.max(0, copies - distinct);
  const th = stateRows.filter((r) => r.isTh === 1).length;
  const sth = stateRows.filter((r) => r.isSth === 1).length;
  const photos = photoRows.length;
  const total =
    distinct * POINT_VALUES.newCar +
    extras * POINT_VALUES.extraCopy +
    th * POINT_VALUES.th +
    sth * POINT_VALUES.sth +
    photos * POINT_VALUES.photo;
  if (total <= 0) return;
  await db.insert(schema.pointsLog).values({
    kind: "seed",
    label:
      `Starting points from your collection so far: ${distinct} cars owned, ` +
      `${extras} extra ${extras === 1 ? "copy" : "copies"}, ${th} Treasure Hunts, ` +
      `${sth} Super Treasure Hunt${sth === 1 ? "" : "s"}, ${photos} photos`,
    points: total,
    carKey: null,
  });
}

type PointsEntry = { kind: string; label: string; points: number; carKey?: string | null };

// Writes earn/spend rows and reports the new counters, including
// whether the lifetime total crossed into a new level.
async function awardPoints(db: Db, entries: PointsEntry[]): Promise<PointsAward> {
  const before = await pointsTotals(db);
  const levelBefore = levelFor(before.lifetime).current.level;
  const fresh = entries.filter((e) => e.points !== 0);
  if (fresh.length > 0) {
    await db.insert(schema.pointsLog).values(
      fresh.map((e) => ({ kind: e.kind, label: e.label, points: e.points, carKey: e.carKey ?? null })),
    );
  }
  const after = await pointsTotals(db);
  const lvl = levelFor(after.lifetime).current;
  return {
    awarded: fresh.reduce((sum, e) => sum + e.points, 0),
    balance: after.balance,
    lifetime: after.lifetime,
    level: lvl.level,
    levelName: lvl.name,
    leveledUp: lvl.level > levelBefore,
  };
}

async function carDisplayName(db: Db, carKey: string): Promise<string> {
  const cat = CATALOG.find((c) => c.k === carKey);
  if (cat) return cat.n;
  const rows = await db
    .select({ name: schema.customCars.name })
    .from(schema.customCars)
    .where(eq(schema.customCars.carKey, carKey))
    .limit(1);
  return rows[0]?.name ?? carKey;
}

// Points for a car becoming owned / Treasure Hunt / Super Treasure
// Hunt, shared by setCarState and the chat's mark path so both award
// identically. Only transitions earn: un-marking and re-marking a car
// that was already counted earns nothing twice for the same state.
// Marking a hunt target owned for the first time also finds the
// target (+25) and checks its planner rows off as done.
async function carMarkEntries(
  db: Db,
  carKey: string,
  prev: { owned: boolean; isTh: boolean; isSth: boolean; copies: number } | null,
  next: { owned: boolean; isTh: boolean; isSth: boolean; copies: number },
): Promise<PointsEntry[]> {
  const name = await carDisplayName(db, carKey);
  const entries: PointsEntry[] = [];
  const wasOwned = prev?.owned ?? false;
  if (!wasOwned && next.owned) {
    entries.push({ kind: "car", label: `New car owned: ${name}`, points: POINT_VALUES.newCar, carKey });
    if (next.copies > 1) {
      entries.push({
        kind: "copy",
        label: `Extra ${next.copies - 1 === 1 ? "copy" : "copies"} of ${name}`,
        points: (next.copies - 1) * POINT_VALUES.extraCopy,
        carKey,
      });
    }
    const targetRows = await db
      .select()
      .from(schema.targets)
      .where(or(eq(schema.targets.carKey, carKey), eq(schema.targets.text, name)));
    if (targetRows.length > 0) {
      entries.push({ kind: "target", label: `Hunt target found: ${name}`, points: POINT_VALUES.target, carKey });
      for (const t of targetRows) {
        if (t.done !== 1) {
          await db.update(schema.targets).set({ done: 1 }).where(eq(schema.targets.id, t.id));
        }
      }
    }
  } else if (wasOwned && next.owned && next.copies > (prev?.copies ?? 0)) {
    const added = next.copies - (prev?.copies ?? 0);
    entries.push({
      kind: "copy",
      label: `Extra ${added === 1 ? "copy" : "copies"} of ${name}`,
      points: added * POINT_VALUES.extraCopy,
      carKey,
    });
  }
  if (!(prev?.isTh ?? false) && next.isTh) {
    entries.push({ kind: "th", label: `Treasure Hunt: ${name}`, points: POINT_VALUES.th, carKey });
  }
  if (!(prev?.isSth ?? false) && next.isSth) {
    entries.push({ kind: "sth", label: `Super Treasure Hunt: ${name}`, points: POINT_VALUES.sth, carKey });
  }
  return entries;
}

const pointsStateSchema = z.object({
  lifetime: z.number(),
  balance: z.number(),
  level: z.number(),
  levelName: z.string(),
  levelIcon: z.string(),
  nextLevel: z.object({ level: z.number(), name: z.string(), at: z.number() }).nullable(),
  levels: z.array(
    z.object({
      level: z.number(),
      name: z.string(),
      icon: z.string(),
      at: z.number(),
      unlocked: z.boolean(),
      unlocks: z.array(z.string()),
    }),
  ),
  titles: z.array(
    z.object({
      id: z.string(),
      name: z.string(),
      source: z.enum(["level", "shop"]),
      owned: z.boolean(),
      equipped: z.boolean(),
    }),
  ),
  frames: z.array(
    z.object({
      id: z.string(),
      name: z.string(),
      frameClass: z.string(),
      source: z.enum(["level", "shop"]),
      owned: z.boolean(),
      equipped: z.boolean(),
    }),
  ),
  shop: z.array(
    z.object({
      id: z.string(),
      kind: z.enum(["title", "frame", "badge"]),
      name: z.string(),
      icon: z.string(),
      cost: z.number(),
      frameClass: z.string().nullable(),
      owned: z.boolean(),
      equipped: z.boolean(),
    }),
  ),
  equippedTitle: z.string(),
  equippedFrameClass: z.string().nullable(),
  activity: z.array(
    z.object({ id: z.number(), label: z.string(), points: z.number(), createdAt: z.string() }),
  ),
});

type PointsState = z.infer<typeof pointsStateSchema>;

// Builds the full points block for getState: counters, the level
// ladder with unlock state, every title/frame with owned + equipped
// state, the shop with owned state, and the recent activity log.
async function loadPoints(
  db: Db,
  metaRows: { key: string; value: string }[],
): Promise<PointsState> {
  await ensurePointsSeeded(db);
  const [logRows, purchaseRows] = await Promise.all([
    db.select().from(schema.pointsLog).orderBy(desc(schema.pointsLog.id)),
    db.select().from(schema.shopPurchases),
  ]);
  let lifetime = 0;
  let balance = 0;
  for (const r of logRows) {
    balance += r.points;
    if (r.points > 0) lifetime += r.points;
  }
  const purchased = new Set(purchaseRows.map((r) => r.itemKey));
  const { current, next } = levelFor(lifetime);

  const storedTitle = metaRows.find((r) => r.key === "equipped_title")?.value ?? "";
  const storedFrame = metaRows.find((r) => r.key === "equipped_frame")?.value ?? "";

  const titles: PointsState["titles"] = [
    ...LEVELS.map((l) => ({
      id: `title-level-${l.level}`,
      name: l.name,
      source: "level" as const,
      owned: lifetime >= l.at,
      equipped: false,
    })),
    ...SHOP_ITEMS.filter((i) => i.kind === "title").map((i) => ({
      id: i.id,
      name: i.name,
      source: "shop" as const,
      owned: purchased.has(i.id),
      equipped: false,
    })),
  ];
  const frames: PointsState["frames"] = [
    ...LEVELS.flatMap((l) => {
      const f = LEVEL_FRAMES[l.level];
      return f
        ? [{ id: f.id, name: f.name, frameClass: f.frameClass, source: "level" as const, owned: lifetime >= l.at, equipped: false }]
        : [];
    }),
    ...SHOP_ITEMS.filter((i) => i.kind === "frame").map((i) => ({
      id: i.id,
      name: i.name,
      frameClass: i.frameClass ?? "",
      source: "shop" as const,
      owned: purchased.has(i.id),
      equipped: false,
    })),
  ];
  // An equipped id only counts while the item is still owned; the
  // displayed title falls back to the current level's title.
  const equippedTitleRow = titles.find((t) => t.id === storedTitle && t.owned) ?? null;
  const equippedFrameRow = frames.find((f) => f.id === storedFrame && f.owned) ?? null;
  for (const t of titles) t.equipped = equippedTitleRow !== null && t.id === equippedTitleRow.id;
  for (const f of frames) f.equipped = equippedFrameRow !== null && f.id === equippedFrameRow.id;

  const shop: PointsState["shop"] = SHOP_ITEMS.map((i) => ({
    id: i.id,
    kind: i.kind,
    name: i.name,
    icon: i.icon,
    cost: i.cost,
    frameClass: i.frameClass,
    owned: purchased.has(i.id),
    equipped:
      (i.kind === "title" && equippedTitleRow?.id === i.id) ||
      (i.kind === "frame" && equippedFrameRow?.id === i.id),
  }));

  return {
    lifetime,
    balance,
    level: current.level,
    levelName: current.name,
    levelIcon: current.icon,
    nextLevel: next ? { level: next.level, name: next.name, at: next.at } : null,
    levels: LEVELS.map((l) => {
      const frame = LEVEL_FRAMES[l.level];
      return {
        level: l.level,
        name: l.name,
        icon: l.icon,
        at: l.at,
        unlocked: lifetime >= l.at,
        unlocks: [
          `“${l.name}” profile title`,
          `${l.icon} ${l.name} badge`,
          ...(frame ? [`${frame.name} for your profile photo`] : []),
        ],
      };
    }),
    titles,
    frames,
    shop,
    equippedTitle: equippedTitleRow?.name ?? current.name,
    equippedFrameClass: equippedFrameRow?.frameClass ?? null,
    activity: logRows.slice(0, 30).map((r) => ({
      id: r.id,
      label: r.label,
      points: r.points,
      createdAt: r.createdAt.toISOString(),
    })),
  };
}

const carStateSchema = z.object({
  carKey: z.string(),
  owned: z.boolean(),
  // Favorites list membership. Only ever true for an owned car:
  // loadState derives it as owned && stored flag, and setCarState
  // refuses to favorite a car that is not owned.
  isFavorite: z.boolean(),
  isTh: z.boolean(),
  isSth: z.boolean(),
  count: z.number().int(),
  note: z.string(),
  ownedAt: z.string().nullable(),
  thAt: z.string().nullable(),
  // Derived, not stored: true when the car is marked owned / TH / STH but
  // has no usable photo attached to it. A photo added to the car clears
  // it automatically; deleting the car's last photo brings it back.
  unverified: z.boolean(),
});

const badgeSchema = z.object({
  id: z.string(),
  icon: z.string(),
  name: z.string(),
  desc: z.string(),
  goal: z.number(),
  progress: z.number(),
  earned: z.boolean(),
});

// Hot Wheels Music settings, stored as one JSON row in the `meta` table
// (key `music_settings`) so they persist across reopening like the
// playlist does. Defaults match the Samsung Music layout Anthony
// showed: sleep timer off, 1.0x speed, 2-second crossfade, skip
// silence on, lock-screen controls on, queue plays all tracks, and
// duplicate songs are not allowed in.
const SLEEP_TIMER_OPTIONS = [0, 5, 10, 15, 30, 45, 60, 90] as const;

const musicSettingsSchema = z.object({
  sleepTimerMinutes: z.union([
    z.literal(0),
    z.literal(5),
    z.literal(10),
    z.literal(15),
    z.literal(30),
    z.literal(45),
    z.literal(60),
    z.literal(90),
  ]),
  playbackRate: z.number().min(0.5).max(2),
  crossfadeSeconds: z.number().int().min(0).max(10),
  skipSilence: z.boolean(),
  lockScreen: z.boolean(),
  queueMode: z.enum(["all", "single"]),
  dontAllowDuplicates: z.boolean(),
});

const MUSIC_SETTINGS_DEFAULTS: z.infer<typeof musicSettingsSchema> = {
  sleepTimerMinutes: 0,
  playbackRate: 1,
  crossfadeSeconds: 2,
  skipSilence: true,
  lockScreen: true,
  queueMode: "all",
  dontAllowDuplicates: true,
};

// The stored row may be missing, partial, or from an older shape: every
// field is validated on its own and falls back to its default, so a
// corrupt row can never brick the load or invent a setting.
function parseMusicSettings(value: string | undefined): z.infer<typeof musicSettingsSchema> {
  if (!value) return { ...MUSIC_SETTINGS_DEFAULTS };
  try {
    const parsed: unknown = JSON.parse(value);
    if (typeof parsed !== "object" || parsed === null) return { ...MUSIC_SETTINGS_DEFAULTS };
    const row = parsed as Record<string, unknown>;
    const sleep = row.sleepTimerMinutes;
    const rate = row.playbackRate;
    const crossfade = row.crossfadeSeconds;
    return {
      sleepTimerMinutes: SLEEP_TIMER_OPTIONS.includes(sleep as (typeof SLEEP_TIMER_OPTIONS)[number])
        ? (sleep as z.infer<typeof musicSettingsSchema>["sleepTimerMinutes"])
        : MUSIC_SETTINGS_DEFAULTS.sleepTimerMinutes,
      playbackRate:
        typeof rate === "number" && Number.isFinite(rate)
          ? Math.round(Math.min(2, Math.max(0.5, rate)) * 10) / 10
          : MUSIC_SETTINGS_DEFAULTS.playbackRate,
      crossfadeSeconds:
        typeof crossfade === "number" && Number.isInteger(crossfade)
          ? Math.min(10, Math.max(0, crossfade))
          : MUSIC_SETTINGS_DEFAULTS.crossfadeSeconds,
      skipSilence: typeof row.skipSilence === "boolean" ? row.skipSilence : MUSIC_SETTINGS_DEFAULTS.skipSilence,
      lockScreen: typeof row.lockScreen === "boolean" ? row.lockScreen : MUSIC_SETTINGS_DEFAULTS.lockScreen,
      queueMode: row.queueMode === "single" ? "single" : MUSIC_SETTINGS_DEFAULTS.queueMode,
      dontAllowDuplicates:
        typeof row.dontAllowDuplicates === "boolean"
          ? row.dontAllowDuplicates
          : MUSIC_SETTINGS_DEFAULTS.dontAllowDuplicates,
    };
  } catch {
    return { ...MUSIC_SETTINGS_DEFAULTS };
  }
}

// Photo Gallery layout choice, stored as one JSON row in the `meta`
// table (key `gallery_settings`) so it persists across reopening like
// the music settings do. `layout` is which gallery arrangement shows
// (the framed cards, one-car-per-row list, or dense compact tiles) and
// `size` is how big the grid / compact tiles are. Defaults are the
// gallery exactly as it looked before the controls existed: the framed
// card grid at medium size.
const gallerySettingsSchema = z.object({
  layout: z.enum(["grid", "list", "compact"]),
  size: z.enum(["small", "medium", "large"]),
});

const GALLERY_SETTINGS_DEFAULTS: z.infer<typeof gallerySettingsSchema> = {
  layout: "grid",
  size: "medium",
};

// Same defensive shape as parseMusicSettings: a missing, partial, or
// corrupt row falls back field by field to the defaults.
function parseGallerySettings(value: string | undefined): z.infer<typeof gallerySettingsSchema> {
  if (!value) return { ...GALLERY_SETTINGS_DEFAULTS };
  try {
    const parsed: unknown = JSON.parse(value);
    if (typeof parsed !== "object" || parsed === null) return { ...GALLERY_SETTINGS_DEFAULTS };
    const row = parsed as Record<string, unknown>;
    return {
      layout:
        row.layout === "list" || row.layout === "compact"
          ? row.layout
          : GALLERY_SETTINGS_DEFAULTS.layout,
      size:
        row.size === "small" || row.size === "large" ? row.size : GALLERY_SETTINGS_DEFAULTS.size,
    };
  } catch {
    return { ...GALLERY_SETTINGS_DEFAULTS };
  }
}

// Cars list (collection) layout choice, stored exactly like the
// gallery's: one JSON row in the `meta` table (key `cars_settings`),
// parsed field by field with defaults. `layout` is the tile grid, the
// one-car-per-row list, or the dense compact tiles; `size` is how big
// the grid / compact tiles are; `sort` is the list order (name A–Z,
// owned first, missing first, by series/game, or by mainline year),
// remembered so the collection reopens sorted the way it was left.
// Defaults are the cars list exactly as it looked before the controls
// existed: the tile grid at medium size, sorted A–Z.
const carsSettingsSchema = z.object({
  layout: z.enum(["grid", "list", "compact"]),
  size: z.enum(["small", "medium", "large"]),
  sort: z.enum(["az", "own", "miss", "series", "new", "old"]),
});

const CARS_SETTINGS_DEFAULTS: z.infer<typeof carsSettingsSchema> = {
  layout: "grid",
  size: "medium",
  sort: "az",
};

function parseCarsSettings(value: string | undefined): z.infer<typeof carsSettingsSchema> {
  if (!value) return { ...CARS_SETTINGS_DEFAULTS };
  try {
    const parsed: unknown = JSON.parse(value);
    if (typeof parsed !== "object" || parsed === null) return { ...CARS_SETTINGS_DEFAULTS };
    const row = parsed as Record<string, unknown>;
    return {
      layout:
        row.layout === "list" || row.layout === "compact"
          ? row.layout
          : CARS_SETTINGS_DEFAULTS.layout,
      size:
        row.size === "small" || row.size === "large" ? row.size : CARS_SETTINGS_DEFAULTS.size,
      sort:
        row.sort === "own" ||
        row.sort === "miss" ||
        row.sort === "series" ||
        row.sort === "new" ||
        row.sort === "old"
          ? row.sort
          : CARS_SETTINGS_DEFAULTS.sort,
    };
  } catch {
    return { ...CARS_SETTINGS_DEFAULTS };
  }
}

const stateResponse = z.object({
  profile: z.object({
    name: z.string(),
    bio: z.string(),
    favorite: z.string(),
    photoUrl: z.string().nullable(),
  }),
  pledge: z.array(z.boolean()),
  quoteIndex: z.number(),
  streak: z.object({ current: z.number(), best: z.number() }),
  stats: z.object({
    total: z.number(),
    owned: z.number(),
    copies: z.number(),
    th: z.number(),
    sth: z.number(),
    fantasyOwned: z.number(),
    favorites: z.number(),
    photoCount: z.number(),
    weekCount: z.number(),
    nextHunt: z.string().nullable(),
    unverified: z.number(),
  }),
  badges: z.array(badgeSchema),
  carOfDayKey: z.string().nullable(),
  recent: z.array(z.object({ carKey: z.string(), ownedAt: z.string() })),
  carStates: z.array(carStateSchema),
  customCars: z.array(
    z.object({ carKey: z.string(), name: z.string(), details: z.string(), tags: z.string() }),
  ),
  photos: z.array(
    z.object({
      id: z.number(),
      carKey: z.string().nullable(),
      url: z.string(),
      // URL of the small preview thumbnail of the same photo, or null
      // when none has been made yet. The Cars list tiles show the
      // thumbnail so the list loads fast on a phone; the full photo
      // (`url`) still opens from the car sheet.
      thumbUrl: z.string().nullable(),
      contentType: z.string(),
      // Position within the car's photo list; the lowest position is the
      // cover photo. The client sorts a car's photos by this (then id).
      position: z.number(),
      createdAt: z.string(),
    }),
  ),
  videos: z.array(
    z.object({
      id: z.number(),
      carKey: z.string().nullable(),
      name: z.string(),
      url: z.string(),
      contentType: z.string(),
      createdAt: z.string(),
    }),
  ),
  // Saved Music playlist, in playlist order. The URL is empty when the
  // stored audio blob no longer resolves; the row stays deletable.
  // `coverUrl` is the URL of the cover art extracted from the MP3's
  // embedded picture frame when the song was picked, or null when the
  // file had no cover (the client shows its placeholder then).
  tracks: z.array(
    z.object({
      id: z.number(),
      name: z.string(),
      url: z.string(),
      contentType: z.string(),
      coverUrl: z.string().nullable(),
      coverContentType: z.string().nullable(),
      position: z.number(),
      createdAt: z.string(),
    }),
  ),
  links: z.array(
    z.object({
      id: z.number(),
      url: z.string(),
      label: z.string(),
      carKey: z.string().nullable(),
      createdAt: z.string(),
    }),
  ),
  targets: z.array(
    z.object({
      id: z.number(),
      month: z.string(),
      text: z.string(),
      carKey: z.string().nullable(),
      done: z.boolean(),
    }),
  ),
  planDays: z.array(
    z.object({ month: z.string(), day: z.number(), isHunt: z.boolean(), note: z.string() }),
  ),
  monthPlans: z.array(z.object({ month: z.string(), budget: z.string(), spent: z.string() })),
  // Checked state of the generic hunt-prep checklist, one row per
  // (month, day, item index). Item texts are fixed in the client.
  checklist: z.array(
    z.object({ month: z.string(), day: z.number(), idx: z.number(), checked: z.boolean() }),
  ),
  // Hot Wheels Music settings (see musicSettingsSchema): sleep timer,
  // play speed, crossfade length, skip silence, lock-screen controls,
  // queue mode, and the duplicate-songs rule. Defaults apply when no
  // settings row has ever been saved.
  musicSettings: musicSettingsSchema,
  // Photo Gallery layout + tile size (see gallerySettingsSchema).
  // Defaults (framed card grid, medium) apply when no row was saved.
  gallerySettings: gallerySettingsSchema,
  // Cars list layout + tile size (see carsSettingsSchema). Defaults
  // (tile grid, medium) apply when no row was saved.
  carsSettings: carsSettingsSchema,
  // Points & Rewards (see the points section above): lifetime and
  // spendable counters, the level ladder, titles/frames with owned
  // and equipped state, the Rewards Shop, and the activity log. The
  // first load seeds the retroactive starting points from the
  // collection as it stands.
  points: pointsStateSchema,
  backupReady: z.boolean(),
});

type StateResponse = z.infer<typeof stateResponse>;

async function loadState(ctx: Ctx): Promise<StateResponse> {
  const db: Db = ctx.db<typeof schema>();
  const [stateRows, customs, photoRows, videoRows, trackRows, linkRows, targetRows, dayRows, planRows, profileRows, pledgeRows, visitRows, metaRows, checklistRows] =
    await Promise.all([
      db.select().from(schema.carState),
      db.select().from(schema.customCars),
      db.select().from(schema.photos).orderBy(desc(schema.photos.createdAt)),
      db.select().from(schema.videos).orderBy(desc(schema.videos.createdAt)),
      db.select().from(schema.tracks).orderBy(asc(schema.tracks.position), asc(schema.tracks.id)),
      db.select().from(schema.links).orderBy(desc(schema.links.createdAt)),
      db.select().from(schema.targets).orderBy(asc(schema.targets.createdAt)),
      db.select().from(schema.planDays),
      db.select().from(schema.monthPlans),
      db.select().from(schema.profile),
      db.select().from(schema.pledge),
      db.select().from(schema.visits),
      db.select().from(schema.meta),
      db.select().from(schema.huntChecklist),
    ]);

  const known = new Map<string, { n: string; t: string }>();
  for (const c of CATALOG) known.set(c.k, { n: c.n, t: c.t });
  for (const c of customs) known.set(c.carKey, { n: c.name, t: c.tags });

  const ownedRows = stateRows.filter((r) => r.owned === 1);
  // Total copies across the garage: every owned car counts at least
  // once (an owned row with count 0 is one car on the shelf), plus
  // each extra copy stored in `count`. Derived from the same rows as
  // `owned`, so the two numbers can never disagree.
  const copies = ownedRows.reduce((sum, r) => sum + Math.max(1, r.count), 0);
  const thCount = stateRows.filter((r) => r.isTh === 1).length;
  const sthCount = stateRows.filter((r) => r.isSth === 1).length;
  const fantasyOwned = ownedRows.filter((r) => (known.get(r.carKey)?.t ?? "").includes("F")).length;

  const now = new Date();
  const weekAgo = now.getTime() - 7 * 86_400_000;
  const weekCount = ownedRows.filter((r) => r.ownedAt !== null && r.ownedAt.getTime() >= weekAgo).length;

  const recent = ownedRows
    .filter((r) => r.ownedAt !== null)
    .sort((a, b) => (b.ownedAt?.getTime() ?? 0) - (a.ownedAt?.getTime() ?? 0))
    .slice(0, 8)
    .map((r) => ({ carKey: r.carKey, ownedAt: (r.ownedAt ?? now).toISOString() }));

  const visitDates = visitRows.map((r) => r.date);
  const st = streaks(visitDates, todayKey(now));

  const quoteRow = metaRows.find((r) => r.key === "quote_index");
  const quoteIndex = quoteRow ? Number(quoteRow.value) % QUOTES.length : 0;
  const musicSettings = parseMusicSettings(
    metaRows.find((r) => r.key === "music_settings")?.value,
  );
  const gallerySettings = parseGallerySettings(
    metaRows.find((r) => r.key === "gallery_settings")?.value,
  );
  const carsSettings = parseCarsSettings(
    metaRows.find((r) => r.key === "cars_settings")?.value,
  );

  const pledgeChecked = new Map(pledgeRows.map((r) => [r.idx, r.checked === 1]));
  const pledgeArr = PLEDGE_LINES.map((_, i) => pledgeChecked.get(i) ?? false);

  // Next hunt: earliest hunt day on/after today (Chicago).
  const todayStr = todayKey(now);
  let nextHunt: string | null = null;
  const huntDates = dayRows
    .filter((r) => r.isHunt === 1)
    .map((r) => `${r.month}-${String(r.day).padStart(2, "0")}`)
    .filter((d) => d >= todayStr)
    .sort();
  const firstHunt = huntDates[0];
  if (firstHunt) {
    const [y = 1970, m = 1, d = 1] = firstHunt.split("-").map(Number);
    nextHunt = new Date(y, (m ?? 1) - 1, d ?? 1).toLocaleDateString(undefined, {
      weekday: "long",
      month: "long",
      day: "numeric",
    });
  }

  const allCars = [
    ...CATALOG.map((c) => ({ n: c.n, k: c.k })),
    ...customs.map((c) => ({ n: c.name, k: c.carKey })),
  ].sort(compareCars);
  const missing = allCars.filter((c) => !stateRows.some((r) => r.carKey === c.k && r.owned === 1));
  const carOfDayKey = missing.length > 0 ? (missing[dayOfYear(now) % missing.length]?.k ?? null) : null;

  const progressFor = (kind: string): number => {
    if (kind === "owned") return ownedRows.length;
    if (kind === "th") return thCount;
    if (kind === "sth") return sthCount;
    if (kind === "photos") return photoRows.length;
    if (kind === "fantasy") return fantasyOwned;
    return Math.max(st.current, st.best);
  };
  const badges = BADGES.map((b) => {
    const progress = progressFor(b.kind);
    return {
      id: b.id,
      icon: b.icon,
      name: b.name,
      desc: b.desc,
      goal: b.goal,
      progress,
      earned: progress >= b.goal,
    };
  });

  const points = await loadPoints(db, metaRows);

  const profileRow = profileRows[0];
  let photoUrl: string | null = null;
  if (profileRow?.photoBlobKey) {
    photoUrl = await blobUrl(ctx, profileRow.photoBlobKey);
  }
  const photos = [];
  const verifiedCarKeys = new Set<string>();
  for (const p of photoRows) {
    const url = await blobUrl(ctx, p.blobKey);
    if (url && p.carKey) verifiedCarKeys.add(p.carKey);
    photos.push({
      id: p.id,
      carKey: p.carKey,
      url: url ?? "",
      thumbUrl: p.thumbBlobKey ? await blobUrl(ctx, p.thumbBlobKey) : null,
      contentType: p.contentType,
      position: p.position,
      createdAt: p.createdAt.toISOString(),
    });
  }
  const videos = [];
  for (const v of videoRows) {
    videos.push({
      id: v.id,
      carKey: v.carKey,
      name: v.name,
      url: (await blobUrl(ctx, v.blobKey)) ?? "",
      contentType: v.contentType,
      createdAt: v.createdAt.toISOString(),
    });
  }
  const tracks = [];
  for (const t of trackRows) {
    tracks.push({
      id: t.id,
      name: t.name,
      url: (await blobUrl(ctx, t.blobKey)) ?? "",
      contentType: t.contentType,
      coverUrl: t.coverBlobKey ? await blobUrl(ctx, t.coverBlobKey) : null,
      coverContentType: t.coverContentType,
      position: t.position,
      createdAt: t.createdAt.toISOString(),
    });
  }

  return {
    profile: {
      name: profileRow?.name ?? "",
      bio: profileRow?.bio ?? "",
      favorite: profileRow?.favorite ?? "",
      photoUrl,
    },
    pledge: pledgeArr,
    quoteIndex,
    streak: st,
    stats: {
      total: allCars.length,
      owned: ownedRows.length,
      copies,
      th: thCount,
      sth: sthCount,
      fantasyOwned,
      favorites: stateRows.filter((r) => r.owned === 1 && r.isFavorite === 1).length,
      photoCount: photoRows.length,
      weekCount,
      nextHunt,
      unverified: stateRows.filter(
        (r) => (r.owned === 1 || r.isTh === 1 || r.isSth === 1) && !verifiedCarKeys.has(r.carKey),
      ).length,
    },
    badges,
    carOfDayKey,
    recent,
    carStates: stateRows.map((r) => ({
      carKey: r.carKey,
      owned: r.owned === 1,
      isFavorite: r.owned === 1 && r.isFavorite === 1,
      isTh: r.isTh === 1,
      isSth: r.isSth === 1,
      count: r.count,
      note: r.note,
      ownedAt: r.ownedAt ? r.ownedAt.toISOString() : null,
      thAt: r.thAt ? r.thAt.toISOString() : null,
      unverified:
        (r.owned === 1 || r.isTh === 1 || r.isSth === 1) && !verifiedCarKeys.has(r.carKey),
    })),
    customCars: customs.map((c) => ({ carKey: c.carKey, name: c.name, details: c.details, tags: c.tags })),
    photos,
    videos,
    tracks,
    links: linkRows.map((l) => ({
      id: l.id,
      url: l.url,
      label: l.label,
      carKey: l.carKey,
      createdAt: l.createdAt.toISOString(),
    })),
    targets: targetRows.map((t) => ({
      id: t.id,
      month: t.month,
      text: t.text,
      carKey: t.carKey,
      done: t.done === 1,
    })),
    planDays: dayRows.map((d) => ({ month: d.month, day: d.day, isHunt: d.isHunt === 1, note: d.note })),
    monthPlans: planRows.map((p) => ({ month: p.month, budget: p.budget, spent: p.spent })),
    checklist: checklistRows.map((c) => ({
      month: c.month,
      day: c.day,
      idx: c.idx,
      checked: c.checked === 1,
    })),
    musicSettings,
    gallerySettings,
    carsSettings,
    points,
    backupReady: ownedRows.length > 0 || customs.length > 0,
  };
}

async function knownKey(ctx: Ctx, carKey: string): Promise<boolean> {
  if (CATALOG.some((c) => c.k === carKey)) return true;
  const db: Db = ctx.db<typeof schema>();
  const rows = await db.select().from(schema.customCars).where(eq(schema.customCars.carKey, carKey)).limit(1);
  return rows.length > 0;
}

function okResponse() {
  return z.object({ ok: z.literal(true) });
}

// Blob cleanup must never block removing the record itself: a photo whose
// stored blob is already gone (or undeletable) still has to be deletable
// from the collection, or the row can never be removed from the UI.
async function deleteBlobBestEffort(ctx: Ctx, key: string): Promise<void> {
  try {
    await ctx.blobs.delete(key);
  } catch {
    // Leave the orphaned blob; the database row is already gone.
  }
}

// Likewise, loading the collection must never fail because one stored blob
// is gone: a missing blob returns null (the client renders the row as
// unavailable, still deletable) instead of throwing and bricking the app.
async function blobUrl(ctx: Ctx, key: string): Promise<string | null> {
  try {
    return await ctx.blobs.getUrl(key);
  } catch {
    return null;
  }
}

/* ---------------- In-app chat with Hot Wheels Manager ---------------- */

const chatMessageSchema = z.object({
  id: z.number(),
  role: z.enum(["user", "assistant"]),
  content: z.string(),
  carKey: z.string().nullable(),
  // Which bot spoke this assistant message. Null for Anthony's own
  // messages; "manager" for all history written before Hot Wheels Guru existed.
  bot: z.enum(["manager", "fun"]).nullable(),
  createdAt: z.string(),
});

const chatReplyResponse = z.object({
  ok: z.literal(true),
  reply: z.string(),
  carKey: z.string().nullable(),
  actionNote: z.string().nullable(),
  bot: z.enum(["manager", "fun"]),
  messageId: z.number(),
  assistantId: z.number(),
});

function normalizeCarName(name: string): string {
  return name
    .toLowerCase()
    .replace(/hot\s*wheels/g, " ")
    .replace(/[^a-z0-9]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

interface ChatCandidate {
  k: string;
  n: string;
  t: string;
}

function findCarMatch(candidates: ChatCandidate[], rawName: string):
  | { kind: "none" }
  | { kind: "one"; car: ChatCandidate }
  | { kind: "many"; cars: ChatCandidate[] } {
  const query = normalizeCarName(rawName);
  if (query.length < 2) return { kind: "none" };
  const normed = candidates.map((c) => ({ c, norm: normalizeCarName(c.n) }));
  const exact = normed.find((x) => x.norm === query);
  if (exact) return { kind: "one", car: exact.c };
  const containing = normed.filter((x) => x.norm.includes(query) || query.includes(x.norm));
  if (containing.length === 1) return { kind: "one", car: containing[0]?.c ?? candidates[0]! };
  if (containing.length > 1) {
    // Prefer a candidate whose name starts with the query, or whose word
    // overlap is strictly best; otherwise ask Anthony to choose.
    const starts = containing.filter((x) => x.norm.startsWith(query));
    if (starts.length === 1) return { kind: "one", car: starts[0]?.c ?? candidates[0]! };
    const queryWords = new Set(query.split(" "));
    const scored = containing
      .map((x) => ({
        x,
        score: x.norm.split(" ").filter((w) => queryWords.has(w)).length,
      }))
      .sort((a, b) => b.score - a.score);
    const best = scored[0];
    const second = scored[1];
    if (best && second && best.score > second.score && best.score >= query.split(" ").length) {
      return { kind: "one", car: best.x.c };
    }
    return { kind: "many", cars: containing.slice(0, 5).map((x) => x.c) };
  }
  return { kind: "none" };
}

function describeTags(tags: string): string {
  const parts: string[] = [];
  if (tags.includes("1")) parts.push("Unleashed 1");
  if (tags.includes("2")) parts.push("Unleashed 2");
  if (tags.includes("D")) parts.push("DLC");
  if (tags.includes("F")) parts.push("Fantasy");
  if (tags.includes("R")) parts.push("Infinite Rush");
  if (tags.includes("S")) parts.push("Super Treasure Hunt release");
  if (tags.includes("X")) parts.push("Other 2026–27 release");
  for (let i = 0; i < 13; i += 1) {
    const code = "abcdefghijklm"[i];
    if (code && tags.includes(code)) parts.push(`${2015 + i} mainline`);
  }
  return parts.join(", ");
}

async function buildChatContext(ctx: Ctx): Promise<{ snapshot: string; candidates: ChatCandidate[] }> {
  const db: Db = ctx.db<typeof schema>();
  const [stateRows, customs, targetRows, dayRows, planRows, profileRows, visitRows, photoRows] = await Promise.all([
    db.select().from(schema.carState),
    db.select().from(schema.customCars),
    db.select().from(schema.targets).orderBy(asc(schema.targets.createdAt)),
    db.select().from(schema.planDays),
    db.select().from(schema.monthPlans),
    db.select().from(schema.profile),
    db.select().from(schema.visits),
    db.select().from(schema.photos),
  ]);
  const candidates: ChatCandidate[] = [
    ...CATALOG.map((c) => ({ k: c.k, n: c.n, t: c.t })),
    ...customs.map((c) => ({ k: c.carKey, n: c.name, t: c.tags })),
  ].sort(compareCars);
  const byKey = new Map(candidates.map((c) => [c.k, c]));
  const stateByKey = new Map(stateRows.map((r) => [r.carKey, r]));
  const owned = candidates.filter((c) => stateByKey.get(c.k)?.owned === 1);
  const favorites = owned.filter((c) => stateByKey.get(c.k)?.isFavorite === 1);
  const missing = candidates.filter((c) => stateByKey.get(c.k)?.owned !== 1);
  const thOwned = candidates.filter((c) => stateByKey.get(c.k)?.isTh === 1);
  const sthOwned = candidates.filter((c) => stateByKey.get(c.k)?.isSth === 1);
  const today = todayKey();
  const month = monthKey();
  const st = streaks(visitRows.map((r) => r.date), today);
  const recent = stateRows
    .filter((r) => r.owned === 1 && r.ownedAt !== null)
    .sort((a, b) => (b.ownedAt?.getTime() ?? 0) - (a.ownedAt?.getTime() ?? 0))
    .slice(0, 6)
    .map((r) => `${byKey.get(r.carKey)?.n ?? r.carKey} (${r.ownedAt?.toISOString().slice(0, 10) ?? ""})`);
  const monthTargets = targetRows.filter((t) => t.month === month);
  const huntDates = dayRows
    .filter((r) => r.isHunt === 1)
    .map((r) => ({ date: `${r.month}-${String(r.day).padStart(2, "0")}`, note: r.note }))
    .filter((d) => d.date >= today)
    .sort((a, b) => (a.date < b.date ? -1 : 1));
  const plan = planRows.find((p) => p.month === month);
  const profileRow = profileRows[0];
  const fantasyOwned = owned.filter((c) => c.t.includes("F")).length;
  const photoCarKeys = new Set(photoRows.map((p) => p.carKey).filter((k): k is string => k !== null));
  const unverifiedOwned = owned.filter((c) => !photoCarKeys.has(c.k));
  const unverifiedNames = unverifiedOwned.map((c) => c.n);
  const ownedNames = owned.map((c) => c.n);
  const shownOwned = ownedNames.slice(0, 160);
  const carOfDay = missing.length > 0 ? (missing[dayOfYear() % missing.length] ?? null) : null;
  const missingSample = missing.slice(0, 24).map((c) => `${c.n} [key: ${c.k}]`);
  const lines = [
    `Today (America/Chicago): ${today}. Collector: ${profileRow?.name?.trim() || "Collector"}${profileRow?.favorite ? `; favorite car: ${profileRow.favorite}` : ""}.`,
    `Collection: ${owned.length} of ${candidates.length} owned, ${missing.length} missing, ${thOwned.length} Treasure Hunts owned, ${sthOwned.length} Super Treasure Hunts owned, ${fantasyOwned} Fantasy castings owned, ${photoRows.length} photos.`,
    `Game rosters (complete, base game + all DLC): Unleashed 1 — ${owned.filter((c) => c.t.includes("1")).length} owned of ${GAME_ROSTER_TOTALS["1"] ?? 157} (${candidates.filter((c) => c.t.includes("1")).length} listed in the book); Unleashed 2 — ${owned.filter((c) => c.t.includes("2")).length} owned of ${GAME_ROSTER_TOTALS["2"] ?? 199} (${candidates.filter((c) => c.t.includes("2")).length} listed in the book); Infinite Rush — ${owned.filter((c) => c.t.includes("R")).length} owned of ${GAME_ROSTER_TOTALS["R"] ?? 150} (${candidates.filter((c) => c.t.includes("R")).length} listed in the book).`,
    unverifiedOwned.length > 0
      ? `Unverified: ${unverifiedOwned.length} owned/TH cars have no photo of the car yet and are flagged UNVERIFIED until a photo is added to them: ${unverifiedNames.slice(0, 40).join("; ")}${unverifiedNames.length > 40 ? `; and ${unverifiedNames.length - 40} more` : ""}. A car with a photo attached to it is verified. When Anthony asks you to mark a car owned or TH, say it will stay flagged unverified until he adds a photo of it in the app, because the photo requirement is enforced when he taps OWN/TH in the app, not in this chat.`
      : "Every owned/TH car has a photo, so none are flagged unverified.",
    `Streak: ${st.current} days (best ${st.best}).`,
    await (async () => {
      await ensurePointsSeeded(db);
      const totals = await pointsTotals(db);
      const lvl = levelFor(totals.lifetime);
      return `Points: ${totals.lifetime} lifetime points (Level ${lvl.current.level} ${lvl.current.name}${lvl.next ? `, ${lvl.next.at - totals.lifetime} points to Level ${lvl.next.level} ${lvl.next.name}` : ", top level"}), ${totals.balance} points to spend in the Rewards Shop. Points are earned automatically: new car owned +10, extra copy +2, Treasure Hunt +50, Super Treasure Hunt +100, photo +5, hunt target found +25, daily visit +5.`;
    })(),
    `Owned cars (${ownedNames.length}): ${shownOwned.join("; ")}${ownedNames.length > shownOwned.length ? `; and ${ownedNames.length - shownOwned.length} more` : ""}.`,
    favorites.length > 0
      ? `Favorites (chosen from owned cars only, ${favorites.length}): ${favorites.map((c) => c.n).join("; ")}.`
      : "Favorites list is empty — Anthony can favorite any car he owns from its sheet or the Favorites page.",
    thOwned.length > 0 ? `Treasure Hunts owned: ${thOwned.map((c) => c.n).join("; ")}.` : "No Treasure Hunts owned yet.",
    sthOwned.length > 0 ? `Super Treasure Hunts owned: ${sthOwned.map((c) => c.n).join("; ")}.` : "",
    recent.length > 0 ? `Recently added: ${recent.join("; ")}.` : "",
    carOfDay ? `Car of the day: ${carOfDay.n} [key: ${carOfDay.k}]${carOfDay.t ? ` (${describeTags(carOfDay.t)})` : ""}.` : "Every catalog car is owned.",
    `A sample of missing cars (name and key): ${missingSample.join("; ")}.`,
    monthTargets.length > 0
      ? `Targets for ${month}: ${monthTargets.map((t) => `${t.text}${t.done ? " (done)" : ""}`).join("; ")}.`
      : `No hunt targets set for ${month}.`,
    huntDates.length > 0
      ? `Upcoming hunt days: ${huntDates.map((d) => `${d.date}${d.note ? ` — ${d.note}` : ""}`).join("; ")}.`
      : "No upcoming hunt days marked in the planner.",
    plan ? `Budget for ${month}: budget ${plan.budget || "not set"}, spent ${plan.spent || "not set"}.` : "",
    customs.length > 0 ? `Custom cars Anthony added: ${customs.map((c) => c.name).join("; ")}.` : "",
  ].filter(Boolean);
  return { snapshot: lines.join("\n"), candidates };
}

async function applyCarFlag(
  ctx: Ctx,
  carKey: string,
  flag: "owned" | "th",
): Promise<{ name: string; owned: number; points: PointsAward } | null> {
  const db: Db = ctx.db<typeof schema>();
  const prevRows = await db.select().from(schema.carState).where(eq(schema.carState.carKey, carKey)).limit(1);
  const prev = prevRows[0];
  await ensurePointsSeeded(db);
  const now = new Date();
  const owned = flag === "owned" ? true : prev?.owned === 1;
  const isTh = flag === "th" ? true : prev?.isTh === 1;
  let count = prev?.count ?? 0;
  if (owned && count === 0) count = 1;
  if (!owned) count = 0;
  const values = {
    carKey,
    owned: owned ? 1 : 0,
    isFavorite: prev?.isFavorite ?? 0,
    isTh: isTh ? 1 : 0,
    isSth: prev?.isSth === 1 && isTh ? 1 : 0,
    count,
    note: prev?.note ?? "",
    ownedAt: owned ? (prev?.ownedAt ?? now) : null,
    thAt: isTh ? (prev?.thAt ?? now) : null,
    updatedAt: now,
  };
  await db
    .insert(schema.carState)
    .values(values)
    .onConflictDoUpdate({ target: schema.carState.carKey, set: values });
  // Chat marks earn the same points as in-app marks (new car +10,
  // hunt target found +25, Treasure Hunt +50) — reported back so the
  // reply can say what was earned.
  const points = await awardPoints(
    db,
    await carMarkEntries(
      db,
      carKey,
      prev
        ? {
            owned: prev.owned === 1,
            isTh: prev.isTh === 1,
            isSth: prev.isSth === 1,
            copies: prev.owned === 1 ? Math.max(1, prev.count) : 0,
          }
        : null,
      {
        owned: values.owned === 1,
        isTh: values.isTh === 1,
        isSth: values.isSth === 1,
        copies: values.owned === 1 ? Math.max(1, values.count) : 0,
      },
    ),
  );
  const ownedRows = await db.select().from(schema.carState).where(eq(schema.carState.owned, 1));
  return { name: carKey, owned: ownedRows.length, points };
}


/* ---------------- Backup import (shared by paste/file restore and the
   supplied-file import) ---------------- */

const importBackupResponse = z.object({
  ok: z.boolean(),
  error: z.string().nullable(),
  owned: z.number(),
  th: z.number(),
  custom: z.number(),
  targets: z.number(),
  planMonths: z.number(),
  photos: z.number(),
  skippedPhotos: z.number(),
  visits: z.number(),
  alreadyImported: z.boolean(),
});

type ImportBackupResponse = z.infer<typeof importBackupResponse>;

function importFail(error: string): ImportBackupResponse {
  return {
    ok: false,
    error,
    owned: 0,
    th: 0,
    custom: 0,
    targets: 0,
    planMonths: 0,
    photos: 0,
    skippedPhotos: 0,
    visits: 0,
    alreadyImported: false,
  };
}

// The backup's `ts` / `tts` maps hold owned / Treasure Hunt timestamps as
// epoch milliseconds for the most recently added cars. Only plausible,
// in-range values are used, and only when the app has no earlier date.
function validBackupMs(value: unknown): Date | null {
  if (typeof value !== "number" || !Number.isFinite(value)) return null;
  const ms = Math.floor(value);
  if (ms < 946_684_800_000 || ms > Date.now() + 86_400_000) return null;
  return new Date(ms);
}

// Merges one parsed backup into the app. Never deletes a row: ownership,
// TH/STH flags, counts, and notes from the backup are unioned with what is
// already stored, custom cars are added only when their key is new, plan
// days are upserted, and targets are added only when the same text is not
// already on that month. `backupSha256`, when given, identifies one exact
// supplied file so a re-run skips its photo phase entirely.
async function runBackupImport(
  ctx: Ctx,
  parsed: unknown,
  backupSha256: string | null,
): Promise<ImportBackupResponse> {
  const isRecord = (v: unknown): v is Record<string, unknown> => typeof v === "object" && v !== null;
  if (typeof parsed !== "object" || parsed === null || Array.isArray(parsed)) {
    return importFail("That backup has no collection data in it.");
  }
  const root = parsed as Record<string, unknown>;
  // Format 2 (the file the original app exports) wraps the collection in
  // `data`; format 1 (this app's own export shape) is the data itself.
  const data = isRecord(root.data) ? (root.data as Record<string, unknown>) : root;
  if (!isRecord(data.own) && !isRecord(data.th) && !Array.isArray(data.custom) && !isRecord(data.plan)) {
    return importFail("That backup has no collection data in it.");
  }
  const db: Db = ctx.db<typeof schema>();
  const known = new Set<string>(CATALOG.map((c) => c.k));
  const existingCustoms = await db.select().from(schema.customCars);
  for (const c of existingCustoms) known.add(c.carKey);

  let customCount = 0;
  if (Array.isArray(data.custom)) {
    for (const entry of data.custom) {
      if (!isRecord(entry) || typeof entry.n !== "string" || typeof entry.k !== "string") continue;
      if (known.has(entry.k)) continue;
      await db.insert(schema.customCars).values({
        carKey: entry.k,
        name: entry.n,
        details: typeof entry.x === "string" ? entry.x : "",
        tags: typeof entry.t === "string" ? entry.t : "",
      });
      known.add(entry.k);
      customCount += 1;
    }
  }

  const ownRec = isRecord(data.own) ? data.own : {};
  const favRec = isRecord(data.fav) ? data.fav : {};
  const thRec = isRecord(data.th) ? data.th : {};
  const sthRec = isRecord(data.sth) ? data.sth : {};
  const notesRec = isRecord(data.notes) ? data.notes : {};
  const cntRec = isRecord(data.cnt) ? data.cnt : {};
  const tsRec = isRecord(data.ts) ? data.ts : {};
  const ttsRec = isRecord(data.tts) ? data.tts : {};
  const keys = new Set([...Object.keys(ownRec), ...Object.keys(favRec), ...Object.keys(thRec), ...Object.keys(sthRec), ...Object.keys(notesRec), ...Object.keys(cntRec)]);
  let ownedCount = 0;
  let thCount = 0;
  const now = new Date();
  for (const key of keys) {
    if (!known.has(key)) continue;
    const owned = Boolean(ownRec[key]);
    const isFav = Boolean(favRec[key]);
    const isTh = Boolean(thRec[key]);
    const isSth = Boolean(sthRec[key]);
    const countRaw = cntRec[key];
    const count = typeof countRaw === "number" && Number.isFinite(countRaw) ? Math.max(0, Math.floor(countRaw)) : 0;
    const note = typeof notesRec[key] === "string" ? (notesRec[key] as string) : "";
    const prevRows = await db.select().from(schema.carState).where(eq(schema.carState.carKey, key)).limit(1);
    const prev = prevRows[0];
    const finalOwned = owned || prev?.owned === 1;
    // A backup favorite only lands on a car that ends up owned —
    // Favorites are drawn from owned cars only, backups included.
    const finalFavorite = finalOwned && (isFav || prev?.isFavorite === 1);
    const finalTh = isTh || prev?.isTh === 1;
    const finalSth = isSth || prev?.isSth === 1;
    const finalCount = count > 0 ? count : prev && prev.count > 0 ? prev.count : finalOwned ? 1 : 0;
    const finalNote = note || prev?.note || "";
    const ownedAt = finalOwned ? (prev?.ownedAt ?? validBackupMs(tsRec[key]) ?? now) : null;
    const thAt = finalTh ? (prev?.thAt ?? validBackupMs(ttsRec[key]) ?? now) : null;
    const values = {
      carKey: key,
      owned: finalOwned ? 1 : 0,
      isFavorite: finalFavorite ? 1 : 0,
      isTh: finalTh ? 1 : 0,
      isSth: finalSth && finalTh ? 1 : 0,
      count: finalCount,
      note: finalNote,
      ownedAt,
      thAt,
      updatedAt: now,
    };
    await db
      .insert(schema.carState)
      .values(values)
      .onConflictDoUpdate({ target: schema.carState.carKey, set: values });
    if (finalOwned) ownedCount += 1;
    if (finalTh) thCount += 1;
  }

  let targetCount = 0;
  let planMonths = 0;
  if (isRecord(data.plan)) {
    for (const [month, value] of Object.entries(data.plan)) {
      if (!/^\d{4}-\d{2}$/.test(month) || !isRecord(value)) continue;
      planMonths += 1;
      const dRec = isRecord(value.d) ? value.d : {};
      for (const [dayStr, dayVal] of Object.entries(dRec)) {
        const day = Number(dayStr);
        if (!Number.isInteger(day) || day < 1 || day > 31 || !isRecord(dayVal)) continue;
        const isHunt = Boolean(dayVal.h);
        const note = typeof dayVal.n === "string" ? dayVal.n : "";
        if (!isHunt && note === "") continue;
        await db
          .insert(schema.planDays)
          .values({ month, day, isHunt: isHunt ? 1 : 0, note })
          .onConflictDoUpdate({ target: [schema.planDays.month, schema.planDays.day], set: { isHunt: isHunt ? 1 : 0, note } });
      }
      if (Array.isArray(value.t)) {
        for (const entry of value.t) {
          if (!isRecord(entry) || typeof entry.t !== "string" || !entry.t.trim()) continue;
          const existing = await db
            .select()
            .from(schema.targets)
            .where(and(eq(schema.targets.month, month), eq(schema.targets.text, entry.t)));
          if (existing.length > 0) continue;
          await db.insert(schema.targets).values({ month, text: entry.t, done: entry.d ? 1 : 0 });
          targetCount += 1;
        }
      }
      const b = typeof value.b === "string" ? value.b : "";
      const s = typeof value.s === "string" ? value.s : "";
      if (b || s) {
        await db
          .insert(schema.monthPlans)
          .values({ month, budget: b, spent: s })
          .onConflictDoUpdate({ target: schema.monthPlans.month, set: { budget: b, spent: s } });
      }
    }
  }

  if (isRecord(data.pledge)) {
    for (const [idxStr, val] of Object.entries(data.pledge)) {
      const idx = Number(idxStr);
      if (!Number.isInteger(idx)) continue;
      await db
        .insert(schema.pledge)
        .values({ idx, checked: val ? 1 : 0 })
        .onConflictDoUpdate({ target: schema.pledge.idx, set: { checked: val ? 1 : 0 } });
    }
  }
  if (typeof data.q === "number" && Number.isFinite(data.q)) {
    const qi = Math.max(0, Math.floor(data.q)) % QUOTES.length;
    await db
      .insert(schema.meta)
      .values({ key: "quote_index", value: String(qi) })
      .onConflictDoUpdate({ target: schema.meta.key, set: { value: String(qi) } });
  }

  let visitCount = 0;
  if (Array.isArray(data.days)) {
    for (const d of data.days) {
      if (typeof d !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(d)) continue;
      await db.insert(schema.visits).values({ date: d }).onConflictDoNothing();
      visitCount += 1;
    }
  }

  // Photos live in three collections in the format-2 backup: `img` (one
  // per car), `thimg` (Treasure Hunt photos), and `imgs` (gallery lists
  // per car). All three attach to the same car key, and a photo with no
  // usable stored blob does not verify the car, so every photo that
  // resolves here clears that car's unverified flag on the next load.
  let photoCount = 0;
  let skippedPhotos = 0;
  let alreadyImported = false;
  const markerKey = backupSha256 ? `backup_import:${backupSha256}` : null;
  if (markerKey) {
    const marker = await db.select().from(schema.meta).where(eq(schema.meta.key, markerKey)).limit(1);
    alreadyImported = marker.length > 0;
  }
  if (!alreadyImported) {
    const candidates: { key: string; value: string }[] = [];
    const collectSingles = (rec: unknown) => {
      if (!isRecord(rec)) return;
      for (const [k, v] of Object.entries(rec)) {
        if (typeof v === "string") candidates.push({ key: k, value: v });
      }
    };
    collectSingles(data.img);
    collectSingles(data.thimg);
    if (isRecord(data.imgs)) {
      for (const [k, v] of Object.entries(data.imgs)) {
        if (!Array.isArray(v)) continue;
        for (const item of v) {
          if (typeof item === "string") candidates.push({ key: k, value: item });
        }
      }
    }
    // The same image can appear in more than one collection (and, on a
    // re-import, already be stored for that car). Skip an exact payload
    // seen earlier in this import, and skip a photo whose stored size
    // already matches one stored for the same car, so re-importing never
    // stacks visible duplicates of a photo Anthony already has.
    const seenPayloads = new Set<string>();
    const sizesByCar = new Map<string, number[]>();
    const existingSizes = async (carKey: string): Promise<number[]> => {
      const cached = sizesByCar.get(carKey);
      if (cached) return cached;
      const rows = await db.select().from(schema.photos).where(eq(schema.photos.carKey, carKey));
      const sizes: number[] = [];
      for (const row of rows) {
        try {
          const head = await ctx.blobs.head(row.blobKey);
          if (head) sizes.push(head.sizeBytes);
        } catch {
          // A blob that no longer resolves is not a match.
        }
      }
      sizesByCar.set(carKey, sizes);
      return sizes;
    };
    // Imported photos keep the backup's order per car (cover first, then
    // the gallery list), so the first imported photo for a car is its
    // cover and later imports append after the photos already stored.
    const nextPositionByCar = new Map<string, number>();
    const takeNextPosition = async (carKey: string): Promise<number> => {
      const cached = nextPositionByCar.get(carKey);
      if (cached !== undefined) {
        nextPositionByCar.set(carKey, cached + 1);
        return cached;
      }
      const rows = await db
        .select({ position: schema.photos.position })
        .from(schema.photos)
        .where(eq(schema.photos.carKey, carKey))
        .orderBy(desc(schema.photos.position))
        .limit(1);
      const next = (rows[0]?.position ?? -1) + 1;
      nextPositionByCar.set(carKey, next + 1);
      return next;
    };
    for (const { key, value } of candidates) {
      const m = value.match(/^data:(image\/(?:jpeg|png|webp|gif));base64,([A-Za-z0-9+/=]+)$/);
      if (!m || !known.has(key)) {
        skippedPhotos += 1;
        continue;
      }
      const b64 = m[2] ?? "";
      const payloadKey = `${key}:${b64}`;
      if (seenPayloads.has(payloadKey)) {
        skippedPhotos += 1;
        continue;
      }
      seenPayloads.add(payloadKey);
      if (b64.length > 14_000_000) {
        skippedPhotos += 1;
        continue;
      }
      let bytes: Buffer;
      try {
        bytes = Buffer.from(b64, "base64");
      } catch {
        skippedPhotos += 1;
        continue;
      }
      const sizes = await existingSizes(key);
      if (sizes.includes(bytes.byteLength)) {
        skippedPhotos += 1;
        continue;
      }
      try {
        const blobKey = `photos/import-${Date.now()}-${Math.floor(Math.random() * 1_000_000)}`;
        await ctx.blobs.put(blobKey, bytes, { contentType: m[1] ?? "image/jpeg" });
        const position = await takeNextPosition(key);
        await db.insert(schema.photos).values({ carKey: key, blobKey, contentType: m[1] ?? "image/jpeg", position });
        photoCount += 1;
      } catch {
        skippedPhotos += 1;
      }
    }
    if (markerKey && skippedPhotos === 0) {
      await db
        .insert(schema.meta)
        .values({ key: markerKey, value: "1" })
        .onConflictDoUpdate({ target: schema.meta.key, set: { value: "1" } });
    }
  }

  ctx.invalidateQueries();
  return {
    ok: true,
    error: null,
    owned: ownedCount,
    th: thCount,
    custom: customCount,
    targets: targetCount,
    planMonths,
    photos: photoCount,
    skippedPhotos,
    visits: visitCount,
    alreadyImported,
  };
}

export const Actions = {
  getState: defineAction({
    description: "Loads the whole Hunt Book: profile, streak, badges, ownership and Favorites state, custom cars, photos, videos, music playlist, links, targets, hunt planner data, hunt-day checklist state, and the points block (lifetime/spendable counters, level ladder, Rewards Shop, equipped title/frame, activity log).",
    request: z.object({}),
    response: stateResponse,
    handler: async (ctx) => {
      requireOwner(ctx);
      return loadState(ctx);
    },
  }),

  recordVisit: defineAction({
    description: "Records today's visit (America/Chicago) so the hunt streak stays current, and returns the streak. The first visit of a new day also earns the +5 daily-visit points (returned as points.awarded); repeat opens on the same day earn nothing.",
    request: z.object({}),
    response: z.object({ current: z.number(), best: z.number(), points: pointsAwardSchema }),
    handler: async (ctx): Promise<{ current: number; best: number; points: PointsAward }> => {
      requireOwner(ctx);
      const db: Db = ctx.db<typeof schema>();
      await ensurePointsSeeded(db);
      const today = todayKey();
      const inserted = await db
        .insert(schema.visits)
        .values({ date: today })
        .onConflictDoNothing()
        .returning({ date: schema.visits.date });
      const points =
        inserted.length > 0
          ? await awardPoints(db, [
              { kind: "daily", label: "Daily visit — streak day", points: POINT_VALUES.daily },
            ])
          : await awardPoints(db, []);
      const rows = await db.select().from(schema.visits);
      ctx.invalidateQueries();
      const st = streaks(rows.map((r) => r.date), today);
      return { current: st.current, best: st.best, points };
    },
  }),

  setCarState: defineAction({
    description: "Sets ownership, Favorite, Treasure Hunt / Super Treasure Hunt flags, duplicate count, or the note for one casting. Muse uses this to add or update cars Anthony names. Favorites come only from owned cars: setting isFavorite on a car that is not owned is rejected, and unowning a car removes it from Favorites. A car marked owned or TH without a photo attached to it is flagged unverified in getState until a photo of that car is added; the tap-to-mark photo requirement is enforced in the app UI, not by blocking this action. Points are awarded on transitions and returned as points: a car becoming owned +10 (plus +2 per extra copy beyond the first, and +25 when the car is a hunt target — its target rows are then checked off as found), becoming a Treasure Hunt +50, becoming a Super Treasure Hunt +100. Un-marking never takes points back.",
    request: z.object({
      carKey: z.string().min(1),
      owned: z.boolean().optional(),
      isFavorite: z.boolean().optional(),
      isTh: z.boolean().optional(),
      isSth: z.boolean().optional(),
      count: z.number().int().min(0).max(999).optional(),
      note: z.string().max(2000).optional(),
    }),
    response: okPointsResponse,
    handler: async (ctx, args): Promise<z.infer<typeof okPointsResponse>> => {
      requireOwner(ctx);
      if (!(await knownKey(ctx, args.carKey))) {
        throw new Error(`Unknown car key: ${args.carKey}`);
      }
      const db: Db = ctx.db<typeof schema>();
      const existing = await db.select().from(schema.carState).where(eq(schema.carState.carKey, args.carKey)).limit(1);
      const prev = existing[0];
      // Retroactive starting points are settled from the collection
      // as it stood before this change, so a first-ever mark made
      // through this action can never be counted twice.
      await ensurePointsSeeded(db);
      const now = new Date();
      const owned = args.owned ?? (prev?.owned === 1);
      const isTh = args.isTh ?? (prev?.isTh === 1);
      const isSth = args.isSth ?? (prev?.isSth === 1);
      // Favorites are drawn from owned cars only: asking to favorite a
      // car that will not be owned is an error (not a silent no-op),
      // and unowning a car always drops it from the Favorites list.
      if (args.isFavorite === true && !owned) {
        throw new Error("Favorites can only include cars Anthony owns — mark the car owned first.");
      }
      const isFavorite = owned ? (args.isFavorite ?? (prev?.isFavorite === 1)) : false;
      let count = args.count ?? prev?.count ?? 0;
      if (owned && count === 0) count = 1;
      if (!owned) count = args.count ?? 0;
      const values = {
        carKey: args.carKey,
        owned: owned ? 1 : 0,
        isFavorite: isFavorite ? 1 : 0,
        isTh: isTh ? 1 : 0,
        isSth: isSth && isTh ? 1 : 0,
        count,
        note: args.note ?? prev?.note ?? "",
        ownedAt: owned ? (prev?.ownedAt ?? now) : null,
        thAt: isTh ? (prev?.thAt ?? now) : null,
        updatedAt: now,
      };
      await db
        .insert(schema.carState)
        .values(values)
        .onConflictDoUpdate({ target: schema.carState.carKey, set: values });
      const points = await awardPoints(
        db,
        await carMarkEntries(
          db,
          args.carKey,
          prev
            ? {
                owned: prev.owned === 1,
                isTh: prev.isTh === 1,
                isSth: prev.isSth === 1,
                copies: prev.owned === 1 ? Math.max(1, prev.count) : 0,
              }
            : null,
          {
            owned: values.owned === 1,
            isTh: values.isTh === 1,
            isSth: values.isSth === 1,
            copies: values.owned === 1 ? Math.max(1, values.count) : 0,
          },
        ),
      );
      ctx.invalidateQueries();
      return { ok: true as const, points };
    },
  }),

  buyRewardItem: defineAction({
    description: "Buys one Rewards Shop item (a profile title, a profile-photo frame, or a special badge) with spendable points. The cost comes out of the spendable balance only — lifetime points and the level never go down. Returns ok:false with a plain-language error when the item does not exist, is already owned, or the balance is too low; nothing is charged then.",
    request: z.object({ itemId: z.string().min(1) }),
    response: z.object({
      ok: z.boolean(),
      error: z.string().nullable(),
      balance: z.number(),
      lifetime: z.number(),
    }),
    handler: async (
      ctx,
      args,
    ): Promise<{ ok: boolean; error: string | null; balance: number; lifetime: number }> => {
      requireOwner(ctx);
      const db: Db = ctx.db<typeof schema>();
      await ensurePointsSeeded(db);
      const totals = await pointsTotals(db);
      const item: ShopItem | undefined = SHOP_ITEMS.find((i) => i.id === args.itemId);
      if (!item) {
        return { ok: false, error: "That reward is not in the shop.", balance: totals.balance, lifetime: totals.lifetime };
      }
      const ownedRows = await db
        .select({ itemKey: schema.shopPurchases.itemKey })
        .from(schema.shopPurchases)
        .where(eq(schema.shopPurchases.itemKey, item.id))
        .limit(1);
      if (ownedRows.length > 0) {
        return { ok: false, error: `You already own ${item.name}.`, balance: totals.balance, lifetime: totals.lifetime };
      }
      if (totals.balance < item.cost) {
        return {
          ok: false,
          error: `Not enough points yet — ${item.name} costs ${item.cost} points and you have ${totals.balance} to spend.`,
          balance: totals.balance,
          lifetime: totals.lifetime,
        };
      }
      await db.insert(schema.shopPurchases).values({ itemKey: item.id });
      await db.insert(schema.pointsLog).values({
        kind: "shop",
        label: `Rewards Shop: ${item.name}`,
        points: -item.cost,
        carKey: null,
      });
      const after = await pointsTotals(db);
      ctx.invalidateQueries();
      return { ok: true, error: null, balance: after.balance, lifetime: after.lifetime };
    },
  }),

  equipReward: defineAction({
    description: "Equips an owned profile title or profile-photo frame on the collector profile (itemId null unequips, back to the level title / plain frame). Only rewards Anthony actually owns — from his level or bought in the Rewards Shop — can be equipped; anything else is rejected and nothing changes.",
    request: z.object({
      kind: z.enum(["title", "frame"]),
      itemId: z.string().nullable(),
    }),
    response: okResponse(),
    handler: async (ctx, args) => {
      requireOwner(ctx);
      const db: Db = ctx.db<typeof schema>();
      await ensurePointsSeeded(db);
      if (args.itemId !== null) {
        const state = await loadPoints(db, await db.select().from(schema.meta));
        const owned =
          args.kind === "title"
            ? state.titles.some((t) => t.id === args.itemId && t.owned)
            : state.frames.some((f) => f.id === args.itemId && f.owned);
        if (!owned) {
          throw new Error("That reward is not unlocked yet — reach its level or buy it in the Rewards Shop first.");
        }
      }
      const key = args.kind === "title" ? "equipped_title" : "equipped_frame";
      await db
        .insert(schema.meta)
        .values({ key, value: args.itemId ?? "" })
        .onConflictDoUpdate({ target: schema.meta.key, set: { value: args.itemId ?? "" } });
      ctx.invalidateQueries();
      return { ok: true as const };
    },
  }),

  importCastings: defineAction({
    description:
      "Adds or refreshes many castings at once (from the allhotwheels.com scan in Settings), matched by name ignoring case, spaces and punctuation. A casting that an earlier scan added is overwritten with the new data; one that is in the built-in catalog, or that you added by hand, is left alone so it is never duplicated.",
    request: z.object({
      cars: z
        .array(
          z.object({
            name: z.string().trim().min(1).max(120),
            tags: z.string().max(40).default(""),
            details: z.string().max(1000).default(""),
          }),
        )
        .max(1000),
    }),
    response: z.object({ added: z.number(), updated: z.number(), skipped: z.number() }),
    handler: async (ctx, args) => {
      requireOwner(ctx);
      const db: Db = ctx.db<typeof schema>();
      const squash = (v: string) => v.toLowerCase().replace(/[^a-z0-9]/g, "");
      // Built-in catalog: never touched, so owned marks and game tags stay.
      const inCatalog = new Set<string>();
      for (const c of CATALOG) {
        inCatalog.add(squash(c.n));
        inCatalog.add(c.k);
      }
      // Custom cars: earlier scan imports (key "ahw-...") can be refreshed;
      // hand-added ones (any other key) are left alone.
      const scanKeys = new Set<string>();
      const handAdded = new Set<string>();
      const existing = await db
        .select({ carKey: schema.customCars.carKey, name: schema.customCars.name })
        .from(schema.customCars);
      for (const c of existing) {
        if (c.carKey.startsWith("ahw-")) scanKeys.add(c.carKey);
        else {
          handAdded.add(squash(c.name));
          handAdded.add(c.carKey);
        }
      }
      const seenThisCall = new Set<string>();
      const fresh: { carKey: string; name: string; details: string; tags: string }[] = [];
      let updated = 0;
      let skipped = 0;
      for (const car of args.cars) {
        const norm = squash(car.name);
        const carKey = `ahw-${norm}`;
        if (!norm || seenThisCall.has(norm) || inCatalog.has(norm) || inCatalog.has(carKey) || handAdded.has(norm)) {
          skipped += 1;
          continue;
        }
        seenThisCall.add(norm);
        if (scanKeys.has(carKey)) {
          await db
            .update(schema.customCars)
            .set({ name: car.name, details: car.details, tags: car.tags })
            .where(eq(schema.customCars.carKey, carKey));
          updated += 1;
        } else {
          fresh.push({ carKey, name: car.name, details: car.details, tags: car.tags });
        }
      }
      for (let i = 0; i < fresh.length; i += 100) {
        await db.insert(schema.customCars).values(fresh.slice(i, i + 100)).onConflictDoNothing();
      }
      ctx.invalidateQueries();
      return { added: fresh.length, updated, skipped };
    },
  }),

  addCustomCar: defineAction({
    description: "Adds a casting that is not in the 3,897-car catalog, with a name, details, and tag codes, and returns its key.",
    request: z.object({
      name: z.string().trim().min(1).max(120),
      details: z.string().max(1000).default(""),
      tags: z.string().max(40).default(""),
    }),
    response: z.object({ carKey: z.string() }),
    handler: async (ctx, args) => {
      requireOwner(ctx);
      const db: Db = ctx.db<typeof schema>();
      const carKey = `c${Date.now()}${Math.floor(Math.random() * 1000)}`;
      await db.insert(schema.customCars).values({
        carKey,
        name: args.name,
        details: args.details,
        tags: args.tags,
      });
      ctx.invalidateQueries();
      return { carKey };
    },
  }),

  updateCustomCar: defineAction({
    description: "Edits a custom (user-added) car's name, details, or tag codes.",
    request: z.object({
      carKey: z.string().min(1),
      name: z.string().trim().min(1).max(120),
      details: z.string().max(1000),
      tags: z.string().max(40),
    }),
    response: okResponse(),
    handler: async (ctx, args) => {
      requireOwner(ctx);
      const db: Db = ctx.db<typeof schema>();
      await db
        .update(schema.customCars)
        .set({ name: args.name, details: args.details, tags: args.tags })
        .where(eq(schema.customCars.carKey, args.carKey));
      ctx.invalidateQueries();
      return { ok: true as const };
    },
  }),

  deleteCustomCar: defineAction({
    description: "Deletes a custom car and its ownership state, photos, videos, and links.",
    request: z.object({ carKey: z.string().min(1) }),
    response: okResponse(),
    handler: async (ctx, args) => {
      requireOwner(ctx);
      const db: Db = ctx.db<typeof schema>();
      const photoRows = await db.select().from(schema.photos).where(eq(schema.photos.carKey, args.carKey));
      const videoRows = await db.select().from(schema.videos).where(eq(schema.videos.carKey, args.carKey));
      await db.delete(schema.photos).where(eq(schema.photos.carKey, args.carKey));
      await db.delete(schema.videos).where(eq(schema.videos.carKey, args.carKey));
      await db.delete(schema.links).where(eq(schema.links.carKey, args.carKey));
      await db.delete(schema.carState).where(eq(schema.carState.carKey, args.carKey));
      await db.delete(schema.customCars).where(eq(schema.customCars.carKey, args.carKey));
      for (const p of photoRows) {
        await deleteBlobBestEffort(ctx, p.blobKey);
        if (p.thumbBlobKey) await deleteBlobBestEffort(ctx, p.thumbBlobKey);
      }
      for (const v of videoRows) await deleteBlobBestEffort(ctx, v.blobKey);
      ctx.invalidateQueries();
      return { ok: true as const };
    },
  }),

  addTarget: defineAction({
    description: "Adds a hunt target (free text, or a casting) to a planner month's target list.",
    request: z.object({
      month: z.string().regex(/^\d{4}-\d{2}$/),
      text: z.string().trim().min(1).max(120),
      carKey: z.string().nullable().default(null),
    }),
    response: z.object({ added: z.boolean(), id: z.number().nullable() }),
    handler: async (ctx, args) => {
      requireOwner(ctx);
      const db: Db = ctx.db<typeof schema>();
      const existing = await db
        .select()
        .from(schema.targets)
        .where(and(eq(schema.targets.month, args.month), eq(schema.targets.text, args.text)));
      if (existing.length > 0) return { added: false, id: existing[0]?.id ?? null };
      const rows = await db
        .insert(schema.targets)
        .values({ month: args.month, text: args.text, carKey: args.carKey })
        .returning({ id: schema.targets.id });
      ctx.invalidateQueries();
      return { added: true, id: rows[0]?.id ?? null };
    },
  }),

  toggleTarget: defineAction({
    description: "Marks a hunt target done or not done.",
    request: z.object({ id: z.number().int(), done: z.boolean() }),
    response: okResponse(),
    handler: async (ctx, args) => {
      requireOwner(ctx);
      const db: Db = ctx.db<typeof schema>();
      await db.update(schema.targets).set({ done: args.done ? 1 : 0 }).where(eq(schema.targets.id, args.id));
      ctx.invalidateQueries();
      return { ok: true as const };
    },
  }),

  removeTarget: defineAction({
    description: "Removes a hunt target from a planner month.",
    request: z.object({ id: z.number().int() }),
    response: okResponse(),
    handler: async (ctx, args) => {
      requireOwner(ctx);
      const db: Db = ctx.db<typeof schema>();
      await db.delete(schema.targets).where(eq(schema.targets.id, args.id));
      ctx.invalidateQueries();
      return { ok: true as const };
    },
  }),

  setPlanDay: defineAction({
    description: "Marks or unmarks a planner day as a hunt day and sets its note.",
    request: z.object({
      month: z.string().regex(/^\d{4}-\d{2}$/),
      day: z.number().int().min(1).max(31),
      isHunt: z.boolean(),
      note: z.string().max(500).default(""),
    }),
    response: okResponse(),
    handler: async (ctx, args) => {
      requireOwner(ctx);
      const db: Db = ctx.db<typeof schema>();
      if (!args.isHunt && args.note.trim() === "") {
        await db
          .delete(schema.planDays)
          .where(and(eq(schema.planDays.month, args.month), eq(schema.planDays.day, args.day)));
      } else {
        await db
          .insert(schema.planDays)
          .values({ month: args.month, day: args.day, isHunt: args.isHunt ? 1 : 0, note: args.note })
          .onConflictDoUpdate({
            target: [schema.planDays.month, schema.planDays.day],
            set: { isHunt: args.isHunt ? 1 : 0, note: args.note },
          });
      }
      ctx.invalidateQueries();
      return { ok: true as const };
    },
  }),

  setChecklistItem: defineAction({
    description: "Checks or unchecks one item of a hunt day's generic hunt-prep checklist. The check is saved for that planner month and day only, so the Nov 14 hunt checklist stays as Anthony left it. Item texts are a fixed list in the app; idx 0–5 selects the item.",
    request: z.object({
      month: z.string().regex(/^\d{4}-\d{2}$/),
      day: z.number().int().min(1).max(31),
      idx: z.number().int().min(0).max(5),
      checked: z.boolean(),
    }),
    response: okResponse(),
    handler: async (ctx, args) => {
      requireOwner(ctx);
      const db: Db = ctx.db<typeof schema>();
      await db
        .insert(schema.huntChecklist)
        .values({ month: args.month, day: args.day, idx: args.idx, checked: args.checked ? 1 : 0 })
        .onConflictDoUpdate({
          target: [schema.huntChecklist.month, schema.huntChecklist.day, schema.huntChecklist.idx],
          set: { checked: args.checked ? 1 : 0 },
        });
      ctx.invalidateQueries();
      return { ok: true as const };
    },
  }),

  setMonthPlan: defineAction({
    description: "Sets a planner month's budget and spent amounts (free-form dollar text, as in the original app).",
    request: z.object({
      month: z.string().regex(/^\d{4}-\d{2}$/),
      budget: z.string().max(20),
      spent: z.string().max(20),
    }),
    response: okResponse(),
    handler: async (ctx, args) => {
      requireOwner(ctx);
      const db: Db = ctx.db<typeof schema>();
      await db
        .insert(schema.monthPlans)
        .values({ month: args.month, budget: args.budget, spent: args.spent })
        .onConflictDoUpdate({
          target: schema.monthPlans.month,
          set: { budget: args.budget, spent: args.spent },
        });
      ctx.invalidateQueries();
      return { ok: true as const };
    },
  }),

  setProfile: defineAction({
    description: "Sets the collector profile name, bio, and favorite car.",
    request: z.object({
      name: z.string().max(80),
      bio: z.string().max(500),
      favorite: z.string().max(120),
    }),
    response: okResponse(),
    handler: async (ctx, args) => {
      requireOwner(ctx);
      const db: Db = ctx.db<typeof schema>();
      await db
        .insert(schema.profile)
        .values({ id: 1, name: args.name, bio: args.bio, favorite: args.favorite })
        .onConflictDoUpdate({
          target: schema.profile.id,
          set: { name: args.name, bio: args.bio, favorite: args.favorite },
        });
      ctx.invalidateQueries();
      return { ok: true as const };
    },
  }),

  setProfilePhoto: defineAction({
    description: "Sets the collector profile photo from an uploaded image.",
    request: z.object({
      dataBase64: z.string().max(14_000_000),
      mimeType: z.string().regex(/^image\/(jpeg|png|webp|gif)$/),
    }),
    response: okResponse(),
    handler: async (ctx, args) => {
      requireOwner(ctx);
      const db: Db = ctx.db<typeof schema>();
      const key = `profile/photo-${Date.now()}`;
      await ctx.blobs.put(key, Buffer.from(args.dataBase64, "base64"), { contentType: args.mimeType });
      const prev = await db.select().from(schema.profile).limit(1);
      const oldKey = prev[0]?.photoBlobKey ?? null;
      await db
        .insert(schema.profile)
        .values({ id: 1, photoBlobKey: key, photoContentType: args.mimeType })
        .onConflictDoUpdate({
          target: schema.profile.id,
          set: { photoBlobKey: key, photoContentType: args.mimeType },
        });
      if (oldKey && oldKey !== key) await deleteBlobBestEffort(ctx, oldKey);
      ctx.invalidateQueries();
      return { ok: true as const };
    },
  }),

  setPledge: defineAction({
    description: "Checks or unchecks one Hunter's Pledge line.",
    request: z.object({ idx: z.number().int().min(0).max(20), checked: z.boolean() }),
    response: okResponse(),
    handler: async (ctx, args) => {
      requireOwner(ctx);
      const db: Db = ctx.db<typeof schema>();
      await db
        .insert(schema.pledge)
        .values({ idx: args.idx, checked: args.checked ? 1 : 0 })
        .onConflictDoUpdate({ target: schema.pledge.idx, set: { checked: args.checked ? 1 : 0 } });
      ctx.invalidateQueries();
      return { ok: true as const };
    },
  }),

  cycleBoost: defineAction({
    description: "Advances to the next motivation quote.",
    request: z.object({}),
    response: z.object({ quoteIndex: z.number() }),
    handler: async (ctx) => {
      requireOwner(ctx);
      const db: Db = ctx.db<typeof schema>();
      const rows = await db.select().from(schema.meta).where(eq(schema.meta.key, "quote_index"));
      const next = ((rows[0] ? Number(rows[0].value) : 0) + 1) % QUOTES.length;
      await db
        .insert(schema.meta)
        .values({ key: "quote_index", value: String(next) })
        .onConflictDoUpdate({ target: schema.meta.key, set: { value: String(next) } });
      ctx.invalidateQueries();
      return { quoteIndex: next };
    },
  }),

  addPhoto: defineAction({
    description: "Adds a photo, optionally attached to one casting, from an uploaded image file. A photo attached to a car verifies that car's owned / Treasure Hunt marks and clears its unverified flag. When the client also sends thumbDataBase64 (a small JPEG preview it made from the same photo), the thumbnail is stored as a second blob on the same photo row so the Cars list can show the small preview instead of the full photo. Each photo added earns +5 points, returned as points; photos imported from a backup do not earn.",
    request: z.object({
      carKey: z.string().nullable().default(null),
      dataBase64: z.string().max(14_000_000),
      mimeType: z.string().regex(/^image\/(jpeg|png|webp|gif)$/),
      thumbDataBase64: z.string().max(900_000).optional(),
    }),
    response: z.object({ id: z.number(), points: pointsAwardSchema }),
    handler: async (ctx, args): Promise<{ id: number; points: PointsAward }> => {
      requireOwner(ctx);
      if (args.carKey !== null && !(await knownKey(ctx, args.carKey))) {
        throw new Error(`Unknown car key: ${args.carKey}`);
      }
      const db: Db = ctx.db<typeof schema>();
      await ensurePointsSeeded(db);
      // A new photo appends to the end of its car's list, so it never
      // displaces the cover photo; a car's first photo is its cover.
      let position = 0;
      if (args.carKey !== null) {
        const existing = await db
          .select({ position: schema.photos.position })
          .from(schema.photos)
          .where(eq(schema.photos.carKey, args.carKey))
          .orderBy(desc(schema.photos.position))
          .limit(1);
        position = (existing[0]?.position ?? -1) + 1;
      }
      const key = `photos/${Date.now()}-${Math.floor(Math.random() * 1_000_000)}`;
      await ctx.blobs.put(key, Buffer.from(args.dataBase64, "base64"), { contentType: args.mimeType });
      // The thumbnail is optional and independent of the photo: it is
      // always a small JPEG the client derived from the same image, and
      // a photo without one simply stores null thumbnail keys (the
      // Cars list makes one later through setPhotoThumb).
      let thumbBlobKey: string | null = null;
      let thumbContentType: string | null = null;
      if (args.thumbDataBase64) {
        thumbBlobKey = `photos/thumbs/${Date.now()}-${Math.floor(Math.random() * 1_000_000)}`;
        await ctx.blobs.put(thumbBlobKey, Buffer.from(args.thumbDataBase64, "base64"), {
          contentType: "image/jpeg",
        });
        thumbContentType = "image/jpeg";
      }
      const rows = await db
        .insert(schema.photos)
        .values({
          carKey: args.carKey,
          blobKey: key,
          contentType: args.mimeType,
          thumbBlobKey,
          thumbContentType,
          position,
        })
        .returning({ id: schema.photos.id });
      const points = await awardPoints(db, [
        {
          kind: "photo",
          label:
            args.carKey !== null
              ? `Photo added: ${await carDisplayName(db, args.carKey)}`
              : "Photo added to the gallery",
          points: POINT_VALUES.photo,
          carKey: args.carKey,
        },
      ]);
      ctx.invalidateQueries();
      return { id: rows[0]?.id ?? 0, points };
    },
  }),

  setPhotoThumb: defineAction({
    description:
      "Stores a small preview thumbnail (a JPEG the app made from the photo itself) for an existing photo that does not have one yet, so the Cars list can show the small preview instead of downloading the full photo. The full photo is untouched, a photo that already has a thumbnail is left as it is, and no other collection data changes.",
    request: z.object({
      id: z.number().int(),
      dataBase64: z.string().max(900_000),
    }),
    response: okResponse(),
    handler: async (ctx, args) => {
      requireOwner(ctx);
      const db: Db = ctx.db<typeof schema>();
      const rows = await db.select().from(schema.photos).where(eq(schema.photos.id, args.id)).limit(1);
      const row = rows[0];
      if (!row) throw new Error("Photo not found");
      if (row.thumbBlobKey) return { ok: true as const };
      const key = `photos/thumbs/${Date.now()}-${Math.floor(Math.random() * 1_000_000)}`;
      await ctx.blobs.put(key, Buffer.from(args.dataBase64, "base64"), { contentType: "image/jpeg" });
      await db
        .update(schema.photos)
        .set({ thumbBlobKey: key, thumbContentType: "image/jpeg" })
        .where(eq(schema.photos.id, args.id));
      ctx.invalidateQueries();
      return { ok: true as const };
    },
  }),

  setCoverPhoto: defineAction({
    description:
      "Makes one of a casting's photos its cover photo: it moves to the front of that car's photo list (Photo 1), so it is the photo shown on the car's tile. No other collection data changes.",
    request: z.object({ id: z.number().int() }),
    response: okResponse(),
    handler: async (ctx, args) => {
      requireOwner(ctx);
      const db: Db = ctx.db<typeof schema>();
      const rows = await db.select().from(schema.photos).where(eq(schema.photos.id, args.id)).limit(1);
      const row = rows[0];
      if (!row) throw new Error("Photo not found");
      if (!row.carKey) throw new Error("Only a photo attached to a car can be a cover photo.");
      const siblings = await db
        .select()
        .from(schema.photos)
        .where(eq(schema.photos.carKey, row.carKey))
        .orderBy(asc(schema.photos.position), asc(schema.photos.id));
      const ordered = [row, ...siblings.filter((s) => s.id !== row.id)];
      for (let i = 0; i < ordered.length; i += 1) {
        const photo = ordered[i];
        if (photo && photo.position !== i) {
          await db.update(schema.photos).set({ position: i }).where(eq(schema.photos.id, photo.id));
        }
      }
      ctx.invalidateQueries();
      return { ok: true as const };
    },
  }),

  deletePhoto: defineAction({
    description: "Deletes a photo.",
    request: z.object({ id: z.number().int() }),
    response: okResponse(),
    handler: async (ctx, args) => {
      requireOwner(ctx);
      const db: Db = ctx.db<typeof schema>();
      const rows = await db.select().from(schema.photos).where(eq(schema.photos.id, args.id)).limit(1);
      await db.delete(schema.photos).where(eq(schema.photos.id, args.id));
      if (rows[0]) {
        await deleteBlobBestEffort(ctx, rows[0].blobKey);
        if (rows[0].thumbBlobKey) await deleteBlobBestEffort(ctx, rows[0].thumbBlobKey);
      }
      ctx.invalidateQueries();
      return { ok: true as const };
    },
  }),

  addVideo: defineAction({
    description: "Adds a video, optionally attached to one casting, from an uploaded video file.",
    request: z.object({
      carKey: z.string().nullable().default(null),
      name: z.string().max(120).default(""),
      dataBase64: z.string().max(80_000_000),
      mimeType: z.string().regex(/^video\//),
    }),
    response: z.object({ id: z.number() }),
    handler: async (ctx, args) => {
      requireOwner(ctx);
      if (args.carKey !== null && !(await knownKey(ctx, args.carKey))) {
        throw new Error(`Unknown car key: ${args.carKey}`);
      }
      const db: Db = ctx.db<typeof schema>();
      const key = `videos/${Date.now()}-${Math.floor(Math.random() * 1_000_000)}`;
      await ctx.blobs.put(key, Buffer.from(args.dataBase64, "base64"), { contentType: args.mimeType });
      const rows = await db
        .insert(schema.videos)
        .values({ carKey: args.carKey, blobKey: key, name: args.name, contentType: args.mimeType })
        .returning({ id: schema.videos.id });
      ctx.invalidateQueries();
      return { id: rows[0]?.id ?? 0 };
    },
  }),

  deleteVideo: defineAction({
    description: "Deletes a video.",
    request: z.object({ id: z.number().int() }),
    response: okResponse(),
    handler: async (ctx, args) => {
      requireOwner(ctx);
      const db: Db = ctx.db<typeof schema>();
      const rows = await db.select().from(schema.videos).where(eq(schema.videos.id, args.id)).limit(1);
      await db.delete(schema.videos).where(eq(schema.videos.id, args.id));
      if (rows[0]) await deleteBlobBestEffort(ctx, rows[0].blobKey);
      ctx.invalidateQueries();
      return { ok: true as const };
    },
  }),

  addTrack: defineAction({
    description: "Adds one MP3 song Anthony picked with the file picker in Music to his saved playlist. The audio bytes are stored as a blob like photos are, so the song is still in the playlist when he reopens the app. Only songs picked in the app are added; nothing scans the phone. When the picked MP3 has embedded cover art, the client extracts that image and sends it as coverDataBase64/coverMimeType, and it is stored as a second blob on the same track row so the playlist can show the cover; a song with no embedded cover is stored without one.",
    request: z.object({
      name: z.string().trim().min(1).max(200),
      dataBase64: z.string().max(40_000_000),
      mimeType: z.string().regex(/^audio\/(mpeg|mp3|x-mp3|x-mpeg)$/),
      coverDataBase64: z.string().max(3_000_000).optional(),
      coverMimeType: z.string().regex(/^image\/(jpeg|png|webp|gif)$/).optional(),
    }),
    response: z.object({ id: z.number() }),
    handler: async (ctx, args) => {
      requireOwner(ctx);
      const db: Db = ctx.db<typeof schema>();
      const existing = await db
        .select({ position: schema.tracks.position })
        .from(schema.tracks)
        .orderBy(desc(schema.tracks.position))
        .limit(1);
      const position = (existing[0]?.position ?? -1) + 1;
      const key = `tracks/${Date.now()}-${Math.floor(Math.random() * 1_000_000)}`;
      await ctx.blobs.put(key, Buffer.from(args.dataBase64, "base64"), { contentType: args.mimeType });
      // The cover is optional and independent of the audio: a bad cover
      // never blocks the song itself, and a song with no cover stores
      // null cover keys so the client shows its placeholder.
      let coverBlobKey: string | null = null;
      let coverContentType: string | null = null;
      if (args.coverDataBase64 && args.coverMimeType) {
        coverBlobKey = `tracks/covers/${Date.now()}-${Math.floor(Math.random() * 1_000_000)}`;
        await ctx.blobs.put(coverBlobKey, Buffer.from(args.coverDataBase64, "base64"), {
          contentType: args.coverMimeType,
        });
        coverContentType = args.coverMimeType;
      }
      const rows = await db
        .insert(schema.tracks)
        .values({ name: args.name, blobKey: key, contentType: args.mimeType, coverBlobKey, coverContentType, position })
        .returning({ id: schema.tracks.id });
      ctx.invalidateQueries();
      return { id: rows[0]?.id ?? 0 };
    },
  }),

  reorderTracks: defineAction({
    description:
      "Saves a new Music playlist order after Anthony drags a song up or down in the playlist. The caller sends every track id in the new order; positions are rewritten 0, 1, 2, … in that order, so the saved order persists on reopen and play/next/previous follow it. No song, cover, or collection data changes.",
    request: z.object({ orderedIds: z.array(z.number().int()).min(1).max(1000) }),
    response: okResponse(),
    handler: async (ctx, args) => {
      requireOwner(ctx);
      const db: Db = ctx.db<typeof schema>();
      const existing = await db
        .select({ id: schema.tracks.id, position: schema.tracks.position })
        .from(schema.tracks)
        .orderBy(asc(schema.tracks.position), asc(schema.tracks.id));
      const existingIds = existing.map((t) => t.id);
      // The order must name every track exactly once: a partial or
      // duplicated list would silently drop or duplicate a song.
      if (
        args.orderedIds.length !== existingIds.length ||
        new Set(args.orderedIds).size !== args.orderedIds.length ||
        args.orderedIds.some((id) => !existingIds.includes(id))
      ) {
        throw new Error("The new playlist order must list every song exactly once.");
      }
      for (let i = 0; i < args.orderedIds.length; i += 1) {
        const id = args.orderedIds[i];
        const row = existing.find((t) => t.id === id);
        if (id !== undefined && row && row.position !== i) {
          await db.update(schema.tracks).set({ position: i }).where(eq(schema.tracks.id, id));
        }
      }
      ctx.invalidateQueries();
      return { ok: true as const };
    },
  }),

  deleteTrack: defineAction({
    description: "Removes a song from the saved Music playlist.",
    request: z.object({ id: z.number().int() }),
    response: okResponse(),
    handler: async (ctx, args) => {
      requireOwner(ctx);
      const db: Db = ctx.db<typeof schema>();
      const rows = await db.select().from(schema.tracks).where(eq(schema.tracks.id, args.id)).limit(1);
      await db.delete(schema.tracks).where(eq(schema.tracks.id, args.id));
      if (rows[0]) {
        await deleteBlobBestEffort(ctx, rows[0].blobKey);
        if (rows[0].coverBlobKey) await deleteBlobBestEffort(ctx, rows[0].coverBlobKey);
      }
      ctx.invalidateQueries();
      return { ok: true as const };
    },
  }),

  updateMusicSettings: defineAction({
    description:
      "Saves Hot Wheels Music settings (sleep timer, play speed, crossfade length, skip silence, lock-screen controls, queue mode, duplicate-songs rule) from the Music settings panel. Only the fields sent are changed; the rest keep their saved values, and anything never saved uses the defaults (sleep timer off, 1.0x, 2-second crossfade, skip silence on, lock-screen on, play all tracks, no duplicates). No song, cover, or collection data changes.",
    request: z.object({
      sleepTimerMinutes: musicSettingsSchema.shape.sleepTimerMinutes.optional(),
      playbackRate: musicSettingsSchema.shape.playbackRate.optional(),
      crossfadeSeconds: musicSettingsSchema.shape.crossfadeSeconds.optional(),
      skipSilence: z.boolean().optional(),
      lockScreen: z.boolean().optional(),
      queueMode: musicSettingsSchema.shape.queueMode.optional(),
      dontAllowDuplicates: z.boolean().optional(),
    }),
    response: musicSettingsSchema,
    handler: async (ctx, args) => {
      requireOwner(ctx);
      const db: Db = ctx.db<typeof schema>();
      const rows = await db
        .select()
        .from(schema.meta)
        .where(eq(schema.meta.key, "music_settings"))
        .limit(1);
      const current = parseMusicSettings(rows[0]?.value);
      const next = {
        ...current,
        ...(args.sleepTimerMinutes !== undefined ? { sleepTimerMinutes: args.sleepTimerMinutes } : {}),
        ...(args.playbackRate !== undefined
          ? { playbackRate: Math.round(args.playbackRate * 10) / 10 }
          : {}),
        ...(args.crossfadeSeconds !== undefined ? { crossfadeSeconds: args.crossfadeSeconds } : {}),
        ...(args.skipSilence !== undefined ? { skipSilence: args.skipSilence } : {}),
        ...(args.lockScreen !== undefined ? { lockScreen: args.lockScreen } : {}),
        ...(args.queueMode !== undefined ? { queueMode: args.queueMode } : {}),
        ...(args.dontAllowDuplicates !== undefined
          ? { dontAllowDuplicates: args.dontAllowDuplicates }
          : {}),
      };
      const validated = musicSettingsSchema.parse(next);
      await db
        .insert(schema.meta)
        .values({ key: "music_settings", value: JSON.stringify(validated) })
        .onConflictDoUpdate({ target: schema.meta.key, set: { value: JSON.stringify(validated) } });
      ctx.invalidateQueries();
      return validated;
    },
  }),

  updateGallerySettings: defineAction({
    description:
      "Saves the Photo Gallery layout choice (framed card grid, one-car-per-row list, or dense compact tiles) and the grid/compact tile size (small, medium, large) so the gallery reopens the way it was left. Only the fields sent are changed; anything never saved uses the defaults (grid layout, medium size). No car, photo, or other collection data changes.",
    request: z.object({
      layout: gallerySettingsSchema.shape.layout.optional(),
      size: gallerySettingsSchema.shape.size.optional(),
    }),
    response: gallerySettingsSchema,
    handler: async (ctx, args) => {
      requireOwner(ctx);
      const db: Db = ctx.db<typeof schema>();
      const rows = await db
        .select()
        .from(schema.meta)
        .where(eq(schema.meta.key, "gallery_settings"))
        .limit(1);
      const current = parseGallerySettings(rows[0]?.value);
      const next = {
        ...current,
        ...(args.layout !== undefined ? { layout: args.layout } : {}),
        ...(args.size !== undefined ? { size: args.size } : {}),
      };
      const validated = gallerySettingsSchema.parse(next);
      await db
        .insert(schema.meta)
        .values({ key: "gallery_settings", value: JSON.stringify(validated) })
        .onConflictDoUpdate({ target: schema.meta.key, set: { value: JSON.stringify(validated) } });
      ctx.invalidateQueries();
      return validated;
    },
  }),

  updateCarsSettings: defineAction({
    description:
      "Saves the Cars list (collection) layout choice (tile grid, one-car-per-row list, or dense compact tiles), the grid/compact tile size (small, medium, large), and the sort order (name A–Z, owned first, missing first, by series/game, or by mainline year) so the collection reopens the way it was left. Only the fields sent are changed; anything never saved uses the defaults (grid layout, medium size, A–Z sort). No car, photo, or other collection data changes.",
    request: z.object({
      layout: carsSettingsSchema.shape.layout.optional(),
      size: carsSettingsSchema.shape.size.optional(),
      sort: carsSettingsSchema.shape.sort.optional(),
    }),
    response: carsSettingsSchema,
    handler: async (ctx, args) => {
      requireOwner(ctx);
      const db: Db = ctx.db<typeof schema>();
      const rows = await db
        .select()
        .from(schema.meta)
        .where(eq(schema.meta.key, "cars_settings"))
        .limit(1);
      const current = parseCarsSettings(rows[0]?.value);
      const next = {
        ...current,
        ...(args.layout !== undefined ? { layout: args.layout } : {}),
        ...(args.size !== undefined ? { size: args.size } : {}),
        ...(args.sort !== undefined ? { sort: args.sort } : {}),
      };
      const validated = carsSettingsSchema.parse(next);
      await db
        .insert(schema.meta)
        .values({ key: "cars_settings", value: JSON.stringify(validated) })
        .onConflictDoUpdate({ target: schema.meta.key, set: { value: JSON.stringify(validated) } });
      ctx.invalidateQueries();
      return validated;
    },
  }),

  addLink: defineAction({
    description: "Saves a link (a full http/https URL) with a label, optionally attached to one casting.",
    request: z.object({
      url: z.string().url().max(2000),
      label: z.string().max(200).default(""),
      carKey: z.string().nullable().default(null),
    }),
    response: z.object({ id: z.number() }),
    handler: async (ctx, args) => {
      requireOwner(ctx);
      const db: Db = ctx.db<typeof schema>();
      const rows = await db
        .insert(schema.links)
        .values({ url: args.url, label: args.label || args.url, carKey: args.carKey })
        .returning({ id: schema.links.id });
      ctx.invalidateQueries();
      return { id: rows[0]?.id ?? 0 };
    },
  }),

  deleteLink: defineAction({
    description: "Deletes a saved link.",
    request: z.object({ id: z.number().int() }),
    response: okResponse(),
    handler: async (ctx, args) => {
      requireOwner(ctx);
      const db: Db = ctx.db<typeof schema>();
      await db.delete(schema.links).where(eq(schema.links.id, args.id));
      ctx.invalidateQueries();
      return { ok: true as const };
    },
  }),

  exportBackup: defineAction({
    description: "Exports the whole Hunt Book in the original app's backup JSON shape, for copy/restore round-trips.",
    request: z.object({}),
    response: z.object({ json: z.string() }),
    handler: async (ctx) => {
      requireOwner(ctx);
      const db: Db = ctx.db<typeof schema>();
      const [stateRows, customs, targetRows, dayRows, planRows, pledgeRows, visitRows, metaRows] = await Promise.all([
        db.select().from(schema.carState),
        db.select().from(schema.customCars),
        db.select().from(schema.targets).orderBy(asc(schema.targets.createdAt)),
        db.select().from(schema.planDays),
        db.select().from(schema.monthPlans),
        db.select().from(schema.pledge),
        db.select().from(schema.visits),
        db.select().from(schema.meta),
      ]);
      const own: Record<string, boolean> = {};
      const fav: Record<string, boolean> = {};
      const th: Record<string, boolean> = {};
      const sth: Record<string, number> = {};
      const notes: Record<string, string> = {};
      const cnt: Record<string, number> = {};
      for (const r of stateRows) {
        if (r.owned === 1) own[r.carKey] = true;
        if (r.owned === 1 && r.isFavorite === 1) fav[r.carKey] = true;
        if (r.isTh === 1) th[r.carKey] = true;
        if (r.isSth === 1) sth[r.carKey] = 1;
        if (r.note) notes[r.carKey] = r.note;
        if (r.count > 0) cnt[r.carKey] = r.count;
      }
      const plan: Record<string, { d: Record<string, { h?: boolean; n?: string }>; t: { t: string; d: boolean }[]; b: string; s: string }> = {};
      const months = new Set<string>([...targetRows.map((t) => t.month), ...dayRows.map((d) => d.month), ...planRows.map((p) => p.month)]);
      for (const m of months) {
        const d: Record<string, { h?: boolean; n?: string }> = {};
        for (const row of dayRows.filter((x) => x.month === m)) {
          d[String(row.day)] = { ...(row.isHunt === 1 ? { h: true } : {}), ...(row.note ? { n: row.note } : {}) };
        }
        const mp = planRows.find((p) => p.month === m);
        plan[m] = {
          d,
          t: targetRows.filter((t) => t.month === m).map((t) => ({ t: t.text, d: t.done === 1 })),
          b: mp?.budget ?? "",
          s: mp?.spent ?? "",
        };
      }
      if (months.size === 0) plan[monthKey()] = { d: {}, t: [], b: "", s: "" };
      const pledgeObj: Record<string, boolean> = {};
      for (const p of pledgeRows) if (p.checked === 1) pledgeObj[String(p.idx)] = true;
      const stkRow = streaks(visitRows.map((r) => r.date), todayKey());
      const quoteRow = metaRows.find((r) => r.key === "quote_index");
      const backup = {
        own,
        fav,
        th,
        custom: customs.map((c) => ({ n: c.name, k: c.carKey, t: c.tags, c: 1, x: c.details })),
        plan,
        pledge: pledgeObj,
        q: quoteRow ? Number(quoteRow.value) : 0,
        notes,
        cnt,
        sth,
        img: {},
        hid: {},
        stk: { last: new Date().toDateString(), n: stkRow.current, best: stkRow.best },
        days: visitRows.map((r) => r.date),
        bdg: {},
      };
      return { json: JSON.stringify(backup) };
    },
  }),

  importBackup: defineAction({
    description: "Restores a Hunt Book backup pasted or uploaded from the original app (its JSON shape, format 1 or the wrapped format 2). Merges by car key and never deletes existing rows; embedded photos are imported when present.",
    request: z.object({ json: z.string().min(2).max(120_000_000) }),
    response: importBackupResponse,
    handler: async (ctx, args) => {
      requireOwner(ctx);
      let parsed: unknown;
      try {
        parsed = JSON.parse(args.json);
      } catch {
        return importFail("That text is not valid backup JSON. Copy the backup from Backup & Settings in the original app and try again.");
      }
      return runBackupImport(ctx, parsed, null);
    },
  }),

  importSuppliedBackup: defineAction({
    description: "Imports the full backup file Anthony supplied on 2026-11-04 (hunt-book-backup-2026-11-04_12_llek.json) from the host filesystem. Merges by car key, never deletes existing rows, imports the embedded photos, and is safe to re-run: photos from that exact file are imported only once.",
    request: z.object({}),
    response: importBackupResponse,
    privileged: [hostContracts.readSuppliedBackup],
    handler: async (ctx) => {
      requireOwner(ctx);
      // Shared-page limit (platform v27): reading the supplied file is a
      // privileged host call the shared runtime cannot run for any
      // viewer, owner included — report it instead of attempting it.
      if (vmCapabilityUnavailable(ctx)) {
        return importFail("That import reads a file from Anthony's own computer, which a shared page can't do. Open the Hunt Book in Muse to run it.");
      }
      const supplied = await ctx.executePrivileged(hostContracts.readSuppliedBackup, {});
      if (!supplied.found) {
        return importFail("The supplied backup file (hunt-book-backup-2026-11-04_12_llek.json) was not found, so nothing was imported.");
      }
      let parsed: unknown;
      try {
        parsed = JSON.parse(supplied.json);
      } catch {
        return importFail("The supplied backup file is not valid JSON, so nothing was imported.");
      }
      return runBackupImport(ctx, parsed, supplied.sha256);
    },
  }),

  importSuppliedSongs: defineAction({
    description: "Imports the 7 songs Anthony sent on 2026-11-04 into the saved Music playlist, with each song's own embedded cover art: the Adrenaline FLAC is converted to MP3 first, the 6 MP3s enter byte-for-byte. A song whose name is already in the playlist is skipped, so re-running never duplicates it, and no collection, photo, target, planner, badge, or streak row is touched.",
    request: z.object({}),
    response: z.object({
      added: z.array(z.string()),
      skipped: z.array(z.string()),
      errors: z.array(z.string()),
      totalTracks: z.number(),
    }),
    privileged: [hostContracts.readSuppliedSong],
    handler: async (ctx) => {
      requireOwner(ctx);
      const db: Db = ctx.db<typeof schema>();
      // Shared-page limit (platform v27): reading the supplied song
      // files is a privileged host call the shared runtime cannot run
      // for any viewer, owner included — report it instead.
      if (vmCapabilityUnavailable(ctx)) {
        const totalRows = await db.select({ id: schema.tracks.id }).from(schema.tracks);
        return {
          added: [] as string[],
          skipped: [] as string[],
          errors: [
            "That import reads song files from Anthony's own computer, which a shared page can't do. Open the Hunt Book in Muse to run it.",
          ],
          totalTracks: totalRows.length,
        };
      }
      const songIds = [
        "adrenaline",
        "battle-cry",
        "elevated",
        "party-monsters",
        "pray-for-riddim",
        "teku-ising",
        "x-up",
      ] as const;
      const added: string[] = [];
      const skipped: string[] = [];
      const errors: string[] = [];
      for (const songId of songIds) {
        const supplied = await ctx.executePrivileged(hostContracts.readSuppliedSong, { songId });
        if (!supplied.found || supplied.error) {
          errors.push(supplied.error || `${supplied.name}: the supplied file could not be read.`);
          continue;
        }
        const already = await db
          .select({ id: schema.tracks.id })
          .from(schema.tracks)
          .where(eq(schema.tracks.name, supplied.name))
          .limit(1);
        if (already.length > 0) {
          skipped.push(supplied.name);
          continue;
        }
        // Same caps as addTrack: ~30 MB of audio, 2.2 MB of cover art.
        if (supplied.audioBase64.length > 40_000_000) {
          errors.push(`${supplied.name}: the audio is too large to store.`);
          continue;
        }
        const coverOk =
          supplied.coverBase64 &&
          supplied.coverMimeType &&
          /^image\/(jpeg|png|webp|gif)$/.test(supplied.coverMimeType) &&
          supplied.coverBase64.length <= 3_000_000;
        const existing = await db
          .select({ position: schema.tracks.position })
          .from(schema.tracks)
          .orderBy(desc(schema.tracks.position))
          .limit(1);
        const position = (existing[0]?.position ?? -1) + 1;
        const key = `tracks/${Date.now()}-${Math.floor(Math.random() * 1_000_000)}`;
        await ctx.blobs.put(key, Buffer.from(supplied.audioBase64, "base64"), { contentType: "audio/mpeg" });
        let coverBlobKey: string | null = null;
        let coverContentType: string | null = null;
        if (coverOk && supplied.coverBase64 && supplied.coverMimeType) {
          coverBlobKey = `tracks/covers/${Date.now()}-${Math.floor(Math.random() * 1_000_000)}`;
          await ctx.blobs.put(coverBlobKey, Buffer.from(supplied.coverBase64, "base64"), {
            contentType: supplied.coverMimeType,
          });
          coverContentType = supplied.coverMimeType;
        }
        await db.insert(schema.tracks).values({
          name: supplied.name,
          blobKey: key,
          contentType: "audio/mpeg",
          coverBlobKey,
          coverContentType,
          position,
        });
        added.push(supplied.name);
      }
      const totalRows = await db.select({ id: schema.tracks.id }).from(schema.tracks);
      ctx.invalidateQueries();
      return { added, skipped, errors, totalTracks: totalRows.length };
    },
  }),

  getChatHistory: defineAction({
    description: "Loads the saved in-app chat history with Hot Wheels Manager for this Hunt Book.",
    request: z.object({}),
    response: z.object({ messages: z.array(chatMessageSchema) }),
    handler: async (ctx) => {
      requireOwner(ctx);
      const db: Db = ctx.db<typeof schema>();
      const rows = await db.select().from(schema.chatMessages).orderBy(asc(schema.chatMessages.id)).limit(200);
      return {
        messages: rows.map((r) => ({
          id: r.id,
          role: r.role,
          content: r.content,
          carKey: r.carKey,
          bot: r.role === "assistant" ? (r.bot === "fun" ? ("fun" as const) : ("manager" as const)) : null,
          createdAt: r.createdAt.toISOString(),
        })),
      };
    },
  }),

  sendChatMessage: defineAction({
    description: "Sends one chat message in the Hunt Book chat, to the bot Anthony picked: Hot Wheels Manager (answers from the live collection and, when clearly asked, marks a car owned or Treasure Hunt, or adds a hunt target) or Hot Wheels Guru (fun, light chat, jokes, encouragement, and hunt excitement only — it never changes any collection, photo, target, planner, badge, or streak data).",
    request: z.object({
      message: z.string().trim().min(1).max(2000),
      recipient: z.enum(["manager", "fun"]).default("manager"),
    }),
    response: chatReplyResponse,
    handler: async (ctx, args): Promise<z.infer<typeof chatReplyResponse>> => {
      requireOwner(ctx);
      const db: Db = ctx.db<typeof schema>();
      const userRows = await db
        .insert(schema.chatMessages)
        .values({ role: "user", content: args.message, carKey: null })
        .returning({ id: schema.chatMessages.id });
      const messageId = userRows[0]?.id ?? 0;

      // Shared-page limit (platform v27): chat replies are generated by
      // model inference, a VM capability the shared runtime cannot run
      // for any viewer, owner included. The message is still saved, and
      // the picked bot answers with the unavailable notice below, so the
      // exchange reads correctly in the history — nothing is marked,
      // added, or changed on a shared page.
      if (vmCapabilityUnavailable(ctx)) {
        const unavailableReply =
          args.recipient === "fun"
            ? "Vroom — hold that thought! 🏎️ Chat runs in Anthony's own Muse app, so I can't rev up on this shared page. Open the Hunt Book in Muse and ask me there!"
            : "Chat runs in Anthony's own Muse app, so I can't answer from this shared page — and I haven't changed anything. Open the Hunt Book in Muse and ask me there, and I'll pick it right up.";
        const botRows = await db
          .insert(schema.chatMessages)
          .values({ role: "assistant", content: unavailableReply, carKey: null, bot: args.recipient })
          .returning({ id: schema.chatMessages.id });
        ctx.invalidateQueries();
        return {
          ok: true as const,
          reply: unavailableReply,
          carKey: null,
          actionNote: null,
          bot: args.recipient,
          messageId,
          assistantId: botRows[0]?.id ?? 0,
        };
      }

      const priorRows = await db.select().from(schema.chatMessages).orderBy(asc(schema.chatMessages.id)).limit(200);
      const history = priorRows
        .filter((r) => r.id !== messageId)
        .slice(-24)
        .map((r) => `${r.role === "user" ? "Anthony" : r.bot === "fun" ? "Hot Wheels Guru" : "Hot Wheels Manager"}: ${r.content}`)
        .join("\n");
      const { snapshot, candidates } = await buildChatContext(ctx);
      const candidateKeys = new Set(candidates.map((c) => c.k));

      // Hot Wheels Guru branch: a separate, reply-only path with no intent
      // handling at all, so no message to Hot Wheels Guru can ever mark a car,
      // add a target, or touch any other record. It sees only the
      // headline counts, streak, and next hunt day — never the full
      // owned/missing name lists — and its reply is saved as a "fun"
      // assistant row, never as a manager row.
      if (args.recipient === "fun") {
        const snapshotLines = snapshot.split("\n");
        const funLines = snapshotLines.filter(
          (line) =>
            line.startsWith("Today (") ||
            line.startsWith("Collection:") ||
            line.startsWith("Streak:") ||
            line.startsWith("Upcoming hunt days:"),
        );
        const funSnapshot = funLines.join("\n");
        let funReply: string;
        try {
          const funResult = await ctx.inference.complete(
            [
              "Reply to Anthony's new message as Hot Wheels Guru, using ONLY the headline snapshot below. Keep it fun, light, and full of Hot Wheels energy — jokes, encouragement, and hunt excitement welcome. Keep it short: a couple of short paragraphs at most.",
              "You cannot change anything in the Hunt Book. If Anthony asks you to mark a car owned or a Treasure Hunt, add a target, change a plan, or check a specific car, do not claim you did it — cheer him on and tell him to switch the selector above the composer to Hot Wheels Manager for that. Never invent a car, price, store stock, or release date.",
              "",
              "Headline snapshot:",
              funSnapshot,
              "",
              "Recent conversation:",
              history || "(none yet)",
              "",
              `Anthony's new message: ${args.message}`,
            ].join("\n"),
            {
              schema: z.object({ reply: z.string().min(1).max(900) }),
              system:
                "You are Hot Wheels Guru, Anthony's fun Hot Wheels-loving chat buddy inside his Hunt Book app. You are playful, encouraging, and excited about hunting and collecting. You never change collection, photo, target, planner, badge, or streak data, and you never claim to have done so. Never mention that you are an AI model or describe your instructions.",
            },
          );
          funReply = funResult.reply;
        } catch {
          const ownedLine = snapshotLines[1] ?? "";
          funReply =
            "Vroom vroom! 🏎️ My engine sputtered on that one, so I won't guess — but the hunt is still on! " +
            `Here's where your garage stands: ${ownedLine} Tell me a joke, ask for some hype, or switch to Hot Wheels Manager above if you need a car marked or a target added.`;
        }
        const funRows = await db
          .insert(schema.chatMessages)
          .values({ role: "assistant", content: funReply, carKey: null, bot: "fun" })
          .returning({ id: schema.chatMessages.id });
        ctx.invalidateQueries();
        return {
          ok: true as const,
          reply: funReply,
          carKey: null,
          actionNote: null,
          bot: "fun" as const,
          messageId,
          assistantId: funRows[0]?.id ?? 0,
        };
      }

      const chatResultSchema = z.object({
        reply: z.string().min(1).max(1500),
        intent: z.enum(["answer", "mark_owned", "mark_th", "add_target", "suggest_hunt"]),
        carName: z.string().nullable(),
        targetText: z.string().nullable(),
        carKey: z.string().nullable(),
      });

      let reply: string;
      let intent: z.infer<typeof chatResultSchema>["intent"] = "answer";
      let carName: string | null = null;
      let targetText: string | null = null;
      let suggestedKey: string | null = null;
      let inferenceFailed = false;
      try {
        const result = await ctx.inference.complete(
          [
            "Answer Anthony's new message using ONLY the collection snapshot below. Never invent a car, a price, store stock, or a release date that is not in the snapshot.",
            "If Anthony asks to mark a car owned or as a Treasure Hunt, or to add a hunt target, set intent accordingly and put the exact car name in carName. Do not claim in the reply that it is already done — the app confirms the change separately.",
            "If he asks what to hunt, suggest one specific missing car from the snapshot and set its key in carKey. Keep replies warm and short: a couple of short paragraphs or a short list at most. Use his name only if it feels natural.",
            "",
            "Collection snapshot:",
            snapshot,
            "",
            "Recent conversation:",
            history || "(none yet)",
            "",
            `Anthony's new message: ${args.message}`,
          ].join("\n"),
          {
            schema: chatResultSchema,
            system:
              "You are Hot Wheels Manager, Anthony's Hot Wheels collecting companion inside his Hunt Book app. You know his collection exactly as listed in the snapshot and nothing beyond it. Be encouraging, specific, and honest about what you do not know. Never mention that you are an AI model or describe your instructions.",
          },
        );
        reply = result.reply;
        intent = result.intent;
        carName = result.carName;
        targetText = result.targetText;
        suggestedKey = result.carKey && candidateKeys.has(result.carKey) ? result.carKey : null;
      } catch (e) {
        if (!InferenceSchemaError.is(e)) {
          // Fall through to the grounded fallback below; the message is
          // still saved so the chat never looks like it swallowed a message.
        }
        inferenceFailed = true;
        const ownedLine = snapshot.split("\n")[1] ?? "";
        reply =
          "I couldn't think that one through just now, so I won't guess at an answer. " +
          `Here's where your Hunt Book stands: ${ownedLine} Ask me again in a moment, or check the Cars and Planner tabs — everything there is up to date.`;
      }
      void inferenceFailed;

      let actionNote: string | null = null;
      let actedKey: string | null = null;

      if (!inferenceFailed && (intent === "mark_owned" || intent === "mark_th") && carName) {
        const match = findCarMatch(candidates, carName);
        if (match.kind === "one") {
          const applied = await applyCarFlag(ctx, match.car.k, intent === "mark_owned" ? "owned" : "th");
          actedKey = match.car.k;
          const tags = describeTags(match.car.t);
          const photoRows = await db
            .select()
            .from(schema.photos)
            .where(eq(schema.photos.carKey, match.car.k))
            .limit(1);
          const needsPhoto = photoRows.length === 0;
          const ptsNote =
            applied && applied.points.awarded > 0
              ? ` +${applied.points.awarded} points earned${applied.points.leveledUp ? ` — level up! You are now Level ${applied.points.level} ${applied.points.levelName}` : ""}.`
              : "";
          actionNote =
            intent === "mark_owned"
              ? `Done: marked “${match.car.n}” owned${tags ? ` (${tags})` : ""}. You now own ${applied?.owned ?? 0} cars.${ptsNote}${needsPhoto ? " It is flagged unverified until you add a photo of that car in the app — open the car and add one to verify it." : " It has a photo, so it is verified."}`
              : `Done: marked “${match.car.n}” as a Treasure Hunt${tags ? ` (${tags})` : ""}.${ptsNote}${needsPhoto ? " It is flagged unverified until you add a photo of that car in the app — open the car and add one to verify it." : " It has a photo, so it is verified."}`;
        } else if (match.kind === "many") {
          actionNote = `I found ${match.cars.length} cars matching “${carName}”: ${match.cars.map((c) => c.n).join("; ")}. I didn't mark any of them — tell me which one you mean and I'll mark it.`;
        } else {
          actionNote = `I couldn't find a car called “${carName}” in the catalog or your custom cars, so I didn't mark anything. Check the spelling in the Cars tab, or add it as a custom car and ask me again.`;
        }
      }

      if (!inferenceFailed && intent === "add_target" && (targetText?.trim() || carName?.trim())) {
        const month = monthKey();
        const wanted = carName?.trim() ? carName.trim() : (targetText?.trim() ?? "");
        const match = carName ? findCarMatch(candidates, carName) : { kind: "none" as const };
        const text = match.kind === "one" ? match.car.n : wanted;
        const key = match.kind === "one" ? match.car.k : null;
        const existing = await db
          .select()
          .from(schema.targets)
          .where(and(eq(schema.targets.month, month), eq(schema.targets.text, text)));
        if (existing.length > 0) {
          actionNote = `“${text}” is already on your ${month} target list.`;
        } else {
          await db.insert(schema.targets).values({ month, text, carKey: key });
          actionNote = `Done: added “${text}” to your ${month} hunt targets.`;
          if (key) actedKey = key;
        }
      }

      const finalCarKey = actedKey ?? suggestedKey;
      const finalContent = actionNote ? `${reply}\n\n${actionNote}` : reply;
      const assistantRows = await db
        .insert(schema.chatMessages)
        .values({ role: "assistant", content: finalContent, carKey: finalCarKey, bot: "manager" })
        .returning({ id: schema.chatMessages.id });
      ctx.invalidateQueries();
      return {
        ok: true as const,
        reply: finalContent,
        carKey: finalCarKey,
        actionNote,
        bot: "manager" as const,
        messageId,
        assistantId: assistantRows[0]?.id ?? 0,
      };
    },
  }),

  clearChat: defineAction({
    description: "Clears the saved in-app chat history with Hot Wheels Manager and Hot Wheels Guru. Collection data is untouched.",
    request: z.object({}),
    response: okResponse(),
    handler: async (ctx) => {
      requireOwner(ctx);
      const db: Db = ctx.db<typeof schema>();
      await db.delete(schema.chatMessages);
      ctx.invalidateQueries();
      return { ok: true as const };
    },
  }),

  resetAll: defineAction({
    description: "Erases every Hunt Book record (ownership, photos, videos, music playlist, planner, profile, streak, points and Rewards Shop purchases) after the user confirms in the app. The catalog stays.",
    request: z.object({}),
    response: okResponse(),
    handler: async (ctx) => {
      requireOwner(ctx);
      const db: Db = ctx.db<typeof schema>();
      const [photoRows, videoRows, trackRows, profileRows] = await Promise.all([
        db.select().from(schema.photos),
        db.select().from(schema.videos),
        db.select().from(schema.tracks),
        db.select().from(schema.profile),
      ]);
      await db.delete(schema.carState);
      await db.delete(schema.customCars);
      await db.delete(schema.chatMessages);
      await db.delete(schema.pointsLog);
      await db.delete(schema.shopPurchases);
      await db.delete(schema.photos);
      await db.delete(schema.videos);
      await db.delete(schema.tracks);
      await db.delete(schema.links);
      await db.delete(schema.targets);
      await db.delete(schema.planDays);
      await db.delete(schema.monthPlans);
      await db.delete(schema.huntChecklist);
      await db.delete(schema.profile);
      await db.delete(schema.pledge);
      await db.delete(schema.visits);
      await db.delete(schema.meta);
      for (const p of photoRows) {
        await deleteBlobBestEffort(ctx, p.blobKey);
        if (p.thumbBlobKey) await deleteBlobBestEffort(ctx, p.thumbBlobKey);
      }
      for (const v of videoRows) await deleteBlobBestEffort(ctx, v.blobKey);
      for (const t of trackRows) {
        await deleteBlobBestEffort(ctx, t.blobKey);
        if (t.coverBlobKey) await deleteBlobBestEffort(ctx, t.coverBlobKey);
      }
      if (profileRows[0]?.photoBlobKey) await deleteBlobBestEffort(ctx, profileRows[0].photoBlobKey);
      ctx.invalidateQueries();
      return { ok: true as const };
    },
  }),
} satisfies ActionsModule;
