CREATE TABLE `catalog_overrides` (
	`car_key` text PRIMARY KEY NOT NULL,
	`tags` text DEFAULT '' NOT NULL,
	`details` text DEFAULT '' NOT NULL,
	`updated_at` integer NOT NULL
);
