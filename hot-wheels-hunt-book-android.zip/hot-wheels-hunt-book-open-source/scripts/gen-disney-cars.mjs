// Generates the Disney Pixar Cars rows in customize/my-cars.csv from
// customize/disney-cars.json (parsed from the Disney Pixar Cars Wiki's
// "List of vehicles by collector number").
//
//   node scripts/gen-disney-cars.mjs   (or: bun run gen-disney-cars)
//
// Rows it owns are the ones whose key starts with "dc"; any other rows
// already in my-cars.csv are kept untouched, and the Disney rows are
// appended after them in page order. Re-running is idempotent.
// `bun run build` then folds my-cars.csv into the generated catalog
// (scripts/apply-customize.mjs) — never hand-edit client/src/catalog.ts.
import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const at = (...p) => join(root, ...p);

function parseCsv(text) {
  const rows = [];
  let row = [];
  let field = "";
  let quoted = false;
  const src = text.replace(/^\uFEFF/, "");
  for (let i = 0; i < src.length; i++) {
    const ch = src[i];
    if (quoted) {
      if (ch === '"') {
        if (src[i + 1] === '"') { field += '"'; i++; } else quoted = false;
      } else field += ch;
    } else if (ch === '"') quoted = true;
    else if (ch === ",") { row.push(field); field = ""; }
    else if (ch === "\n" || ch === "\r") {
      if (ch === "\r" && src[i + 1] === "\n") i++;
      row.push(field); field = "";
      rows.push(row); row = [];
    } else field += ch;
  }
  if (field !== "" || row.length > 0) { row.push(field); rows.push(row); }
  return rows.filter((r) => r.some((c) => c.trim() !== ""));
}

function csvField(v) {
  const s = String(v ?? "");
  return /[",\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

/** Clean first-release display: '2006_ZZ003 Standalone', '2009 Mainline'. */
function firstReleaseDisplay(v) {
  const base = v.code ? `${v.year}_${v.code}` : `${v.year}`;
  return `${base} ${v.series}`;
}

function detailsFor(v) {
  const parts = ["Disney Pixar Cars", v.section, v.subsection];
  if (v.number !== null && v.number !== undefined) parts.push(`Collector #${v.number}`);
  parts.push(`First release ${firstReleaseDisplay(v)}`);
  if (v.chase) parts.push("Chase");
  if (v.unreleased) parts.push("Unreleased");
  if (v.notes) parts.push(v.notes);
  return parts.join(" · ");
}

const data = JSON.parse(readFileSync(at("customize", "disney-cars.json"), "utf8"));
const vehicles = data.vehicles ?? [];
if (vehicles.length === 0) throw new Error("disney-cars.json has no vehicles");

const seen = new Set();
const rows = vehicles.map((v) => {
  if (!v.key || !v.key.startsWith("dc")) throw new Error(`bad key for "${v.name}": ${v.key}`);
  if (seen.has(v.key)) throw new Error(`duplicate Disney key "${v.key}"`);
  seen.add(v.key);
  return [v.name, "Disney", detailsFor(v), v.key];
});

const csvPath = at("customize", "my-cars.csv");
const kept = [];
if (existsSync(csvPath)) {
  const existing = parseCsv(readFileSync(csvPath, "utf8"));
  const head = (existing[0] ?? []).map((h) => h.trim().toLowerCase());
  if (head.join(",") !== "name,tags,details,key") {
    throw new Error(`customize/my-cars.csv has an unexpected header: ${existing[0]?.join(",")}`);
  }
  for (const r of existing.slice(1)) {
    const key = (r[3] ?? "").trim();
    if (key.startsWith("dc")) continue; // owned by this generator
    kept.push(r);
  }
}

const out = ["name,tags,details,key"]
  .concat(kept.map((r) => r.map(csvField).join(",")))
  .concat(rows.map((r) => r.map(csvField).join(",")))
  .join("\n") + "\n";
writeFileSync(csvPath, out);
console.log(`gen-disney-cars: ${rows.length} Disney Cars rows in customize/my-cars.csv (${kept.length} other rows kept)`);
