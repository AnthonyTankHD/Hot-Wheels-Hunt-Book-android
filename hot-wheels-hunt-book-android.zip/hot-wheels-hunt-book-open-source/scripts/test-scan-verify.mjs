/* Harness for scan-to-verify (client/src/ScanVerify.tsx).
   Runs the real module code in Bun with stubbed camera/DOM pieces —
   no phone, no live camera. Exits non-zero if any check fails. */

import {
  captureFrame,
  captureSize,
  classifyCameraError,
  parseSiteCrossCheck,
  saveScannedPhoto,
  scanPhotoPayload,
  SCAN_MAX_SIDE_PX,
} from "../client/src/ScanVerify.tsx";

let pass = 0;
let fail = 0;
function check(name, ok, extra = "") {
  if (ok) {
    pass++;
    console.log(`  ok - ${name}`);
  } else {
    fail++;
    console.log(`  FAIL - ${name} ${extra}`);
  }
}
function eq(a, b) {
  return JSON.stringify(a) === JSON.stringify(b);
}

// --- captureSize: downscale cap -------------------------------------
console.log("captureSize");
check("4000x3000 caps to 1600x1200", eq(captureSize(4000, 3000), { width: 1600, height: 1200 }));
check("800x600 unchanged", eq(captureSize(800, 600), { width: 800, height: 600 }));
check("1920x1080 caps to 1600x900", eq(captureSize(1920, 1080), { width: 1600, height: 900 }));
check("100x5000 caps to 32x1600", eq(captureSize(100, 5000), { width: 32, height: 1600 }));
check("max side constant is 1600", SCAN_MAX_SIDE_PX === 1600);

// --- captureFrame: stub video + stub canvas --------------------------
console.log("captureFrame");
function stubCanvas(blobBytes) {
  const canvas = {
    width: 0,
    height: 0,
    drawn: null,
    getContext: () => ({
      drawImage: (video, x, y, w, h) => {
        canvas.drawn = { w, h };
      },
    }),
    toBlob: (cb) => cb(blobBytes === null ? null : new Blob([blobBytes], { type: "image/jpeg" })),
  };
  return canvas;
}
{
  const video = { videoWidth: 1920, videoHeight: 1080 };
  const canvas = stubCanvas("x".repeat(100));
  const file = await captureFrame(video, canvas);
  check("returns a File", file instanceof File);
  check("file named scan.jpg", file?.name === "scan.jpg");
  check("file is image/jpeg", file?.type === "image/jpeg");
  check("file holds the captured bytes", file?.size === 100);
  check("canvas sized to capped frame", canvas.width === 1600 && canvas.height === 900);
  check("drawImage drew at capped size", eq(canvas.drawn, { w: 1600, h: 900 }));
  check("server mime regex accepts image/jpeg", /^image\/(jpeg|png|webp|gif)$/.test(file?.type ?? ""));
}
{
  const file = await captureFrame({ videoWidth: 0, videoHeight: 0 }, stubCanvas("x"));
  check("no frame yet returns null", file === null);
}
{
  const file = await captureFrame({ videoWidth: 800, videoHeight: 600 }, stubCanvas(null));
  check("canvas toBlob null returns null", file === null);
}

// --- classifyCameraError ---------------------------------------------
console.log("classifyCameraError");
check("NotAllowedError -> denied", classifyCameraError({ name: "NotAllowedError" }).kind === "denied");
check("SecurityError -> denied", classifyCameraError({ name: "SecurityError" }).kind === "denied");
check("NotFoundError -> missing", classifyCameraError({ name: "NotFoundError" }).kind === "missing");
check("OverconstrainedError -> missing", classifyCameraError({ name: "OverconstrainedError" }).kind === "missing");
check("AbortError -> unavailable", classifyCameraError({ name: "AbortError" }).kind === "unavailable");
check("plain Error -> unavailable", classifyCameraError(new Error("boom")).kind === "unavailable");
check("denied message points at the picker", classifyCameraError({ name: "NotAllowedError" }).message.includes("pick a photo"));

// --- parseSiteCrossCheck ----------------------------------------------
console.log("parseSiteCrossCheck");
{
  const c = parseSiteCrossCheck({
    x: "Imported from allhotwheels.com · Superstar Speeders Star Wars 4-pack (2026) · 1 release (2026)",
    custom: false,
  });
  check("imported with series: hasSiteData", c.hasSiteData === true);
  check("imported with series: series parsed", c.hasSiteData && c.series === "Superstar Speeders Star Wars 4-pack (2026)");
  check("imported with series: releases 1", c.hasSiteData && c.releases === 1);
  check("imported with series: span 2026", c.hasSiteData && c.span === "2026");
}
{
  const c = parseSiteCrossCheck({
    x: "Imported from allhotwheels.com · Mainline 2020, HW Turbo 2021 +1 more · 5 releases (2020–2021)",
    custom: false,
  });
  check("multi-series: series kept with +more", c.hasSiteData && c.series === "Mainline 2020, HW Turbo 2021 +1 more");
  check("multi-series: releases 5", c.hasSiteData && c.releases === 5);
  check("multi-series: span 2020–2021", c.hasSiteData && c.span === "2020–2021");
}
{
  const c = parseSiteCrossCheck({ x: "Imported from allhotwheels.com · 3 releases (2020–2024)", custom: false });
  check("imported no series: series null", c.hasSiteData && c.series === null);
  check("imported no series: releases 3", c.hasSiteData && c.releases === 3);
  check("imported no series: span kept", c.hasSiteData && c.span === "2020–2024");
}
{
  const c = parseSiteCrossCheck({ x: "2022 · HW id", custom: false });
  check("built-in details: no site data", c.hasSiteData === false && c.custom === false);
  check("built-in details: app details kept", !c.hasSiteData && c.details === "2022 · HW id");
}
{
  const c = parseSiteCrossCheck({ x: "My custom car", custom: true });
  check("custom car: no site data", c.hasSiteData === false && c.custom === true);
}
{
  const c = parseSiteCrossCheck({ x: undefined, custom: false });
  check("no details: no site data", c.hasSiteData === false);
}

// --- scanPhotoPayload (stubbed Image + canvas) ------------------------
console.log("scanPhotoPayload");
function installDomStubs({ imageOk = true } = {}) {
  globalThis.URL.createObjectURL = () => "blob:stub";
  globalThis.URL.revokeObjectURL = () => {};
  globalThis.Image = class {
    constructor() {
      this.naturalWidth = 800;
      this.naturalHeight = 600;
    }
    set src(_v) {
      queueMicrotask(() => {
        if (imageOk) this.onload?.();
        else this.onerror?.(new Error("load failed"));
      });
    }
  };
  globalThis.document = {
    createElement: () => ({
      width: 0,
      height: 0,
      getContext: () => ({ drawImage() {} }),
      toDataURL: () => "data:image/jpeg;base64," + "A".repeat(100),
    }),
  };
}
{
  installDomStubs({ imageOk: true });
  const bytes = new Uint8Array([0xff, 0xd8, 0xff, 0xe0, 1, 2, 3]);
  const file = new File([bytes], "picked.jpg", { type: "image/jpeg" });
  const payload = await scanPhotoPayload(file);
  check("payload mimeType image/jpeg", payload.mimeType === "image/jpeg");
  check(
    "payload dataBase64 is the file bytes",
    Buffer.from(payload.dataBase64, "base64").equals(Buffer.from(bytes)),
  );
  check("payload carries the thumbnail", payload.thumbDataBase64 === "A".repeat(100));
  check("payload under the server 14MB cap", payload.dataBase64.length < 14_000_000);
}
{
  installDomStubs({ imageOk: false });
  const file = new File([new Uint8Array([1, 2, 3])], "bad.jpg", { type: "image/jpeg" });
  const payload = await scanPhotoPayload(file);
  check("undecodable image: photo still saves without a thumb", payload.dataBase64.length > 0 && payload.thumbDataBase64 === undefined);
}

// --- saveScannedPhoto: orchestration with injected fakes --------------
console.log("saveScannedPhoto");
{
  const order = [];
  const calls = [];
  const fakeAddPhoto = async (args) => {
    order.push("addPhoto");
    calls.push(args);
    return { points: { awarded: 5, leveledUp: false, levelName: "Collector" } };
  };
  const fakeApplyMark = async () => {
    order.push("applyMark");
    return { points: { awarded: 25, leveledUp: true, levelName: "Hunter" } };
  };
  const file = new File([new Uint8Array([9, 9, 9])], "scan.jpg", { type: "image/jpeg" });
  let payloadFile = null;
  const result = await saveScannedPhoto({
    carKey: "bone-shaker",
    file,
    applyMark: fakeApplyMark,
    addPhoto: fakeAddPhoto,
    buildPayload: async (f) => {
      payloadFile = f;
      return { dataBase64: "AAA", mimeType: "image/jpeg", thumbDataBase64: "BBB" };
    },
  });
  check("addPhoto called once with the car key", calls.length === 1 && calls[0].carKey === "bone-shaker");
  check("addPhoto got the captured bytes + thumb", calls[0].dataBase64 === "AAA" && calls[0].thumbDataBase64 === "BBB");
  check("payload built from the captured file", payloadFile === file);
  check("applyMark runs after addPhoto", eq(order, ["addPhoto", "applyMark"]));
  check("earned combines photo + mark points", result.earned === 30);
  check("level-up from the mark is reported", result.leveled === true && result.levelName === "Hunter");
}
{
  let markCalled = false;
  let threw = null;
  try {
    await saveScannedPhoto({
      carKey: "bone-shaker",
      file: new File([new Uint8Array([1])], "scan.jpg", { type: "image/jpeg" }),
      applyMark: async () => {
        markCalled = true;
      },
      addPhoto: async () => {
        throw new Error("blob store down");
      },
      buildPayload: async () => ({ dataBase64: "AAA", mimeType: "image/jpeg" }),
    });
  } catch (e) {
    threw = e;
  }
  check("addPhoto failure: mark never applied", markCalled === false);
  check("addPhoto failure: error propagates", threw instanceof Error);
}

// --- unverified clears when the scan photo saves ----------------------
// The server derives unverified as "owned and no photo row" (owned
// cars minus the set of car keys with photos). A scan save is the
// same addPhoto call the picker uses, so the photo row it inserts
// clears the flag by the same rule.
console.log("unverified derivation (server rule)");
{
  const owned = [{ k: "bone-shaker", n: "Bone Shaker" }];
  const isUnverified = (carKey, photoCarKeys) => !photoCarKeys.has(carKey);
  check("owned car with no photo is unverified", isUnverified("bone-shaker", new Set()) === true);
  const afterScan = new Set(["bone-shaker"]); // the photo row addPhoto inserted
  check("same car with a scan photo is verified", owned.every((c) => !isUnverified(c.k, afterScan)));
}

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail === 0 ? 0 : 1);
