/* Harness for the local Hot Wheels Manager (client/src/manager.ts).
   Runs the real engine against a small fixture collection — no phone,
   no network, no model. Exits non-zero if any check fails. */

import {
  answerManager,
  buildManagerSnapshot,
  findCars,
  MANAGER_HELP,
} from "../client/src/manager.ts";

let pass = 0;
let fail = 0;
function check(name, ok, extra = "") {
  if (ok) {
    pass++;
    console.log(`  ok - ${name}`);
  } else {
    fail++;
    console.log(`  FAIL - ${name} ${extra}`);
  }
}
function eq(a, b) {
  return JSON.stringify(a) === JSON.stringify(b);
}
function has(text, sub) {
  return typeof text === "string" && text.includes(sub);
}

// --- fixture collection ---------------------------------------------
const C = (key, name, tags, extra = {}) => ({
  key,
  name,
  tags,
  details: extra.details,
  owned: false,
  isTh: false,
  isSth: false,
  copies: 0,
  unverified: false,
  hasPhoto: false,
  custom: false,
  ...extra,
});

const cars = [
  C("boneshaker", "Bone Shaker", "F", { owned: true, copies: 2, hasPhoto: true }),
  C("twinmill", "Twin Mill", "F"),
  C("dccarsm1", "Lightning McQueen", "C"),
  C("dccarsmmater", "Mater", "C"),
  C("dccarsm5", "Dinoco Lightning McQueen", "C", { owned: true, hasPhoto: true }),
  C("dccarsm35", "Lightning McQueen with Bumper Stickers", "C"),
  C("supertuned", "Super Tuned", "M", { owned: true, copies: 1, isTh: true, hasPhoto: true }),
  C("16angels", "16 Angels", "F", { owned: true, copies: 1, isTh: true, isSth: true, hasPhoto: true }),
  C("customotto", "Custom Otto", "M", { owned: true, copies: 1, hasPhoto: true }),
  C("asphaltassault", "Asphalt Assault", "M"),
  C("powerpistons", "Power Pistons", "M"),
  C("doublevision", "Double Vision", "M", { owned: true, copies: 1, unverified: true }),
  C("sharkruiser", "Sharkruiser", "F"),
  C("phantomracer", "Phantom Racer", "", { owned: true, copies: 1, hasPhoto: true, custom: true }),
  C("slingshot", "Sling Shot", "M", { hasPhoto: true }),
];

const snap = {
  name: "Anthony",
  cars,
  total: 15,
  owned: 7,
  copies: 8,
  th: 2,
  sth: 1,
  fantasyOwned: 2,
  unverified: 1,
  photoCount: 7,
  streakCurrent: 17,
  streakBest: 17,
  pointsLifetime: 3030,
  pointsBalance: 2480,
  level: 5,
  levelName: "Garage Legend",
  targets: [{ id: 1, month: "2026-11", text: "Twin Mill", carKey: "twinmill", done: false }],
  month: "2026-11",
  dayOfYear: 100,
};

const ask = (q) => answerManager(q, snap);

// --- buildManagerSnapshot mapping ------------------------------------
const mapped = buildManagerSnapshot(
  {
    profileName: "Anthony",
    stats: { total: 15, owned: 7, copies: 8, th: 2, sth: 1, fantasyOwned: 2, unverified: 1, photoCount: 7 },
    streak: { current: 17, best: 17 },
    points: { lifetime: 3030, balance: 2480, level: 5, levelName: "Garage Legend" },
    targets: snap.targets,
    carStates: [
      { carKey: "boneshaker", owned: true, isTh: false, isSth: false, count: 2, unverified: false },
      { carKey: "dccarsm1", owned: false, isTh: false, isSth: false, count: 0, unverified: false },
      { carKey: "doublevision", owned: true, isTh: false, isSth: false, count: 1, unverified: true },
    ],
    photos: [
      { carKey: "boneshaker", url: "blob://photo1" },
      { carKey: "doublevision", url: "" },
    ],
  },
  [
    { k: "boneshaker", n: "Bone Shaker", t: "F", custom: false },
    { k: "dccarsm1", n: "Lightning McQueen", t: "C", custom: false },
    { k: "doublevision", n: "Double Vision", t: "M", custom: false },
  ],
  "2026-11",
  100,
);
check("snapshot maps owned + copies + photo", mapped.cars[0].owned && mapped.cars[0].copies === 2 && mapped.cars[0].hasPhoto);
check("snapshot: no-photo car hasPhoto false (empty url)", !mapped.cars[2].hasPhoto && mapped.cars[2].unverified);
check("snapshot: Disney car present, tag C", mapped.cars[1].tags === "C" && mapped.cars[1].key.startsWith("dc"));
check("snapshot carries stats/points/streak", mapped.owned === 7 && mapped.pointsBalance === 2480 && mapped.streakCurrent === 17);

// --- name matching ----------------------------------------------------
check("findCars exact match", findCars("Bone Shaker", snap).kind === "one");
check("findCars exact Disney McQueen", findCars("Lightning McQueen", snap).kind === "one" && findCars("Lightning McQueen", snap).car.key === "dccarsm1");
check("findCars ambiguous McQueen is many", findCars("McQueen", snap).kind === "many");
check("findCars unknown is none", findCars("Zebra Zoomer", snap).kind === "none");

// --- counts ------------------------------------------------------------
check("count owned", has(ask("how many do I own").text, "7 cars"));
check("count TH", has(ask("how many Treasure Hunts do I have").text, "2 Treasure Hunts"));
check("count STH", has(ask("how many Super Treasure Hunts").text, "1 Super Treasure Hunt"));
check("count Disney owned/total", has(ask("how many Disney Cars do I own").text, "1 of 4"));
check("count missing", has(ask("how many cars am I still missing").text, "8 of 15"));
check("count need photo", has(ask("how many need a photo").text, "1 car"));
check("count copies", has(ask("how many copies do I have").text, "8 copies"));
check("count fantasy", has(ask("how many Fantasy cars do I own").text, "2 of 4"));

// --- lists -------------------------------------------------------------
{
  const r = ask("show my Treasure Hunts");
  check("list TH has both, filter th", r.items?.length === 2 && r.action?.kind === "openFilter" && r.action.filter === "th");
}
{
  const r = ask("show my Disney Cars");
  check("list Disney has 4, all dc keys, filter C", r.items?.length === 4 && r.items.every((i) => i.key.startsWith("dc")) && r.action?.filter === "C");
}
{
  const r = ask("show cars needing a photo");
  check("list needs-photo is Double Vision, filter unv", r.items?.length === 1 && r.items[0].name === "Double Vision" && r.action?.filter === "unv");
}
{
  const r = ask("show unowned Mainline");
  check("list unowned Mainline", r.items?.length === 3 && r.items.some((i) => i.name === "Asphalt Assault") && r.action?.filter === "M");
}
{
  const r = ask("show my Fantasy cars");
  check("list Fantasy owned", r.items?.length === 2 && r.items.every((i) => ["Bone Shaker", "16 Angels"].includes(i.name)));
}

// --- streak / points / level ------------------------------------------
check("streak answer", has(ask("what's my streak").text, "17 day"));
check("points answer", has(ask("how many points do I have").text, "2,480") && has(ask("how many points do I have").text, "3,030"));
check("level answer", has(ask("what level am I").text, "Level 5 Garage Legend"));
check("greeting with question falls through to streak", has(ask("hey what's my streak").text, "17 day"));

// --- status checks ------------------------------------------------------
check("do I own Bone Shaker: yes", has(ask("do I own Bone Shaker").text, "Yes"));
check("do I own Twin Mill: no", has(ask("do I own Twin Mill").text, "Not yet"));
check("is Super Tuned a TH: yes", has(ask("is Super Tuned a Treasure Hunt").text, "Yes"));
check("is 16 Angels an STH: yes", has(ask("is 16 Angels a Super Treasure Hunt").text, "Yes"));
check("copies of Bone Shaker: 2", has(ask("how many copies of Bone Shaker").text, "2 copies"));
check("about Bone Shaker", has(ask("tell me about Bone Shaker").text, "You own it"));

// --- mark TH: photo gate -------------------------------------------------
{
  const r = ask("mark Custom Otto as a Treasure Hunt");
  check("mark TH owned+photo -> markTh action", r.action?.kind === "markTh" && r.action.carKey === "customotto");
}
{
  const r = ask("mark Twin Mill as a Treasure Hunt");
  check("mark TH unowned -> verifyTh, never direct", r.action?.kind === "verifyTh" && r.action.carKey === "twinmill");
}
{
  const r = ask("mark Double Vision as a Treasure Hunt");
  check("mark TH owned no-photo -> verifyTh", r.action?.kind === "verifyTh" && r.action.carKey === "doublevision");
}
check("mark TH already TH: no action", ask("mark Super Tuned as a Treasure Hunt").action === undefined);

// --- mark owned: photo gate ----------------------------------------------
{
  const r = ask("mark Twin Mill owned");
  check("mark owned no-photo -> verifyOwn, never direct", r.action?.kind === "verifyOwn" && r.action.carKey === "twinmill");
}
{
  const r = ask("mark Asphalt Assault owned");
  check("mark owned no-photo (2) -> verifyOwn", r.action?.kind === "verifyOwn");
}
check("mark owned already owned: no action", ask("mark Bone Shaker owned").action === undefined);
{
  const r = ask("mark Sling Shot owned");
  check("mark owned WITH photo on file -> direct markOwned", r.action?.kind === "markOwned" && r.action.carKey === "slingshot");
}
{
  const r = ask("mark McQueen owned");
  check("mark owned ambiguous -> many, no action", r.action === undefined && has(r.text, "found 3 cars"));
}
check("mark owned unknown car -> no action", ask("mark Zebra Zoomer owned").action === undefined);
// Sweep: no car without a photo ever gets a direct markOwned.
{
  let bad = [];
  for (const c of cars) {
    const r = ask(`mark ${c.name} owned`);
    if (!c.hasPhoto && r.action?.kind === "markOwned") bad.push(c.name);
    if (c.owned && r.action) bad.push(`${c.name} (owned, still got an action)`);
  }
  check("sweep: no direct markOwned without photo", bad.length === 0, bad.join(", "));
}

// --- STH from chat ---------------------------------------------------------
{
  const r = ask("mark Custom Otto as a Super Treasure Hunt");
  check("mark STH offers TH first (markTh for owned+photo car)", r.action?.kind === "markTh" && has(r.text, "Treasure Hunt first"));
}

// --- targets ---------------------------------------------------------------
check("add existing target -> already on list", has(ask("add Twin Mill to my targets").text, "already on"));
{
  const r = ask("add Asphalt Assault to my targets");
  check("add new target -> addTarget action", r.action?.kind === "addTarget" && r.action.carKey === "asphaltassault");
}
{
  const r = ask("remove Twin Mill from my targets");
  check("remove target -> removeTarget id 1", r.action?.kind === "removeTarget" && r.action.targetId === 1);
}
check("show targets lists Twin Mill", has(ask("show my targets").text, "Twin Mill"));

// --- hunt pick ---------------------------------------------------------------
{
  const a = ask("pick a hunt for me");
  const b = ask("pick a hunt for me");
  const pickName = a.items?.[0]?.name ?? "";
  const pool = ["Asphalt Assault", "Power Pistons"];
  check("hunt pick is an unowned Mainline car", pool.includes(pickName), pickName);
  check("hunt pick deterministic", a.text === b.text);
  check("hunt pick offers addTarget", a.action?.kind === "addTarget");
}

// --- fun / help / unknown ------------------------------------------------------
check("joke has no action", ask("tell me a joke").action === undefined && ask("tell me a joke").text.length > 10);
check("hype has no action", ask("let's go hunting").action === undefined);
check("greeting alone", has(ask("hey").text, "Hey"));
check("help lists capabilities", ask("help").text === MANAGER_HELP);
check("unknown input -> help fallback, no fake answer", has(ask("what's the weather like").text, "Here's what I can do"));
check("empty input -> prompt, no crash", ask("   ").text.length > 0);

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail === 0 ? 0 : 1);
