// Adds the native Android project (first run) and patches it:
//   - camera permission, so "take a photo / record a video" works
//   - launcher icon generated from assets/icon.png
// Run after `bun run build:android`:
//   node scripts/prepare-android.mjs
import { execSync } from "node:child_process";
import { existsSync, readFileSync, writeFileSync } from "node:fs";

const run = (cmd) => execSync(cmd, { stdio: "inherit" });

if (!existsSync("android")) {
  run("npx cap add android");
}
run("npx cap sync android");

const manifestPath = "android/app/src/main/AndroidManifest.xml";
let manifest = readFileSync(manifestPath, "utf8");
if (!manifest.includes("android.permission.CAMERA")) {
  const perms =
    '    <uses-permission android:name="android.permission.CAMERA" />\n' +
    '    <uses-feature android:name="android.hardware.camera" android:required="false" />\n';
  const marker = /(\s*<uses-permission android:name="android.permission.INTERNET" \/>)/;
  if (marker.test(manifest)) {
    manifest = manifest.replace(marker, `$1\n${perms.trimEnd()}`);
  } else {
    manifest = manifest.replace("</manifest>", `${perms}</manifest>`);
  }
  writeFileSync(manifestPath, manifest);
  console.log("patched AndroidManifest.xml (camera)");
}

try {
  run("npx --yes @capacitor/assets generate --android --iconBackgroundColor '#0b3d91' --iconBackgroundColorDark '#0b3d91'");
} catch {
  console.warn("icon generation failed — the APK will use the default Capacitor icon");
}
