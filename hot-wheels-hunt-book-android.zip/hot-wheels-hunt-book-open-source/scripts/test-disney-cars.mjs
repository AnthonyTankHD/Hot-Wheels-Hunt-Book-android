// Harness for the Disney Pixar Cars section.
//   bun scripts/test-disney-cars.mjs
//
// Checks, against the durable artifacts (no live page fetch):
//  (a) parsed row count matches the source page tables minus exact
//      dupes (360 raw rows, 0 exact dupes in the Sept 2026 snapshot —
//      the wiki had already fixed the April dupes), and the dedupe rule
//      itself, exercised on synthetic duplicate rows;
//  (b) every Disney key unique, and none collides with any other
//      catalog key (checked against the GENERATED catalog);
//  (c) spot checks from the brief (incl. unnumbered entries and the
//      same-name-different-number entries that must stay separate);
//  (d) the logo asset exists (JPEG bytes) and is wired into App.tsx
//      (import, filter header, sidebar row);
//  plus: my-cars.csv rows match the JSON one-for-one, tags are Disney
//  only (no TH/STH), details carry section/collector/first-release,
//  lists.json has the C tag + filter, and the build stamp / shell
//  version are untouched (v67, shell 6).
import { existsSync, readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const at = (...p) => join(root, ...p);

let pass = 0;
let fail = 0;
const failures = [];
function check(name, ok, extra = "") {
  if (ok) { pass++; console.log(`  ok   ${name}`); }
  else { fail++; failures.push(name); console.log(`  FAIL ${name}${extra ? ` — ${extra}` : ""}`); }
}

function parseCsv(text) {
  const rows = [];
  let row = [];
  let field = "";
  let quoted = false;
  const src = text.replace(/^\uFEFF/, "");
  for (let i = 0; i < src.length; i++) {
    const ch = src[i];
    if (quoted) {
      if (ch === '"') {
        if (src[i + 1] === '"') { field += '"'; i++; } else quoted = false;
      } else field += ch;
    } else if (ch === '"') quoted = true;
    else if (ch === ",") { row.push(field); field = ""; }
    else if (ch === "\n" || ch === "\r") {
      if (ch === "\r" && src[i + 1] === "\n") i++;
      row.push(field); field = "";
      rows.push(row); row = [];
    } else field += ch;
  }
  if (field !== "" || row.length > 0) { row.push(field); rows.push(row); }
  return rows.filter((r) => r.some((c) => c.trim() !== ""));
}

const data = JSON.parse(readFileSync(at("customize", "disney-cars.json"), "utf8"));
const vehicles = data.vehicles ?? [];

// (a) row counts: raw rows per table, minus exact dupes, == unique rows.
console.log("(a) parsed rows vs source tables");
const expectedRaw = {
  "Cars / Mainline singles": 162,
  "Cars / Mega Size": 26,
  "Cars / Trucks & Trailers": 23,
  "Cars Toon / Mainline singles": 46,
  "Cars Toon / Deluxe": 31,
  "Cars 2 / Mainline singles": 54,
  "Cars 2 / Deluxe": 18,
};
for (const [table, n] of Object.entries(expectedRaw)) {
  const [section, subsection] = table.split(" / ");
  const got = vehicles.filter((v) => v.section === section && v.subsection === subsection).length;
  check(`${table}: ${n} rows`, got === n, `got ${got}`);
}
check(`raw total ${data._rawRows}`, data._rawRows === 360, `got ${data._rawRows}`);
check(`dupes removed ${data._dupesRemoved} (Sept snapshot: wiki already fixed the April dupes)`, data._dupesRemoved === 0);
// The dedupe rule itself, on synthetic duplicate rows:
const dupeKey = (v) => [v.section, v.subsection, v.number, v.name, v.firstRelease].join("|");
const seenKeys = new Set();
let syntheticDupes = 0;
for (const v of [...vehicles, ...vehicles.slice(0, 5)]) {
  const k = dupeKey(v);
  if (seenKeys.has(k)) syntheticDupes++;
  seenKeys.add(k);
}
check("dedupe rule drops exact duplicates (5 synthetic re-rows)", syntheticDupes === 5, `got ${syntheticDupes}`);
// The April dupe names each appear exactly once now.
for (const n of ["Petrol Pulaski", "Edwin Kranks", "Jamie", 'Timothy "Timezone" Truecoat', "T.J.", "Miles Axlerod", "Otis", "Fabrizio", "Mary Esgocar"]) {
  check(`April dupe "${n}" appears once`, vehicles.filter((v) => v.name === n).length === 1);
}

// (b) keys unique + no collision with the rest of the catalog.
console.log("(b) keys");
const keys = vehicles.map((v) => v.key);
check("all 360 Disney keys unique", new Set(keys).size === keys.length);
check("all Disney keys carry the dc- prefix", keys.every((k) => k.startsWith("dc")));
const catalogTs = readFileSync(at("server", "src", "catalog.ts"), "utf8");
const catalogKeys = [...catalogTs.matchAll(/"k":"([^"]+)"/g)].map((m) => m[1]);
check(`generated catalog has ${catalogKeys.length} entries`, catalogKeys.length === 5188 + 360, `got ${catalogKeys.length}`);
check("generated catalog keys unique", new Set(catalogKeys).size === catalogKeys.length);
const nonDc = new Set(catalogKeys.filter((k) => !k.startsWith("dc")));
check("no Disney key collides with a non-Disney catalog key", keys.every((k) => !nonDc.has(k)));
const dcInCatalog = keys.filter((k) => catalogKeys.includes(k));
check("all 360 Disney keys present in the generated catalog", dcInCatalog.length === 360, `got ${dcInCatalog.length}`);

// (c) spot checks.
console.log("(c) spot checks");
const find = (name, section, number) =>
  vehicles.find((v) => v.name === name && v.section === section && (number === undefined || v.number === number));
const spots = [
  ["Lightning McQueen", "Cars", 1, "dccarsm1"],
  ["Dinoco Lightning McQueen", "Cars", 5, "dccarsm5"],
  ['Strip Weathers aka "The King"', "Cars", 47, "dccarsm47"],
  ["Sally", "Cars", 48, "dccarsm48"], // wiki numbered her #48 after April
  ["Mater", "Cars", undefined, "dccarsmmater"], // still unnumbered
  ["Burnt Lightning McQueen", "Cars Toon", 1, "dctoonm1"],
  ["Finn McMissile", "Cars 2", undefined, "dccars2mfinnmcmissile"],
  ["Francesco Bernoulli", "Cars 2", undefined, "dccars2mfrancescobernoulli"],
  ["Hydraulic Ramone", "Cars", 13, "dccarsm13"],
  ["Hydraulic Ramone", "Cars 2", 19, "dccars2m19"],
  ["Kabuto", "Cars Toon", 12, "dctoonm12"],
  ["Kabuto", "Cars 2", 35, "dccars2m35"],
  ["Chuki", "Cars", 59, "dccarsm59"],
  ["Chuki", "Cars", 90, "dccarsm90"],
];
for (const [name, section, number, key] of spots) {
  const v = find(name, section, number);
  check(`${name} (${section}${number === undefined ? ", unnumbered" : ` #${number}`})`, Boolean(v) && v.key === key,
    v ? `key=${v.key}` : "missing");
}
const chase = vehicles.find((v) => v.name === "Lightning McQueen with Bumper Stickers");
check("Chase flagged: Lightning McQueen with Bumper Stickers", Boolean(chase?.chase));
const unrel = vehicles.find((v) => v.name === "N2O Cola Pitty (short)");
check("Unreleased flagged: N2O Cola Pitty (short)", Boolean(unrel?.unreleased));

// my-cars.csv matches the JSON one-for-one.
console.log("my-cars.csv <-> JSON");
const csvRows = parseCsv(readFileSync(at("customize", "my-cars.csv"), "utf8"));
const dcRows = csvRows.slice(1).filter((r) => (r[3] ?? "").startsWith("dc"));
check("my-cars.csv has 360 Disney rows", dcRows.length === 360, `got ${dcRows.length}`);
const csvByKey = new Map(dcRows.map((r) => [r[3], r]));
let csvMatch = true;
for (const v of vehicles) {
  const r = csvByKey.get(v.key);
  if (!r || r[0] !== v.name || r[1] !== "Disney") { csvMatch = false; break; }
  if (!r[2].includes("Disney Pixar Cars") || !r[2].includes(v.section) || !r[2].includes(v.subsection)) { csvMatch = false; break; }
  if (v.number !== null && v.number !== undefined && !r[2].includes(`Collector #${v.number}`)) { csvMatch = false; break; }
  if (v.chase && !r[2].includes("Chase")) { csvMatch = false; break; }
  if (v.unreleased && !r[2].includes("Unreleased")) { csvMatch = false; break; }
}
check("every CSV row matches its JSON vehicle (name/tags/details)", csvMatch);
check("no Disney row carries TH/STH tags", dcRows.every((r) => r[1] === "Disney"));

// lists.json: tag + filter.
console.log("lists.json");
const lists = JSON.parse(readFileSync(at("customize", "lists.json"), "utf8"));
check('tag "C" = Disney', lists.tags?.C?.label === "Disney");
check('filter ["C", "Disney Cars"] present', (lists.filters ?? []).some(([c, l]) => c === "C" && l === "Disney Cars"));

// (d) logo asset + wiring.
console.log("(d) logo");
const logoPath = at("client", "src", "assets", "disney-cars-logo.png");
check("logo asset exists", existsSync(logoPath));
const logoBytes = existsSync(logoPath) ? readFileSync(logoPath) : Buffer.alloc(0);
check("logo is PNG bytes (89504e47…)", logoBytes.length > 1000 && logoBytes[0] === 0x89 && logoBytes[1] === 0x50 && logoBytes[2] === 0x4e && logoBytes[3] === 0x47);
check("logo PNG has an alpha channel (IHDR color type 6 = RGBA)", logoBytes.length > 29 && logoBytes[25] === 6);
const appTsx = readFileSync(at("client", "src", "App.tsx"), "utf8");
check("App.tsx imports the logo", appTsx.includes('disney-cars-logo.png'));
check("filter header shows the logo for filter C", appTsx.includes('filter === "C" ? { src: disneyCarsImg'));
check("sidebar has a Disney Cars row", appTsx.includes('"Disney Cars", countFor("C")'));
check('picker groups include Disney Cars', appTsx.includes('{ code: "C", label: "Disney Cars" }'));

// (e) Disney tile placeholder: an unowned Disney car with no photo shows
// the Cars logo instead of the Hot Wheels flame; Hot Wheels cars keep it.
console.log("(e) Disney tile placeholder");
check("isDisneyCar helper defined (dc key or tag C)", appTsx.includes("function isDisneyCar") && appTsx.includes('car.k.startsWith("dc")') && appTsx.includes('car.t.includes("C")'));
const placeholderSwaps = (appTsx.match(/\? disneyCarsImg : logoImg/g) ?? []).length;
check("placeholder swaps to the Cars logo at 4 sites (grid, favorites, car of the day, picker)", placeholderSwaps === 4);
check("Hot Wheels flame placeholder still used for other cars", appTsx.includes("src={logoImg}"));
check("grid tile keeps its lock icon", appTsx.includes('className="tile-lock"'));

// Stamp + shell untouched (stamp is v69 since the transparent-logo swap; shell stays 6).
console.log("stamp / shell");
const stamp = readFileSync(at("client", "src", "build-stamp.ts"), "utf8");
check('SPLASH_BUILD_STAMP is v69-2026-11-25-disney-logo', stamp.includes('"v69-2026-11-25-disney-logo"'));
check("SHELL_VERSION still 6", /SHELL_VERSION = 6/.test(stamp));

console.log(`\n${pass} passed, ${fail} failed${fail ? ` — ${failures.join("; ")}` : ""}`);
process.exit(fail ? 1 : 0);
