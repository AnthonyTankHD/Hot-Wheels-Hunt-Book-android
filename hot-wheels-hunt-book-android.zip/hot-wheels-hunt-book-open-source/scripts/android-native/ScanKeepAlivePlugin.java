package com.huntbook.hotwheels;

import android.Manifest;
import android.content.Intent;
import android.os.Build;

import com.getcapacitor.JSObject;
import com.getcapacitor.PermissionState;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;

/**
 * Bridge for the allhotwheels.com scan's background keep-alive
 * (ScanKeepAliveService). The web page calls startScan when a scan
 * starts, updateScan after every page, and stopScan on every exit path
 * (finish, pause, stop, error) — the service and its wake lock must
 * never outlive the scan.
 *
 * Every method resolves even when the service cannot start (for
 * example the notification permission was denied): the scan then runs
 * in the foreground exactly as it did before, and never fails because
 * of the keep-alive.
 */
@CapacitorPlugin(
    name = "ScanKeepAlive",
    permissions = {
        @Permission(alias = "notifications", strings = { Manifest.permission.POST_NOTIFICATIONS })
    }
)
public class ScanKeepAlivePlugin extends Plugin {

    private Intent serviceIntent(String action, PluginCall call) {
        Intent svc = new Intent(getContext(), ScanKeepAliveService.class);
        svc.setAction(action);
        if (call != null) {
            svc.putExtra(ScanKeepAliveService.EXTRA_PAGE, call.getInt("page", 0));
            svc.putExtra(ScanKeepAliveService.EXTRA_TOTAL_PAGES, call.getInt("totalPages", 0));
            svc.putExtra(ScanKeepAliveService.EXTRA_CASTINGS, call.getInt("castings", 0));
        }
        return svc;
    }

    /** Starts the scan's foreground service (and its wake lock). */
    @PluginMethod
    public void startScan(PluginCall call) {
        try {
            Intent svc = serviceIntent(ScanKeepAliveService.ACTION_START, call);
            if (Build.VERSION.SDK_INT >= 26) {
                getContext().startForegroundService(svc);
            } else {
                getContext().startService(svc);
            }
        } catch (Exception ignored) {
            // the scan still runs while the app is open
        }
        call.resolve();
    }

    /** Refreshes the notification's page / casting counts. */
    @PluginMethod
    public void updateScan(PluginCall call) {
        try {
            // The service is already running, so delivering a new
            // intent to it is allowed even from the background.
            getContext().startService(serviceIntent(ScanKeepAliveService.ACTION_UPDATE, call));
        } catch (Exception ignored) {
            // a missed progress update is harmless
        }
        call.resolve();
    }

    /** Stops the service and releases its wake lock. */
    @PluginMethod
    public void stopScan(PluginCall call) {
        try {
            getContext().stopService(serviceIntent(ScanKeepAliveService.ACTION_STOP, null));
        } catch (Exception ignored) {
            // nothing to stop
        }
        call.resolve();
    }

    /** Android 13+: asks about the scan notification. Never blocks the scan. */
    @PluginMethod
    public void requestNotifications(PluginCall call) {
        if (Build.VERSION.SDK_INT < 33 || getPermissionState("notifications") == PermissionState.GRANTED) {
            JSObject res = new JSObject();
            res.put("granted", true);
            call.resolve(res);
            return;
        }
        requestPermissionForAlias("notifications", call, "notifCallback");
    }

    @PermissionCallback
    private void notifCallback(PluginCall call) {
        JSObject res = new JSObject();
        res.put("granted", getPermissionState("notifications") == PermissionState.GRANTED);
        call.resolve(res);
    }
}
