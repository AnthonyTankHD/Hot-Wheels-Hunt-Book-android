package com.huntbook.hotwheels;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;

/**
 * Shows the "music playing" notification. While it runs, Android keeps the
 * app (and the music in it) alive when the app is minimized.
 */
public class MusicKeepAliveService extends Service {
    private static final String CHANNEL = "hw_music";
    private static final int NOTIF_ID = 4711;
    public static final String ACTION_PREV = "com.huntbook.hotwheels.MEDIA_PREV";
    public static final String ACTION_TOGGLE = "com.huntbook.hotwheels.MEDIA_TOGGLE";
    public static final String ACTION_NEXT = "com.huntbook.hotwheels.MEDIA_NEXT";
    private static boolean foreground = false;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent != null ? intent.getAction() : null;
        if (action != null) {
            // A notification button was pressed: pass it to the web page.
            String name = null;
            if (ACTION_PREV.equals(action)) {
                name = "prev";
            } else if (ACTION_TOGGLE.equals(action)) {
                name = "toggle";
            } else if (ACTION_NEXT.equals(action)) {
                name = "next";
            }
            if (name != null) {
                MusicLibraryPlugin.dispatch(name);
            }
            if (!foreground) {
                stopSelf();
            }
            return START_NOT_STICKY;
        }
        String title = intent != null ? intent.getStringExtra("title") : null;
        String artist = intent != null ? intent.getStringExtra("artist") : null;
        Notification n = build(title, artist);
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
            } else {
                startForeground(NOTIF_ID, n);
            }
            foreground = true;
        } catch (Exception e) {
            stopSelf();
        }
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        foreground = false;
        super.onDestroy();
    }

    private PendingIntent actionIntent(String action, int code) {
        Intent i = new Intent(this, MusicKeepAliveService.class);
        i.setAction(action);
        int f = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) {
            f |= PendingIntent.FLAG_IMMUTABLE;
        }
        return PendingIntent.getService(this, code, i, f);
    }

    private Notification build(String title, String artist) {
        Notification.Builder b;
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm != null && nm.getNotificationChannel(CHANNEL) == null) {
                nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Music playing", NotificationManager.IMPORTANCE_LOW));
            }
            b = new Notification.Builder(this, CHANNEL);
        } else {
            b = new Notification.Builder(this);
        }
        b.setSmallIcon(android.R.drawable.ic_media_play);
        b.setContentTitle(title != null && !title.isEmpty() ? title : "Hot Wheels Hunt Book");
        b.setContentText(artist != null && !artist.isEmpty() ? artist : "Music playing");
        b.setOngoing(true);
        b.addAction(android.R.drawable.ic_media_previous, "Previous", actionIntent(ACTION_PREV, 1));
        b.addAction(android.R.drawable.ic_media_pause, "Pause", actionIntent(ACTION_TOGGLE, 2));
        b.addAction(android.R.drawable.ic_media_next, "Next", actionIntent(ACTION_NEXT, 3));
        b.setStyle(new Notification.MediaStyle().setShowActionsInCompactView(0, 1, 2));
        Intent open = getPackageManager().getLaunchIntentForPackage(getPackageName());
        if (open != null) {
            int f = PendingIntent.FLAG_UPDATE_CURRENT;
            if (Build.VERSION.SDK_INT >= 23) {
                f |= PendingIntent.FLAG_IMMUTABLE;
            }
            b.setContentIntent(PendingIntent.getActivity(this, 0, open, f));
        }
        return b.build();
    }
}
