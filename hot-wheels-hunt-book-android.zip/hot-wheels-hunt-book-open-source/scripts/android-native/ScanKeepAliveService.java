package com.huntbook.hotwheels;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;

/**
 * Keeps the allhotwheels.com scan running while the app is minimized or
 * the screen is off, and shows its progress in a notification.
 *
 * Modeled on MusicKeepAliveService: a foreground service with an ongoing
 * notification, plus a partial wake lock so the phone's CPU keeps fetching
 * pages with the screen off. The wake lock is held only while a scan is
 * running: it is taken when the scan starts and released the moment the
 * scan stops for any reason (finish, pause, stop, error) or when the
 * service is destroyed. If the app is swiped away the service dies with
 * it — the scan's progress is already saved, so it resumes on reopen.
 *
 * The service never starts itself: the web page starts it when a scan
 * starts and stops it on every exit path. Starting it while the app is
 * in the foreground is always allowed; updates are delivered to the
 * already-running service, which is also allowed from the background.
 */
public class ScanKeepAliveService extends Service {
    private static final String CHANNEL = "hw_scan";
    private static final int NOTIF_ID = 4712;
    public static final String ACTION_START = "com.huntbook.hotwheels.SCAN_START";
    public static final String ACTION_UPDATE = "com.huntbook.hotwheels.SCAN_UPDATE";
    public static final String ACTION_STOP = "com.huntbook.hotwheels.SCAN_STOP";
    public static final String EXTRA_PAGE = "page";
    public static final String EXTRA_TOTAL_PAGES = "totalPages";
    public static final String EXTRA_CASTINGS = "castings";

    /** Safety net: never hold the wake lock longer than a scan can take. */
    private static final long WAKE_LOCK_TIMEOUT_MS = 2 * 60 * 60 * 1000L;

    private static volatile boolean running = false;
    private PowerManager.WakeLock wakeLock = null;

    /** True while a scan is running in the background (MainActivity reads this). */
    public static boolean isRunning() {
        return running;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent != null ? intent.getAction() : null;
        if (action == null) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (ACTION_STOP.equals(action)) {
            stopScanning();
            return START_NOT_STICKY;
        }
        if (ACTION_UPDATE.equals(action)) {
            if (running) {
                NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
                if (nm != null) {
                    nm.notify(NOTIF_ID, build(intent));
                }
            }
            return START_NOT_STICKY;
        }
        if (ACTION_START.equals(action)) {
            acquireWakeLock();
            Notification n = build(intent);
            try {
                if (Build.VERSION.SDK_INT >= 29) {
                    startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
                } else {
                    startForeground(NOTIF_ID, n);
                }
                running = true;
            } catch (Exception e) {
                // No foreground service (e.g. the notification permission
                // is missing on this build): the scan still runs while
                // the app is open, it just has no background protection.
                releaseWakeLock();
                stopSelf();
            }
            return START_NOT_STICKY;
        }
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        releaseWakeLock();
        running = false;
        super.onDestroy();
    }

    private void stopScanning() {
        releaseWakeLock();
        running = false;
        try {
            stopForeground(true);
        } catch (Exception ignored) {
            // Already stopped.
        }
        stopSelf();
    }

    private void acquireWakeLock() {
        try {
            if (wakeLock != null && wakeLock.isHeld()) return;
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            if (pm == null) return;
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "HuntBook:ScanKeepAlive");
            // A timeout is the backstop: even if a stop call were ever
            // lost, the lock lets go on its own instead of draining the
            // battery overnight. A full scan takes about 40 minutes.
            wakeLock.acquire(WAKE_LOCK_TIMEOUT_MS);
        } catch (Exception ignored) {
            wakeLock = null;
        }
    }

    private void releaseWakeLock() {
        try {
            if (wakeLock != null && wakeLock.isHeld()) {
                wakeLock.release();
            }
        } catch (Exception ignored) {
            // Already released.
        }
        wakeLock = null;
    }

    private Notification build(Intent intent) {
        int page = intent != null ? intent.getIntExtra(EXTRA_PAGE, 0) : 0;
        int totalPages = intent != null ? intent.getIntExtra(EXTRA_TOTAL_PAGES, 0) : 0;
        int castings = intent != null ? intent.getIntExtra(EXTRA_CASTINGS, 0) : 0;
        Notification.Builder b;
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm != null && nm.getNotificationChannel(CHANNEL) == null) {
                nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Scan running", NotificationManager.IMPORTANCE_LOW));
            }
            b = new Notification.Builder(this, CHANNEL);
        } else {
            b = new Notification.Builder(this);
        }
        b.setSmallIcon(android.R.drawable.ic_menu_search);
        b.setContentTitle("Scanning allhotwheels.com");
        String pages = totalPages > 0 ? "Page " + page + " of ~" + totalPages : "Page " + page;
        b.setContentText(pages + " · " + castings + " castings found");
        if (totalPages > 0 && page >= 0) {
            b.setProgress(totalPages, Math.min(page, totalPages), false);
        }
        b.setOngoing(true);
        b.setOnlyAlertOnce(true);
        Intent open = getPackageManager().getLaunchIntentForPackage(getPackageName());
        if (open != null) {
            int f = PendingIntent.FLAG_UPDATE_CURRENT;
            if (Build.VERSION.SDK_INT >= 23) {
                f |= PendingIntent.FLAG_IMMUTABLE;
            }
            b.setContentIntent(PendingIntent.getActivity(this, 0, open, f));
        }
        return b.build();
    }
}
