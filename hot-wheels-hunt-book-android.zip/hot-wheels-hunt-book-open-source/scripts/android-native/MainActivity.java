package com.huntbook.hotwheels;

import android.os.Bundle;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(MusicLibraryPlugin.class);
        registerPlugin(ScanKeepAlivePlugin.class);
        super.onCreate(savedInstanceState);
    }

    @Override
    public void onPause() {
        super.onPause();
        // Keep the web view running so music continues when the app is minimized,
        // and so a scan keeps fetching pages with the app minimized or the
        // screen off (its foreground service holds a wake lock for that).
        boolean keepWebView = MusicLibraryPlugin.keepAlive || ScanKeepAliveService.isRunning();
        if (keepWebView && getBridge() != null && getBridge().getWebView() != null) {
            getBridge().getWebView().onResume();
            getBridge().getWebView().resumeTimers();
        }
    }
}
