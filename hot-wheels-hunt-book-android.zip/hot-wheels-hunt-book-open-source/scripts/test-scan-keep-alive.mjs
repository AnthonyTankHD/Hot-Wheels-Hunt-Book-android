// Harness for the scan keep-alive (client/src/scan-keep-alive.ts).
// Run: bun scripts/test-scan-keep-alive.mjs
//
// The native service / wake lock cannot run in this VM, so this tests
// the JS side only: the keep-alive starts with the scan, updates carry
// the right page/casting counts, it stops on finish / pause / stop /
// error, a failing or missing plugin never blocks the scan, and a saved
// mid-scan state loads back (the "picks up where it left off" claim).
// The fake plugin stands in for the real ScanKeepAlive native plugin;
// the fake runner stands in for runScan (real network) and drives the
// same onProgress calls runScan makes after every page.

const store = new Map();
globalThis.localStorage = {
  getItem: (k) => (store.has(k) ? store.get(k) : null),
  setItem: (k, v) => store.set(k, v),
  removeItem: (k) => store.delete(k),
};

let passed = 0;
let failed = 0;
function check(name, ok, detail = "") {
  if (ok) {
    passed++;
    console.log(`  ok  ${name}`);
  } else {
    failed++;
    console.log(`  FAIL ${name}${detail ? ` — ${detail}` : ""}`);
  }
}
const tick = () => new Promise((r) => setTimeout(r, 0));
const fresh = (tag) => import(`../client/src/scan-keep-alive.ts?harness=${tag}`);
const ahw = await import("../client/src/ahw-import.ts");

function recordingPlugin() {
  const calls = [];
  return {
    calls,
    async requestNotifications() {
      calls.push(["requestNotifications"]);
      return { granted: true };
    },
    async startScan(o) {
      calls.push(["startScan", { ...o }]);
    },
    async updateScan(o) {
      calls.push(["updateScan", { ...o }]);
    },
    async stopScan() {
      calls.push(["stopScan"]);
    },
  };
}

function throwingPlugin() {
  const calls = [];
  const boom = async (...args) => {
    calls.push(args);
    throw new Error("native boom");
  };
  return {
    calls,
    requestNotifications: () => boom("requestNotifications"),
    startScan: (o) => boom("startScan", o),
    updateScan: (o) => boom("updateScan", o),
    stopScan: () => boom("stopScan"),
  };
}

function fakeState(requests, castingNames) {
  const castings = {};
  for (const n of castingNames) castings[n.toLowerCase().replace(/[^a-z0-9]/g, "")] = { name: n };
  return { years: [2024, 2023], page: 1, castings, requests, releasesSeen: requests * 24, done: false };
}

/** Fake runner: reports two pages, then finishes / pauses / throws. */
function fakeRunner(mode) {
  return async (state, _handle, onProgress) => {
    const s1 = fakeState(state.requests + 10, ["Bone Shaker", "Twin Mill", "Power Rocket"]);
    onProgress(s1, "Year 2024, page 3 of 12");
    const s2 = fakeState(state.requests + 11, ["Bone Shaker", "Twin Mill", "Power Rocket", "Croc Rod", "Mad Manga"]);
    onProgress(s2, "Year 2024, page 4 of 12");
    if (mode === "error") throw new Error("The site refused the request (403). The scan has stopped.");
    if (mode === "pause") return { ...s2, done: false };
    return { ...s2, done: true };
  };
}

// 1. The notification question is asked once, then never again.
{
  console.log("ask once:");
  const m = await fresh("ask");
  const p = recordingPlugin();
  await m.askScanNotifications(p);
  await m.askScanNotifications(p);
  check("requestNotifications called exactly once", p.calls.filter((c) => c[0] === "requestNotifications").length === 1, JSON.stringify(p.calls));
}

// 2. Finish: start -> updates with the right counts -> stop, in order.
{
  console.log("finish path:");
  const m = await fresh("finish");
  const p = recordingPlugin();
  const state = fakeState(0, []);
  const out = await m.runScanWithKeepAlive(state, { stopped: false }, () => {}, fakeRunner("finish"), p);
  await tick();
  const kinds = p.calls.map((c) => c[0]);
  check("returns the finished state", out.done === true);
  check("asks about notifications once", kinds.filter((k) => k === "requestNotifications").length === 1);
  check("startScan first, with page 0 / 1,552 pages / 0 castings", JSON.stringify(p.calls[1]) === JSON.stringify(["startScan", { page: 0, totalPages: 1552, castings: 0 }]), JSON.stringify(p.calls[1]));
  const updates = p.calls.filter((c) => c[0] === "updateScan");
  check("two progress updates", updates.length === 2, JSON.stringify(updates));
  check("update 1 carries page 10 / 3 castings", JSON.stringify(updates[0]?.[1]) === JSON.stringify({ page: 10, totalPages: 1552, castings: 3 }), JSON.stringify(updates[0]));
  check("update 2 carries page 11 / 5 castings", JSON.stringify(updates[1]?.[1]) === JSON.stringify({ page: 11, totalPages: 1552, castings: 5 }), JSON.stringify(updates[1]));
  check("stopScan last, exactly once", kinds[kinds.length - 1] === "stopScan" && kinds.filter((k) => k === "stopScan").length === 1, kinds.join(","));
  check(
    "order is ask, start, updates, stop",
    kinds.join(",") === "requestNotifications,startScan,updateScan,updateScan,stopScan",
    kinds.join(","),
  );
}

// 3. Pause: the service still stops.
{
  console.log("pause path:");
  const m = await fresh("pause");
  const p = recordingPlugin();
  const out = await m.runScanWithKeepAlive(fakeState(40, ["Bone Shaker"]), { stopped: true }, () => {}, fakeRunner("pause"), p);
  await tick();
  check("returns the unfinished state", out.done === false);
  check("stopScan called once on pause", p.calls.filter((c) => c[0] === "stopScan").length === 1, JSON.stringify(p.calls.map((c) => c[0])));
  check("startScan resumed from page 40", JSON.stringify(p.calls.find((c) => c[0] === "startScan")?.[1]) === JSON.stringify({ page: 40, totalPages: 1552, castings: 1 }), JSON.stringify(p.calls));
}

// 4. Error: the service still stops, and the error still reaches the panel.
{
  console.log("error path:");
  const m = await fresh("error");
  const p = recordingPlugin();
  let err = null;
  try {
    await m.runScanWithKeepAlive(fakeState(0, []), { stopped: false }, () => {}, fakeRunner("error"), p);
  } catch (e) {
    err = e;
  }
  await tick();
  check("error propagates", err instanceof Error && /403/.test(err.message), String(err));
  check("stopScan called once on error", p.calls.filter((c) => c[0] === "stopScan").length === 1, JSON.stringify(p.calls.map((c) => c[0])));
}

// 5. A plugin that throws on every call never blocks the scan.
{
  console.log("throwing plugin:");
  const m = await fresh("throwing");
  const p = throwingPlugin();
  let out = null;
  let err = null;
  try {
    out = await m.runScanWithKeepAlive(fakeState(0, []), { stopped: false }, () => {}, fakeRunner("finish"), p);
  } catch (e) {
    err = e;
  }
  await tick();
  check("scan still finishes", err === null && out?.done === true, String(err));
  check("every native call was attempted anyway", p.calls.length === 5, JSON.stringify(p.calls));
  check("no-plugin path resolves silently", (await m.startScanKeepAlive(1, 2)) === undefined && (await m.updateScanKeepAlive(1, 2)) === undefined && (await m.stopScanKeepAlive()) === undefined && (await m.askScanNotifications()) === undefined);
}

// 6. No native plugin at all (this VM / the web build): everything is a quiet no-op.
{
  console.log("no plugin (web):");
  const m = await fresh("web");
  check("available() is false here", m.scanKeepAliveAvailable() === false);
  let err = null;
  try {
    await m.askScanNotifications();
    await m.startScanKeepAlive(3, 7);
    await m.updateScanKeepAlive(3, 7);
    await m.stopScanKeepAlive();
  } catch (e) {
    err = e;
  }
  check("all four calls resolve without throwing", err === null, String(err));
}

// 7. Resume: a saved mid-scan state loads back intact.
{
  console.log("resume round-trip:");
  const state = ahw.newScan();
  state.years = state.years.slice(10);
  state.page = 7;
  state.requests = 120;
  state.releasesSeen = 2880;
  ahw.addRelease(state.castings, { name: "Bone Shaker", year: 2024, segment: "mainline", sku: "x", series: "", sth: false, th: false });
  ahw.saveScan(state);
  const back = ahw.loadScan();
  check("years / page / requests survive", back !== null && back.years.length === state.years.length && back.page === 7 && back.requests === 120, JSON.stringify(back && { years: back.years.length, page: back.page, requests: back.requests }));
  check("castings survive", back !== null && Object.keys(back.castings).length === 1 && back.castings.boneshaker?.name === "Bone Shaker");
  check("totals match the panel copy", ahw.TOTAL_RELEASES === 37247 && ahw.TOTAL_SCAN_PAGES === 1552, `${ahw.TOTAL_RELEASES}/${ahw.TOTAL_SCAN_PAGES}`);
  ahw.clearScan();
  check("clearScan removes it", ahw.loadScan() === null);
}

console.log(`\n${passed} passed, ${failed} failed`);
if (failed > 0) process.exit(1);
