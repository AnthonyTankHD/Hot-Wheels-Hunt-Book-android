// Wrapper around the native "MusicLibrary" plugin (Android only): reads the
// phone's music list from MediaStore and saves small cover pictures.
import { Capacitor, registerPlugin } from "@capacitor/core";

export interface LibTrack {
  id: string; // MediaStore id (stable while the file stays on the phone)
  uri: string; // content:// address, played in place
  title: string;
  artist: string;
  album: string;
  albumId: string;
  durationMs: number;
  trackNo: number; // 1001 means disc 1 track 1 on some files
  year: number;
  addedAt: number; // seconds since 1970
  size: number;
  mime: string;
}

interface MusicLibraryPlugin {
  checkAccess(): Promise<{ granted: boolean }>;
  requestAccess(): Promise<{ granted: boolean }>;
  scan(o: { offset: number; limit: number }): Promise<{ total: number; items: LibTrack[] }>;
  getArt(o: { uri: string; key: string; size: number }): Promise<{ path?: string }>;
  setPlaying(o: { playing: boolean; title: string; artist: string }): Promise<void>;
  addListener(event: "mediaAction", cb: (e: { action: string }) => void): Promise<{ remove: () => Promise<void> }>;
  requestNotifications(): Promise<{ granted: boolean }>;
}

const Native = registerPlugin<MusicLibraryPlugin>("MusicLibrary");

export function musicNativeAvailable(): boolean {
  return Capacitor.isNativePlatform() && Capacitor.isPluginAvailable("MusicLibrary");
}

export async function ensureMusicAccess(): Promise<boolean> {
  const have = await Native.checkAccess();
  if (have.granted) return true;
  return (await Native.requestAccess()).granted;
}

/** Reads the whole music list from the phone, page by page. */
export async function scanPhone(onProgress?: (done: number, total: number) => void): Promise<LibTrack[]> {
  const out: LibTrack[] = [];
  const PAGE = 500;
  let total = 0;
  for (let offset = 0; ; offset += PAGE) {
    const page = await Native.scan({ offset, limit: PAGE });
    total = page.total;
    for (const t of page.items) {
      out.push({
        ...t,
        trackNo: Number(t.trackNo) || 0,
        year: Number(t.year) || 0,
        durationMs: Number(t.durationMs) || 0,
        addedAt: Number(t.addedAt) || 0,
        size: Number(t.size) || 0,
      });
    }
    onProgress?.(out.length, total);
    if (page.items.length === 0 || out.length >= total) break;
  }
  return out;
}

/** The address a web-view <audio> tag can play for a song on the phone. */
export function playableUrl(uri: string): string {
  return Capacitor.convertFileSrc(uri);
}

// ---- cover pictures ----
// Rows ask for their cover as they scroll into view and cancel when they
// scroll away. The newest request is served first, and a request that is
// cancelled before it started is dropped, so fast scrolling never leaves the
// rows on screen waiting behind rows that are long gone.
const artResults = new Map<string, string | null>();
interface ArtJob {
  key: string;
  uri: string;
  waiters: Set<(url: string | null) => void>;
  started: boolean;
}
const artJobs = new Map<string, ArtJob>();
const artPending: ArtJob[] = [];
let artRunning = 0;
const ART_PARALLEL = 3;

function artKey(t: Pick<LibTrack, "albumId" | "id">): string {
  return t.albumId && t.albumId !== "0" ? `a${t.albumId}` : `t${t.id}`;
}

function artPump() {
  while (artRunning < ART_PARALLEL && artPending.length > 0) {
    const job = artPending.pop()!; // newest first
    job.started = true;
    artRunning += 1;
    Native.getArt({ uri: job.uri, key: job.key, size: 320 })
      .then((r) => {
        const url = r.path ? Capacitor.convertFileSrc(r.path) : null;
        artResults.set(job.key, url);
        job.waiters.forEach((cb) => cb(url));
      })
      .catch(() => {
        // not remembered: it can be tried again later
        job.waiters.forEach((cb) => cb(null));
      })
      .finally(() => {
        artJobs.delete(job.key);
        artRunning -= 1;
        artPump();
      });
  }
}

/** Asks for a song's cover. Returns a function that cancels the request. */
export function requestArt(track: Pick<LibTrack, "uri" | "albumId" | "id">, cb: (url: string | null) => void): () => void {
  const key = artKey(track);
  if (artResults.has(key)) {
    cb(artResults.get(key) ?? null);
    return () => {};
  }
  let job = artJobs.get(key);
  if (!job) {
    job = { key, uri: track.uri, waiters: new Set(), started: false };
    artJobs.set(key, job);
    artPending.push(job);
  } else if (!job.started) {
    const at = artPending.indexOf(job);
    if (at >= 0) {
      artPending.splice(at, 1);
      artPending.push(job); // asked for again: move to the front
    }
  }
  job.waiters.add(cb);
  artPump();
  const mine = job;
  return () => {
    mine.waiters.delete(cb);
    if (mine.waiters.size === 0 && !mine.started) {
      const at = artPending.indexOf(mine);
      if (at >= 0) artPending.splice(at, 1);
      artJobs.delete(mine.key);
    }
  };
}

// ---- notification / background playback ----
// player.ts uses these three. Each one maps to a method the native
// MusicLibrary plugin already offers (see scripts/android-native/
// MusicLibraryPlugin.java): requestNotifications, the "mediaAction"
// listener the plugin fires via dispatch(), and setPlaying. On the web
// (no native plugin) they resolve quietly and do nothing.

/** Android 13+: asks once about the "music playing" notification. */
export async function askNotifications(): Promise<void> {
  if (!musicNativeAvailable()) return;
  try {
    await Native.requestNotifications();
  } catch {
    // notifications are a nice-to-have; never break playback over them
  }
}

/** Calls back with "prev" / "toggle" / "next" when a notification button is pressed. */
export async function onNotificationAction(cb: (action: string) => void): Promise<void> {
  if (!musicNativeAvailable()) return;
  await Native.addListener("mediaAction", (e) => cb(e.action));
}

/**
 * Starts or stops the "music playing" notification that keeps playback
 * alive while the app is minimized (MusicKeepAliveService). Passing false
 * stops the service again.
 */
export async function setBackgroundPlaying(on: boolean, title?: string, artist?: string): Promise<void> {
  if (!musicNativeAvailable()) return;
  try {
    await Native.setPlaying({ playing: on, title: title ?? "", artist: artist ?? "" });
  } catch {
    // the music still plays while the app is open
  }
}
