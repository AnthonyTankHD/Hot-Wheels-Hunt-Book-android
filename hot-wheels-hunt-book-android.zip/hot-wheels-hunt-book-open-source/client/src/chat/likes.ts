// Likes on Chat Rooms messages.
//
// Data shape: `likedBy` is a MAP from a collector's uid to their
// display name, stored on the message doc:
//
//   likedBy: { "<uid>": "Anthony", "<uid>": "Sam" }
//
// A map, not an array of {uid, name} objects, for one reason:
// Firestore security rules have no lambdas, so they cannot pull the
// uids out of an array to check that a like change only touches the
// requester's own entry. With a map the rules can —
// `likedBy.diff(before).affectedKeys()` must be exactly
// [request.auth.uid] (see firestore.rules). Behaviour is the same
// either way: one like per person, count = number of entries,
// who-liked = the stored names (there is no user-profile collection
// to look names up from, so the name is stored with the like).
// Messages written before likes existed have no `likedBy` field and
// render as zero likes.

export type LikeMap = Record<string, string>;

/** Coerce whatever Firestore hands us into a clean map. Missing, null,
 *  non-object, or junk entries all become zero likes. */
export function normalizeLikes(raw: unknown): LikeMap {
  if (!raw || typeof raw !== "object" || Array.isArray(raw)) return {};
  const out: LikeMap = {};
  for (const [uid, name] of Object.entries(raw as Record<string, unknown>)) {
    if (typeof name === "string" && name.length > 0) out[uid] = name;
  }
  return out;
}

export function likeCount(likes: LikeMap): number {
  return Object.keys(likes).length;
}

export function hasLiked(likes: LikeMap, uid: string): boolean {
  return uid in likes;
}

/** Display names of everyone who liked, in like order. */
export function likerNames(likes: LikeMap): string[] {
  return Object.values(likes);
}

/** Toggle one collector's like. Returns a new map; the input is never
 *  mutated. A uid can never appear twice — the map key is the guard. */
export function toggleLike(likes: LikeMap, me: { uid: string; name: string }): LikeMap {
  const next: LikeMap = { ...likes };
  if (me.uid in next) {
    delete next[me.uid];
  } else {
    next[me.uid] = me.name;
  }
  return next;
}

/**
 * Mirror of the Firestore rule for message updates, for tests: the
 * update may only change `likedBy`, and the only entry that may be
 * added, removed, or changed inside it is the requester's own uid.
 * `before`/`after` are the whole message docs (plain objects).
 * Everything else — text, uid, displayName, createdAt — must be
 * identical, and no other field may appear or disappear.
 */
export function isLikeOnlyUpdate(
  before: Record<string, unknown>,
  after: Record<string, unknown>,
  uid: string,
): boolean {
  const beforeLikes = normalizeLikes(before.likedBy);
  const afterLikes = normalizeLikes(after.likedBy);

  // No field other than likedBy may be added, removed, or changed.
  const otherKeys = new Set([...Object.keys(before), ...Object.keys(after)].filter((k) => k !== "likedBy"));
  for (const k of otherKeys) {
    if (JSON.stringify(before[k]) !== JSON.stringify(after[k])) return false;
  }

  // Inside likedBy, exactly one uid may differ, and it must be yours.
  const allUids = new Set([...Object.keys(beforeLikes), ...Object.keys(afterLikes)]);
  const changed = [...allUids].filter((u) => beforeLikes[u] !== afterLikes[u]);
  return changed.length === 1 && changed[0] === uid;
}
