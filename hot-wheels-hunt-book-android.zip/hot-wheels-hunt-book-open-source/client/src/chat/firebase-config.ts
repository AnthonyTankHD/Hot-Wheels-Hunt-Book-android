// Firebase config for the online Chat Rooms (Auth + Firestore).
//
// The Android app is otherwise fully offline — everything lives
// on-device in IndexedDB — so Chat Rooms need a Firebase project to
// hold the accounts, the rooms, and the messages. To wire one up:
//
//   1. Create a project at https://console.firebase.google.com
//      (free Spark plan is enough to start).
//   2. In the project, enable Authentication -> Sign-in method ->
//      Email/Password.
//   3. Create a Firestore Database (production mode), then publish
//      the rules in firestore.rules at the repo root (Firestore
//      Database -> Rules -> Publish).
//   4. Register a Web app (Project settings -> Your apps) and paste
//      its config values below, replacing every YOUR_... placeholder.
//
// Until real values are pasted in, `isFirebaseConfigured()` is false
// and the Chat Rooms view shows a setup notice instead of crashing —
// the rest of the app works exactly as before.
import { initializeApp, type FirebaseApp } from "firebase/app";
import { getAuth, type Auth } from "firebase/auth";
import { getFirestore, type Firestore } from "firebase/firestore";

export const FIREBASE_CONFIG = {
  apiKey: "AIzaSyAvCd7dEn1OWmVPZMqG_eSRPSeMWeY05go",
  authDomain: "hot-wheels-hunt-book.firebaseapp.com",
  projectId: "hot-wheels-hunt-book",
  storageBucket: "hot-wheels-hunt-book.firebasestorage.app",
  messagingSenderId: "389446700205",
  appId: "1:389446700205:web:d487deed1ac6e8800c8a24",
} as const;

// True once real values have been pasted into FIREBASE_CONFIG above.
export function isFirebaseConfigured(): boolean {
  return !Object.values(FIREBASE_CONFIG).some((value) => value.startsWith("YOUR_"));
}

let app: FirebaseApp | null = null;

export function getFirebaseApp(): FirebaseApp {
  if (!app) app = initializeApp(FIREBASE_CONFIG);
  return app;
}

export function getFirebaseAuth(): Auth {
  return getAuth(getFirebaseApp());
}

export function getFirebaseDb(): Firestore {
  return getFirestore(getFirebaseApp());
}
