// Online Chat Rooms — collectors talking to each other inside the app.
//
// This replaces the old "Chat with Hot Wheels Manager" (a local,
// fallback-only chat with no model behind it). People sign up with an
// email + password account (Firebase Auth) and talk in rooms stored
// in Firestore: four preset rooms (General, Trading, Show Off,
// Treasure Hunts) plus rooms any signed-in collector creates.
//
// Firebase is NOT configured in this tree yet (see
// ./firebase-config.ts): until a real project is wired up this view
// shows a setup notice instead of crashing, and the rest of the app
// works exactly as before. Messages are capped at 500 characters and
// the log shows the latest 200 per room.
import { useEffect, useRef, useState } from "react";
import type { FormEvent } from "react";
import {
  createUserWithEmailAndPassword,
  onAuthStateChanged,
  signInWithEmailAndPassword,
  signOut,
  updateProfile,
  type User,
} from "firebase/auth";
import {
  addDoc,
  collection,
  doc,
  getDoc,
  limit,
  onSnapshot,
  orderBy,
  query,
  serverTimestamp,
  setDoc,
  type Timestamp,
} from "firebase/firestore";
import { getFirebaseAuth, getFirebaseDb, isFirebaseConfigured } from "./firebase-config";

const PRESET_ROOMS = [
  {
    id: "general",
    name: "General",
    description: "Talk Hot Wheels — hunts, hauls, and whatever is on the pegs.",
  },
  {
    id: "trading",
    name: "Trading",
    description: "Swap cars with other collectors. Agree the trade here, then sort postage between yourselves.",
  },
  {
    id: "show-off",
    name: "Show Off",
    description: "Your best finds, your rarest cars, your shelf setups.",
  },
  {
    id: "treasure-hunts",
    name: "Treasure Hunts",
    description: "TH and STH sightings, tips, and bragging rights.",
  },
] as const;

interface Room {
  id: string;
  name: string;
  description: string;
  preset: boolean;
  createdBy: string | null;
  createdAt: Timestamp | null;
}

interface RoomMessage {
  id: string;
  text: string;
  uid: string;
  displayName: string;
  createdAt: Timestamp | null;
}

function displayNameOf(user: User): string {
  return user.displayName?.trim() || user.email?.split("@")[0] || "Collector";
}

function friendlyAuthError(err: unknown): string {
  const code = (err as { code?: string } | null)?.code ?? "";
  if (code === "auth/email-already-in-use") return "That email already has an account — try signing in instead.";
  if (code === "auth/invalid-email") return "That email doesn't look right.";
  if (code === "auth/weak-password") return "Password needs to be at least 6 characters.";
  if (code === "auth/invalid-credential" || code === "auth/user-not-found" || code === "auth/wrong-password") {
    return "Wrong email or password — check them and try again.";
  }
  if (code === "auth/network-request-failed") return "No connection — check you're online and try again.";
  if (code === "auth/too-many-requests") return "Too many tries — wait a bit and try again.";
  return "That didn't go through — try again.";
}

function friendlyError(err: unknown): string {
  const code = (err as { code?: string } | null)?.code ?? "";
  if (code === "permission-denied") return "You don't have permission to do that — the Firestore rules may not be published yet.";
  if (code === "unavailable") return "Chat is unreachable right now — check you're online and try again.";
  return "That didn't go through — try again.";
}

function roomFromSnap(id: string, data: Record<string, unknown>): Room {
  return {
    id,
    name: typeof data.name === "string" ? data.name : "Unnamed room",
    description: typeof data.description === "string" ? data.description : "",
    preset: data.preset === true,
    createdBy: typeof data.createdBy === "string" ? data.createdBy : null,
    createdAt: (data.createdAt as Timestamp | null) ?? null,
  };
}

function messageFromSnap(id: string, data: Record<string, unknown>): RoomMessage {
  return {
    id,
    text: typeof data.text === "string" ? data.text : "",
    uid: typeof data.uid === "string" ? data.uid : "",
    displayName: typeof data.displayName === "string" ? data.displayName : "Collector",
    createdAt: (data.createdAt as Timestamp | null) ?? null,
  };
}

export function ChatRoomsView() {
  const configured = isFirebaseConfigured();
  const [authReady, setAuthReady] = useState(false);
  const [authUser, setAuthUser] = useState<User | null>(null);
  const [authMode, setAuthMode] = useState<"signin" | "signup">("signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [authError, setAuthError] = useState("");
  const [authBusy, setAuthBusy] = useState(false);
  const [rooms, setRooms] = useState<Room[]>([]);
  const [roomsError, setRoomsError] = useState("");
  const [activeRoomId, setActiveRoomId] = useState<string | null>(null);
  const [messages, setMessages] = useState<RoomMessage[]>([]);
  const [draft, setDraft] = useState("");
  const [sending, setSending] = useState(false);
  const [sendError, setSendError] = useState("");
  const [newRoomName, setNewRoomName] = useState("");
  const [newRoomDesc, setNewRoomDesc] = useState("");
  const [creating, setCreating] = useState(false);
  const [createError, setCreateError] = useState("");
  const bottomRef = useRef<HTMLDivElement | null>(null);

  // Who is signed in (Firebase Auth). Nothing here runs until a real
  // Firebase project is configured — see firebase-config.ts.
  useEffect(() => {
    if (!configured) return;
    const unsub = onAuthStateChanged(getFirebaseAuth(), (user) => {
      setAuthUser(user);
      setAuthReady(true);
    });
    return unsub;
  }, [configured]);

  // Live room list, signed-in users only.
  useEffect(() => {
    if (!configured || !authUser) return;
    const unsub = onSnapshot(
      query(collection(getFirebaseDb(), "rooms"), orderBy("createdAt", "asc")),
      (snap) => {
        setRooms(snap.docs.map((d) => roomFromSnap(d.id, d.data())));
        setRoomsError("");
      },
      (err) => setRoomsError(friendlyError(err)),
    );
    return unsub;
  }, [configured, authUser]);

  // Live messages for the open room, oldest first.
  useEffect(() => {
    if (!configured || !authUser || !activeRoomId) return;
    const unsub = onSnapshot(
      query(
        collection(getFirebaseDb(), "rooms", activeRoomId, "messages"),
        orderBy("createdAt", "asc"),
        limit(200),
      ),
      (snap) => setMessages(snap.docs.map((d) => messageFromSnap(d.id, d.data()))),
      () => setMessages([]),
    );
    return unsub;
  }, [configured, authUser, activeRoomId]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ block: "end" });
  }, [messages.length, sending]);

  const activeRoom =
    rooms.find((r) => r.id === activeRoomId) ??
    PRESET_ROOMS.find((r) => r.id === activeRoomId);
  const customRooms = rooms.filter((r) => !r.preset);

  const openRoom = async (roomId: string, preset: boolean) => {
    setSendError("");
    if (preset) {
      // Preset rooms are just names until someone opens one — create
      // the Firestore doc the first time so messages have a home.
      // getDoc first: a blind setDoc would rewrite createdAt on every
      // open and shuffle the room list.
      try {
        const ref = doc(getFirebaseDb(), "rooms", roomId);
        const snap = await getDoc(ref);
        if (!snap.exists()) {
          const presetRoom = PRESET_ROOMS.find((r) => r.id === roomId);
          if (!presetRoom) return;
          await setDoc(ref, {
            name: presetRoom.name,
            description: presetRoom.description,
            preset: true,
            createdBy: null,
            createdAt: serverTimestamp(),
          });
        }
      } catch (err) {
        setRoomsError(friendlyError(err));
        return;
      }
    }
    setMessages([]);
    setActiveRoomId(roomId);
  };

  const submitAuth = async (e: FormEvent) => {
    e.preventDefault();
    const cleanEmail = email.trim();
    if (!cleanEmail.includes("@")) {
      setAuthError("That email doesn't look right.");
      return;
    }
    if (password.length < 6) {
      setAuthError("Password needs to be at least 6 characters.");
      return;
    }
    setAuthBusy(true);
    setAuthError("");
    try {
      if (authMode === "signup") {
        const cred = await createUserWithEmailAndPassword(getFirebaseAuth(), cleanEmail, password);
        const name = displayName.trim() || cleanEmail.split("@")[0] || "Collector";
        await updateProfile(cred.user, { displayName: name });
      } else {
        await signInWithEmailAndPassword(getFirebaseAuth(), cleanEmail, password);
      }
      setPassword("");
    } catch (err) {
      setAuthError(friendlyAuthError(err));
    } finally {
      setAuthBusy(false);
    }
  };

  const createRoom = async (e: FormEvent) => {
    e.preventDefault();
    const name = newRoomName.trim();
    if (!name || !authUser || creating) return;
    setCreating(true);
    setCreateError("");
    try {
      const ref = await addDoc(collection(getFirebaseDb(), "rooms"), {
        name: name.slice(0, 60),
        description: newRoomDesc.trim().slice(0, 140),
        preset: false,
        createdBy: authUser.uid,
        createdAt: serverTimestamp(),
      });
      setNewRoomName("");
      setNewRoomDesc("");
      setMessages([]);
      setActiveRoomId(ref.id);
    } catch (err) {
      setCreateError(friendlyError(err));
    } finally {
      setCreating(false);
    }
  };

  const sendMessage = async (e: FormEvent) => {
    e.preventDefault();
    const text = draft.trim();
    if (!text || !authUser || !activeRoomId || sending) return;
    setSending(true);
    setSendError("");
    try {
      await addDoc(collection(getFirebaseDb(), "rooms", activeRoomId, "messages"), {
        text: text.slice(0, 500),
        uid: authUser.uid,
        displayName: displayNameOf(authUser),
        createdAt: serverTimestamp(),
      });
      setDraft("");
    } catch (err) {
      setSendError(friendlyError(err));
    } finally {
      setSending(false);
    }
  };

  // ---- Not configured yet: setup notice, not a crash. ----
  if (!configured) {
    return (
      <div>
        <section aria-label="Chat Rooms" className="pn">
          <h1 className="hw-h2" style={{ fontSize: 20, margin: 0, lineHeight: 1.2 }}>💬 Chat Rooms</h1>
          <p className="mut mt-1">Talk to other collectors right inside the Hunt Book.</p>
          <p className="mt-3 font-semibold">Chat Rooms aren&apos;t switched on yet.</p>
          <p className="mt-1 text-sm text-[var(--dim)]">
            They need a Firebase project to hold the accounts, rooms, and messages — the app is
            fully offline until one is wired up, and everything else works fine without it.
          </p>
          <ol className="mt-3 list-decimal space-y-1 pl-5 text-sm text-[var(--dim)]">
            <li>Create a free project at console.firebase.google.com.</li>
            <li>Enable Authentication → Sign-in method → Email/Password.</li>
            <li>Create a Firestore Database, then publish the rules in <code>firestore.rules</code> (in the project folder).</li>
            <li>Register a Web app and paste its config into <code>client/src/chat/firebase-config.ts</code>.</li>
            <li>Rebuild the app — the rooms appear here.</li>
          </ol>
        </section>
      </div>
    );
  }

  if (!authReady) {
    return (
      <div>
        <section aria-label="Chat Rooms" className="pn">
          <h1 className="hw-h2" style={{ fontSize: 20, margin: 0, lineHeight: 1.2 }}>💬 Chat Rooms</h1>
          <p className="mt-3 font-semibold">Loading your chat…</p>
        </section>
      </div>
    );
  }

  // ---- Signed out: sign in or make an account. ----
  if (!authUser) {
    return (
      <div>
        <section aria-label="Chat Rooms" className="pn">
          <h1 className="hw-h2" style={{ fontSize: 20, margin: 0, lineHeight: 1.2 }}>💬 Chat Rooms</h1>
          <p className="mut mt-1">Talk to other collectors right inside the Hunt Book.</p>
          <div className="chat-recipient" role="group" aria-label="Sign in or sign up">
            <button
              type="button"
              aria-pressed={authMode === "signin"}
              className={authMode === "signin" ? "recipient-manager" : ""}
              onClick={() => {
                setAuthMode("signin");
                setAuthError("");
              }}
            >
              Sign in
            </button>
            <button
              type="button"
              aria-pressed={authMode === "signup"}
              className={authMode === "signup" ? "recipient-fun" : ""}
              onClick={() => {
                setAuthMode("signup");
                setAuthError("");
              }}
            >
              Sign up
            </button>
          </div>
          <form className="mt-4 space-y-3" onSubmit={submitAuth}>
            {authMode === "signup" && (
              <label className="block">
                <span className="text-sm font-bold">Display name (what other collectors see)</span>
                <input
                  type="text"
                  value={displayName}
                  onChange={(e) => setDisplayName(e.target.value)}
                  placeholder="e.g. Anthony"
                  autoComplete="nickname"
                  className="mt-1 w-full rounded-xl border border-[var(--border)] bg-[var(--surface-2)] px-4 py-3 text-base outline-none focus:border-[var(--accent)]"
                />
              </label>
            )}
            <label className="block">
              <span className="text-sm font-bold">Email</span>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@example.com"
                autoComplete="email"
                className="mt-1 w-full rounded-xl border border-[var(--border)] bg-[var(--surface-2)] px-4 py-3 text-base outline-none focus:border-[var(--accent)]"
              />
            </label>
            <label className="block">
              <span className="text-sm font-bold">Password</span>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="At least 6 characters"
                autoComplete={authMode === "signup" ? "new-password" : "current-password"}
                className="mt-1 w-full rounded-xl border border-[var(--border)] bg-[var(--surface-2)] px-4 py-3 text-base outline-none focus:border-[var(--accent)]"
              />
            </label>
            {authError && <p className="font-semibold text-[var(--accent)]">{authError}</p>}
            <button type="submit" disabled={authBusy} className="hw-btn w-full px-5 py-3 text-sm font-bold disabled:opacity-50">
              {authBusy ? "Hold on…" : authMode === "signup" ? "Create account" : "Sign in"}
            </button>
          </form>
          <p className="mut mt-3 text-center text-sm">
            Your email is only used to sign you in — other collectors see your display name, not your email.
          </p>
        </section>
      </div>
    );
  }

  // ---- Signed in: room list, or the open room. ----
  return (
    <div>
      <section aria-label="Chat Rooms" className="pn">
        <div className="flex flex-wrap items-start justify-between gap-2">
          <div>
            <h1 className="hw-h2" style={{ fontSize: 20, margin: 0, lineHeight: 1.2 }}>💬 Chat Rooms</h1>
            <p className="mut mt-1">Signed in as <b>{displayNameOf(authUser)}</b></p>
          </div>
          <button
            type="button"
            className="hw-btn px-4 py-2 text-sm font-bold"
            onClick={() => {
              setActiveRoomId(null);
              void signOut(getFirebaseAuth());
            }}
          >
            Sign out
          </button>
        </div>

        {roomsError && <p className="mt-3 font-semibold text-[var(--accent)]">{roomsError}</p>}

        {activeRoomId === null ? (
          <>
            <h2 className="mt-4 text-base font-extrabold">Rooms</h2>
            <div className="mt-2 space-y-2">
              {PRESET_ROOMS.map((room) => (
                <button
                  key={room.id}
                  type="button"
                  className="chat-room-row"
                  onClick={() => void openRoom(room.id, true)}
                >
                  <span className="chat-room-name">💬 {room.name}</span>
                  <span className="chat-room-desc">{room.description}</span>
                </button>
              ))}
            </div>

            <h2 className="mt-5 text-base font-extrabold">Rooms collectors made</h2>
            {customRooms.length === 0 ? (
              <p className="mt-1 text-sm text-[var(--dim)]">No collector-made rooms yet — make the first one below.</p>
            ) : (
              <div className="mt-2 space-y-2">
                {customRooms.map((room) => (
                  <button
                    key={room.id}
                    type="button"
                    className="chat-room-row"
                    onClick={() => void openRoom(room.id, false)}
                  >
                    <span className="chat-room-name">💬 {room.name}</span>
                    <span className="chat-room-desc">{room.description || "A room made by a collector."}</span>
                  </button>
                ))}
              </div>
            )}

            <h2 className="mt-5 text-base font-extrabold">Make a room</h2>
            <form className="mt-2 space-y-2" onSubmit={createRoom}>
              <input
                type="text"
                value={newRoomName}
                onChange={(e) => setNewRoomName(e.target.value)}
                placeholder="Room name, e.g. RLC Hunters"
                maxLength={60}
                className="w-full rounded-xl border border-[var(--border)] bg-[var(--surface-2)] px-4 py-3 text-base outline-none focus:border-[var(--accent)]"
              />
              <input
                type="text"
                value={newRoomDesc}
                onChange={(e) => setNewRoomDesc(e.target.value)}
                placeholder="What is this room about? (optional)"
                maxLength={140}
                className="w-full rounded-xl border border-[var(--border)] bg-[var(--surface-2)] px-4 py-3 text-base outline-none focus:border-[var(--accent)]"
              />
              {createError && <p className="font-semibold text-[var(--accent)]">{createError}</p>}
              <button type="submit" disabled={!newRoomName.trim() || creating} className="hw-btn px-5 py-3 text-sm font-bold disabled:opacity-50">
                {creating ? "Making it…" : "Create room"}
              </button>
            </form>
          </>
        ) : (
          <>
            <button
              type="button"
              className="mt-3 font-bold text-[var(--accent)] underline"
              onClick={() => {
                setActiveRoomId(null);
                setMessages([]);
              }}
            >
              ← All rooms
            </button>
            <h2 className="mt-2 text-lg font-extrabold">
              {activeRoom?.name ?? "Room"}
            </h2>
            {activeRoom?.description && <p className="mut text-sm">{activeRoom.description}</p>}

            <div className="pn chat-log mt-3" role="log" aria-label={`Messages in ${activeRoom?.name ?? "this room"}`}>
              {messages.length === 0 ? (
                <p className="text-center text-sm text-[var(--dim)]">
                  No messages yet — say hey and get the room going. 🏁
                </p>
              ) : (
                <div className="flex flex-col gap-2">
                  {messages.map((m) => {
                    const isOwn = m.uid === authUser.uid;
                    return (
                      <div key={m.id} style={{ display: "flex", justifyContent: isOwn ? "flex-end" : "flex-start" }}>
                        <div className={`max-w-[82%] ${isOwn ? "chat-bubble-user" : "chat-bubble-muse"}`}>
                          {!isOwn && <span className="chat-speaker">{m.displayName}</span>}
                          <p className="text-sm leading-snug break-words">{m.text}</p>
                          <span className="mt-1 block text-right text-[11px] opacity-70">
                            {m.createdAt ? m.createdAt.toDate().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }) : "…"}
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
              <div ref={bottomRef} />
            </div>

            <form className="chat-composer" onSubmit={sendMessage} aria-label="Send a message">
              <label className="min-w-0 flex-1">
                <span className="sr-only">Message the room</span>
                <input
                  type="text"
                  value={draft}
                  onChange={(e) => setDraft(e.target.value)}
                  placeholder={`Message ${activeRoom?.name ?? "the room"}…`}
                  autoComplete="off"
                  maxLength={500}
                  disabled={sending}
                  className="w-full rounded-full border border-[var(--border)] bg-[var(--surface-2)] px-4 py-3 text-base outline-none focus:border-[var(--accent)] disabled:opacity-60"
                />
              </label>
              <button
                type="submit"
                disabled={!draft.trim() || sending}
                className="hw-btn shrink-0 px-5 py-3 text-sm font-bold disabled:opacity-50"
              >
                Send
              </button>
            </form>
            {sendError && <p className="mt-2 text-center font-semibold text-[var(--accent)]">{sendError}</p>}
            <p className="mut mt-2 px-1 text-center">
              Be kind — no spam, no scams. Messages are 500 characters max.
            </p>
          </>
        )}
      </section>
    </div>
  );
}
