// Wrapper around the native "ScanKeepAlive" plugin (Android only): keeps
// the allhotwheels.com scan running while the app is minimized or the
// screen is off, with a notification showing its progress.
//
// Mirrors client/src/music/native.ts. The plugin is a foreground service
// (ScanKeepAliveService) with a partial wake lock, so the scan keeps
// fetching pages in the background; the notification shows the page and
// casting counts and tapping it returns to the app.
//
// Every call here is best-effort and never throws: if the plugin is
// missing or the notification permission was denied, the scan simply
// runs in the foreground exactly as it did before the keep-alive
// existed. On the web (no native plugin) these resolve quietly and do
// nothing.

import { Capacitor, registerPlugin } from "@capacitor/core";
import { TOTAL_SCAN_PAGES, runScan, type ScanHandle, type ScanState } from "./ahw-import";

interface ScanKeepAlivePlugin {
  startScan(o: { page: number; totalPages: number; castings: number }): Promise<void>;
  updateScan(o: { page: number; totalPages: number; castings: number }): Promise<void>;
  stopScan(): Promise<void>;
  requestNotifications(): Promise<{ granted: boolean }>;
}

const Native = registerPlugin<ScanKeepAlivePlugin>("ScanKeepAlive");

export function scanKeepAliveAvailable(): boolean {
  return Capacitor.isNativePlatform() && Capacitor.isPluginAvailable("ScanKeepAlive");
}

// The `plugin` parameter on every function below is a test seam only:
// production callers omit it and talk to the real native plugin. The
// harness (scripts/test-scan-keep-alive.mjs) passes a recording fake.
type PluginArg = ScanKeepAlivePlugin | undefined;

function pluginOrNative(plugin: PluginArg): ScanKeepAlivePlugin | null {
  if (plugin) return plugin;
  return scanKeepAliveAvailable() ? Native : null;
}

let askedNotif = false;

/** Android 13+: asks once about the scan notification. Never blocks the scan. */
export async function askScanNotifications(plugin?: ScanKeepAlivePlugin): Promise<void> {
  const p = pluginOrNative(plugin);
  if (!p || askedNotif) return;
  askedNotif = true;
  try {
    await p.requestNotifications();
  } catch {
    // notifications are a nice-to-have; never break the scan over them
  }
}

/** Starts the scan's foreground service (and its wake lock). */
export async function startScanKeepAlive(page: number, castings: number, plugin?: ScanKeepAlivePlugin): Promise<void> {
  const p = pluginOrNative(plugin);
  if (!p) return;
  try {
    await p.startScan({ page, totalPages: TOTAL_SCAN_PAGES, castings });
  } catch {
    // the scan still runs while the app is open
  }
}

/** Refreshes the notification's page / casting counts. */
export async function updateScanKeepAlive(page: number, castings: number, plugin?: ScanKeepAlivePlugin): Promise<void> {
  const p = pluginOrNative(plugin);
  if (!p) return;
  try {
    await p.updateScan({ page, totalPages: TOTAL_SCAN_PAGES, castings });
  } catch {
    // a missed progress update is harmless
  }
}

/** Stops the service and releases its wake lock. */
export async function stopScanKeepAlive(plugin?: ScanKeepAlivePlugin): Promise<void> {
  const p = pluginOrNative(plugin);
  if (!p) return;
  try {
    await p.stopScan();
  } catch {
    // nothing to stop
  }
}

/**
 * Runs (or resumes) a scan with the keep-alive held for exactly the
 * scan's lifetime: it starts before the first page, the notification is
 * updated after every page, and the service is stopped in a `finally`
 * — whether the scan finishes, pauses, is stopped, or errors — so the
 * service and its wake lock never outlive the scan.
 */
export async function runScanWithKeepAlive(
  state: ScanState,
  handle: ScanHandle,
  onProgress: (s: ScanState, note: string) => void,
  run: typeof runScan = runScan,
  plugin?: ScanKeepAlivePlugin,
): Promise<ScanState> {
  await askScanNotifications(plugin);
  await startScanKeepAlive(state.requests, Object.keys(state.castings).length, plugin);
  try {
    return await run(state, handle, (s, note) => {
      onProgress(s, note);
      void updateScanKeepAlive(s.requests, Object.keys(s.castings).length, plugin);
    });
  } finally {
    await stopScanKeepAlive(plugin);
  }
}
