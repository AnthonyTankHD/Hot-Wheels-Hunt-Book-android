// Build identity. Bump SPLASH_BUILD_STAMP in every build that republishes
// the client; the first number (v52) is what the in-app updater compares.
// Format: v<number>-<yyyy>-<mm>-<dd>-<short-name>
export const SPLASH_BUILD_STAMP = "v66-2026-11-22-scan-background";

// Version of the native Android shell (the installed APK itself). Bump it
// only when the native side changes (new Capacitor plugin, permissions).
// (Shell 2 added the native music scanner; shell 3 added background playback;
// shell 6 added the scan keep-alive foreground service.)
// A GitHub update whose shell number differs is not loaded in-app; the
// updater offers the APK download instead.
export const SHELL_VERSION = 6;
