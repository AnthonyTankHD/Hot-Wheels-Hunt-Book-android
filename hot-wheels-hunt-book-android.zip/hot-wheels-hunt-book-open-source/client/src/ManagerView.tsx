/* ---------------- Hot Wheels Manager chat ----------------
   The in-app Manager: a local, offline, rules-based chat over the
   live collection. It answers from the snapshot built from getState
   + the catalog — no network, no cloud model. Every reply comes from
   client/src/manager.ts; this view only renders the conversation and
   executes the reply's action when Anthony taps its confirm button.

   Data actions always run through the app's existing actions
   (setCarState / addTarget / removeTarget) and refresh afterwards.
   The photo rule is enforced twice: the engine only ever offers a
   direct mark when the car already has a usable photo, and the view
   re-checks the live snapshot before it executes anything. Marking
   owned or TH on a car with no photo goes through the existing
   PhotoVerifyDialog instead (App renders it from onVerifyOwn /
   onVerifyTh) — photo or camera scan first, mark only after the
   photo saves. Chat history is session-only in v1: it does not save
   to the book. */

import { useMemo, useRef, useState } from "react";
import { api } from "./api";
import {
  answerManager,
  buildManagerSnapshot,
  MANAGER_INTRO,
  type ManagerAction,
  type ManagerReply,
  type ManagerSnapshot,
} from "./manager";
import type { DisplayCar, State, Tab } from "./App";

type CarState = State["carStates"][number];

interface ChatMsg {
  id: number;
  role: "user" | "manager";
  text: string;
  items?: { key: string; name: string; note?: string }[];
  action?: ManagerAction;
  actionLabel?: string;
  secondary?: ManagerAction;
  secondaryLabel?: string;
  /** Set once a confirm button was tapped, so it can't double-fire. */
  actionDone?: string;
}

const QUICK_CHIPS = [
  "How many do I own?",
  "What's my streak?",
  "Pick a hunt for me",
  "Show my Treasure Hunts",
  "How many Disney Cars?",
  "Show cars needing a photo",
];

function buildSnapshot(
  data: State,
  all: DisplayCar[],
  stateMap: Map<string, CarState>,
  photosByCar: Map<string, State["photos"]>,
  month: string,
): ManagerSnapshot {
  const photos = [...photosByCar.values()].flat().map((p) => ({ carKey: p.carKey, url: p.url }));
  return buildManagerSnapshot(
    {
      profileName: data.profile.name ?? "",
      stats: data.stats,
      streak: data.streak,
      points: data.points,
      targets: data.targets,
      carStates: [...stateMap.values()],
      photos,
    },
    all,
    month,
  );
}

export function ManagerView(props: {
  data: State;
  all: DisplayCar[];
  stateMap: Map<string, CarState>;
  photosByCar: Map<string, State["photos"]>;
  month: string;
  onNavigate: (tab: Tab, filter?: string) => void;
  onOpenCar: (key: string) => void;
  onVerifyOwn: (car: DisplayCar) => void;
  onVerifyTh: (car: DisplayCar) => void;
  onToast: (msg: string) => void;
  onRefresh: () => void;
}) {
  const [messages, setMessages] = useState<ChatMsg[]>([
    { id: 0, role: "manager", text: MANAGER_INTRO },
  ]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const idRef = useRef(1);
  const listRef = useRef<HTMLDivElement | null>(null);

  // The snapshot is rebuilt whenever the book data changes, so every
  // answer reads the live collection — never a stale copy.
  const snapshot = useMemo(
    () => buildSnapshot(props.data, props.all, props.stateMap, props.photosByCar, props.month),
    [props.data, props.all, props.stateMap, props.photosByCar, props.month],
  );
  const snapRef = useRef(snapshot);
  snapRef.current = snapshot;
  const byKey = useMemo(() => new Map(props.all.map((c) => [c.k, c])), [props.all]);

  const push = (msg: Omit<ChatMsg, "id">) => {
    setMessages((prev) => [...prev, { ...msg, id: idRef.current++ }]);
    requestAnimationFrame(() => {
      listRef.current?.scrollTo({ top: listRef.current.scrollHeight });
    });
  };

  const send = (text: string) => {
    const trimmed = text.trim();
    if (!trimmed || busy) return;
    setInput("");
    push({ role: "user", text: trimmed });
    const reply: ManagerReply = answerManager(trimmed, snapRef.current);
    push({
      role: "manager",
      text: reply.text,
      items: reply.items,
      action: reply.action,
      actionLabel: reply.actionLabel,
      secondary: reply.secondary,
      secondaryLabel: reply.secondaryLabel,
    });
  };

  const markDone = (msg: ChatMsg, note: string) => {
    setMessages((prev) => prev.map((m) => (m.id === msg.id ? { ...m, actionDone: note } : m)));
  };

  const executeAction = async (msg: ChatMsg, action: ManagerAction) => {
    if (busy) return;
    const snap = snapRef.current;
    const carKey = (action as { carKey?: string }).carKey;
    const car = carKey ? snap.cars.find((c) => c.key === carKey) : undefined;
    setBusy(true);
    try {
      if (action.kind === "openFilter") {
        props.onNavigate("cars", action.filter);
        markDone(msg, "Opened in Cars ✓");
        return;
      }
      if (action.kind === "openCar") {
        props.onOpenCar(action.carKey);
        markDone(msg, "Opened ✓");
        return;
      }
      if (action.kind === "verifyOwn" || action.kind === "verifyTh") {
        const display = byKey.get(action.carKey);
        if (!display) {
          push({ role: "manager", text: "That car isn't in the book anymore — I can't open the photo flow for it." });
          return;
        }
        if (action.kind === "verifyOwn") props.onVerifyOwn(display);
        else props.onVerifyTh(display);
        markDone(msg, "Photo dialog opened 📷");
        return;
      }
      if (action.kind === "markTh") {
        // Gate re-check on the LIVE snapshot: owned + usable photo, or
        // the mark does not run — the engine is never trusted alone.
        if (!car || !car.owned || !car.hasPhoto) {
          push({ role: "manager", text: `I can't mark that one TH right now — it needs to be owned with a photo first. Tap “Verify with a photo” on its car sheet and I'll pick it up from there.` });
          markDone(msg, "Needs a photo first");
          return;
        }
        const res = await api.setCarState({ carKey: action.carKey, isTh: true });
        props.onRefresh();
        const pts = res.points?.awarded ?? 0;
        props.onToast(pts > 0 ? `Treasure Hunt marked ⭐ +${pts} points` : "Treasure Hunt marked ⭐");
        push({ role: "manager", text: `Done — ${car.name} is a Treasure Hunt now. ⭐${pts > 0 ? ` +${pts} points.` : ""}` });
        markDone(msg, "Marked TH ✓");
        return;
      }
      if (action.kind === "markOwned") {
        // Same gate: a usable photo must already be on file.
        if (!car || !car.hasPhoto) {
          push({ role: "manager", text: `That one still needs a photo first — I can't mark it owned without one. Tap “Verify with a photo” and snap it, then the mark goes on.` });
          markDone(msg, "Needs a photo first");
          return;
        }
        const res = await api.setCarState({ carKey: action.carKey, owned: true, count: Math.max(1, car.copies) });
        props.onRefresh();
        const pts = res.points?.awarded ?? 0;
        props.onToast(pts > 0 ? `Marked owned ✓ +${pts} points` : "Marked owned ✓");
        push({ role: "manager", text: `Done — ${car.name} is owned now. ✓${pts > 0 ? ` +${pts} points.` : ""}${car.unverified ? " It has a photo, so it's verified." : ""}` });
        markDone(msg, "Marked owned ✓");
        return;
      }
      if (action.kind === "addTarget") {
        const res = await api.addTarget({ month: snap.month, text: action.text, carKey: action.carKey });
        props.onRefresh();
        if (!res.added) {
          push({ role: "manager", text: `“${action.text}” is already on your ${snap.month} target list.` });
        } else {
          props.onToast(`Added “${action.text}” to your targets 🎯`);
          push({ role: "manager", text: `Done — “${action.text}” is on your ${snap.month} hunt targets. 🎯` });
        }
        markDone(msg, res.added ? "Added to targets ✓" : "Already on the list");
        return;
      }
      if (action.kind === "removeTarget") {
        await api.removeTarget({ id: action.targetId });
        props.onRefresh();
        push({ role: "manager", text: `Done — took “${action.text}” off your ${snap.month} targets.` });
        markDone(msg, "Removed ✓");
        return;
      }
    } catch {
      push({ role: "manager", text: "That couldn't be saved — nothing changed. Try again in a moment." });
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="pn p-3">
      <div className="flex items-start justify-between gap-2">
        <div>
          <h2 className="hw-h2" style={{ fontSize: 19 }}>🤖 Hot Wheels Manager</h2>
          <p className="mut mt-1 text-sm">
            I work from the collection on this phone — ask me about your cars, or tell me to mark one. No internet, no cloud, just your book.
          </p>
        </div>
        <button
          type="button"
          className="hw-btn hw-btn-ghost shrink-0 px-3 py-1.5 text-xs font-bold"
          onClick={() => setMessages([{ id: idRef.current++, role: "manager", text: MANAGER_INTRO }])}
        >
          Clear chat
        </button>
      </div>

      <div ref={listRef} className="mt-3 max-h-[52vh] space-y-2 overflow-y-auto pr-1" aria-live="polite">
        {messages.map((m) => (
          <div key={m.id} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
            <div
              className={`max-w-[88%] rounded-2xl px-3 py-2 text-sm leading-relaxed whitespace-pre-line ${
                m.role === "user"
                  ? "bg-[var(--accent)] font-semibold text-white"
                  : "border border-[var(--border)] bg-[var(--surface-2)] text-[var(--text)]"
              }`}
            >
              <p>{m.text}</p>
              {m.items && m.items.length > 0 && (
                <div className="mt-2 space-y-1">
                  {m.items.map((it) => (
                    <button
                      key={it.key}
                      type="button"
                      className="block w-full rounded-lg bg-[var(--surface)] px-2 py-1.5 text-left text-[13px] font-semibold hover:opacity-80"
                      onClick={() => props.onOpenCar(it.key)}
                    >
                      {it.name}
                      {it.note && <span className="mut block text-xs font-normal">{it.note}</span>}
                    </button>
                  ))}
                </div>
              )}
              {m.role === "manager" && m.action && (
                <div className="mt-2 flex flex-wrap gap-2">
                  {m.actionDone ? (
                    <span className="text-xs font-bold text-[var(--dim)]">{m.actionDone}</span>
                  ) : (
                    <>
                      <button
                        type="button"
                        disabled={busy}
                        className="hw-btn px-3 py-1.5 text-xs font-bold disabled:opacity-50"
                        onClick={() => void executeAction(m, m.action!)}
                      >
                        {m.actionLabel ?? "Do it"}
                      </button>
                      {m.secondary && (
                        <button
                          type="button"
                          disabled={busy}
                          className="hw-btn hw-btn-ghost px-3 py-1.5 text-xs font-bold disabled:opacity-50"
                          onClick={() => void executeAction(m, m.secondary!)}
                        >
                          {m.secondaryLabel ?? "Open"}
                        </button>
                      )}
                    </>
                  )}
                </div>
              )}
            </div>
          </div>
        ))}
      </div>

      <div className="mt-3 flex flex-wrap gap-1.5">
        {QUICK_CHIPS.map((chip) => (
          <button
            key={chip}
            type="button"
            className="rounded-full border border-[var(--border)] bg-[var(--surface)] px-3 py-1.5 text-xs font-semibold hover:opacity-80"
            onClick={() => send(chip)}
          >
            {chip}
          </button>
        ))}
      </div>

      <form
        className="mt-3 flex gap-2"
        onSubmit={(e) => {
          e.preventDefault();
          send(input);
        }}
      >
        <label className="sr-only" htmlFor="manager-input">Ask the Manager</label>
        <input
          id="manager-input"
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Ask about your cars…"
          autoComplete="off"
          className="min-w-0 flex-1 rounded-[10px] border border-[var(--border)] bg-[var(--surface-2)] px-4 py-2.5 text-base outline-none focus:border-[var(--accent)]"
        />
        <button type="submit" disabled={!input.trim() || busy} className="hw-btn shrink-0 px-4 py-2.5 font-bold disabled:opacity-50">
          Send
        </button>
      </form>
      <p className="mut mt-2 text-center text-xs">
        Local only — your chat stays on this phone for this session and isn&apos;t saved to the book.
      </p>
    </div>
  );
}
