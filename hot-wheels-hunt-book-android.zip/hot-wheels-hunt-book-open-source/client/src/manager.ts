/* ---------------- Hot Wheels Manager (local, offline) ----------------
   A rules-based assistant that lives in the Android app and answers
   from the collection on this phone. It is NOT a general AI: no network
   calls, no cloud model, no free-form reasoning — every reply comes
   from the live snapshot the view builds from getState + the catalog,
   matched by small keyword rules and squashed-name lookup.

   PHOTO RULE (non-negotiable): marking a car OWNED never happens
   without a photo. The engine never returns a direct "mark owned"
   action for a car with no photo on file — it returns "verifyOwn",
   which the view turns into the existing PhotoVerifyDialog (photo or
   camera scan first, mark only after the photo saves). A car that
   already HAS a photo may be marked owned directly, exactly like the
   car sheet's OWN button does. The same gate applies to Treasure
   Hunts: "markTh" is only ever returned for an owned car that already
   has a photo; anything else gets "verifyTh". The view re-checks
   both gates before it executes anything, so a stale snapshot can
   never slip a mark past the photo rule. */

import { squash } from "./ahw-import";

export interface ManagerCar {
  key: string;
  name: string;
  /** Tag codes, e.g. "M" Mainline, "F" Fantasy, "C" Disney Cars. */
  tags: string;
  details?: string;
  owned: boolean;
  isTh: boolean;
  isSth: boolean;
  copies: number;
  unverified: boolean;
  hasPhoto: boolean;
  custom: boolean;
}

export interface ManagerTarget {
  id: number;
  month: string;
  text: string;
  carKey: string | null;
  done: boolean;
}

export interface ManagerSnapshot {
  name: string;
  cars: ManagerCar[];
  total: number;
  owned: number;
  copies: number;
  th: number;
  sth: number;
  fantasyOwned: number;
  unverified: number;
  photoCount: number;
  streakCurrent: number;
  streakBest: number;
  pointsLifetime: number;
  pointsBalance: number;
  level: number;
  levelName: string;
  targets: ManagerTarget[];
  /** Current planner month, "yyyy-mm". */
  month: string;
  /** Day of the year, 1-366 — seeds the daily hunt pick. */
  dayOfYear: number;
}

export type ManagerAction =
  | { kind: "markTh"; carKey: string }
  | { kind: "markOwned"; carKey: string }
  | { kind: "verifyOwn"; carKey: string }
  | { kind: "verifyTh"; carKey: string }
  | { kind: "addTarget"; carKey: string | null; text: string }
  | { kind: "removeTarget"; targetId: number; text: string }
  | { kind: "openFilter"; filter: string }
  | { kind: "openCar"; carKey: string };

export interface ManagerReply {
  text: string;
  items?: { key: string; name: string; note?: string }[];
  moreCount?: number;
  action?: ManagerAction;
  actionLabel?: string;
  secondary?: ManagerAction;
  secondaryLabel?: string;
}

export const MANAGER_INTRO =
  "Hey — I'm the Hot Wheels Manager, and I work from the collection on this phone. Ask me how many cars you own, what's a Treasure Hunt, or what to hunt next — or tell me to mark a car or add a target. No internet, no cloud — just your book.";

export const MANAGER_HELP =
  "Here's what I can do:\n" +
  "• Counts — “how many do I own”, “how many Treasure Hunts”, “how many Disney Cars”, “how many still missing”, “how many need a photo”\n" +
  "• Lists — “show my Treasure Hunts”, “show my Disney Cars”, “show cars needing a photo”, “show unowned Mainline”\n" +
  "• Streak & points — “what's my streak”, “how many points”, “what level am I”\n" +
  "• Marks — “mark Bone Shaker as a Treasure Hunt” (owned cars with a photo), “mark Twin Mill owned” (I'll ask for a photo first — the photo rule still applies)\n" +
  "• Targets — “add Twin Mill to my targets”, “remove Bone Shaker from my targets”, “show my targets”\n" +
  "• Hunts — “pick a hunt for me”, “what should I hunt”\n" +
  "• Checks — “do I own Bone Shaker”, “is Super Tuned a Treasure Hunt”\n" +
  "• Fun — “tell me a joke”, “let's go hunting”";

/** Minimal slice of the getState response the snapshot needs, so the
    builder stays testable without the whole app state. */
export interface ManagerStateInput {
  profileName: string;
  stats: {
    total: number;
    owned: number;
    copies: number;
    th: number;
    sth: number;
    fantasyOwned: number;
    unverified: number;
    photoCount: number;
  };
  streak: { current: number; best: number };
  points: { lifetime: number; balance: number; level: number; levelName: string };
  targets: ManagerTarget[];
  carStates: { carKey: string; owned: boolean; isTh: boolean; isSth: boolean; count: number; unverified: boolean }[];
  photos: { carKey: string | null; url: string }[];
}

export interface ManagerCatalogCar {
  k: string;
  n: string;
  t: string;
  x?: string;
  custom: boolean;
}

/** Merges the catalog with live car states + photos into the snapshot
    the engine answers from. A photo counts as usable exactly like the
    car sheet's gate: the photo row must have a URL. */
export function buildManagerSnapshot(
  input: ManagerStateInput,
  all: ManagerCatalogCar[],
  month: string,
  dayOfYear?: number,
): ManagerSnapshot {
  const stateByKey = new Map(input.carStates.map((s) => [s.carKey, s]));
  const photoKeys = new Set(input.photos.filter((p) => p.carKey && p.url).map((p) => p.carKey as string));
  const cars: ManagerCar[] = all.map((c) => {
    const s = stateByKey.get(c.k);
    return {
      key: c.k,
      name: c.n,
      tags: c.t,
      details: c.x,
      owned: Boolean(s?.owned),
      isTh: Boolean(s?.isTh),
      isSth: Boolean(s?.isSth),
      copies: s?.count ?? 0,
      unverified: Boolean(s?.unverified),
      hasPhoto: photoKeys.has(c.k),
      custom: c.custom,
    };
  });
  const now = new Date();
  const start = new Date(now.getFullYear(), 0, 0);
  const doy = dayOfYear ?? Math.floor((now.getTime() - start.getTime()) / 86400000);
  return {
    name: input.profileName,
    cars,
    total: input.stats.total,
    owned: input.stats.owned,
    copies: input.stats.copies,
    th: input.stats.th,
    sth: input.stats.sth,
    fantasyOwned: input.stats.fantasyOwned,
    unverified: input.stats.unverified,
    photoCount: input.stats.photoCount,
    streakCurrent: input.streak.current,
    streakBest: input.streak.best,
    pointsLifetime: input.points.lifetime,
    pointsBalance: input.points.balance,
    level: input.points.level,
    levelName: input.points.levelName,
    targets: input.targets,
    month,
    dayOfYear: doy,
  };
}

const JOKES = [
  "Why did the Hot Wheels car go to therapy? Too many issues with its track record.",
  "I told a Treasure Hunt joke once. Nobody found it — that's the whole point.",
  "What do you call a slow Hot Wheels car? A shelf queen.",
  "Why don't Hot Wheels cars ever get lost? They always follow the orange track.",
  "My favorite workout? Running the track. My favorite meal? Anything but a die-cast diet.",
  "What's a Treasure Hunt's favorite song? “You Can't Always Get What You Want” — because the pegs were empty.",
];

const HYPE = [
  "Let's GO. The pegs won't check themselves. 🔥",
  "New hunt energy: eyes on the pegs, hands off the commons unless they spark joy.",
  "Somewhere out there is a Treasure Hunt with your name on it. Go find it.",
  "Strap in — today's the day the shelf gets a new resident. 🏁",
  "Hunt like every peg is hiding a Super. Because one of them is.",
];

const LIST_CAP = 10;

function fmt(n: number): string {
  return n.toLocaleString("en-US");
}

function carNote(c: ManagerCar): string {
  const bits: string[] = [];
  if (c.isSth) bits.push("Super Treasure Hunt");
  else if (c.isTh) bits.push("Treasure Hunt");
  if (c.owned) bits.push(c.copies > 1 ? `${c.copies} copies` : "owned");
  else bits.push("not owned");
  if (c.unverified) bits.push("needs a photo");
  return bits.join(" · ");
}

export type CarMatch =
  | { kind: "one"; car: ManagerCar }
  | { kind: "many"; cars: ManagerCar[] }
  | { kind: "none" };

export function findCars(query: string, snap: ManagerSnapshot): CarMatch {
  const q = squash(query);
  if (q.length < 2) return { kind: "none" };
  const exact = snap.cars.filter((c) => squash(c.name) === q || c.key === q);
  if (exact.length === 1) return { kind: "one", car: exact[0]! };
  if (exact.length > 1) return { kind: "many", cars: exact.slice(0, 6) };
  // Substring: the query's words all appear in the name, in order.
  const loose = snap.cars.filter((c) => squash(c.name).includes(q));
  if (loose.length === 1) return { kind: "one", car: loose[0]! };
  if (loose.length > 1) {
    // Prefer the shortest name — usually the base casting, not a variant.
    const sorted = [...loose].sort((a, b) => a.name.length - b.name.length);
    if (sorted[0] && sorted[1] && sorted[0].name.length + 8 < sorted[1].name.length) {
      return { kind: "one", car: sorted[0] };
    }
    return { kind: "many", cars: sorted.slice(0, 6) };
  }
  return { kind: "none" };
}

function listReply(
  title: string,
  cars: ManagerCar[],
  filter: string,
  snap: ManagerSnapshot,
): ManagerReply {
  const sorted = [...cars].sort((a, b) => a.name.localeCompare(b.name));
  const shown = sorted.slice(0, LIST_CAP);
  const more = sorted.length - shown.length;
  const items = shown.map((c) => ({ key: c.key, name: c.name, note: carNote(c) }));
  const text =
    sorted.length === 0
      ? `${title}: none yet.`
      : `${title} (${fmt(sorted.length)}):\n${shown.map((c) => `• ${c.name} — ${carNote(c)}`).join("\n")}` +
        (more > 0 ? `\n…and ${fmt(more)} more — tap below to see them all.` : "");
  void snap;
  return {
    text,
    items: items.length > 0 ? items : undefined,
    moreCount: more > 0 ? more : undefined,
    action: { kind: "openFilter", filter },
    actionLabel: "Show in Cars",
  };
}

function huntPick(snap: ManagerSnapshot): ManagerReply {
  // Prefer Mainline — the series he owns most of — then Fantasy, then
  // anything unowned. Deterministic per day: the same day always picks
  // the same car, tomorrow picks the next one.
  const mainline = snap.cars
    .filter((c) => !c.owned && c.tags.includes("M"))
    .sort((a, b) => a.name.localeCompare(b.name));
  const fantasy = snap.cars
    .filter((c) => !c.owned && c.tags.includes("F"))
    .sort((a, b) => a.name.localeCompare(b.name));
  const pool = mainline.length > 0 ? mainline : fantasy.length > 0 ? fantasy : snap.cars.filter((c) => !c.owned).sort((a, b) => a.name.localeCompare(b.name));
  if (pool.length === 0) {
    return { text: "You've got them all — every car in the book is owned! Time to hunt for customs or wait for the next release. 🏆" };
  }
  const pick = pool[snap.dayOfYear % pool.length]!;
  const series =
    pick.tags.includes("M")
      ? `Mainline is the series you own most of, and this one's still missing`
      : pick.tags.includes("F")
        ? `Fantasy is your flavor — this one's still missing`
        : `This one's still missing from your garage`;
  return {
    text: `Today's hunt pick: ${pick.name}. ${series}. ${pick.details ? `(${pick.details})` : ""}`.trim(),
    items: [{ key: pick.key, name: pick.name, note: carNote(pick) }],
    action: { kind: "addTarget", carKey: pick.key, text: pick.name },
    actionLabel: "Add to targets",
    secondary: { kind: "openCar", carKey: pick.key },
    secondaryLabel: "Open the car",
  };
}

function helpReply(): ManagerReply {
  return { text: MANAGER_HELP };
}

export function answerManager(input: string, snap: ManagerSnapshot): ManagerReply {
  const raw = input.trim();
  const lower = raw.toLowerCase();
  const norm = lower.replace(/[^a-z0-9 ]/g, " ").replace(/\s+/g, " ").trim();

  if (!norm) return { text: "Say the word — ask me about your cars, or tell me to mark one. Type “help” to see what I can do." };

  // --- help / fallback anchors ---
  if (/\bhelp\b/.test(norm) || /what can you do/.test(norm) || /what do you do/.test(norm)) {
    return helpReply();
  }

  // --- fun: jokes & hype (no data changes, ever) ---
  if (/joke/.test(norm)) {
    const joke = JOKES[snap.dayOfYear % JOKES.length]!;
    return { text: joke };
  }
  if (/let ?'?s go hunting|hype me|pump me up|hunt hype|i ?'?m (bored|ready)|let ?'?s hunt/.test(norm)) {
    const hype = HYPE[snap.dayOfYear % HYPE.length]!;
    return { text: `${hype} You're on a ${snap.streakCurrent}-day streak, by the way — don't break it now. 🔥` };
  }

  // --- greeting alone (a greeting WITH a question falls through) ---
  if (/^(hi|hello|hey|yo|hiya|howdy|good (morning|afternoon|evening))$/.test(norm)) {
    const name = snap.name ? `, ${snap.name}` : "";
    return { text: `Hey${name}! 🔥 ${snap.owned} cars owned, ${snap.streakCurrent}-day streak. What are we hunting today? Type “help” if you want the full list of what I can do.` };
  }

  // --- Super Treasure Hunt: chat can't do this one ---
  if (/super treasure hunt|\bsth\b/.test(norm) && /mark|make|set/.test(norm)) {
    const sthName = norm.match(/^(?:mark|make|set)\s+(.+?)\s+(?:as\s+)?(?:a\s+)?(?:super treasure hunt|sth)\b/)?.[1] ?? "";
    const match = findCars(sthName, snap);
    if (match.kind === "one") {
      const c = match.car;
      if (c.isSth) return { text: `${c.name} is already a Super Treasure Hunt. 👑` };
      return {
        text: `I can't mark a Super Treasure Hunt from chat — mark ${c.name} as a Treasure Hunt first, then flip STH on in its car sheet. Want me to mark it TH?`,
        action: c.owned && c.hasPhoto ? { kind: "markTh", carKey: c.key } : { kind: "verifyTh", carKey: c.key },
        actionLabel: c.owned && c.hasPhoto ? "Yes — mark it TH" : "Verify with a photo first",
      };
    }
    return { text: "I can't mark a Super Treasure Hunt from chat — mark the car as a Treasure Hunt first, then flip STH on in its car sheet." };
  }

  // --- mark owned ---
  // The captured group is the car phrase already — it goes straight to
  // the matcher (squash handles punctuation). The FILLER-stripper is
  // only for free-form tails, never for a captured phrase, so names
  // that contain small words ("My Name Is Not Chuck") survive.
  const ownedMatch = norm.match(/^(?:mark|set)\s+(.+?)\s+(?:as\s+)?owned\b/) ?? norm.match(/^(.+?)\s+is\s+owned\b/) ?? norm.match(/^i\s+own\s+(.+?)\s+now\b/);
  if (ownedMatch?.[1]) {
    const match = findCars(ownedMatch[1].trim(), snap);
    if (match.kind === "one") {
      const c = match.car;
      if (c.owned) return { text: `${c.name} is already owned. ✓${c.unverified ? " It still needs a photo to be verified, though — open it and add one." : ""}` };
      if (c.hasPhoto) {
        return {
          text: `${c.name} already has a photo on file, so I can mark it owned right now. Tap to confirm.`,
          action: { kind: "markOwned", carKey: c.key },
          actionLabel: "Yes — mark it owned",
          secondary: { kind: "openCar", carKey: c.key },
          secondaryLabel: "Open the car",
        };
      }
      return {
        text: `To mark ${c.name} owned I need a photo of that exact casting first — that's the rule for every car, no exceptions. Tap below and snap one (or pick one), and the mark goes on the moment the photo saves.`,
        action: { kind: "verifyOwn", carKey: c.key },
        actionLabel: "📷 Verify with a photo",
        secondary: { kind: "openCar", carKey: c.key },
        secondaryLabel: "Open the car",
      };
    }
    if (match.kind === "many") {
      return {
        text: `I found ${match.cars.length} cars matching that: ${match.cars.map((c) => c.name).join("; ")}. Tell me which one you mean and I'll mark it — I won't guess.`,
        items: match.cars.map((c) => ({ key: c.key, name: c.name, note: carNote(c) })),
      };
    }
    return { text: `I couldn't find a car called “${ownedMatch[1].trim()}” in the catalog or your customs, so I didn't mark anything. Check the spelling in the Cars tab, or add it as a custom car and ask me again.` };
  }

  // --- mark Treasure Hunt ---
  const thMatch = norm.match(/^(?:mark|make|set)\s+(.+?)\s+(?:as\s+)?(?:a\s+)?(?:treasure hunt|th)\b/) ?? norm.match(/^(.+?)\s+is\s+(?:a\s+)?(?:treasure hunt|th)\b/);
  if (thMatch?.[1]) {
    const match = findCars(thMatch[1].trim(), snap);
    if (match.kind === "one") {
      const c = match.car;
      if (c.isTh) return { text: `${c.name} is already a Treasure Hunt. ⭐` };
      if (!c.owned) {
        return {
          text: `${c.name} isn't owned yet, and a Treasure Hunt mark needs a photo of the car first. Tap below and snap one — the photo saves, then the TH mark goes on.`,
          action: { kind: "verifyTh", carKey: c.key },
          actionLabel: "📷 Verify with a photo",
          secondary: { kind: "openCar", carKey: c.key },
          secondaryLabel: "Open the car",
        };
      }
      if (!c.hasPhoto) {
        return {
          text: `${c.name} is owned but has no photo yet, and a Treasure Hunt mark needs one. Tap below and snap it — the TH mark goes on the moment the photo saves.`,
          action: { kind: "verifyTh", carKey: c.key },
          actionLabel: "📷 Verify with a photo",
          secondary: { kind: "openCar", carKey: c.key },
          secondaryLabel: "Open the car",
        };
      }
      return {
        text: `${c.name} is owned and has a photo, so I can mark it a Treasure Hunt right now. Tap to confirm — it's worth +50 points.`,
        action: { kind: "markTh", carKey: c.key },
        actionLabel: "Yes — mark it TH",
        secondary: { kind: "openCar", carKey: c.key },
        secondaryLabel: "Open the car",
      };
    }
    if (match.kind === "many") {
      return {
        text: `I found ${match.cars.length} cars matching that: ${match.cars.map((c) => c.name).join("; ")}. Tell me which one you mean and I'll mark it — I won't guess.`,
        items: match.cars.map((c) => ({ key: c.key, name: c.name, note: carNote(c) })),
      };
    }
    return { text: `I couldn't find a car called “${thMatch[1].trim()}” in the catalog or your customs, so I didn't mark anything. Check the spelling in the Cars tab, or add it as a custom car and ask me again.` };
  }

  // --- targets: remove ---
  const removeMatch = norm.match(/^(?:remove|drop|delete)\s+(.+?)\s+from\s+(?:my\s+|the\s+)?targets?\b/);
  if (removeMatch?.[1]) {
    const phrase = removeMatch[1].trim();
    const carMatch = findCars(phrase, snap);
    const target =
      snap.targets.find((t) => t.month === snap.month && carMatch.kind === "one" && t.carKey === carMatch.car.key) ??
      snap.targets.find((t) => t.month === snap.month && squash(t.text) === squash(phrase)) ??
      null;
    if (!target) {
      return { text: `I couldn't find “${phrase}” on your ${snap.month} target list, so there's nothing to remove. Say “show my targets” to see what's on it.` };
    }
    return {
      text: `Want me to take “${target.text}” off your ${snap.month} targets? Tap to confirm.`,
      action: { kind: "removeTarget", targetId: target.id, text: target.text },
      actionLabel: "Yes — remove it",
    };
  }

  // --- targets: add ---
  const addMatch = norm.match(/^(?:add|make)\s+(.+?)\s+(?:to|as)\s+(?:my\s+|the\s+)?(?:hunt\s+)?targets?\b/) ?? norm.match(/^(?:add|make)\s+(.+?)\s+(?:a\s+)?(?:hunt\s+)?target\b/);
  if (addMatch?.[1]) {
    const phrase = addMatch[1].trim();
    const match = findCars(phrase, snap);
    const wanted = match.kind === "one" ? match.car.name : phrase;
    const existing = snap.targets.find((t) => t.month === snap.month && (t.text === wanted || (match.kind === "one" && t.carKey === match.car.key)));
    if (existing) {
      return { text: `“${existing.text}” is already on your ${snap.month} target list.` };
    }
    if (match.kind === "many") {
      return {
        text: `I found ${match.cars.length} cars matching that: ${match.cars.map((c) => c.name).join("; ")}. Tell me which one you mean and I'll add it — I won't guess.`,
        items: match.cars.map((c) => ({ key: c.key, name: c.name, note: carNote(c) })),
      };
    }
    return {
      text: `Want me to add “${wanted}” to your ${snap.month} hunt targets? Tap to confirm.`,
      action: { kind: "addTarget", carKey: match.kind === "one" ? match.car.key : null, text: wanted },
      actionLabel: "Yes — add it",
    };
  }

  // --- targets: show ---
  if (/targets?/.test(norm) && /show|list|what|my/.test(norm) && !/add|remove/.test(norm)) {
    const mine = snap.targets.filter((t) => t.month === snap.month);
    if (mine.length === 0) {
      return { text: `No hunt targets on your ${snap.month} list yet. Tell me “add Twin Mill to my targets” and I'll put it on there.` };
    }
    const lines = mine.map((t) => `• ${t.text}${t.done ? " ✓ found" : ""}`).join("\n");
    return { text: `Your ${snap.month} hunt targets (${mine.length}):\n${lines}`, action: { kind: "openFilter", filter: "miss" }, actionLabel: "Show missing cars" };
  }

  // --- hunt pick ---
  if (/pick|surprise me|suggest|what should i hunt|what(?:'s| is) next|hunt (?:pick|idea|suggestion|for me)/.test(norm)) {
    return huntPick(snap);
  }

  // --- status: do I own / is it a TH / is it an STH / copies ---
  const ownQ = norm.match(/^(?:do i|have i|did i)\s+(?:own|have|get|got|find|found)\s+(.+)$/) ?? norm.match(/^do i own (.+)$/);
  if (ownQ?.[1]) {
    const match = findCars(ownQ[1].trim(), snap);
    if (match.kind === "one") {
      const c = match.car;
      return {
        text: c.owned
          ? `Yes — you own ${c.name}${c.copies > 1 ? ` (${c.copies} copies)` : ""}${c.isSth ? ", and it's a Super Treasure Hunt 👑" : c.isTh ? ", and it's a Treasure Hunt ⭐" : ""}.${c.unverified ? " It still needs a photo to be verified." : ""}`
          : `Not yet — ${c.name} is still on your missing list.${c.isTh ? " (It's marked as a Treasure Hunt, though.)" : ""}`,
        secondary: { kind: "openCar", carKey: c.key },
        secondaryLabel: "Open the car",
      };
    }
    if (match.kind === "many") {
      return {
        text: `I found ${match.cars.length} cars matching that: ${match.cars.map((c) => c.name).join("; ")}. Which one did you mean?`,
        items: match.cars.map((c) => ({ key: c.key, name: c.name, note: carNote(c) })),
      };
    }
    return { text: `I couldn't find a car called “${ownQ[1].trim()}” in the catalog or your customs.` };
  }
  const sthQ = norm.match(/^is\s+(.+?)\s+(?:a\s+)?(?:super treasure hunt|sth)\b/);
  if (sthQ?.[1]) {
    const match = findCars(sthQ[1].trim(), snap);
    if (match.kind === "one") {
      const c = match.car;
      return { text: c.isSth ? `Yes — ${c.name} is a Super Treasure Hunt. 👑` : `${c.name} isn't a Super Treasure Hunt.${c.isTh ? " It is a regular Treasure Hunt, though. ⭐" : ""}` };
    }
    return { text: `I couldn't find a car called “${sthQ[1].trim()}” to check.` };
  }
  const thQ = norm.match(/^is\s+(.+?)\s+(?:a\s+)?(?:treasure hunt|th)\b/);
  if (thQ?.[1]) {
    const match = findCars(thQ[1].trim(), snap);
    if (match.kind === "one") {
      const c = match.car;
      return { text: c.isTh ? `Yes — ${c.name} is a Treasure Hunt. ⭐` : `${c.name} isn't marked as a Treasure Hunt.${c.isSth ? " It's a Super Treasure Hunt, though. 👑" : ""}` };
    }
    return { text: `I couldn't find a car called “${thQ[1].trim()}” to check.` };
  }
  const copiesQ = norm.match(/how many copies of (.+)$/);
  if (copiesQ?.[1]) {
    const match = findCars(copiesQ[1].trim(), snap);
    if (match.kind === "one") {
      const c = match.car;
      return { text: c.owned ? `You've got ${c.copies} ${c.copies === 1 ? "copy" : "copies"} of ${c.name}.` : `You don't own ${c.name} yet, so 0 copies.` };
    }
    return { text: `I couldn't find a car called “${copiesQ[1].trim()}” to check.` };
  }

  // --- "tell me about / what is X" ---
  // norm strips apostrophes ("what's" -> "what s"), so the pattern
  // allows the space.
  const aboutQ = norm.match(/^(?:tell me about|what ?'?s|what is|who is|info(?:rmation)? (?:on|about))\s+(.+)$/);
  if (aboutQ?.[1]) {
    const match = findCars(aboutQ[1].trim(), snap);
    if (match.kind === "one") {
      const c = match.car;
      return {
        text: `${c.name}${c.details ? ` — ${c.details}` : ""}. ${c.owned ? `You own it${c.copies > 1 ? ` (${c.copies} copies)` : ""}` : "You don't own it yet"}${c.isSth ? ", it's a Super Treasure Hunt 👑" : c.isTh ? ", it's a Treasure Hunt ⭐" : ""}${c.unverified ? ". It still needs a photo to be verified" : "."}`,
        secondary: { kind: "openCar", carKey: c.key },
        secondaryLabel: "Open the car",
      };
    }
    if (match.kind === "many") {
      return {
        text: `I found ${match.cars.length} cars matching that: ${match.cars.map((c) => c.name).join("; ")}. Which one did you mean?`,
        items: match.cars.map((c) => ({ key: c.key, name: c.name, note: carNote(c) })),
      };
    }
  }

  // --- lists ---
  const listWord = /show|list|which/.test(norm);
  if (listWord || /^my /.test(norm)) {
    if (/treasure hunt/.test(norm)) {
      if (/super/.test(norm)) {
        return listReply("Your Super Treasure Hunts", snap.cars.filter((c) => c.isSth), "S", snap);
      }
      return listReply("Your Treasure Hunts", snap.cars.filter((c) => c.isTh), "th", snap);
    }
    if (/disney/.test(norm)) {
      const owned = snap.cars.filter((c) => c.tags.includes("C") && c.owned);
      const all = snap.cars.filter((c) => c.tags.includes("C"));
      const shown = owned.length > 0 ? [...owned, ...all.filter((c) => !c.owned)] : all;
      const reply = listReply("Disney Cars", shown, "C", snap);
      reply.text = `Disney Cars — you own ${fmt(owned.length)} of ${fmt(all.length)}. ` + reply.text.replace(/^Disney Cars \(\d[\d,]*\):\n/, "");
      return reply;
    }
    if (/fantasy/.test(norm)) {
      return listReply("Your Fantasy castings", snap.cars.filter((c) => c.tags.includes("F") && c.owned), "F", snap);
    }
    if (/mainline/.test(norm)) {
      const unowned = snap.cars.filter((c) => c.tags.includes("M") && !c.owned);
      return listReply("Unowned Mainline", unowned, "M", snap);
    }
    if (/photo|unverified|verif/.test(norm)) {
      return listReply("Cars needing a photo", snap.cars.filter((c) => c.unverified), "unv", snap);
    }
    if (/missing|don'?t (?:own|have)|not owned/.test(norm)) {
      return listReply("Still missing", snap.cars.filter((c) => !c.owned), "miss", snap);
    }
    if (/owned|have|mine/.test(norm) && /show|list|my/.test(norm)) {
      return listReply("Cars you own", snap.cars.filter((c) => c.owned), "own", snap);
    }
    if (/favorite/.test(norm)) {
      return { text: "Favorites live on the Favorites page — I can count them, but the list itself is there. (Tap Favorites in the menu.)" };
    }
  }

  // --- streak / points / level ---
  if (/streak/.test(norm)) {
    return { text: `Your streak is ${snap.streakCurrent} day${snap.streakCurrent === 1 ? "" : "s"} — best ever is ${snap.streakBest}. 🔥 Open the app tomorrow to keep it alive.` };
  }
  if (/points?/.test(norm)) {
    return { text: `You've got ${fmt(snap.pointsBalance)} points to spend, ${fmt(snap.pointsLifetime)} lifetime. You're Level ${snap.level} ${snap.levelName}.` };
  }
  if (/level/.test(norm)) {
    return { text: `You're Level ${snap.level} ${snap.levelName}, with ${fmt(snap.pointsLifetime)} lifetime points.` };
  }

  // --- counts ---
  if (/how many|count|number of/.test(norm)) {
    if (/treasure hunt/.test(norm)) {
      if (/super/.test(norm)) return { text: `You have ${fmt(snap.sth)} Super Treasure Hunt${snap.sth === 1 ? "" : "s"}. 👑` };
      return { text: `You have ${fmt(snap.th)} Treasure Hunt${snap.th === 1 ? "" : "s"}. ⭐` };
    }
    if (/disney/.test(norm)) {
      const total = snap.cars.filter((c) => c.tags.includes("C")).length;
      const owned = snap.cars.filter((c) => c.tags.includes("C") && c.owned).length;
      return {
        text: `Disney Cars: you own ${fmt(owned)} of ${fmt(total)}.`,
        action: { kind: "openFilter", filter: "C" },
        actionLabel: "Show Disney Cars",
      };
    }
    if (/fantasy/.test(norm)) {
      const total = snap.cars.filter((c) => c.tags.includes("F")).length;
      return { text: `Fantasy castings: you own ${fmt(snap.fantasyOwned)} of ${fmt(total)} in the catalog. 🔥` };
    }
    if (/mainline/.test(norm)) {
      const total = snap.cars.filter((c) => c.tags.includes("M")).length;
      const owned = snap.cars.filter((c) => c.tags.includes("M") && c.owned).length;
      return { text: `Mainline: you own ${fmt(owned)} of ${fmt(total)}.` };
    }
    if (/photo|unverified|verif/.test(norm)) {
      return {
        text: `${fmt(snap.unverified)} car${snap.unverified === 1 ? "" : "s"} still need${snap.unverified === 1 ? "s" : ""} a photo to be verified.`,
        action: { kind: "openFilter", filter: "unv" },
        actionLabel: "Show them",
      };
    }
    if (/missing|don'?t (?:own|have)|not owned/.test(norm)) {
      return {
        text: `You're still missing ${fmt(snap.total - snap.owned)} of ${fmt(snap.total)} cars. Plenty of hunting left. 🎯`,
        action: { kind: "openFilter", filter: "miss" },
        actionLabel: "Show missing cars",
      };
    }
    if (/cop(y|ies)/.test(norm)) {
      return { text: `You've got ${fmt(snap.copies)} copies in total across ${fmt(snap.owned)} cars you own.` };
    }
    if (/own|have|got|collection/.test(norm)) {
      return { text: `You own ${fmt(snap.owned)} cars (${fmt(snap.copies)} copies) out of ${fmt(snap.total)} in the book.` };
    }
    if (/total|in the book|catalog/.test(norm)) {
      return { text: `The book holds ${fmt(snap.total)} cars, and you own ${fmt(snap.owned)} of them.` };
    }
  }

  // --- nothing matched: helpful fallback, never a fake answer ---
  return {
    text: `I don't have an answer for that one — I only know what's in your book, and I won't guess. ${MANAGER_HELP}`,
  };
}
