import { useEffect, useRef, useState } from "react";
import { api } from "./api";
import { fileToBase64 } from "./sdk-client";

/* ---------------- Scan to verify ----------------
   Verifies a car by scanning it with the live camera instead of
   picking a photo from the file picker. The scan replaces the
   photo-picker FLOW, not the photo itself: the captured frame is
   saved through the existing addPhoto path (full photo + thumbnail,
   same as a picked photo), which is what clears the UNVERIFIED flag.
   The scan proves the car was in front of the camera at that moment;
   it does not identify the casting by itself.

   Camera path: the WebView's own getUserMedia. Capacitor's bridge
   already grants VIDEO_CAPTURE by asking Android for the CAMERA
   permission (BridgeWebChromeClient.onPermissionRequest), and the
   manifest already declares CAMERA — so no native change, no new
   plugin, and SHELL_VERSION stays put. If the camera can't start
   (no camera, permission denied, old WebView), the caller falls back
   to the photo picker — never a dead end. No barcode/UPC work: the
   built-in catalog has no SKU data to match a barcode against.

   Cross-check: the scan screen shows the casting's allhotwheels.com
   info the app ALREADY has from the catalog import (series, year
   span, release count, parsed out of the details string toImportCar
   wrote). Display only, from already-imported data: no live fetch
   while scanning, no new 429 risk, and the site has no
   photo-identification API anyway. A custom car, or a casting with
   no imported site record, says so and shows the app's own details. */

/** A car as the scan screen needs it: name, key, stored details, custom flag. */
export type ScanCar = { n: string; k: string; x?: string; custom: boolean };

/** Longest side of a captured frame. A phone camera frame is far
    bigger than the photo store needs (addPhoto caps at 14 MB of
    base64); 1600 px keeps the capture sharp and well under the cap. */
export const SCAN_MAX_SIDE_PX = 1600;

/** Downscaled capture size, keeping the aspect ratio. */
export function captureSize(
  width: number,
  height: number,
  maxSide: number = SCAN_MAX_SIDE_PX,
): { width: number; height: number } {
  const scale = Math.min(1, maxSide / Math.max(width, height));
  return {
    width: Math.max(1, Math.round(width * scale)),
    height: Math.max(1, Math.round(height * scale)),
  };
}

/** Draws the current video frame to a canvas and returns it as a
    JPEG File, ready for the addPhoto path. Returns null when the
    video has no frame yet or the canvas can't produce one. The
    canvas is passed in so the logic is testable without a live
    camera (a stub canvas works). */
export async function captureFrame(
  video: HTMLVideoElement,
  canvas: HTMLCanvasElement,
): Promise<File | null> {
  const w = video.videoWidth;
  const h = video.videoHeight;
  if (!w || !h) return null;
  const size = captureSize(w, h);
  canvas.width = size.width;
  canvas.height = size.height;
  const ctx = canvas.getContext("2d");
  if (!ctx) return null;
  ctx.drawImage(video, 0, 0, size.width, size.height);
  const blob = await new Promise<Blob | null>((resolve) =>
    canvas.toBlob((b) => resolve(b), "image/jpeg", 0.85),
  );
  if (!blob) return null;
  return new File([blob], "scan.jpg", { type: "image/jpeg" });
}

export type CameraFailureKind = "denied" | "missing" | "unavailable";

/** Maps a getUserMedia failure to the fallback the UI shows. Every
    kind ends at the photo picker — the scan never blocks verifying. */
export function classifyCameraError(err: unknown): { kind: CameraFailureKind; message: string } {
  const name = (err as { name?: string } | null)?.name ?? "";
  if (name === "NotAllowedError" || name === "SecurityError") {
    return {
      kind: "denied",
      message: "Camera permission was denied — pick a photo instead, nothing is marked.",
    };
  }
  if (name === "NotFoundError" || name === "OverconstrainedError") {
    return {
      kind: "missing",
      message: "No camera was found on this device — pick a photo instead, nothing is marked.",
    };
  }
  return {
    kind: "unavailable",
    message: "The camera couldn't start — pick a photo instead, nothing is marked.",
  };
}

/* ---- allhotwheels cross-check (already-imported data only) ---- */

export type SiteCrossCheck =
  | { hasSiteData: true; series: string | null; releases: number | null; span: string | null }
  | { hasSiteData: false; custom: boolean; details: string | undefined };

const SITE_PREFIX = "Imported from allhotwheels.com · ";

/** Parses the details string toImportCar wrote for a scan-imported
    casting ("Imported from allhotwheels.com · <series> · N releases
    (YEAR–YEAR)", series part absent when the card had none) into the
    series / release count / year span the scan screen shows. Anything
    else (built-in catalog cars, custom cars) has no imported site
    record, so the screen says that and shows the app's own details. */
export function parseSiteCrossCheck(car: { x?: string; custom: boolean }): SiteCrossCheck {
  const details = car.x ?? "";
  if (!details.startsWith(SITE_PREFIX)) {
    return { hasSiteData: false, custom: car.custom, details: car.x };
  }
  const rest = details.slice(SITE_PREFIX.length);
  const relMatch = rest.match(/(\d+) releases? \(([^)]*)\)\s*$/);
  const releases = relMatch ? Number(relMatch[1]) : null;
  const span = relMatch ? (relMatch[2] ?? null) : null;
  let series: string | null = null;
  if (relMatch) {
    const before = rest.slice(0, relMatch.index).trim();
    const cleaned = before.endsWith("·") ? before.slice(0, -1).trim() : before;
    series = cleaned.length > 0 ? cleaned : null;
  }
  return { hasSiteData: true, series, releases, span };
}

/* ---- saving a scan (the same addPhoto path as a picked photo) ---- */

const SCAN_THUMB_MAX_PX = 360;

/* Thumbnail for a scan capture. Mirrors App.tsx's makeThumbDataUrl
   (360 px longest side, JPEG 0.82, bare base64); kept here so this
   file doesn't import App.tsx and make a circular import. If the
   thumbnail can't be made the photo still saves — it just uses its
   full URL until the app's backfill makes one. */
async function makeScanThumb(file: File): Promise<string | null> {
  const url = URL.createObjectURL(file);
  try {
    const img = await new Promise<HTMLImageElement>((resolve, reject) => {
      const el = new Image();
      el.onload = () => resolve(el);
      el.onerror = () => reject(new Error("image load failed"));
      el.src = url;
    });
    if (!img.naturalWidth || !img.naturalHeight) return null;
    const scale = Math.min(1, SCAN_THUMB_MAX_PX / Math.max(img.naturalWidth, img.naturalHeight));
    const canvas = document.createElement("canvas");
    canvas.width = Math.max(1, Math.round(img.naturalWidth * scale));
    canvas.height = Math.max(1, Math.round(img.naturalHeight * scale));
    const ctx2d = canvas.getContext("2d");
    if (!ctx2d) return null;
    ctx2d.drawImage(img, 0, 0, canvas.width, canvas.height);
    const dataUrl = canvas.toDataURL("image/jpeg", 0.82);
    return dataUrl.startsWith("data:image/jpeg") ? dataUrl : null;
  } catch {
    return null;
  } finally {
    URL.revokeObjectURL(url);
  }
}

/** The addPhoto payload for a scan capture: full photo plus its
    thumbnail, the same shape the file picker builds. */
export async function scanPhotoPayload(
  file: File,
): Promise<{ dataBase64: string; mimeType: string; thumbDataBase64?: string }> {
  const { dataBase64, mimeType } = await fileToBase64(file);
  const thumb = await makeScanThumb(file);
  const thumbDataBase64 = thumb ? thumb.slice(thumb.indexOf(",") + 1) : undefined;
  return thumbDataBase64 && thumbDataBase64.length <= 900_000
    ? { dataBase64, mimeType, thumbDataBase64 }
    : { dataBase64, mimeType };
}

export type ScanPhotoPoints = { earned: number; leveled: boolean; levelName?: string };

/** Saves a scan capture exactly like a picked photo — addPhoto with
    the car's key (which is what clears UNVERIFIED), then the mark the
    verify dialog asked for — and returns the combined points, so the
    caller toasts the same way the picker path does. addPhoto and
    buildPayload are injectable so the flow is testable without a
    phone; the component uses the real ones. If addPhoto throws, the
    mark is never applied. */
export async function saveScannedPhoto(args: {
  carKey: string;
  file: File;
  applyMark: () => Promise<unknown>;
  buildPayload?: (file: File) => Promise<{ dataBase64: string; mimeType: string; thumbDataBase64?: string }>;
  addPhoto?: (args: {
    carKey: string;
    dataBase64: string;
    mimeType: string;
    thumbDataBase64?: string;
  }) => Promise<{ points: { awarded: number; leveledUp?: boolean; levelName?: string } }>;
}): Promise<ScanPhotoPoints> {
  const payload = await (args.buildPayload ?? scanPhotoPayload)(args.file);
  const photoRes = await (args.addPhoto ?? api.addPhoto)({ carKey: args.carKey, ...payload });
  const markRes = await args.applyMark();
  const markPoints = (markRes as { points?: { awarded?: number; leveledUp?: boolean; levelName?: string } } | null | undefined)
    ?.points;
  return {
    earned: photoRes.points.awarded + (markPoints?.awarded ?? 0),
    leveled: photoRes.points.leveledUp || Boolean(markPoints?.leveledUp),
    levelName: markPoints?.levelName ?? photoRes.points.levelName,
  };
}

/* ---- the scan screen ---- */

/** The site-record card shown under the viewfinder. Display only:
    it reads the already-imported record, never fetches while
    scanning. */
function SiteCrossCheckCard(props: { car: ScanCar }) {
  const check = parseSiteCrossCheck(props.car);
  return (
    <div className="scan-crosscheck">
      <p className="scan-crosscheck-label">allhotwheels.com record</p>
      {check.hasSiteData ? (
        <>
          {check.series && <p className="scan-crosscheck-line">Series: {check.series}</p>}
          <p className="scan-crosscheck-line">
            {check.releases !== null
              ? `${check.releases} release${check.releases === 1 ? "" : "s"}`
              : "Releases unknown"}
            {check.span ? ` · ${check.span}` : ""}
          </p>
          <p className="scan-crosscheck-note">
            Checked against the site record already in the app — no live lookup while scanning.
          </p>
        </>
      ) : (
        <>
          <p className="scan-crosscheck-line">
            {check.custom
              ? "Custom car — the site has no record for it."
              : "No site info for this casting yet — the allhotwheels scan hasn't pulled its record."}
          </p>
          {check.details && <p className="scan-crosscheck-note">App details: {check.details}</p>}
        </>
      )}
    </div>
  );
}

/** Full-screen live camera viewfinder for scan-to-verify. The parent
    (PhotoVerifyDialog) owns saving: onCapture hands it the confirmed
    frame, onBack returns to the photo options, onUnavailable fires
    when the camera can't start so the parent falls back to the
    picker. The camera stream is stopped on unmount, on back, and
    after a confirmed capture. */
export function ScanVerifyView(props: {
  car: ScanCar;
  onCapture: (file: File) => Promise<void>;
  onBack: () => void;
  onUnavailable: (message: string) => void;
}) {
  const { car } = props;
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const [phase, setPhase] = useState<"starting" | "live" | "review">("starting");
  const [videoReady, setVideoReady] = useState(false);
  const [captured, setCaptured] = useState<{ file: File; url: string } | null>(null);
  const [confirmBusy, setConfirmBusy] = useState(false);

  const stopStream = () => {
    streamRef.current?.getTracks().forEach((t) => t.stop());
    streamRef.current = null;
  };

  // Open the rear camera once, on mount. Any failure reports back to
  // the parent, which falls back to the photo picker.
  useEffect(() => {
    let cancelled = false;
    (async () => {
      const md = navigator.mediaDevices;
      if (!md?.getUserMedia) {
        props.onUnavailable("This device can't open the camera here — pick a photo instead, nothing is marked.");
        return;
      }
      try {
        const stream = await md.getUserMedia({
          video: { facingMode: { ideal: "environment" } },
          audio: false,
        });
        if (cancelled) {
          stream.getTracks().forEach((t) => t.stop());
          return;
        }
        streamRef.current = stream;
        const video = videoRef.current;
        if (video) {
          video.srcObject = stream;
          await video.play().catch(() => undefined);
        }
        setPhase("live");
      } catch (err) {
        if (!cancelled) props.onUnavailable(classifyCameraError(err).message);
      }
    })();
    return () => {
      cancelled = true;
      stopStream();
    };
    // The parent callbacks are stable for the dialog's lifetime.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // The review still's object URL is released when it changes or the
  // view unmounts, so a retaken scan leaves nothing behind.
  useEffect(() => {
    return () => {
      if (captured) URL.revokeObjectURL(captured.url);
    };
  }, [captured]);

  const handleCapture = async () => {
    const video = videoRef.current;
    const canvas = canvasRef.current;
    if (!video || !canvas) return;
    const file = await captureFrame(video, canvas);
    if (!file) return;
    setCaptured({ file, url: URL.createObjectURL(file) });
    setPhase("review");
  };

  const handleRetake = () => {
    if (captured) URL.revokeObjectURL(captured.url);
    setCaptured(null);
    setPhase("live");
  };

  const handleConfirm = async () => {
    if (!captured || confirmBusy) return;
    setConfirmBusy(true);
    try {
      await props.onCapture(captured.file);
      // On success the parent closes the dialog (and this view with
      // it, stopping the stream). On failure the parent shows the
      // error in the photo options and this view unmounts.
    } finally {
      setConfirmBusy(false);
    }
  };

  return (
    <div className="scan-view" role="dialog" aria-modal="true" aria-label={`Scan ${car.n} to verify`}>
      {phase === "review" && captured ? (
        <img className="scan-review-img" src={captured.url} alt={`Scan of ${car.n}`} />
      ) : (
        <video
          ref={videoRef}
          className="scan-video"
          playsInline
          muted
          autoPlay
          onCanPlay={() => setVideoReady(true)}
        />
      )}
      {phase === "live" && (
        <div className="scan-frame" aria-hidden="true">
          <i className="scan-corner scan-corner-tl" />
          <i className="scan-corner scan-corner-tr" />
          <i className="scan-corner scan-corner-bl" />
          <i className="scan-corner scan-corner-br" />
        </div>
      )}
      <div className="scan-top">
        <p className="scan-title">Scan {car.n}</p>
        <p className="scan-hint">
          {phase === "review"
            ? "Check the scan — this photo will verify the car."
            : phase === "starting"
              ? "Opening the camera…"
              : "Point the camera at the car — tap the button to scan it"}
        </p>
      </div>
      <div className="scan-bottom">
        <SiteCrossCheckCard car={car} />
        {phase === "review" && captured ? (
          <>
            <button
              type="button"
              className="hw-btn w-full py-3 font-bold"
              disabled={confirmBusy}
              onClick={handleConfirm}
            >
              {confirmBusy ? "Saving scan…" : "Use this scan"}
            </button>
            <button
              type="button"
              className="hw-btn hw-btn-ghost w-full py-3 font-bold"
              disabled={confirmBusy}
              onClick={handleRetake}
            >
              Retake
            </button>
          </>
        ) : (
          <>
            <button
              type="button"
              className="scan-capture"
              aria-label="Scan the car"
              disabled={phase !== "live" || !videoReady}
              onClick={handleCapture}
            >
              <span className="scan-capture-dot" aria-hidden="true" />
            </button>
            <button type="button" className="hw-btn hw-btn-ghost px-4 py-2.5 text-sm font-bold" onClick={props.onBack}>
              Back to photo options
            </button>
          </>
        )}
      </div>
      {/* Off-screen canvas the capture is drawn to; never shown. */}
      <canvas ref={canvasRef} className="hidden" aria-hidden="true" />
    </div>
  );
}
