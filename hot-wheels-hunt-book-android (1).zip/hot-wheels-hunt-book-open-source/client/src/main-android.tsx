// Entry point for the Android (Capacitor) build.
//
// First it checks whether a newer build was downloaded from GitHub (see
// ./ota.ts); if so the web view is handed over to it and nothing else
// starts here. Otherwise `./local/install` must come first (it switches
// the action client to the on-device runtime), then the normal app.
import { bootOta, confirmOtaSoon } from "./ota";

if (!(await bootOta())) {
  await import("./local/install");
  await import("./main");
  confirmOtaSoon();
}
