import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import type { ChangeEvent, FormEvent, ReactNode, SyntheticEvent } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { SafeAreaTopScrim } from "./sdk-client";
import { fileToBase64, bytesToBase64 } from "./sdk-client";
import { api, type ApiResponse } from "./api";
import { CATALOG, FILTERS, GAME_DLC_FILTERS, GAME_ROSTER_TOTALS, QUOTES, TAG_CLASS, TAG_LEGEND, type CatalogCar } from "./catalog";
import bgImg from "./assets/hunt-book-bg.jpg";
import logoImg from "./assets/hot-wheels-logo.png";
import splashWallpaperImg from "./assets/splash-wallpaper.jpg";
import beatThatUrl from "./assets/beat-that.mp3";
import unleashed1Img from "./assets/game-unleashed-1.png";
import unleashed2Img from "./assets/game-unleashed-2.png";
import infiniteRushImg from "./assets/game-infinite-rush.png";
import ytThumbWdUbe8SuHxo from "./assets/yt/WdUbe8SuHxo.jpg";
import ytThumbF3dD from "./assets/yt/F3dD-zaxUTE.jpg";
import ytThumbGvWVP from "./assets/yt/gvWVPxJktMQ.jpg";
import ytThumbOlwSb from "./assets/yt/olwSbCSbPKk.jpg";
import ytThumbQ17yQ from "./assets/yt/Q17yQPEHuYI.jpg";
import ytThumbM1Par from "./assets/yt/m1ParXbQqyc.jpg";
import ytThumbOmifX from "./assets/yt/omifXx7MaCI.jpg";
import ytThumb9sj from "./assets/yt/9sj_gJAXmT4.jpg";
import ytThumbJNdn from "./assets/yt/j_NdN1Y8r2M.jpg";
import ytThumbKfSg7 from "./assets/yt/KfSg7W1Gqnw.jpg";
// The self-contained phone copy of the Hunt Book (a single HTML file
// Anthony opens on his phone; bundled as a file asset, not parsed).
import phoneCopyUrl from "./assets/phone-copy.htm" with { type: "file" };

/* The page's blue Hot Wheels pattern backdrop. It used to be painted
   as `background-attachment: fixed` on the scrolling page wrapper,
   which made the browser repaint/resample the full-screen cover photo
   on every scroll frame — a classic source of scroll lag on phones.
   The same photo now lives on its own fixed layer (see .hw-bg in
   theme.css), composited once and never repainted while scrolling;
   the picture on screen is unchanged. */
function PageBackground() {
  return <div className="hw-bg" aria-hidden="true" style={{ backgroundImage: `url(${bgImg})` }} />;
}

// Background silence: the Hunt Book must never make sound while
// Anthony is not actually looking at it. When the page is hidden
// (he switched apps, locked the phone, or moved to another Muse
// view while this page stays alive in the background) or is being
// unloaded, every audio/video element in the app is paused on the
// spot. Nothing here ever presses play again — coming back to the
// app never resumes a sound by itself; Anthony taps play himself.
function pauseAllMedia() {
  try {
    document
      .querySelectorAll<HTMLMediaElement>("audio, video")
      .forEach((el) => {
        if (!el.paused) el.pause();
      });
  } catch {
    // Best-effort only: a media element that refuses to pause must
    // never break the visibility handling around it.
  }
}

// Live background-activity scan for the Diagnostics page: reads the
// actual page state (is it hidden, is any sound or video playing
// right now, is a YouTube player mounted) instead of assuming the
// background handlers above did their job, so Anthony can check for
// himself that nothing is running while he is not using the app.
function scanBackgroundActivity(): { hidden: boolean; playing: number; youtubeOpen: boolean } {
  let playing = 0;
  try {
    document.querySelectorAll<HTMLMediaElement>("audio, video").forEach((el) => {
      if (!el.paused && !el.ended) playing += 1;
    });
  } catch {
    // Best-effort only, like pauseAllMedia above.
  }
  const youtubeOpen = !!document.querySelector('iframe[src*="youtube.com/embed"]');
  return { hidden: document.hidden, playing, youtubeOpen };
}

// Boot marks for the Diagnostics Performance Test. performance.now()
// is milliseconds since this page started loading. dataReadyMs says
// when this open's book data first arrived; splashGoneMs says when
// the intro splash left. homeSettledMs is different in kind: it is a
// duration, not a timestamp — how long Home took to settle once
// everything it was waiting on was out of the way, measured from the
// later of the two marks to the second painted frame after it. The
// splash waits for Anthony's Press Start tap, so timing from page
// load would bill his waiting time to the app (one run read 72.95 s,
// nearly all of it the splash sitting waiting for the press);
// starting the clock when the intro leaves keeps the number about
// the app. Written once per page load by App; read by the
// Performance Test. null = has not happened yet on this open.
const bootMarks: {
  dataReadyMs: number | null;
  splashGoneMs: number | null;
  homeSettledMs: number | null;
} = {
  dataReadyMs: null,
  splashGoneMs: null,
  homeSettledMs: null,
};

// Fingerprint of the shipped client bundle. The stamp is the build
// identity Settings shows and the "Update to current build" button
// works from: the button stashes the stamp of the build that asked
// for the update, and the freshly loaded app compares it against
// its own stamp to confirm whether the reload really landed on a
// newer build (see ProfileView and the update-check effect in App).
// Bump this string in any build that republishes the client.
const SPLASH_BUILD_STAMP = "v51-2026-11-12-thumbnail-backfill-settle-fix";

// "v46-2026-11-12-update-build" → "Build v46 · Nov 12, 2026" — the
// friendly form Settings shows for the stamp above. Falls back to
// the raw stamp if it ever stops matching the expected shape.
function buildLabel(stamp: string): string {
  const m = /^v(\d+)-(\d{4})-(\d{2})-(\d{2})/.exec(stamp);
  if (!m) return stamp;
  const [, ver = "", year = "", mo = "", day = ""] = m;
  const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  const month = months[Number(mo) - 1] ?? "";
  return `Build v${ver} · ${month} ${Number(day)}, ${year}`;
}

function initialLetter(name: string): string {
  const clean = name.replace(/^[^A-Za-z0-9]+/, "");
  const ch = clean[0];
  if (!ch) return "#";
  return /\d/.test(ch) ? "#" : ch.toUpperCase();
}

type State = ApiResponse<typeof api, "getState">;
type CarState = State["carStates"][number];
type Tab = "home" | "cars" | "favorites" | "planner" | "gallery" | "music" | "videos" | "chat" | "rewards" | "profile" | "diagnostics";

interface DisplayCar {
  k: string;
  n: string;
  t: string;
  x?: string;
  custom: boolean;
}

const YEAR_CODES = ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m"];
const YEAR_LABELS: Record<string, string> = {
  a: "2015", b: "2016", c: "2017", d: "2018", e: "2019", f: "2020", g: "2021",
  h: "2022", i: "2023", j: "2024", k: "2025", l: "2026", m: "2027",
};

function sortKey(name: string): string {
  return name.replace(/^[^A-Za-z0-9]+/, "").toLowerCase();
}

type Badge = State["badges"][number];

/* Points & Rewards: the award summary every points-earning action
   returns, and the toast text for it. A level-up gets its own line so
   the moment is not lost inside the points line. */
type PointsAward = ApiResponse<typeof api, "setCarState">["points"];
type Points = State["points"];

function pointsToastText(p: PointsAward): string {
  return p.leveledUp
    ? `+${p.awarded} points ⭐ Level up — you're ${p.levelName} now!`
    : `+${p.awarded} points ⭐`;
}

/* Closest unearned badge: the one furthest along toward its goal
   (highest progress / goal), so earning it rolls the card on to the
   next furthest along. Ties break on fewest left, then badge order.
   With the live data this picks the 3-Day Streak badge (2 of 3) first,
   then Speed Demon (121 of 250) once the streak badge is earned. */
function closestUnearnedBadge(badges: Badge[]): Badge | undefined {
  const ratio = (b: Badge) => (b.goal > 0 ? b.progress / b.goal : 0);
  return [...badges]
    .filter((b) => !b.earned)
    .sort((a, b) => ratio(b) - ratio(a) || (a.goal - a.progress) - (b.goal - b.progress))[0];
}

/* Unit for the "how much is left" line, from the badge id prefix
   (the ids in the live badge data: stk/th/sth/ph/fan/own). */
function badgeUnit(id: string): string {
  if (id.startsWith("stk")) return "day";
  if (id.startsWith("sth")) return "Super Treasure Hunt";
  if (id.startsWith("th")) return "Treasure Hunt";
  if (id.startsWith("ph")) return "photo";
  if (id.startsWith("fan")) return "Fantasy casting";
  return "car";
}

function compareCars(a: DisplayCar, b: DisplayCar): number {
  const x = sortKey(a.n);
  const y = sortKey(b.n);
  const dx = /^\d/.test(x);
  const dy = /^\d/.test(y);
  if (dx !== dy) return dx ? -1 : 1;
  return x < y ? -1 : x > y ? 1 : 0;
}

/* Variant grouping for the Cars list: close variants of one casting —
   the same car whose name differs only by a leading model year
   ("2012 Custom Volkswagen Bug (1968)" vs "2018 Custom Volkswagen Bug
   (1968)"), a trailing bracketed note ("Bone Shaker (Hardtop)",
   "Batmobile (The Batman)"), or a trailing sequel numeral ("Twin Mill"
   vs "Twin Mill II") — share a group key built from the name with those
   decorations stripped. Grouping is presentational only: every car
   keeps its own entry, count, photo, and OWN / TH controls, and no car
   is ever merged or removed. `castingBase` returns the display form of
   the main casting's name; `castingGroupKey` is the comparable key. */
function castingBase(name: string): string {
  return name
    .replace(/^(19|20)\d\d\s+/, "")
    .replace(/\s*\([^)]*\)\s*$/, "")
    .replace(/\s+(II|III|IV|V|2|3|4|5)$/, "");
}

function castingGroupKey(name: string): string {
  return sortKey(castingBase(name));
}

/* Sort-by-series/game rank: the games first (Unleashed 1, Unleashed 2
   Turbocharged, Infinite Rush), then DLC, then Mainline by year, then
   Super Treasure Hunt releases, Fantasy, and Showcase, with anything
   else last. The second element orders Mainline cars by year; A–Z
   breaks the remaining ties. */
function seriesRank(car: DisplayCar): readonly [number, number] {
  const t = car.t;
  if (t.includes("1")) return [0, 0];
  if (t.includes("2")) return [1, 0];
  if (t.includes("R")) return [2, 0];
  if (t.includes("D")) return [3, 0];
  const year = carYear(t);
  if (year !== null) return [4, year];
  if (t.includes("S")) return [5, 0];
  if (t.includes("F")) return [6, 0];
  if (t.includes("X")) return [7, 0];
  return [8, 0];
}

/* Small preview thumbnails for the Cars list: the list tiles show a
   thumbnail (longest side 360 px, JPEG) instead of the full photo, so
   the list loads fast on a phone; tapping a car still opens its sheet
   with the full photos. Thumbnails are made here in the browser from
   the photo itself — from the picked file when a photo is added, or
   from the stored photo's own URL for photos that predate thumbnails —
   and saved with the photo (addPhoto / setPhotoThumb). Any failure
   (undecodable image, blocked canvas) returns null and the photo
   simply keeps using its full URL. */
const THUMB_MAX_PX = 360;

async function makeThumbDataUrl(source: Blob | string): Promise<string | null> {
  const url = typeof source === "string" ? source : URL.createObjectURL(source);
  try {
    const img = await new Promise<HTMLImageElement>((resolve, reject) => {
      const el = new Image();
      el.onload = () => resolve(el);
      el.onerror = () => reject(new Error("image load failed"));
      el.src = url;
    });
    if (!img.naturalWidth || !img.naturalHeight) return null;
    const scale = Math.min(1, THUMB_MAX_PX / Math.max(img.naturalWidth, img.naturalHeight));
    const canvas = document.createElement("canvas");
    canvas.width = Math.max(1, Math.round(img.naturalWidth * scale));
    canvas.height = Math.max(1, Math.round(img.naturalHeight * scale));
    const ctx2d = canvas.getContext("2d");
    if (!ctx2d) return null;
    ctx2d.drawImage(img, 0, 0, canvas.width, canvas.height);
    const dataUrl = canvas.toDataURL("image/jpeg", 0.82);
    return dataUrl.startsWith("data:image/jpeg") ? dataUrl : null;
  } catch {
    return null;
  } finally {
    if (typeof source !== "string") URL.revokeObjectURL(url);
  }
}

/* The addPhoto payload for a picked file: the full photo plus, when it
   can be made, its thumbnail as bare base64 (the shape addPhoto and
   setPhotoThumb accept). */
async function photoPayloadWithThumb(
  file: File,
): Promise<{ dataBase64: string; mimeType: string; thumbDataBase64?: string }> {
  const { dataBase64, mimeType } = await fileToBase64(file);
  const thumb = await makeThumbDataUrl(file);
  const thumbDataBase64 = thumb ? thumb.slice(thumb.indexOf(",") + 1) : undefined;
  return thumbDataBase64 && thumbDataBase64.length <= 900_000
    ? { dataBase64, mimeType, thumbDataBase64 }
    : { dataBase64, mimeType };
}

/* Thumbnail backfill, shared by the whole app. Photos saved before
   thumbnails existed (the imported collection) have no small preview,
   so every tile, strip, and gallery slot that shows one downloads
   the full photo. Two workers fill the gap, both drawing from this
   one attempted set so a photo is never processed twice in a visit:
   the Cars list handles the cover photos of cars on screen first
   (the ones he is looking at), and the app-level pass in App queues
   EVERY other photo in the book — non-cover photos and cars never
   browsed included — and drains the queue one photo at a time in
   the background. Each thumbnail is made from the photo itself and
   saved with setPhotoThumb; any failure just leaves that photo on
   its full URL, and a photo is attempted at most once per visit. */
const thumbBackfillAttempted = new Set<number>();
const thumbBackfillQueue: { id: number; url: string }[] = [];
let thumbBackfillRunning = false;

async function drainThumbBackfill(onSaved: () => void): Promise<void> {
  if (thumbBackfillRunning) return;
  thumbBackfillRunning = true;
  let saved = false;
  try {
    for (;;) {
      const next = thumbBackfillQueue.shift();
      if (!next) break;
      const thumb = await makeThumbDataUrl(next.url);
      if (!thumb) continue;
      const dataBase64 = thumb.slice(thumb.indexOf(",") + 1);
      if (dataBase64.length > 900_000) continue;
      try {
        await api.setPhotoThumb({ id: next.id, dataBase64 });
        saved = true;
      } catch {
        // Best effort: the photo keeps using its full URL.
      }
    }
  } finally {
    thumbBackfillRunning = false;
    if (saved) onSaved();
  }
}

function carYear(tags: string): number | null {
  for (const code of YEAR_CODES) {
    if (tags.includes(code)) return 2015 + YEAR_CODES.indexOf(code);
  }
  return null;
}

function chicagoToday(): string {
  return new Intl.DateTimeFormat("en-CA", {
    timeZone: "America/Chicago",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(new Date());
}

function thisMonth(): string {
  return chicagoToday().slice(0, 7);
}

function shiftMonth(month: string, delta: number): string {
  const [y = 1970, m = 1] = month.split("-").map(Number);
  const d = new Date(y, (m ?? 1) - 1 + delta, 1);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
}

function monthLabel(month: string): string {
  const [y = 1970, m = 1] = month.split("-").map(Number);
  return new Date(y, (m ?? 1) - 1, 1).toLocaleDateString(undefined, { month: "long", year: "numeric" });
}

function greet(): string {
  const h = new Date().getHours();
  if (h < 12) return "Good morning";
  if (h < 18) return "Good afternoon";
  return "Good evening";
}

function tagsToChips(tags: string, limit = 4) {
  const chips: { label: string; cls: string }[] = [];
  for (const ch of tags) {
    const leg = TAG_LEGEND[ch];
    if (!leg) continue;
    chips.push({ label: leg[0], cls: TAG_CLASS[leg[1]] ?? "tag-year" });
    if (chips.length >= limit) break;
  }
  return chips;
}

// What the Cars search matches against: the car's name and details, plus
// the human-readable series/game labels its tag codes stand for. Tag
// codes alone ("1", "F", "R", ...) never appear on screen, so searching
// "Unleashed 1", "Fantasy", "Infinite Rush", "2015 Mainline", or
// "Showcase" would otherwise match nothing even though those series
// are exactly what the filter chips show. FILTERS labels carry the full
// names ("Unleashed 1", "Fantasy", "Super Treasure Hunts", ...); the
// TAG_LEGEND labels carry the short forms shown on tiles ("U1", "FC",
// "RUSH", "STH", the year). Details (x) carry the series written in the
// catalog itself, e.g. "2019 · HW Hot Trucks".
const FILTER_LABEL_BY_CODE = new Map<string, string>(FILTERS);

// A filter code matches a car when every tag code in it is among the
// car's tags. Single-code filters ("1", "D", a year, ...) behave
// exactly as `t.includes(code)` always did; the per-game DLC
// sub-category codes ("1P", "2Q", "RT" — the game's tag plus that
// game's DLC marker) match only that game's DLC cars.
function carMatchesFilter(car: DisplayCar, code: string): boolean {
  for (const ch of code) if (!car.t.includes(ch)) return false;
  return true;
}

function carSearchHaystack(car: DisplayCar): string {
  const parts = [car.n, car.x ?? ""];
  for (const ch of car.t) {
    const leg = TAG_LEGEND[ch];
    if (leg) parts.push(leg[0]);
    const filterLabel = FILTER_LABEL_BY_CODE.get(ch);
    if (filterLabel) parts.push(filterLabel);
  }
  // The per-game DLC sub-category names ("Unleashed 1 DLC", ...) so
  // searching one finds exactly that game's DLC cars.
  for (const dlcCode of Object.values(GAME_DLC_FILTERS)) {
    if (carMatchesFilter(car, dlcCode)) {
      const dlcLabel = FILTER_LABEL_BY_CODE.get(dlcCode);
      if (dlcLabel) parts.push(dlcLabel);
    }
  }
  return parts.join(" ").toLowerCase();
}

/* Haystacks are pure functions of the car, and the DisplayCar objects
   in the derived list are stable between renders, so each car's
   haystack is built once and cached on the object. The Cars search
   used to rebuild all ~5,200 haystack strings on every keystroke,
   which is most of why typing in the search box felt sticky. */
const haystackCache = new WeakMap<DisplayCar, string>();
function carSearchHaystackCached(car: DisplayCar): string {
  let h = haystackCache.get(car);
  if (h === undefined) {
    h = carSearchHaystack(car);
    haystackCache.set(car, h);
  }
  return h;
}

function buildTags(opts: { fantasy: boolean; u1: boolean; u2: boolean; dlc: boolean; rush: boolean; year: string; sthRelease: boolean }): string {
  let t = "";
  if (opts.u1) t += "1";
  if (opts.u2) t += "2";
  if (opts.dlc) t += "D";
  if (opts.fantasy) t += "F";
  if (opts.rush) t += "R";
  if (opts.year) t += opts.year;
  if (opts.sthRelease) t += "S";
  return t;
}

function tagsToOpts(tags: string) {
  let year = "";
  for (const code of YEAR_CODES) if (tags.includes(code)) year = code;
  return {
    fantasy: tags.includes("F"),
    u1: tags.includes("1"),
    u2: tags.includes("2"),
    dlc: tags.includes("D"),
    rush: tags.includes("R"),
    year,
    sthRelease: tags.includes("S"),
  };
}

export function App() {
  const queryClient = useQueryClient();
  const [tab, setTab] = useState<Tab>("home");
  const [toast, setToast] = useState("");
  const [selectedKey, setSelectedKey] = useState<string | null>(null);
  const [sideOpen, setSideOpen] = useState(false);
  const [showSplash, setShowSplash] = useState(true);
  const [splashKey] = useState(0);
  // Stable dismiss callback: SplashScreen's effects key off it, so an
  // inline arrow (a new identity on every render) would tear down and
  // re-run the splash's jingle effect whenever the app re-renders.
  const dismissSplash = useCallback(() => setShowSplash(false), []);
  const [carsFilter, setCarsFilter] = useState("all");
  const [confirm, setConfirm] = useState<{ title: string; body: string; label: string; run: () => Promise<unknown> | void } | null>(null);
  const [confirmBusy, setConfirmBusy] = useState(false);
  const visitedRef = useRef(false);

  // Light / dark choice from Backup & Settings, kept in localStorage
  // like the old crossfade toggle was: null means follow the system
  // (the CSS media query), an explicit value is written to
  // <html data-theme> and overrides it. The toggle flips from
  // whichever mode is currently showing, system or explicit.
  const [theme, setTheme] = useState<"light" | "dark" | null>(() => {
    try {
      const stored = window.localStorage.getItem("hunt-book-theme");
      return stored === "light" || stored === "dark" ? stored : null;
    } catch {
      return null;
    }
  });

  useEffect(() => {
    const root = document.documentElement;
    if (theme) root.setAttribute("data-theme", theme);
    else root.removeAttribute("data-theme");
  }, [theme]);

  const toggleTheme = () => {
    const showingDark =
      theme ?? window.matchMedia("(prefers-color-scheme: dark)").matches;
    const next = showingDark ? "light" : "dark";
    setTheme(next);
    try {
      window.localStorage.setItem("hunt-book-theme", next);
    } catch {
      // Private mode or blocked storage: the switch still applies
      // for this visit, it just will not stick on reopening.
    }
    setToast(next === "dark" ? "Dark mode on" : "Light mode on");
  };

  // Stop all sound the moment the app leaves the foreground, so the
  // splash jingle, the music player, and any video can never keep
  // playing (or start) while Anthony is not using the app. The
  // splash and the music player also handle this themselves (the
  // splash dismisses, the player settles its crossfade); this
  // app-wide net covers every other audio/video element, including
  // ones mounted by views that have no background handling of their
  // own. Playback is never auto-resumed on return.
  useEffect(() => {
    const root = document.documentElement;
    const markBackground = () => root.setAttribute("data-app-background", "");
    const markForeground = () => root.removeAttribute("data-app-background");
    const onVisibility = () => {
      if (document.hidden) {
        pauseAllMedia();
        // Freezes every CSS animation while the app is off screen
        // (theme.css: html[data-app-background] *), so the flame
        // glow, sheens, and other loops burn no battery in the
        // background; they resume on their own when he returns.
        markBackground();
      } else {
        markForeground();
      }
    };
    const onPageHide = () => {
      pauseAllMedia();
      markBackground();
    };
    const onPageShow = () => {
      if (!document.hidden) markForeground();
    };
    document.addEventListener("visibilitychange", onVisibility);
    window.addEventListener("pagehide", onPageHide);
    window.addEventListener("pageshow", onPageShow);
    return () => {
      document.removeEventListener("visibilitychange", onVisibility);
      window.removeEventListener("pagehide", onPageHide);
      window.removeEventListener("pageshow", onPageShow);
    };
  }, []);

  const stateQuery = useQuery({
    queryKey: ["hunt-state"],
    queryFn: () => api.getState({}),
    // The book's data only changes through this app's own mutations
    // (which invalidate explicitly) or Muse's actions between
    // visits. Without a staleTime, React Query treated the state as
    // stale instantly, so every return to the app (window focus)
    // refetched the whole book and re-rendered everything — a
    // visible hitch on the phone. 30 s of freshness keeps quick
    // app-switching smooth; anything older still refreshes on focus,
    // and every in-app save still refreshes immediately.
    staleTime: 30_000,
  });

  const visit = useMutation({
    mutationFn: () => api.recordVisit({}),
    onSuccess: (res) => {
      // Only refetch the whole book when the visit actually changed
      // something the screen shows: a new streak day or earned
      // points. A repeat open on the same day changes nothing, and
      // refetching anyway doubled the startup load for no reason.
      const snap = queryClient.getQueryData<State>(["hunt-state"]);
      const streakChanged =
        !snap || snap.streak.current !== res.current || snap.streak.best !== res.best;
      if (res.points.awarded > 0 || streakChanged) {
        queryClient.invalidateQueries({ queryKey: ["hunt-state"] });
      }
      // The first open of a new day earns the +5 daily-visit points;
      // repeat opens the same day award 0 and stay silent.
      if (res.points.awarded > 0) setToast(`+${res.points.awarded} points ⭐ Daily visit`);
    },
  });

  useEffect(() => {
    if (!visitedRef.current) {
      visitedRef.current = true;
      visit.mutate();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (!toast) return;
    const t = setTimeout(() => setToast(""), 3500);
    return () => clearTimeout(t);
  }, [toast]);

  // "Update to current build" confirmation: the Settings button
  // stashes the stamp of the build that asked for the update in
  // sessionStorage right before reloading the page cache-free.
  // sessionStorage survives that reload, so on this fresh load the
  // stash says an update was just requested; comparing it with
  // this bundle's own stamp tells whether the reload landed on a
  // newer build or the phone was already current. Either way the
  // stash is consumed so the toast fires exactly once.
  useEffect(() => {
    try {
      const askedFrom = window.sessionStorage.getItem("hw-update-check");
      if (!askedFrom) return;
      window.sessionStorage.removeItem("hw-update-check");
      setToast(
        askedFrom === SPLASH_BUILD_STAMP
          ? "✅ Already on the current build — nothing newer to load"
          : `✅ Updated — you're on the current build (${buildLabel(SPLASH_BUILD_STAMP)})`,
      );
    } catch {
      // Storage blocked: no confirmation toast; the update reload
      // itself is unaffected.
    }
  }, []);

  const refresh = () => queryClient.invalidateQueries({ queryKey: ["hunt-state"] });

  const setCar = useMutation({
    mutationFn: (args: { carKey: string; owned?: boolean; isFavorite?: boolean; isTh?: boolean; isSth?: boolean; count?: number; note?: string }) =>
      api.setCarState(args),
    onSuccess: (res) => {
      refresh();
      // Points toasts for the tile OWN/TH taps and Home's "I found
      // it!" — the server awards on transitions only, so un-marking
      // and no-change saves stay silent.
      if (res.points.awarded > 0) setToast(pointsToastText(res.points));
    },
  });

  // Favorites toggle shared by the Cars tiles, the car sheet, and the
  // Favorites page. The server enforces owned-only, so a failure here
  // (e.g. the car was just unowned) surfaces as a toast, never a
  // favorite on a car Anthony does not own.
  //
  // The tap updates the cached state the moment it lands — the car
  // moves into (or out of) the Favorites list and the counts change
  // right away — then the save runs and a success toast confirms it.
  // Before this, the button's only feedback was the full getState
  // refetch that follows a save, so on Anthony's phone a tap looked
  // completely dead: no movement, no message, and the favorite never
  // stuck. If the save fails, the optimistic change is rolled back so
  // the list never shows a favorite that is not really saved.
  const toggleFavorite = async (key: string, fav: boolean) => {
    const queryKey = ["hunt-state"] as const;
    const snapshot = queryClient.getQueryData<State>(queryKey);
    if (snapshot) {
      const carStates = snapshot.carStates.map((s) =>
        s.carKey === key ? { ...s, isFavorite: fav && s.owned } : s,
      );
      queryClient.setQueryData<State>(queryKey, {
        ...snapshot,
        carStates,
        stats: {
          ...snapshot.stats,
          favorites: carStates.filter((s) => s.owned && s.isFavorite).length,
        },
      });
    }
    try {
      await api.setCarState({ carKey: key, isFavorite: fav });
      setToast(fav ? "Added to Favorites ❤️" : "Removed from Favorites");
    } catch {
      if (snapshot) queryClient.setQueryData<State>(queryKey, snapshot);
      setToast("That couldn't be saved — favorites are only for cars you own.");
    } finally {
      refresh();
    }
  };

  const openCar = (key: string) => {
    setSelectedKey(key);
    setSideOpen(false);
    setTab("cars");
  };

  const navigate = (next: Tab, filter?: string) => {
    if (filter !== undefined) setCarsFilter(filter);
    setSideOpen(false);
    setTab(next);
  };

  const data = stateQuery.data;

  const derived = useMemo(() => {
    const stateMap = new Map<string, CarState>();
    for (const s of data?.carStates ?? []) stateMap.set(s.carKey, s);
    const customs = (data?.customCars ?? []).map((c) => ({
      k: c.carKey, n: c.name, t: c.tags, x: c.details, custom: true,
    }));
    const all: DisplayCar[] = [
      ...CATALOG.map((c: CatalogCar) => ({ k: c.k, n: c.n, t: c.t, x: c.x, custom: false })),
      ...customs,
    ].sort(compareCars);
    const byKey = new Map(all.map((c) => [c.k, c]));
    const photosByCar = new Map<string, State["photos"]>();
    for (const p of data?.photos ?? []) {
      if (!p.carKey) continue;
      const list = photosByCar.get(p.carKey) ?? [];
      list.push(p);
      photosByCar.set(p.carKey, list);
    }
    // A car's photos cycle in position order: the lowest position is the
    // cover photo (Photo 1), the rest follow in the order they were added
    // or imported. The gallery's newest-first order is untouched.
    for (const list of photosByCar.values()) {
      list.sort((a, b) => a.position - b.position || a.id - b.id);
    }
    return { stateMap, all, byKey, photosByCar };
  }, [data]);

  // Record this open's boot marks once (see bootMarks above): when
  // the book's data first arrives, when the splash leaves, and how
  // long Home then took to settle — timed from the later of the
  // first two, so the splash's wait for Press Start is never
  // counted as app slowness.
  useEffect(() => {
    if (data && bootMarks.dataReadyMs === null) {
      bootMarks.dataReadyMs = performance.now();
    }
  }, [data]);
  useEffect(() => {
    if (!showSplash && bootMarks.splashGoneMs === null) {
      bootMarks.splashGoneMs = performance.now();
    }
  }, [showSplash]);
  useEffect(() => {
    if (!data || showSplash || bootMarks.homeSettledMs !== null) return;
    let cancelled = false;
    requestAnimationFrame(() => {
      requestAnimationFrame(() => {
        if (cancelled || bootMarks.homeSettledMs !== null) return;
        const start = Math.max(bootMarks.dataReadyMs ?? 0, bootMarks.splashGoneMs ?? 0);
        bootMarks.homeSettledMs = Math.max(1, performance.now() - start);
      });
    });
    return () => {
      cancelled = true;
    };
  }, [data, showSplash]);

  // App-level thumbnail backfill (see thumbBackfillAttempted above):
  // once his data is in and he is past the splash, queue every photo
  // in the book that still has no thumbnail — not just the cover
  // photos of cars he happens to browse — and let the shared drain
  // make and save them in the background. When it saves any, one
  // refresh brings the new thumbnails onto the screen; photos added
  // later without one are picked up the same way on the next data
  // change, because only attempted ids are skipped.
  useEffect(() => {
    if (!data || showSplash) return;
    let queued = false;
    for (const p of data.photos) {
      if (p.url && !p.thumbUrl && !thumbBackfillAttempted.has(p.id)) {
        thumbBackfillAttempted.add(p.id);
        thumbBackfillQueue.push({ id: p.id, url: p.url });
        queued = true;
      }
    }
    if (queued) void drainThumbBackfill(refresh);
    // refresh is App's stable invalidate callback; the attempted set
    // keeps re-runs from re-queueing finished photos.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [data, showSplash]);

  if (stateQuery.isPending) {
    return (
      <>
        {showSplash && <SplashScreen key={splashKey} onDone={dismissSplash} />}
        <PageBackground />
        <div className="min-h-screen">
          <SafeAreaTopScrim backgroundColor="var(--bg)" />
          <main className="px-4 py-16 text-center">
            <p className="text-2xl font-semibold text-white">Loading your Hunt Book…</p>
          </main>
        </div>
      </>
    );
  }

  if (stateQuery.error || !data) {
    // Owner-only book (platform v27): a guest or non-owner on a shared
    // page gets the server's owner_required denial, which is not a
    // connection problem — say so plainly instead of the retry copy.
    const ownerRequired =
      stateQuery.error instanceof Error && stateQuery.error.message.includes("owner_required");
    return (
      <>
        {showSplash && <SplashScreen key={splashKey} onDone={dismissSplash} />}
        <PageBackground />
        <div className="min-h-screen">
          <SafeAreaTopScrim backgroundColor="var(--bg)" />
          <main className="px-4 py-16 text-center">
          <p className="text-2xl font-semibold text-white">
            {ownerRequired ? "This Hunt Book is private." : "Couldn’t load the Hunt Book."}
          </p>
          <p className="mt-2 text-sm text-white/80">
            {ownerRequired
              ? "It belongs to its owner — sign in as the owner to open it."
              : "Check your connection and try again."}
          </p>
          <button
            type="button"
            className="hw-btn mt-4 px-5 py-2.5 font-semibold"
            onClick={() => stateQuery.refetch()}
          >
            Try again
          </button>
          </main>
        </div>
      </>
    );
  }

  const selectedCar = selectedKey ? derived.byKey.get(selectedKey) ?? null : null;

  return (
    <>
      {showSplash && <SplashScreen key={splashKey} onDone={dismissSplash} />}
      <PageBackground />
      <div className="min-h-screen text-[var(--text)]">
      <SafeAreaTopScrim backgroundColor="var(--bg)" />
      <div className="scanlines" aria-hidden="true" />

      {toast && (
        <div role="status" className="hw-toast">
          {toast}
        </div>
      )}

      <Sidebar
        data={data}
        all={derived.all}
        stateMap={derived.stateMap}
        tab={tab}
        carsFilter={carsFilter}
        open={sideOpen}
        onNavigate={navigate}
        onClose={() => setSideOpen(false)}
      />

      <div className="hw-main-wrap">
        <div className="mx-auto w-full max-w-3xl px-2.5">
          <header className="hdr">
            <button type="button" className="mb" aria-label="Open menu" onClick={() => setSideOpen(true)}>
              ☰
            </button>
            <img src={logoImg} alt="Hot Wheels" />
            <b>HUNT BOOK</b>
            <small>{data.stats.owned} / {data.stats.total} owned</small>
          </header>

      <main className="pt-1 pb-6">
        <div key={tab} className="view-anim">
        {tab === "home" && (
          <HomeView
            data={data}
            byKey={derived.byKey}
            stateMap={derived.stateMap}
            photosByCar={derived.photosByCar}
            onOpenCar={openCar}
            onQuick={navigate}
            onOwn={(key) => setCar.mutateAsync({ carKey: key, owned: true })}
            onToast={setToast}
            onBoost={async () => {
              await api.cycleBoost({});
              refresh();
            }}
            onGoBackup={() => setTab("profile")}
            onShowBadges={() => setTab("profile")}
            onGoPlanner={() => setTab("planner")}
            onChat={() => setTab("chat")}
            onMusic={() => setTab("music")}
            onVideos={() => setTab("videos")}
            onFavorites={() => setTab("favorites")}
            onRewards={() => setTab("rewards")}
          />
        )}
        {tab === "cars" && (
          <CarsView
            data={data}
            all={derived.all}
            stateMap={derived.stateMap}
            photosByCar={derived.photosByCar}
            filter={carsFilter}
            onFilterChange={setCarsFilter}
            onSelect={setSelectedKey}
            onToggleOwn={(key, owned) => setCar.mutateAsync({ carKey: key, owned })}
            onToggleTh={(key, th) => setCar.mutateAsync({ carKey: key, isTh: th })}
            onToggleFavorite={toggleFavorite}
            onToast={setToast}
            onRefresh={refresh}
          />
        )}
        {tab === "favorites" && (
          <FavoritesView
            data={data}
            all={derived.all}
            stateMap={derived.stateMap}
            photosByCar={derived.photosByCar}
            onOpenCar={openCar}
            onToggleFavorite={toggleFavorite}
            onGoCars={() => navigate("cars", "all")}
          />
        )}
        {tab === "planner" && (
          <PlannerView
            data={data}
            all={derived.all}
            stateMap={derived.stateMap}
            onToast={setToast}
            onRefresh={refresh}
            onOpenCar={openCar}
          />
        )}
        {tab === "gallery" && (
          <GalleryView data={data} byKey={derived.byKey} onToast={setToast} onRefresh={refresh} onOpenCar={openCar} onConfirm={setConfirm} />
        )}
        {tab === "music" && (
          <MusicView data={data} onToast={setToast} onRefresh={refresh} onConfirm={setConfirm} />
        )}
        {tab === "videos" && (
          <VideoFeedView data={data} byKey={derived.byKey} onToast={setToast} onRefresh={refresh} onConfirm={setConfirm} />
        )}
        {tab === "chat" && (
          <ChatView
            data={data}
            byKey={derived.byKey}
            onOpenCar={openCar}
            onGoCars={() => navigate("cars", "all")}
            onGoPlanner={() => navigate("planner")}
            onRefresh={refresh}
            onConfirm={setConfirm}
          />
        )}
        {tab === "rewards" && (
          <RewardsView data={data} onToast={setToast} onRefresh={refresh} />
        )}
        {tab === "profile" && (
          <ProfileView data={data} onToast={setToast} onRefresh={refresh} onConfirm={setConfirm} onToggleTheme={toggleTheme} />
        )}
        {tab === "diagnostics" && (
          <DiagnosticsView
            data={data}
            all={derived.all}
            byKey={derived.byKey}
            stateMap={derived.stateMap}
            photosByCar={derived.photosByCar}
            onRefresh={async () => {
              await stateQuery.refetch();
            }}
            onToast={setToast}
          />
        )}
        </div>
      </main>
      <div className="flames" aria-hidden="true" />
        </div>
      </div>

      {selectedCar && (
        <CarSheet
          car={selectedCar}
          state={derived.stateMap.get(selectedCar.k)}
          photos={derived.photosByCar.get(selectedCar.k) ?? []}
          links={data.links.filter((l) => l.carKey === selectedCar.k)}
          targets={data.targets}
          onClose={() => setSelectedKey(null)}
          onToast={setToast}
          onRefresh={refresh}
          onConfirm={setConfirm}
        />
      )}

      {confirm && (
        <div className="fixed inset-0 z-[80] flex items-end justify-center bg-black/55 p-4 sm:items-center" role="dialog" aria-modal="true" aria-label={confirm.title}>
          <div className="hw-dlg-box">
            <h2 className="hw-h2" style={{ fontSize: 19 }}>{confirm.title}</h2>
            <p className="mt-2 text-sm text-[var(--dim)]">{confirm.body}</p>
            <div className="mt-5 flex gap-2">
              <button type="button" disabled={confirmBusy} className="hw-btn hw-btn-ghost flex-1 px-4 py-2.5 font-semibold disabled:opacity-50" onClick={() => setConfirm(null)}>
                Cancel
              </button>
              <button
                type="button"
                disabled={confirmBusy}
                className="hw-btn flex-1 px-4 py-2.5 font-semibold disabled:opacity-60"
                onClick={async () => {
                  const run = confirm.run;
                  setConfirmBusy(true);
                  try {
                    await run();
                    setConfirm(null);
                  } catch {
                    // Close the dialog but say so: previously the dialog
                    // closed silently while the photo was still there.
                    setConfirm(null);
                    setToast("That couldn't be deleted. Please try again.");
                  } finally {
                    setConfirmBusy(false);
                  }
                }}
              >
                {confirmBusy ? "Working…" : confirm.label}
              </button>
            </div>
          </div>
        </div>
      )}

      </div>
    </>
  );
}

/* ------- Splash screen + Beat That! jingle (press-start only, 2026-11-12) -------
   The jingle is the same user-supplied file as always
   (client/src/assets/beat-that.mp3, the 2.90 s Hot Wheels
   "Beat That!" clip). It is rendered by exactly one <audio> element,
   inside this splash, and it dies with the splash: unmounting pauses
   the element and releases its source, so no detached copy can keep
   playing after Anthony leaves.

   PRESS START ONLY — there is no automatic start any more. Every
   earlier build tried to guess whether a load was a genuine open
   (navigation type, session/build marks, paint proofs, dwell), and
   every guess eventually fired on its own in the background — or,
   after Press Start was added on top of the gate, started before
   Anthony ever got the chance to press it ("I haven't had a chance
   to hit start it just does it on it own"). So the guessing is
   gone: NOTHING in this component calls play() except the Press
   Start handler. No mount trigger, no foreground trigger, no
   timers that start the sound, and no code path that dismisses
   the splash on a timer either — the splash simply waits, silent,
   until he presses the button. A background load can paint this
   splash all it wants; without his thumb on the button there is
   no sound to hear, full stop.

   Pressing Press Start plays the jingle exactly once (the clip
   has no loop and the start is latched, so no second press or
   stray tap can restart it), runs the premium animation in sync
   with it, and the splash leaves when the clip ends — a 4.5 s
   fallback covers a stalled clip, and if a web view ever refuses
   even a pressed play(), the splash still lets him in right away.
   A tap anywhere else on the splash deliberately does nothing:
   the button is the one way in.

   WHILE PLAYING, the same stops as ever apply: if painting stalls
   (a frame gap over ~500 ms — the page was backgrounded or
   throttled), the page hides, or the browser freezes/parks the
   page mid-jingle, the sound pauses and the splash dismisses.
   Before the press those signals do nothing at all — there is no
   sound to stop, and the splash keeps waiting for him. The
   app-wide pauseAllMedia net in App fires on hidden/pagehide as
   a second net.

   TIMING. The jingle is 2.90 s. While the splash waits for the
   press, the premium animation (zoom-in overshoot, hold, gold
   shimmer, glide-right exit) idles on its settled centre frame —
   it does not run ahead without the sound — and the gold
   Press Start button breathes below the logo. On the press the
   choreography restarts from zero on the audio's own clock, so
   picture and sound stay in step; reduced motion shows the
   wallpaper static. */

function SplashScreen({ onDone }: { onDone: () => void }) {
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const splashRef = useRef<HTMLDivElement | null>(null);
  const finishedRef = useRef(false);
  // Set once the jingle is genuinely playing; the animation reads it
  // to switch its clock from wall time to the audio's own position.
  const playingRef = useRef(false);
  // Wall-clock origin for the animation's brief fallback window:
  // once his press has started the jingle but its duration is not
  // readable yet, the choreography runs on this clock until the
  // audio's own position takes over. While the splash is still
  // waiting for the press the animation does not use a clock at
  // all — it idles on its settled frame (see the animation effect).
  const animStartRef = useRef(0);
  // Highest animation progress reached; progress never runs
  // backwards when the clock source switches mid-splash.
  const maxPRef = useRef(0);
  const [leaving, setLeaving] = useState(false);
  // True once the jingle has genuinely started (his press only):
  // the Press Start button hides and can never offer a second play.
  const [jingleStarted, setJingleStarted] = useState(false);
  // The Press Start button's route into the one start path: the
  // jingle effect below publishes its press handler here, and the
  // button is the ONLY caller — there are no automatic or
  // tap-anywhere triggers left to share it with.
  const pressStartRef = useRef<(() => void) | null>(null);
  const [reducedMotion] = useState(
    () =>
      typeof window !== "undefined" &&
      window.matchMedia("(prefers-reduced-motion: reduce)").matches,
  );

  const finish = useCallback(() => {
    if (finishedRef.current) return;
    finishedRef.current = true;
    audioRef.current?.pause();
    setLeaving(true);
    window.setTimeout(onDone, 380);
  }, [onDone]);

  // One rAF loop for the splash's whole life: the mid-play
  // watchdog. The moment painting stalls while the jingle sounds
  // (a frame gap over ~500 ms means the page was backgrounded or
  // throttled to a crawl; a watched splash frames every ~16 ms),
  // the sound stops and the splash dismisses. Before his press
  // the audio is paused, so the watchdog simply idles.
  useEffect(() => {
    let raf = 0;
    let prevFrameAt = 0;
    const loop = () => {
      const now = performance.now();
      if (prevFrameAt > 0) {
        const gap = now - prevFrameAt;
        const audio = audioRef.current;
        if (
          gap > 500 &&
          audio &&
          !audio.paused &&
          !audio.ended &&
          !finishedRef.current
        ) {
          audio.pause();
          finish();
        }
      }
      prevFrameAt = now;
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [finish]);

  // The jingle itself. There is exactly one start path and exactly
  // one caller: his press on the Press Start button, published to
  // pressStartRef below. Nothing here runs on mount, on a timer, or
  // on any page signal — the splash waits silently until he presses.
  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) {
      // No audio element at all: the press just lets him in.
      pressStartRef.current = finish;
      return () => {
        pressStartRef.current = null;
      };
    }
    let cancelled = false;
    let attemptInFlight = false;
    let started = false;
    let fallbackTimer = 0;

    const onPressStart = () => {
      if (cancelled || started || attemptInFlight || finishedRef.current) return;
      if (document.hidden) return;
      if (!audio.paused && !audio.ended) {
        started = true;
        playingRef.current = true;
        setJingleStarted(true);
        return;
      }
      attemptInFlight = true;
      // Hard fallback so a clip that stalls after the press never
      // traps him on the splash; the `ended` event normally wins.
      fallbackTimer = window.setTimeout(finish, 4500);
      let played: Promise<void> | undefined;
      try {
        played = audio.play();
      } catch {
        attemptInFlight = false;
        window.clearTimeout(fallbackTimer);
        finish();
        return;
      }
      if (!played) {
        attemptInFlight = false;
        started = true;
        playingRef.current = true;
        setJingleStarted(true);
        return;
      }
      played.then(
        () => {
          attemptInFlight = false;
          if (cancelled || finishedRef.current) return;
          // Race guard: play() resolves asynchronously — the app
          // can slip into the background while the start is in
          // flight, after every pause handler has already run. If
          // the page is hidden by then, silence it on the spot and
          // leave the start unmarked, so his press still works
          // when he comes back to the splash.
          if (document.hidden) {
            audio.pause();
            return;
          }
          started = true;
          playingRef.current = true;
          setJingleStarted(true);
          // Restart the choreography with the sound instead of
          // leaving the animation wherever the idle frame held it.
          maxPRef.current = 0;
          animStartRef.current = 0;
        },
        () => {
          attemptInFlight = false;
          if (cancelled || finishedRef.current || started) return;
          // Even a genuine press was refused (a web view demanding
          // a different gesture, a decode hiccup). He asked to go
          // in — let him in quietly rather than leaving him stuck
          // on a silent splash.
          finish();
        },
      );
    };

    // The Press Start button is the only trigger there is.
    pressStartRef.current = onPressStart;
    return () => {
      cancelled = true;
      pressStartRef.current = null;
      window.clearTimeout(fallbackTimer);
    };
  }, [finish]);

  // Leaving mid-jingle stops the sound immediately and dismisses
  // the splash: hidden, pagehide, and the Page Lifecycle freeze
  // (the browser parking the page just before a discard/restore).
  // Before his press nothing is playing, so these signals leave
  // the waiting splash exactly as it is — he still gets his chance
  // to hit Start when he comes back. No window blur listener —
  // inside this framed web view, blur fires for shell focus shifts
  // while Anthony is still looking at the page, and it killed the
  // jingle on genuine opens before.
  useEffect(() => {
    const stopForBackground = () => {
      const audio = audioRef.current;
      if (!audio || audio.paused || audio.ended) return;
      audio.pause();
      finish();
    };
    const onVisibility = () => {
      if (document.hidden) stopForBackground();
    };
    document.addEventListener("visibilitychange", onVisibility);
    window.addEventListener("pagehide", stopForBackground);
    document.addEventListener("freeze", stopForBackground);
    return () => {
      document.removeEventListener("visibilitychange", onVisibility);
      window.removeEventListener("pagehide", stopForBackground);
      document.removeEventListener("freeze", stopForBackground);
    };
  }, [finish]);

  // Teardown: when the splash unmounts — however it happens — pause
  // the jingle AND release the audio element. Removing a media
  // element from the page does not stop its sound; a detached
  // <audio> keeps playing out of reach of every pause handler. The
  // jingle cannot outlive the splash.
  useEffect(() => {
    const audio = audioRef.current;
    return () => {
      if (!audio) return;
      try {
        audio.pause();
        audio.removeAttribute("src");
        audio.load();
      } catch {
        // Best-effort only: teardown must never throw.
      }
    };
  }, []);

  // Premium animation synced to the jingle (Ultimate Edition feel).
  // Once his press starts the jingle, the splash element's
  // transform is read from the audio element's own playback
  // position every frame, so the move tracks the sound: glide in
  // from a moderate zoom with a soft overshoot settle, hold centre
  // with a gentle breathing swell, a gold shimmer crosses around
  // the middle, then it glides right off screen, growing and
  // tilting, as the jingle ends at 2.9 s. While the splash waits
  // for the press, the animation idles on the settled centre
  // keyframe with a slow breathing swell — it never runs ahead
  // without the sound. Reduced motion: no animation.
  useEffect(() => {
    if (reducedMotion) return;
    const img = splashRef.current;
    if (!img) return;
    // Keyframes over playback progress p (0..1). `xOff` is a fraction
    // of the off-screen distance, so the exit always clears the image
    // whatever the viewport width; `x` is an absolute pixel offset.
    const KEYS = [
      { p: 0.0, scale: 1.85, x: 0, xOff: 0, rot: -2.5, opacity: 1 },
      { p: 0.1, scale: 1.16, x: 0, xOff: 0, rot: -1, opacity: 1 },
      { p: 0.2, scale: 0.97, x: 0, xOff: 0, rot: 0.4, opacity: 1 },
      { p: 0.3, scale: 1.0, x: 0, xOff: 0, rot: 0, opacity: 1 },
      { p: 0.45, scale: 1.015, x: 0, xOff: 0, rot: 0, opacity: 1 },
      { p: 0.58, scale: 1.02, x: 0, xOff: 0, rot: -0.3, opacity: 1 },
      { p: 0.7, scale: 1.0, x: 0, xOff: 0, rot: 0, opacity: 1 },
      { p: 0.8, scale: 1.05, x: 0, xOff: 0, rot: 0, opacity: 1 },
      { p: 0.88, scale: 1.02, x: 0, xOff: 0, rot: 0, opacity: 1 },
      { p: 0.94, scale: 1.1, x: 0, xOff: 0.35, rot: 3, opacity: 1 },
      { p: 1.0, scale: 1.3, x: 0, xOff: 1, rot: 5.5, opacity: 1 },
    ];
    const easeOutCubic = (t: number) => 1 - Math.pow(1 - t, 3);
    const easeInQuad = (t: number) => t * t;
    const smooth = (t: number) => t * t * (3 - 2 * t);
    // Easing per keyframe segment: a soft ease-out glide for the
    // entrance, gentle smoothing for the hold, accelerating ease-in
    // for the exit.
    const SEGMENT_EASE = [
      easeOutCubic,
      smooth,
      smooth,
      smooth,
      smooth,
      smooth,
      smooth,
      smooth,
      easeInQuad,
      easeInQuad,
    ];
    const BASE_FILTER =
      "drop-shadow(0 3px 8px rgb(0 0 0 / 0.35)) drop-shadow(0 0 2px rgb(0 0 0 / 0.25))";
    let raf = 0;
    const tick = () => {
      if (finishedRef.current) return;
      const audio = audioRef.current;
      let p: number;
      if (
        playingRef.current &&
        audio &&
        Number.isFinite(audio.duration) &&
        audio.duration > 0
      ) {
        p = Math.min(1, Math.max(0, audio.currentTime / audio.duration));
      } else if (playingRef.current) {
        // His press started the jingle but its clock is not
        // readable yet: run the same keyframes on a wall clock
        // until the audio's own position takes over.
        if (animStartRef.current === 0) animStartRef.current = performance.now();
        p = Math.min(1, (performance.now() - animStartRef.current) / 2900);
      } else {
        // Still waiting for his press: hold the settled centre
        // keyframe. The choreography belongs to the jingle; it
        // does not run — and never exits — before he starts it.
        p = 0.3;
      }
      // Progress never runs backwards (see maxPRef above).
      if (p < maxPRef.current) p = maxPRef.current;
      else maxPRef.current = p;
      const vw = window.innerWidth;
      const w = img.offsetWidth || 0;
      const off = vw / 2 + w / 2 + 32;
      // Interpolate between the surrounding keyframes.
      let i = 0;
      while (i < KEYS.length - 2 && p > (KEYS[i + 1]?.p ?? 1)) i += 1;
      const a = KEYS[i] ?? KEYS[0]!;
      const b = KEYS[i + 1] ?? KEYS[KEYS.length - 1]!;
      const span = Math.max(1e-6, b.p - a.p);
      const rawT = Math.min(1, Math.max(0, (p - a.p) / span));
      const ease = SEGMENT_EASE[i] ?? smooth;
      const t = ease(rawT);
      const lerp = (u: number, v: number) => u + (v - u) * t;
      let scale = lerp(a.scale, b.scale);
      const x = lerp(a.x, b.x) + lerp(a.xOff, b.xOff) * off;
      const y = 0;
      const rot = lerp(a.rot, b.rot);
      const skew = 0;
      const opacity = lerp(a.opacity, b.opacity);
      // Subtle breathing swell while the image holds centre.
      if (p >= 0.3 && p < 0.45) {
        scale += 0.01 * Math.sin(((p - 0.3) / 0.15) * Math.PI);
      }
      // Idle breathing while the splash waits for his press: a
      // slow, barely-there swell on the held frame, so the splash
      // feels alive without moving ahead of the sound.
      if (!playingRef.current) {
        scale += 0.008 * Math.sin(performance.now() / 1400);
      }
      // Gold shimmer, roughly the middle of the jingle (about
      // 1.3–1.8 s in): a smooth sine swell lifts the brightness a
      // touch and warms the halo gold, fading in and out on a bell
      // curve so it feels like light crossing a polished surface.
      const SHIMMER_START = 0.45;
      const SHIMMER_END = 0.62;
      let filter = BASE_FILTER;
      if (p >= SHIMMER_START && p <= SHIMMER_END) {
        const u = (p - SHIMMER_START) / (SHIMMER_END - SHIMMER_START);
        const env = Math.sin(u * Math.PI);
        filter =
          `${BASE_FILTER} ` +
          `brightness(${(1 + 0.07 * env).toFixed(3)}) ` +
          `saturate(${(1 + 0.08 * env).toFixed(3)}) ` +
          `drop-shadow(0 0 ${(26 * env).toFixed(1)}px rgb(246 196 83 / ${(0.4 * env).toFixed(3)}))`;
      }
      img.style.transform =
        `translate3d(${x.toFixed(1)}px, ${y.toFixed(1)}px, 0) ` +
        `rotate(${rot.toFixed(2)}deg) skewX(${skew.toFixed(2)}deg) ` +
        `scale(${scale.toFixed(3)})`;
      img.style.opacity = opacity.toFixed(3);
      img.style.filter = filter;
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [reducedMotion]);

  return (
    <div
      ref={splashRef}
      role="dialog"
      aria-modal="true"
      aria-label="Hot Wheels Hunt Book splash screen"
      className={`splash${leaving ? " leaving" : ""}`}
      style={{
        backgroundColor: "#1a7bff",
        // Anthony's blue Hot Wheels wallpaper: the flame logo is part
        // of the image itself, so no separate logo is layered on top.
        // The animation above transforms this whole element, carrying
        // the baked-in logo through the zoom, shimmer, and exit.
        backgroundImage: `url(${splashWallpaperImg})`,
        backgroundSize: "cover",
        backgroundPosition: "center",
        // The splash opens on its settled idle frame (the animation
        // effect holds it there until his press); the zoom-in
        // entrance belongs to the jingle, not to the page load.
        ...(reducedMotion ? {} : { transform: "translate3d(0, 0, 0)" }),
      }}
    >
      {/* Premium Ultimate Edition finish, layered over the wallpaper:
          a gold inner frame with a soft vignette and top gloss, one
          slow sheen sweep across the whole splash, and a small gold
          ULTIMATE EDITION badge under the baked-in logo. All three
          ride inside the splash element, so they travel with the
          jingle-synced animation above. */}
      <div className="splash-frame" aria-hidden="true" />
      <div className="splash-sheen" aria-hidden="true" />
      <div className="splash-badge" aria-hidden="true">
        Ultimate Edition
      </div>
      {/* Press Start: the ONLY way the jingle ever plays. It is
          there from the moment the splash mounts and stays until
          he presses it — nothing starts on its own, and the
          splash does not leave on its own either. Pressing it
          plays the clip exactly once and stops, and the splash
          then leaves on the clip's end. */}
      {!jingleStarted && !leaving && (
        <button
          type="button"
          className="splash-start"
          aria-label="Press start — play the Beat That! jingle"
          onClick={() => pressStartRef.current?.()}
        >
          <span className="splash-start-tri" aria-hidden="true">
            ▶
          </span>
          Press Start
        </button>
      )}
      {/* The one and only jingle element in the app: the Beat That!
          clip, owned by this splash and released when it unmounts. */}
      <audio
        ref={audioRef}
        src={beatThatUrl}
        preload="auto"
        onEnded={() => window.setTimeout(finish, 300)}
      />
    </div>
  );
}

/* ---------------- Sidebar (original drawer) ---------------- */

function Sidebar(props: {
  data: State;
  all: DisplayCar[];
  stateMap: Map<string, CarState>;
  tab: Tab;
  carsFilter: string;
  open: boolean;
  onNavigate: (tab: Tab, filter?: string) => void;
  onClose: () => void;
}) {
  const { data, all, stateMap } = props;
  const [gamesOpen, setGamesOpen] = useState(
    ["1", "2", "R", ...Object.values(GAME_DLC_FILTERS)].includes(props.carsFilter),
  );
  const [yearsOpen, setYearsOpen] = useState(YEAR_CODES.includes(props.carsFilter));

  // Every sidebar count in ONE pass over the catalog, memoized until
  // the collection or its state actually changes. This used to be
  // ~28 separate full-catalog filters (one per menu row, plus one per
  // year chip) re-run on every render of the app — every toast, every
  // refetch — which made routine interactions stutter on a phone as
  // the catalog grew past 5,000 cars. The numbers are identical to
  // the per-row filters they replace.
  const counts = useMemo(() => {
    const groups = new Map<string, { total: number; owned: number }>();
    const years = new Map<string, { total: number; owned: number }>();
    const bump = (map: Map<string, { total: number; owned: number }>, code: string, owned: boolean) => {
      const g = map.get(code) ?? { total: 0, owned: 0 };
      g.total += 1;
      if (owned) g.owned += 1;
      map.set(code, g);
    };
    const groupCodes = ["1", "2", "R", ...Object.values(GAME_DLC_FILTERS), "F", "M", "X"];
    let miss = 0;
    let th = 0;
    let unv = 0;
    let fav = 0;
    let sTotal = 0;
    let sOwned = 0;
    for (const c of all) {
      const st = stateMap.get(c.k);
      const owned = Boolean(st?.owned);
      if (!owned) miss += 1;
      if (st?.isTh) th += 1;
      if (st?.unverified) unv += 1;
      if (owned && st?.isFavorite) fav += 1;
      // Super Treasure Hunts are the S-tagged releases plus any car flagged STH.
      if (c.t.includes("S") || st?.isSth) {
        sTotal += 1;
        if (owned) sOwned += 1;
      }
      for (const code of groupCodes) if (carMatchesFilter(c, code)) bump(groups, code, owned);
      for (const code of YEAR_CODES) if (c.t.includes(code)) bump(years, code, owned);
    }
    return { groups, years, miss, th, unv, fav, sTotal, sOwned };
  }, [all, stateMap]);

  const countFor = (code: string): string => {
    if (code === "all") return `${data.stats.owned}/${all.length}`;
    if (code === "miss") return String(counts.miss);
    if (code === "th") return String(counts.th);
    if (code === "unv") return String(counts.unv);
    if (code === "fav") return String(counts.fav);
    if (code === "S") return `${counts.sOwned}/${counts.sTotal}`;
    const g = counts.groups.get(code) ?? { total: 0, owned: 0 };
    // Game progress is measured against each game's complete roster
    // (base game + all DLC: 157 / 199 / 150), not just the cars the
    // book lists for that game, so the denominator comes from
    // GAME_ROSTER_TOTALS. Every other group counts the book itself.
    const rosterTotal = GAME_ROSTER_TOTALS[code];
    return rosterTotal !== undefined ? `${g.owned}/${rosterTotal}` : `${g.owned}/${g.total}`;
  };
  const yearCount = (code: string): string => {
    const y = counts.years.get(code) ?? { total: 0, owned: 0 };
    return `${y.owned}/${y.total}`;
  };
  // Group header totals add the three games up the same way the rows
  // do: owned counted once per game a car appears in, over the sum of
  // the three complete rosters (157 + 199 + 150 = 506).
  const gamesOwnedSum = (["1", "2", "R"] as const).reduce(
    (sum, code) => sum + (counts.groups.get(code)?.owned ?? 0),
    0,
  );
  const gamesRosterSum = (["1", "2", "R"] as const).reduce(
    (sum, code) => sum + (GAME_ROSTER_TOTALS[code] ?? 0),
    0,
  );
  const gamesTotal = `${gamesOwnedSum}/${gamesRosterSum}`;
  const earned = data.badges.filter((b) => b.earned).length;

  const item = (
    tab: Tab,
    filter: string | undefined,
    icon: ReactNode,
    label: string,
    count?: string,
    sub = false,
    ariaLabel?: string,
  ) => {
    const active = filter === undefined ? props.tab === tab : props.tab === "cars" && props.carsFilter === filter;
    return (
      <button
        key={`${tab}-${filter ?? ""}-${label}`}
        type="button"
        aria-label={ariaLabel}
        className={`nv ${active ? "on" : ""}${sub ? " sub" : ""}`}
        onClick={() => props.onNavigate(tab, filter)}
      >
        <span aria-hidden="true">{icon}</span>
        {label}
        {count !== undefined && <small>{count}</small>}
      </button>
    );
  };

  return (
    <>
      <button
        type="button"
        aria-label="Close menu"
        className={`hw-scrim ${props.open ? "on" : ""}`}
        onClick={props.onClose}
        tabIndex={props.open ? 0 : -1}
      />
      <aside className={`hw-side ${props.open ? "open" : ""}`} aria-label="Hunt Book menu">
        <div className="sb-h">
          <img src={logoImg} alt="Hot Wheels" />
        </div>
        <div className="sb-t" aria-hidden="true" />
        <div className="sb-premium">
          <span className="sb-premium-badge">★ Ultimate Edition</span>
          <span className="sb-premium-stats">
            {data.stats.owned} / {data.stats.total} owned · {data.stats.th} TH · 🔥 {data.streak.current}-day streak
          </span>
        </div>
        {item("home", undefined, "🏠", "Home")}
        {item("favorites", undefined, "❤️", "Favorites", countFor("fav"))}
        <div className="sb-s">Hunt</div>
        {item("planner", undefined, "📅", "Hunt Planner")}
        {item("cars", "th", "⭐", "Treasure Hunts", countFor("th"))}
        {item("cars", "S", "🌟", "Super Treasure Hunts", countFor("S"))}
        {item("cars", "miss", "🎯", "Still Missing", countFor("miss"))}
        {item("cars", "unv", "📷", "Needs a photo", countFor("unv"))}
        <div className="sb-s">Collection</div>
        {item("cars", "all", "🏁", "All Cars", countFor("all"))}
        <details
          className="sb-d"
          open={gamesOpen}
          onToggle={(e) => setGamesOpen(e.currentTarget.open)}
        >
          <summary aria-label="Hot Wheels Games">🎮 Hot Wheels Games<small>{gamesTotal}</small></summary>
          <div className="sb-g">
            {item("cars", "1", <img src={unleashed1Img} alt="" />, "Unleashed 1", countFor("1"))}
            {item("cars", GAME_DLC_FILTERS["1"] ?? "1P", "💜", "DLC", countFor(GAME_DLC_FILTERS["1"] ?? "1P"), true, "Unleashed 1 DLC")}
            {item("cars", "2", <img src={unleashed2Img} alt="" />, "Unleashed 2", countFor("2"))}
            {item("cars", GAME_DLC_FILTERS["2"] ?? "2Q", "💜", "DLC", countFor(GAME_DLC_FILTERS["2"] ?? "2Q"), true, "Unleashed 2 DLC")}
            {item("cars", "R", <img src={infiniteRushImg} alt="" />, "Infinite Rush", countFor("R"))}
            {item("cars", GAME_DLC_FILTERS.R ?? "RT", "💜", "DLC", countFor(GAME_DLC_FILTERS.R ?? "RT"), true, "Infinite Rush DLC")}
          </div>
        </details>
        <details
          className="sb-d"
          open={yearsOpen}
          onToggle={(e) => setYearsOpen(e.currentTarget.open)}
        >
          <summary aria-label="Mainline by year, 2015 to 2027">🗓️ Mainline by year<small>2015–27</small></summary>
          <div className="ycg">
            {[...YEAR_CODES].reverse().map((code) => (
              <button
                key={code}
                type="button"
                className={`yc ${props.tab === "cars" && props.carsFilter === code ? "on" : ""}`}
                onClick={() => props.onNavigate("cars", code)}
              >
                <b>{YEAR_LABELS[code]}</b>
                <small>{yearCount(code)}</small>
              </button>
            ))}
          </div>
        </details>
        {item("cars", "F", "🔥", "Fantasy Castings", countFor("F"))}
        {item("cars", "M", "🏷️", "Mainline", countFor("M"))}
        {item("cars", "X", "🆕", "Other 2026–27 Releases", countFor("X"))}
        <div className="sb-s">Media</div>
        {item("gallery", undefined, "🖼️", "Photo Gallery", String(data.photos.length))}
        {item("gallery", undefined, "🎬", "Videos", String(data.videos.length))}
        {item("videos", undefined, "📺", "Video Feed")}
        {item("music", undefined, "🎵", "Music", String(data.tracks.length))}
        {item("chat", undefined, "💬", "Chat with Hot Wheels Manager")}
        <div className="sb-s">Rewards</div>
        {item("rewards", undefined, "⭐", "Rewards & Points", `${data.points.balance} pts`)}
        <div className="sb-s">Settings</div>
        {item("profile", undefined, "🏅", "Badges", `${earned}/${data.badges.length}`)}
        {item("profile", undefined, "👤", "My Profile")}
        {item("profile", undefined, "⚙️", "Backup & Settings")}
        {item("diagnostics", undefined, "🩺", "Diagnostics")}
        <div className="sb-t" style={{ marginTop: 18 }} aria-hidden="true" />
        <div className="sb-drive">DRIVE TO WIN</div>
      </aside>
    </>
  );
}

/* ---------------- Home ---------------- */

// One photo tile in a Home showcase grid (Treasure Hunt showcase,
// Favorites showcase): the car's cover photo (or the faded logo
// placeholder when its photo can't load), its name, and a small tag.
// Super Treasure Hunts get the gold frame via .show-tile-sth.
function ShowcaseTile(props: {
  car: DisplayCar;
  photoUrl: string | null;
  badge: { label: string; cls: string } | null;
  sth?: boolean;
  onOpen: (key: string) => void;
}) {
  const { car } = props;
  return (
    <button
      type="button"
      className={`show-tile${props.sth ? " show-tile-sth" : ""}`}
      onClick={() => props.onOpen(car.k)}
      aria-label={`Open ${car.n}`}
    >
      {props.photoUrl ? (
        <img src={props.photoUrl} alt="" className="show-photo" loading="lazy" />
      ) : (
        <span className="show-ph" aria-hidden="true">
          <img src={logoImg} alt="" />
        </span>
      )}
      <span className="show-tile-name">{car.n}</span>
      {props.badge && <span className={`tag ${props.badge.cls}`}>{props.badge.label}</span>}
    </button>
  );
}

function HomeView(props: {
  data: State;
  byKey: Map<string, DisplayCar>;
  stateMap: Map<string, CarState>;
  photosByCar: Map<string, State["photos"]>;
  onOpenCar: (key: string) => void;
  onQuick: (tab: Tab, filter?: string) => void;
  onOwn: (key: string) => Promise<unknown>;
  onToast: (msg: string) => void;
  onBoost: () => void;
  onGoBackup: () => void;
  onShowBadges: () => void;
  onGoPlanner: () => void;
  onChat: () => void;
  onMusic: () => void;
  onVideos: () => void;
  onFavorites: () => void;
  onRewards: () => void;
}) {
  const { data } = props;
  const pct = data.stats.total > 0 ? Math.round((data.stats.owned / data.stats.total) * 100) : 0;
  const ringOff = 314 * (1 - pct / 100);
  const name = data.profile.name.trim() || "Collector";
  const carOfDay = data.carOfDayKey ? props.byKey.get(data.carOfDayKey) ?? null : null;
  const quote = QUOTES[data.quoteIndex % QUOTES.length] ?? QUOTES[0] ?? "";
  const earned = data.badges.filter((b) => b.earned).length;
  const showBackupNote = data.stats.owned === 0 && data.customCars.length === 0;
  const nextBadge = closestUnearnedBadge(data.badges);
  const nextRemaining = nextBadge ? Math.max(0, nextBadge.goal - nextBadge.progress) : 0;
  const nextShown = nextBadge ? Math.min(nextBadge.progress, nextBadge.goal) : 0;
  const nextUnit = nextBadge ? badgeUnit(nextBadge.id) : "";
  const nextRemainingLabel = nextBadge
    ? nextBadge.id.startsWith("stk")
      ? `${nextRemaining} ${nextUnit}${nextRemaining === 1 ? "" : "s"} away`
      : `${nextRemaining} ${nextUnit}${nextRemaining === 1 ? "" : "s"} to go`
    : "";
  // Days left until the Nov 14 Kansas Die-cast hunt, counted in
  // Chicago calendar days like the rest of the app (chicagoToday),
  // with both dates at UTC midnight so daylight saving never skews
  // the count by one. No planner, target, or car data is read here:
  // the hunt date itself is fixed, so the card is purely a countdown
  // that taps through to the Planner.
  const huntDaysLeft = (() => {
    const [ty = 1970, tm = 1, td = 1] = chicagoToday().split("-").map(Number);
    const todayMs = Date.UTC(ty, tm - 1, td);
    const huntMs = Date.UTC(2026, 10, 14);
    return Math.round((huntMs - todayMs) / 86_400_000);
  })();
  const huntLabel =
    huntDaysLeft > 1
      ? `${huntDaysLeft} days to go`
      : huntDaysLeft === 1
        ? "1 day to go"
        : huntDaysLeft === 0
          ? "Today!"
          : "Hunt day has passed";
  const huntCountText = huntDaysLeft > 0 ? String(huntDaysLeft) : huntDaysLeft === 0 ? "0" : "—";
  const huntCountUnit = huntDaysLeft === 1 ? "day" : huntDaysLeft > 0 ? "days" : huntDaysLeft === 0 ? "today" : "passed";
  const [verifyCar, setVerifyCar] = useState<DisplayCar | null>(null);

  // Showcase lists, drawn only from Anthony's real marks: the cover
  // photo of a car is its first photo in position order, and the
  // thumbnail stands in for the full photo so Home loads fast. TH
  // showcase puts the Super Treasure Hunt first, then the rest A–Z.
  const coverUrl = (key: string): string | null => {
    const p = props.photosByCar.get(key)?.[0];
    return p && p.url ? p.thumbUrl ?? p.url : null;
  };
  const thShowcase = data.carStates
    .filter((s) => s.isTh || s.isSth)
    .map((s) => {
      const car = props.byKey.get(s.carKey);
      return car ? { car, isSth: s.isSth } : null;
    })
    .filter((x): x is { car: DisplayCar; isSth: boolean } => x !== null)
    .sort((a, b) => Number(b.isSth) - Number(a.isSth) || a.car.n.localeCompare(b.car.n));
  const favShowcase = data.carStates
    .filter((s) => s.isFavorite)
    .map((s) => props.byKey.get(s.carKey))
    .filter((c): c is DisplayCar => !!c)
    .sort((a, b) => a.n.localeCompare(b.n));

  return (
    <div className="space-y-5 stagger">
      <section aria-label="Collection showcase" className="pn pn-premium showcase">
        <div>
          <span className="show-kicker">★ Ultimate Edition</span>
          <h2 className="hw-h2" style={{ fontSize: 20, margin: "6px 0 0" }}>
            {greet()}, {name} 👋
          </h2>
          <small className="mut">Here&apos;s your garage today</small>
        </div>
        <div className="hring mt-3">
          <svg className="ring-glow" viewBox="0 0 120 120" width="108" height="108" style={{ flex: "none" }} role="img" aria-label={`${pct}% owned`}>
            <defs>
              <linearGradient id="rg" x1="0" y1="0" x2="1" y2="1">
                <stop offset="0" stopColor="#ffd21f" />
                <stop offset="0.55" stopColor="#eda417" />
                <stop offset="1" stopColor="#e8321e" />
              </linearGradient>
            </defs>
            <circle cx="60" cy="60" r="50" fill="none" stroke="#243468" strokeWidth="12" />
            <circle cx="60" cy="60" r="50" fill="none" stroke="url(#rg)" strokeWidth="12" strokeLinecap="round" strokeDasharray="314" strokeDashoffset={ringOff} transform="rotate(-90 60 60)" style={{ transition: "stroke-dashoffset 1s ease" }} />
            <text x="60" y="67" textAnchor="middle" fontSize="26" fontWeight="900" fill="currentColor">{pct}%</text>
          </svg>
          <div className="hstats">
            <div className="st">🏁<b>{data.stats.owned}</b><small>of {data.stats.total} owned</small></div>
            <div className="st">📦<b>{data.stats.copies}</b><small>total copies</small></div>
            <div className="st">⭐<b>{data.stats.th}</b><small>Treasure Hunts</small></div>
            <div className="st">🌟<b>{data.stats.sth}</b><small>Super Treasure Hunts</small></div>
            <div className="st">❤️<b>{data.stats.favorites}</b><small>Favorites</small></div>
            <div className="st">📷<b>{data.stats.photoCount}</b><small>Photos</small></div>
          </div>
        </div>
      </section>

      <button
        type="button"
        aria-label={`Next hunt: Kansas Die-cast, Saturday, November 14, ${huntLabel}. Open the Hunt Planner`}
        className="pn next-badge-card gold-ring"
        onClick={props.onGoPlanner}
      >
        <span className="hw-h2">📅 Next hunt</span>
        <span className="next-badge-row">
          <span className="next-hunt-count" aria-hidden="true">
            <span className="next-hunt-number">{huntCountText}</span>
            <span className="next-hunt-unit">{huntCountUnit}</span>
          </span>
          <span className="next-badge-main">
            <span className="next-badge-name">Kansas Die-cast</span>
            <span className="next-badge-desc">Saturday, November 14</span>
          </span>
          <span className="next-badge-chevron" aria-hidden="true">›</span>
        </span>
        <span className="next-badge-foot">
          <span className="next-badge-left">{huntLabel}</span>
          <span>Open planner ›</span>
        </span>
      </button>

      {nextBadge ? (
        <button
          type="button"
          aria-label={`Next badge: ${nextBadge.name}, ${nextShown} of ${nextBadge.goal}, ${nextRemainingLabel}. View all badges`}
          className="pn next-badge-card gold-ring"
          onClick={props.onShowBadges}
        >
          <span className="hw-h2">🏅 Next badge</span>
          <span className="next-badge-row">
            <span className="next-badge-icon" aria-hidden="true">{nextBadge.icon}</span>
            <span className="next-badge-main">
              <span className="next-badge-name">{nextBadge.name}</span>
              <span className="next-badge-desc">{nextBadge.desc}</span>
            </span>
            <span className="next-badge-chevron" aria-hidden="true">›</span>
          </span>
          <span className="bar" aria-hidden="true">
            <i style={{ width: `${Math.min(100, (nextBadge.progress / nextBadge.goal) * 100)}%` }} />
          </span>
          <span className="next-badge-foot">
            <span>{nextShown} of {nextBadge.goal}</span>
            <span className="next-badge-left">{nextRemainingLabel}</span>
          </span>
        </button>
      ) : (
        <button
          type="button"
          aria-label={`All badges earned, ${earned} of ${data.badges.length}. View all badges`}
          className="pn next-badge-card gold-ring"
          onClick={props.onShowBadges}
        >
          <span className="hw-h2">🏅 Next badge</span>
          <span className="next-badge-row">
            <span className="next-badge-icon" aria-hidden="true">🏆</span>
            <span className="next-badge-main">
              <span className="next-badge-name">All badges earned</span>
              <span className="next-badge-desc">Every badge in the Hunt Book is yours.</span>
            </span>
            <span className="next-badge-chevron" aria-hidden="true">›</span>
          </span>
          <span className="bar" aria-hidden="true">
            <i style={{ width: "100%" }} />
          </span>
          <span className="next-badge-foot">
            <span>{earned} of {data.badges.length}</span>
            <span className="next-badge-left">View all badges ›</span>
          </span>
        </button>
      )}

      {(() => {
        const pts = data.points;
        const curLevel = pts.levels.find((l) => l.level === pts.level);
        const levelStart = curLevel?.at ?? 0;
        const progressPct = pts.nextLevel
          ? Math.min(100, Math.max(0, ((pts.lifetime - levelStart) / (pts.nextLevel.at - levelStart)) * 100))
          : 100;
        const toNext = pts.nextLevel ? pts.nextLevel.at - pts.lifetime : 0;
        return (
          <button
            type="button"
            aria-label={`Points and rewards: ${pts.balance} points to spend, ${pts.lifetime} lifetime points, Level ${pts.level} ${pts.levelName}${pts.nextLevel ? `, ${toNext} points to ${pts.nextLevel.name}` : ""}. Open Rewards and Points`}
            className="pn next-badge-card gold-ring"
            onClick={props.onRewards}
          >
            <span className="hw-h2">⭐ Points &amp; Rewards</span>
            <span className="next-badge-row">
              <span className="next-hunt-count" aria-hidden="true">
                <span className="next-hunt-number">{pts.balance}</span>
                <span className="next-hunt-unit">to spend</span>
              </span>
              <span className="next-badge-main">
                <span className="next-badge-name">{pts.levelIcon} Level {pts.level} · {pts.levelName}</span>
                <span className="next-badge-desc">{pts.lifetime} lifetime points</span>
              </span>
              <span className="next-badge-chevron" aria-hidden="true">›</span>
            </span>
            <span className="bar" aria-hidden="true">
              <i style={{ width: `${progressPct}%` }} />
            </span>
            <span className="next-badge-foot">
              <span>{pts.nextLevel ? `Next: Level ${pts.nextLevel.level} ${pts.nextLevel.name}` : "Top level reached 🏆"}</span>
              <span className="next-badge-left">{pts.nextLevel ? `${toNext} points to go` : "Hot Wheels Legend!"}</span>
            </span>
          </button>
        );
      })()}

      {thShowcase.length > 0 && (
        <section aria-label="Treasure Hunt showcase" className="pn">
          <h2 className="hw-h2">🏆 Treasure Hunt Showcase</h2>
          <div className="show-grid">
            {thShowcase.map(({ car, isSth }) => (
              <ShowcaseTile
                key={car.k}
                car={car}
                photoUrl={coverUrl(car.k)}
                badge={isSth ? { label: "★ STH", cls: "tag-sth" } : { label: "TH", cls: "tag-th" }}
                sth={isSth}
                onOpen={props.onOpenCar}
              />
            ))}
          </div>
          <p className="mt-2 text-sm text-[var(--dim)]">
            {data.stats.th} Treasure Hunts and {data.stats.sth} Super Treasure Hunt{data.stats.sth === 1 ? "" : "s"} in the
            garage — tap one to open it.
          </p>
        </section>
      )}

      {data.stats.unverified > 0 && (
        <section aria-label="Cars needing a photo to verify" className="pn">
          <h2 className="hw-h2">📷 Photo check</h2>
          <p className="mt-1 text-sm text-[var(--dim)]">
            {data.stats.unverified} {data.stats.unverified === 1 ? "owned or Treasure Hunt car is" : "owned or Treasure Hunt cars are"} flagged
            unverified — no photo of {data.stats.unverified === 1 ? "that car" : "those cars"} yet. Add a photo of each one to verify it.
          </p>
          <button type="button" className="hw-btn mt-3 px-4 py-2.5 text-sm font-bold" onClick={() => props.onQuick("cars", "unv")}>
            See unverified cars
          </button>
        </section>
      )}

      <section aria-label="Favorites" className="pn">
        <h2 className="hw-h2">❤️ Favorites</h2>
        {favShowcase.length === 0 ? (
          <p className="mt-1 text-sm text-[var(--dim)]">
            Your favorite cars, picked only from the ones you own. Add your Top 10 and the cars you reach for most.
          </p>
        ) : (
          <>
            <div className="show-grid">
              {favShowcase.slice(0, 6).map((car) => (
                <ShowcaseTile
                  key={car.k}
                  car={car}
                  photoUrl={coverUrl(car.k)}
                  badge={{ label: "❤️ FAVORITE", cls: "tag-fav" }}
                  onOpen={props.onOpenCar}
                />
              ))}
            </div>
            <p className="mt-2 text-sm text-[var(--dim)]">
              {data.stats.favorites} {data.stats.favorites === 1 ? "favorite" : "favorites"} picked from your{" "}
              {data.stats.owned} owned cars.
              {data.stats.favorites > 6 ? " Showing 6 here — open Favorites to see them all." : ""}
            </p>
          </>
        )}
        <button type="button" className="hw-btn mt-3 px-4 py-2.5 text-sm font-bold" onClick={props.onFavorites}>
          Open Favorites
        </button>
      </section>

      <section aria-label="Music" className="pn">
        <h2 className="hw-h2">🎵 Music</h2>
        <p className="mt-1 text-sm text-[var(--dim)]">
          {data.tracks.length === 0
            ? "Pick MP3s from your phone and they stay saved here as your playlist."
            : `${data.tracks.length} ${data.tracks.length === 1 ? "song" : "songs"} in your playlist.`}
        </p>
        <button type="button" className="hw-btn mt-3 px-4 py-2.5 text-sm font-bold" onClick={props.onMusic}>
          Open Music
        </button>
      </section>

      <section aria-label="Video Feed" className="pn">
        <h2 className="hw-h2">📺 Video Feed</h2>
        <p className="mt-1 text-sm text-[var(--dim)]">
          {data.videos.length === 0
            ? "Your own hunt videos plus Hot Wheels videos from YouTube — hunts, new releases, and collection showcases."
            : `${data.videos.length} ${data.videos.length === 1 ? "video" : "videos"} of yours saved, plus Hot Wheels videos from YouTube.`}
        </p>
        <button type="button" className="hw-btn mt-3 px-4 py-2.5 text-sm font-bold" onClick={props.onVideos}>
          Open Video Feed
        </button>
      </section>

      <section aria-label="Chat with Hot Wheels Manager" className="pn">
        <h2 className="hw-h2">💬 Chat with Hot Wheels Manager</h2>
        <p className="mt-1 text-sm text-[var(--dim)]">
          Ask about your collection, what to hunt next, or tell Hot Wheels Manager you found a car and it can mark it owned for you.
        </p>
        <button type="button" className="hw-btn mt-3 px-4 py-2.5 text-sm font-bold" onClick={props.onChat}>
          Open the chat
        </button>
      </section>

      {showBackupNote && (
        <section aria-label="Restore a backup" className="pn">
          <h2 className="hw-h2">Your collection starts empty here</h2>
          <p className="mt-1 text-sm text-[var(--dim)]">
            If you have a backup from the original Hunt Book app, restore it and your cars, targets, and hunt days come back —
            photos included when they are in the backup file.
          </p>
          <button type="button" className="hw-btn mt-3 px-4 py-2 text-sm font-bold" onClick={props.onGoBackup}>
            Restore a backup
          </button>
        </section>
      )}

      {carOfDay && (
        <section aria-label="Car of the day" className="pn">
          <h2 className="hw-h2">🎲 Car of the day</h2>
          <div className="flex items-center gap-3">
            {(() => {
              const photo = props.photosByCar.get(carOfDay.k)?.[0];
              return photo && photo.url ? (
                <img src={photo.thumbUrl ?? photo.url} alt="" loading="lazy" decoding="async" className="h-16 w-16 shrink-0 rounded-[10px] object-cover" />
              ) : (
                <div className="flex h-16 w-16 shrink-0 items-center justify-center rounded-[10px] bg-[#0e1738]">
                  <img src={logoImg} alt="" className="h-[70%] w-[70%] object-contain opacity-45 grayscale" />
                </div>
              );
            })()}
            <div className="min-w-0 flex-1">
              <p className="font-bold leading-tight">{carOfDay.n}</p>
              <div className="mt-1 flex flex-wrap">
                {tagsToChips(carOfDay.t).map((c) => (
                  <span key={c.label} className={`tag ${c.cls}`}>{c.label}</span>
                ))}
                {carOfDay.custom && <span className="tag tag-custom">MY ADD</span>}
              </div>
            </div>
          </div>
          {carOfDay.x && <p className="mt-2 text-sm text-[var(--dim)]">{carOfDay.x}</p>}
          <div className="mt-2 flex gap-2">
            <button type="button" className="hw-btn hw-btn-alt flex-1" onClick={() => props.onOpenCar(carOfDay.k)}>
              Open
            </button>
            <button
              type="button"
              className="hw-btn flex-1"
              onClick={() => {
                if (hasUsablePhoto(props.photosByCar.get(carOfDay.k))) {
                  void props.onOwn(carOfDay.k);
                } else {
                  setVerifyCar(carOfDay);
                }
              }}
            >
              I found it! OWN
            </button>
          </div>
        </section>
      )}

      <section aria-label="Recently added" className="pn">
        <h2 className="hw-h2">🆕 Recently added</h2>
        {data.recent.length === 0 ? (
          <p className="mt-1 text-sm text-[var(--dim)]">Nothing marked owned yet. Tap OWN on a car in the Cars tab when you find one.</p>
        ) : (
          <ul className="mt-2">
            {data.recent.map((r) => {
              const car = props.byKey.get(r.carKey);
              if (!car) return null;
              return (
                <li key={r.carKey}>
                  <button type="button" className="flex w-full items-center justify-between border-b border-[var(--border)] py-2 text-left" onClick={() => props.onOpenCar(r.carKey)}>
                    <span className="font-semibold">{car.n}</span>
                    <span className="text-xs text-[var(--dim)]">{new Date(r.ownedAt).toLocaleDateString(undefined, { month: "short", day: "numeric" })}</span>
                  </button>
                </li>
              );
            })}
          </ul>
        )}
        <p className="mt-3 border-t border-[var(--border)] pt-3 text-sm text-[var(--dim)]">
          {data.stats.weekCount} {data.stats.weekCount === 1 ? "car" : "cars"} added this week.
        </p>
      </section>

      <section aria-label="Badges" className="pn">
        <div className="flex items-baseline justify-between">
          <h2 className="hw-h2">🏅 Badges</h2>
          <span className="text-sm font-bold text-[var(--accent)]">{earned}/{data.badges.length}</span>
        </div>
        <ul className="mt-2 space-y-2">
          {data.badges.slice(0, 4).map((b) => (
            <li key={b.id} className="flex items-center gap-3">
              <span className="text-xl" aria-hidden="true">{b.icon}</span>
              <div className="min-w-0 flex-1">
                <p className="text-sm font-semibold">{b.name}</p>
                <div className="bar">
                  <i style={{ width: `${Math.min(100, (b.progress / b.goal) * 100)}%` }} />
                </div>
              </div>
              <span className="text-xs text-[var(--dim)]">{Math.min(b.progress, b.goal)}/{b.goal}</span>
            </li>
          ))}
        </ul>
        <button type="button" className="hw-btn hw-btn-alt mt-3 text-sm font-bold" onClick={props.onShowBadges}>
          View all badges
        </button>
      </section>

      <section aria-label="Motivation" className="pn">
        <h2 className="hw-h2">Never stop the hunt</h2>
        <p className="big">{quote}</p>
        <button type="button" className="hw-btn mt-1 text-sm font-bold" onClick={props.onBoost}>
          🔥 New boost
        </button>
      </section>

      {verifyCar && (
        <PhotoVerifyDialog
          car={verifyCar}
          kind="own"
          onClose={() => setVerifyCar(null)}
          onToast={props.onToast}
          applyMark={() => props.onOwn(verifyCar.k)}
        />
      )}
    </div>
  );
}

/* ---------------- Cars ---------------- */

function CarsView(props: {
  data: State;
  all: DisplayCar[];
  stateMap: Map<string, CarState>;
  photosByCar: Map<string, State["photos"]>;
  filter: string;
  onFilterChange: (filter: string) => void;
  onSelect: (key: string) => void;
  onToggleOwn: (key: string, owned: boolean) => Promise<unknown>;
  onToggleTh: (key: string, th: boolean) => Promise<unknown>;
  onToggleFavorite: (key: string, fav: boolean) => Promise<void>;
  onToast: (msg: string) => void;
  onRefresh: () => void;
}) {
  const [query, setQuery] = useState("");
  const filter = props.filter;
  const setFilter = props.onFilterChange;
  const [limit, setLimit] = useState(60);
  // Letter the jump row asked for; the effect below scrolls to its
  // header once the list has rendered with that section included.
  const [pendingJump, setPendingJump] = useState<string | null>(null);
  const [showAdd, setShowAdd] = useState(false);
  const [targetsOnly, setTargetsOnly] = useState(false);

  // Cars list layout + tile size, persisted server-side with the rest
  // of the app data (see updateCarsSettings) so the collection
  // reopens the way it was left — the same pattern as the gallery
  // settings. The local copy drives the layout instantly; the server
  // copy re-syncs it on refresh.
  type CarsSettings = State["carsSettings"];
  const [carsSettings, setCarsSettings] = useState<CarsSettings>(() => props.data.carsSettings);
  useEffect(() => {
    setCarsSettings(props.data.carsSettings);
  }, [props.data.carsSettings]);
  const changeCarsSettings = (patch: Partial<CarsSettings>) => {
    const next = { ...carsSettings, ...patch };
    setCarsSettings(next);
    void api
      .updateCarsSettings(patch)
      .then(() => props.onRefresh())
      .catch(() => props.onToast("That setting could not be saved. Try again."));
  };
  // The sort order is one of the saved cars settings, so the list
  // reopens sorted the way it was left; changing it here saves it the
  // same way the layout and tile size do.
  const sort = carsSettings.sort;
  const setSort = (value: CarsSettings["sort"]) => changeCarsSettings({ sort: value });
  const [verifyReq, setVerifyReq] = useState<{
    car: DisplayCar;
    kind: "own" | "th";
    apply: () => Promise<unknown>;
  } | null>(null);

  // Turning a mark ON needs photo proof (unless the car already has a
  // usable photo); turning it OFF never does.
  const requestToggle = (
    car: DisplayCar,
    kind: "own" | "th",
    turningOn: boolean,
    apply: () => Promise<unknown>,
  ) => {
    if (!turningOn || hasUsablePhoto(props.photosByCar.get(car.k))) {
      void apply();
      return;
    }
    setVerifyReq({ car, kind, apply });
  };

  // Cars marked as hunt targets, in any planner month: by car key, or
  // by exact name for a target added as free text with no car key. A
  // car counts once even if it is a target in several months, and a
  // done target still counts — only removing it un-marks it.
  const targetKeys = useMemo(() => {
    const keys = new Set<string>();
    const names = new Set<string>();
    for (const t of props.data.targets) {
      if (t.carKey) keys.add(t.carKey);
      names.add(t.text);
    }
    return { keys, names };
  }, [props.data.targets]);
  const targetCarCount = useMemo(
    () => props.all.filter((c) => targetKeys.keys.has(c.k) || targetKeys.names.has(c.n)).length,
    [props.all, targetKeys],
  );

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return props.all.filter((c) => {
      if (q && !carSearchHaystackCached(c).includes(q)) return false;
      if (targetsOnly && !targetKeys.keys.has(c.k) && !targetKeys.names.has(c.n)) return false;
      const st = props.stateMap.get(c.k);
      if (filter === "miss") return !st?.owned;
      if (filter === "own") return Boolean(st?.owned);
      if (filter === "fav") return Boolean(st?.owned && st?.isFavorite);
      if (filter === "th") return Boolean(st?.isTh);
      if (filter === "unv") return Boolean(st?.unverified);
      if (filter === "S") return c.t.includes("S") || Boolean(st?.isSth);
      if (filter === "all") return true;
      return carMatchesFilter(c, filter);
    });
  }, [props.all, props.stateMap, query, filter, targetsOnly, targetKeys]);

  // Variant groups within the cars currently on show: cars whose names
  // differ only by a model year, a bracketed note, or a sequel numeral
  // (see castingBase) share a group. A group only counts when at least
  // two of its cars are in the current filter/search, and each member
  // maps to the group's display base (the main casting's name, taken
  // from its shortest member) and the group's size. Grouping never
  // merges cars: it only clusters them in the A–Z order and labels
  // them; every car keeps its own tile, count, and controls.
  const groupInfo = useMemo(() => {
    const byGroup = new Map<string, DisplayCar[]>();
    for (const car of filtered) {
      const gk = castingGroupKey(car.n);
      const members = byGroup.get(gk) ?? [];
      members.push(car);
      byGroup.set(gk, members);
    }
    const info = new Map<string, { base: string; size: number }>();
    for (const members of byGroup.values()) {
      if (members.length < 2) continue;
      const shortest = [...members].sort((a, b) => a.n.length - b.n.length || compareCars(a, b))[0];
      if (!shortest) continue;
      const base = castingBase(shortest.n);
      for (const m of members) info.set(m.k, { base, size: members.length });
    }
    return info;
  }, [filtered]);
  const variantGroupCount = useMemo(
    () => new Set([...groupInfo.values()].map((g) => g.base)).size,
    [groupInfo],
  );

  // The letter a car sits under in the A–Z order: grouped cars file
  // under their main casting's name, every other car under its own.
  const displayInitial = (car: DisplayCar): string => {
    const g = groupInfo.get(car.k);
    return g ? initialLetter(g.base) : initialLetter(car.n);
  };

  // A–Z order with variant grouping: a grouped car sorts by its main
  // casting's name so the variants sit together under it; singletons
  // sort by their own name exactly as before. Digit-leading keys still
  // file before letters, and the car's own name breaks ties inside a
  // group (so "2012 …" and "2018 …" precede the bare casting name).
  const compareAz = (a: DisplayCar, b: DisplayCar): number => {
    const ka = groupInfo.has(a.k) ? castingGroupKey(a.n) : sortKey(a.n);
    const kb = groupInfo.has(b.k) ? castingGroupKey(b.n) : sortKey(b.n);
    const da = /^\d/.test(ka);
    const db = /^\d/.test(kb);
    if (da !== db) return da ? -1 : 1;
    if (ka !== kb) return ka < kb ? -1 : 1;
    return compareCars(a, b);
  };

  const ordered = useMemo(() => {
    if (sort === "series") {
      return [...filtered].sort((a, b) => {
        const [ra, ya] = seriesRank(a);
        const [rb, yb] = seriesRank(b);
        return ra - rb || ya - yb || compareCars(a, b);
      });
    }
    if (sort === "new") return [...filtered].sort((a, b) => (carYear(b.t) ?? 0) - (carYear(a.t) ?? 0) || compareCars(a, b));
    if (sort === "old") return [...filtered].sort((a, b) => (carYear(a.t) ?? 9999) - (carYear(b.t) ?? 9999) || compareCars(a, b));
    if (sort === "own") return [...filtered].sort((a, b) => Number(props.stateMap.get(b.k)?.owned ?? false) - Number(props.stateMap.get(a.k)?.owned ?? false) || compareCars(a, b));
    if (sort === "miss") return [...filtered].sort((a, b) => Number(props.stateMap.get(a.k)?.owned ?? false) - Number(props.stateMap.get(b.k)?.owned ?? false) || compareCars(a, b));
    return [...filtered].sort(compareAz);
    // compareAz reads groupInfo, which is a memo over `filtered`.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [filtered, sort, groupInfo, props.stateMap]);

  const shown = ordered.slice(0, limit);
  const ownedCount = useMemo(
    () => props.all.filter((c) => props.stateMap.get(c.k)?.owned).length,
    [props.all, props.stateMap],
  );

  // Letters present in the current filter/search, in A–Z order, and
  // where each letter's section starts in A–Z order. A grouped car
  // counts under its main casting's letter, matching where it sits in
  // the A–Z order. The jump row uses the A–Z position even when
  // another sort is active, because tapping a letter switches the
  // list to A–Z before scrolling.
  const jumpLetters = ["#", ..."ABCDEFGHIJKLMNOPQRSTUVWXYZ"];
  const presentLetters = useMemo(
    () => new Set(filtered.map((c) => displayInitial(c))),
    // displayInitial reads groupInfo, which is a memo over `filtered`.
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [filtered, groupInfo],
  );
  const azFiltered = useMemo(
    () => [...filtered].sort(compareAz),
    // compareAz reads groupInfo, which is a memo over `filtered`.
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [filtered, groupInfo],
  );
  const jumpToLetter = (letter: string) => {
    const idx = azFiltered.findIndex((c) => displayInitial(c) === letter);
    if (idx < 0) return;
    if (sort !== "az") setSort("az");
    // The list pages in 60s, so a later letter's header may not be
    // rendered yet; grow the page to include a full page of that
    // letter's cars, so the section can be browsed, not just glimpsed.
    setLimit((l) => Math.max(l, idx + 60));
    setPendingJump(letter);
  };
  useEffect(() => {
    if (!pendingJump) return;
    const id = pendingJump === "#" ? "car-letter-num" : `car-letter-${pendingJump}`;
    document.getElementById(id)?.scrollIntoView({ behavior: "auto", block: "start" });
    setPendingJump(null);
  }, [pendingJump, limit, sort, shown.length]);

  // Thumbnail backfill, fast path: photos saved before thumbnails
  // existed (the imported collection) have no small preview, so
  // their tiles would download the full photo. For the cover photos
  // of the cars on screen, make the thumbnail from the photo itself
  // and save it right away — a few at a time, each photo attempted
  // at most once per visit (the attempted set is shared with the
  // app-level backfill in App, which covers every other photo in
  // the book), and any failure just leaves that tile on the full
  // photo. Once saved, every later open loads only the small
  // preview in the list.
  useEffect(() => {
    const missing = shown
      .map((car) => props.photosByCar.get(car.k)?.[0])
      .filter((p): p is NonNullable<typeof p> => Boolean(p && p.url && !p.thumbUrl))
      .filter((p) => !thumbBackfillAttempted.has(p.id))
      .slice(0, 8);
    if (missing.length === 0) return;
    let cancelled = false;
    void (async () => {
      let saved = false;
      for (const p of missing) {
        if (cancelled) return;
        thumbBackfillAttempted.add(p.id);
        const thumb = await makeThumbDataUrl(p.url);
        if (cancelled || !thumb) continue;
        const dataBase64 = thumb.slice(thumb.indexOf(",") + 1);
        if (dataBase64.length > 900_000) continue;
        try {
          await api.setPhotoThumb({ id: p.id, dataBase64 });
          saved = true;
        } catch {
          // Best effort: the tile keeps using the full photo.
        }
      }
      if (!cancelled && saved) props.onRefresh();
    })();
    return () => {
      cancelled = true;
    };
    // props.onRefresh is the parent's stable refresh callback.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [shown, props.photosByCar]);

  const filterLabel = (FILTERS.find(([code]) => code === filter) ?? ["all", "Collection"])[1];
  // Game filters show the game's logo instead of the red text heading.
  // The same transparent logo files already used in the sidebar. A
  // game's DLC sub-category keeps its game's logo, with a DLC caption
  // under it so the sub-category reads as its own list.
  const isDlcFilter = (Object.values(GAME_DLC_FILTERS) as string[]).includes(filter);
  const gameLogo =
    filter === "1" || filter === GAME_DLC_FILTERS["1"] ? { src: unleashed1Img, wide: true }
    : filter === "2" || filter === GAME_DLC_FILTERS["2"] ? { src: unleashed2Img, wide: true }
    : filter === "R" || filter === GAME_DLC_FILTERS["R"] ? { src: infiniteRushImg, wide: false }
    : null;
  const ownedPct = props.all.length > 0 ? Math.round((ownedCount / props.all.length) * 100) : 0;
  // When a game filter is active, progress is also shown against that
  // game's complete roster (base game + all DLC), which is bigger than
  // the set of that game's cars listed in the book.
  const gameRosterTotal = GAME_ROSTER_TOTALS[filter];
  const gameListed = gameRosterTotal !== undefined ? props.all.filter((c) => c.t.includes(filter)) : [];
  const gameOwned = gameListed.filter((c) => props.stateMap.get(c.k)?.owned).length;
  const gameRosterPct =
    gameRosterTotal !== undefined && gameRosterTotal > 0 ? Math.round((gameOwned / gameRosterTotal) * 100) : 0;

  return (
    <div>
      <div className="pn">
        {gameLogo ? (
          <>
            <h1 className="game-logo-header">
              <img
                src={gameLogo.src}
                alt={filterLabel}
                className={gameLogo.wide ? "logo-wide" : "logo-rush"}
              />
            </h1>
            {isDlcFilter && <div className="game-dlc-caption">💜 DLC</div>}
          </>
        ) : (
          <h1 className="hw-h2" style={{ fontSize: 20 }}>{filterLabel}</h1>
        )}
        {gameRosterTotal !== undefined && (
          <>
            <div className="stats">
              <span>
                {gameOwned} owned of {gameRosterTotal} in the complete roster
              </span>
              <span>
                {gameListed.length} listed in the book
              </span>
              <span>{gameRosterPct}%</span>
            </div>
            <div className="bar">
              <i style={{ width: `${gameRosterPct}%` }} />
            </div>
          </>
        )}
        <div className="stats">
          <span>{ownedCount} owned of {props.all.length}</span>
          <span>{props.data.stats.th} Treasure Hunts</span>
          <span>{ownedPct}%</span>
        </div>
        <div className="bar">
          <i style={{ width: `${ownedPct}%` }} />
        </div>

        <div className="targets-only-row">
          <button
            type="button"
            className="targets-only-toggle"
            aria-pressed={targetsOnly}
            onClick={() => { setTargetsOnly((v) => !v); setLimit(60); }}
          >
            🎯 Targets only
          </button>
          <span className="targets-only-note">
            {targetsOnly
              ? `${targetCarCount} ${targetCarCount === 1 ? "car" : "cars"} marked as hunt targets`
              : "Show only cars marked as hunt targets"}
          </span>
        </div>

        <label className="relative mt-2 block">
          <span className="sr-only">Search cars by name or series</span>
          <input
            type="text"
            value={query}
            onChange={(e) => { setQuery(e.target.value); setLimit(60); }}
            placeholder="Search by name or series…"
            aria-label="Search cars by name or series"
            className="w-full rounded-[10px] border border-[var(--border)] bg-[var(--surface-2)] px-4 py-2.5 pr-11 text-base outline-none focus:border-[var(--accent)]"
          />
          {query && (
            <button
              type="button"
              aria-label="Clear search"
              onClick={() => { setQuery(""); setLimit(60); }}
              className="absolute top-1/2 right-2 flex h-8 w-8 -translate-y-1/2 items-center justify-center rounded-full bg-[var(--surface)] text-lg font-bold text-[var(--dim)]"
            >
              ×
            </button>
          )}
        </label>

        <div className="mt-1 flex gap-1.5 overflow-x-auto py-2" role="group" aria-label="Filter cars" style={{ scrollbarWidth: "none" }}>
        {FILTERS.map(([code, label]) => {
          const count = code === "all" ? props.all.length
            : code === "miss" ? props.all.filter((c) => !props.stateMap.get(c.k)?.owned).length
            : code === "own" ? ownedCount
            : code === "fav" ? props.all.filter((c) => props.stateMap.get(c.k)?.owned && props.stateMap.get(c.k)?.isFavorite).length
            : code === "th" ? props.all.filter((c) => props.stateMap.get(c.k)?.isTh).length
            : code === "unv" ? props.all.filter((c) => props.stateMap.get(c.k)?.unverified).length
            : code === "S" ? props.all.filter((c) => c.t.includes("S") || props.stateMap.get(c.k)?.isSth).length
            : props.all.filter((c) => carMatchesFilter(c, code)).length;
          const active = filter === code;
          return (
            <button
              key={code}
              type="button"
              aria-pressed={active}
              onClick={() => { setFilter(code); setLimit(60); }}
              className={`chip ${active ? "on" : ""}`}
            >
              {label} · {count}
            </button>
          );
        })}
      </div>

      <div className="mt-1 flex items-center gap-2">
        <label htmlFor="car-sort" className="mut shrink-0 font-semibold">Sort</label>
        <select
          id="car-sort"
          value={sort}
          onChange={(e) => setSort(e.target.value as CarsSettings["sort"])}
          className="rounded-[10px] border border-[var(--border)] bg-[var(--surface-2)] px-3 py-2 text-sm font-semibold"
        >
          <option value="az">Name A–Z</option>
          <option value="own">Owned first</option>
          <option value="miss">Missing first</option>
          <option value="series">Series / game</option>
          <option value="new">Newest year first</option>
          <option value="old">Oldest year first</option>
        </select>
        <button
          type="button"
          className="hw-btn ml-auto px-4 py-2 text-sm font-bold"
          onClick={() => setShowAdd(true)}
        >
          Add a car
        </button>
      </div>

      <div className="gallery-controls">
        <div className="gallery-switch" role="group" aria-label="Collection layout">
          {(
            [
              ["list", "☰", "List"],
              ["grid", "▦", "Grid"],
              ["compact", "▤", "Compact"],
            ] as const
          ).map(([value, icon, label]) => (
            <button
              key={value}
              type="button"
              aria-pressed={carsSettings.layout === value}
              onClick={() => changeCarsSettings({ layout: value })}
            >
              <span aria-hidden="true">{icon}</span> {label}
            </button>
          ))}
        </div>
        {carsSettings.layout !== "list" && (
          <div className="gallery-switch gallery-switch--size" role="group" aria-label="Car tile size">
            {(
              [
                ["small", "Small"],
                ["medium", "Medium"],
                ["large", "Large"],
              ] as const
            ).map(([value, label]) => (
              <button
                key={value}
                type="button"
                aria-pressed={carsSettings.size === value}
                onClick={() => changeCarsSettings({ size: value })}
              >
                {label}
              </button>
            ))}
          </div>
        )}
      </div>

      {filtered.length > 0 && (
        <div className="letter-jump" role="group" aria-label="Jump to a letter in the car list">
          {jumpLetters.map((letter) => {
            const present = presentLetters.has(letter);
            return (
              <button
                key={letter}
                type="button"
                disabled={!present}
                onClick={() => jumpToLetter(letter)}
                aria-label={letter === "#" ? "Jump to cars starting with a number" : `Jump to cars starting with ${letter}`}
              >
                {letter}
              </button>
            );
          })}
        </div>
      )}
      </div>

      <p className="mt-1 px-1 text-sm font-bold text-white [text-shadow:0_1px_2px_rgba(0,0,0,0.45)]" role="status">
        Showing {shown.length} of {filtered.length} {filtered.length === 1 ? "car" : "cars"}
        {targetsOnly ? " · targets only" : ""}
        {sort === "az" && variantGroupCount > 0
          ? ` · ${variantGroupCount} variant ${variantGroupCount === 1 ? "group" : "groups"}`
          : ""}
        {query ? ` for “${query}”` : ""}.
      </p>

      {filtered.length === 0 ? (
        <div className="pn mt-2 p-6 text-center">
          {targetsOnly ? (
            <>
              <p className="text-xl font-semibold">
                {targetCarCount === 0 ? "No hunt targets yet." : "No hunt targets match that."}
              </p>
              <p className="mut mt-1">
                {targetCarCount === 0
                  ? "Add a car as a target from its sheet or the Hunt Planner, then switch Targets only back on to see it here."
                  : "Try a different search or filter — the cars you marked as targets are still on your target list."}
              </p>
              <button type="button" className="hw-btn mt-3 px-4 py-2 text-sm font-bold" onClick={() => { setTargetsOnly(false); setLimit(60); }}>
                Show the full list
              </button>
            </>
          ) : filter === "fav" && !query ? (
            <>
              <p className="text-xl font-semibold">No favorites yet.</p>
              <p className="mut mt-1">
                Favorites come only from cars you own. Tap the ❤️ on an owned car here, or open the Favorites page to build your list.
              </p>
            </>
          ) : (
            <>
              <p className="text-xl font-semibold">No cars match that.</p>
              <p className="mut mt-1">Try a different search, or add the car yourself — it may not be in the catalog yet.</p>
            </>
          )}
        </div>
      ) : (
        <div
          className={
            carsSettings.layout === "list"
              ? "pn cars-list mt-2"
              : carsSettings.layout === "compact"
                ? `pn cars-compact cars-compact--${carsSettings.size} mt-2`
                : `pn gridv gridv--${carsSettings.size} mt-2`
          }
        >
          {(() => {
            let letter = "";
            let lastGroupBase: string | null = null;
            return shown.map((car) => {
              const st = props.stateMap.get(car.k);
              const photos = props.photosByCar.get(car.k) ?? [];
              const photo = photos[0];
              const owned = Boolean(st?.owned);
              const th = Boolean(st?.isTh);
              const sth = Boolean(st?.isSth);
              const count = st?.count ?? 0;
              const chips = tagsToChips(car.t, 4);
              const extra = Math.max(0, car.t.length - chips.length);
              // In the A–Z order a grouped car files under its main
              // casting, so the letter header follows the casting's
              // letter; the first member of a group also gets the
              // group header naming the casting and its variant count.
              const group = sort === "az" ? groupInfo.get(car.k) : undefined;
              const dispInitial = sort === "az" ? displayInitial(car) : initialLetter(car.n);
              const showLetter = sort === "az" && dispInitial !== letter;
              if (showLetter) letter = dispInitial;
              const showGroup = Boolean(group) && group?.base !== lastGroupBase;
              lastGroupBase = group ? group.base : null;
              // The same pieces render in all three layouts — photo
              // tile, name, tag chips, and the OWN / TH toggles (with
              // the photo-required requestToggle path) — only the
              // arrangement and CSS change, like the gallery layouts.
              const photoTile = (
                <button type="button" className="tp" onClick={() => props.onSelect(car.k)} aria-label={`Open ${car.n}`}>
                  {photo && photo.url ? (
                    <img src={photo.thumbUrl ?? photo.url} alt="" loading="lazy" decoding="async" className="tile-photo-img" />
                  ) : (
                    <span className="tile-placeholder" aria-hidden="true">
                      <img src={logoImg} alt="" className="tile-logo" />
                      <svg className="tile-lock" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <rect x="5" y="10.5" width="14" height="9.5" rx="2" />
                        <path d="M8 10.5V8a4 4 0 0 1 8 0v2.5" />
                        <circle cx="12" cy="15.25" r="1.3" fill="currentColor" stroke="none" />
                      </svg>
                    </span>
                  )}
                  {photos.length > 1 && <b className="tn">📷 {photos.length}</b>}
                </button>
              );
              const nameLine = (
                <div className="tt" onClick={() => props.onSelect(car.k)}>{car.n}</div>
              );
              const chipRow = (
                <div className="tg2">
                  {chips.map((c) => (
                    <span key={c.label} className={`tag ${c.cls}`}>{c.label}</span>
                  ))}
                  {extra > 0 && <span className="tag">+{extra}</span>}
                  {car.custom && <span className="tag tag-custom">MY ADD</span>}
                  {owned && st?.isFavorite && <span className="tag tag-fav">❤️ FAVORITE</span>}
                  {groupInfo.get(car.k) && (
                    <span className="tag tag-variant">🔗 {groupInfo.get(car.k)?.size} variants</span>
                  )}
                  {st && st.count > 1 && <span className="tag tag-year">×{st.count}</span>}
                  {st?.unverified && <span className="tag tag-unverified">UNVERIFIED</span>}
                  {(owned || th) && !st?.unverified && hasUsablePhoto(photos) && <span className="tag tag-verified">✓ PHOTO</span>}
                </div>
              );
              const toggleRow = (
                <div className="tb">
                  <button
                    type="button"
                    aria-pressed={owned}
                    aria-label={`${owned ? "Mark not owned" : "Mark owned"}: ${car.n}`}
                    onClick={() => requestToggle(car, "own", !owned, () => props.onToggleOwn(car.k, !owned))}
                    className={`tg o ${owned ? "on" : ""}`}
                  >
                    OWN
                  </button>
                  <button
                    type="button"
                    aria-pressed={th}
                    aria-label={`${th ? "Remove Treasure Hunt" : "Mark Treasure Hunt"}: ${car.n}`}
                    onClick={() => requestToggle(car, "th", !th, () => props.onToggleTh(car.k, !th))}
                    className={`tg t ${th ? "on" : ""}`}
                  >
                    TH
                  </button>
                  {owned && (
                    <button
                      type="button"
                      aria-pressed={Boolean(st?.isFavorite)}
                      aria-label={st?.isFavorite ? `Remove ${car.n} from favorites` : `Add ${car.n} to favorites`}
                      title={st?.isFavorite ? "Remove from Favorites" : "Add to Favorites"}
                      onClick={() => void props.onToggleFavorite(car.k, !st?.isFavorite)}
                      className={`tg f ${st?.isFavorite ? "on" : ""}`}
                    >
                      ❤️
                    </button>
                  )}
                </div>
              );
              return (
                <div key={car.k} className="contents">
                  {showLetter && <div className="L" id={letter === "#" ? "car-letter-num" : `car-letter-${letter}`}>{letter}</div>}
                  {showGroup && group && (
                    <div className="VG">
                      <span aria-hidden="true">🔗</span> {group.base}
                      <span className="VG-n">{group.size} variants · each car keeps its own entry</span>
                    </div>
                  )}
                  {carsSettings.layout === "list" ? (
                    <div className={`tile tile--list ${owned ? "got" : ""}`}>
                      {photoTile}
                      <div className="tile-body">
                        {nameLine}
                        {car.x && <p className="tile-details">{car.x}</p>}
                        <p className="tile-status">
                          <span className={owned ? "tile-owned" : "tile-not-owned"}>
                            {owned ? `Owned ×${count}` : "Not owned"}
                          </span>
                          {th && <span className="tag tag-th">TREASURE HUNT</span>}
                          {sth && <span className="tag tag-sth">SUPER TREASURE HUNT</span>}
                        </p>
                        {chipRow}
                        {toggleRow}
                      </div>
                    </div>
                  ) : carsSettings.layout === "compact" ? (
                    <div className={`tile tile--compact ${owned ? "got" : ""}`}>
                      {photoTile}
                      {nameLine}
                      <div className={`tile-count ${owned ? "" : "not-owned"}`}>
                        {owned ? `×${count} owned` : "Not owned"}
                      </div>
                      {toggleRow}
                    </div>
                  ) : (
                    <div className={`tile ${owned ? "got" : ""}`}>
                      {photoTile}
                      {nameLine}
                      {chipRow}
                      {toggleRow}
                    </div>
                  )}
                </div>
              );
            });
          })()}
        </div>
      )}

      {filtered.length > limit && (
        <button type="button" className="hw-btn hw-btn-ghost mt-4 w-full py-3 font-bold" onClick={() => setLimit((l) => l + 120)}>
          Show more cars
        </button>
      )}

      {showAdd && (
        <CustomCarForm
          title="Add a car"
          onClose={() => setShowAdd(false)}
          onSaved={(name) => {
            setShowAdd(false);
            props.onToast(`Added “${name}”`);
            props.onRefresh();
          }}
        />
      )}

      {verifyReq && (
        <PhotoVerifyDialog
          car={verifyReq.car}
          kind={verifyReq.kind}
          onClose={() => setVerifyReq(null)}
          onToast={props.onToast}
          applyMark={verifyReq.apply}
        />
      )}
    </div>
  );
}

/* ---------------- Favorites ---------------- */

/* Anthony's Favorites list, drawn only from cars he owns: the server
   refuses to favorite an unowned car and unowning a car removes it
   from the list, so everything here is an owned car by construction.
   The page shows the current favorites as tiles (tap to open the car
   sheet, ❤️ button to remove) and, below, every other owned car with
   an Add button, so the whole list can be built from this one page. */
function FavoritesView(props: {
  data: State;
  all: DisplayCar[];
  stateMap: Map<string, CarState>;
  photosByCar: Map<string, State["photos"]>;
  onOpenCar: (key: string) => void;
  onToggleFavorite: (key: string, fav: boolean) => Promise<void>;
  onGoCars: () => void;
}) {
  const [query, setQuery] = useState("");
  const [addLimit, setAddLimit] = useState(30);
  const ownedCars = useMemo(
    () => props.all.filter((c) => props.stateMap.get(c.k)?.owned),
    [props.all, props.stateMap],
  );
  const favorites = useMemo(
    () => ownedCars.filter((c) => props.stateMap.get(c.k)?.isFavorite),
    [ownedCars, props.stateMap],
  );
  const q = query.trim().toLowerCase();
  const addable = ownedCars.filter(
    (c) => !props.stateMap.get(c.k)?.isFavorite && (q === "" || carSearchHaystack(c).includes(q)),
  );
  const shownAddable = addable.slice(0, addLimit);
  const favPct = ownedCars.length > 0 ? Math.round((favorites.length / ownedCars.length) * 100) : 0;

  return (
    <div>
      <section aria-label="Favorites" className="pn">
        <h1 className="hw-h2" style={{ fontSize: 20 }}>❤️ Favorites</h1>
        <div className="stats">
          <span>{favorites.length} {favorites.length === 1 ? "favorite" : "favorites"}</span>
          <span>{ownedCars.length} owned cars to pick from</span>
          <span>{favPct}%</span>
        </div>
        <div className="bar">
          <i style={{ width: `${favPct}%` }} />
        </div>
        <p className="mut mt-1">
          Favorites come only from cars you own. If a car stops being owned, it leaves this list.
        </p>
      </section>

      {favorites.length === 0 ? (
        <section aria-label="No favorites yet" className="pn mt-2 p-6 text-center">
          <p className="text-xl font-semibold">No favorites yet.</p>
          <p className="mut mt-1">
            {ownedCars.length === 0
              ? "Mark a car owned first — favorites are picked from your owned cars."
              : "Pick the cars you love most from your owned cars below — your Top 10, the ones you reach for first."}
          </p>
          {ownedCars.length === 0 && (
            <button type="button" className="hw-btn mt-3 px-4 py-2 text-sm font-bold" onClick={props.onGoCars}>
              Open the collection
            </button>
          )}
        </section>
      ) : (
        <div className="pn gridv mt-2" aria-label="Your favorite cars">
          {favorites.map((car) => {
            const st = props.stateMap.get(car.k);
            const photos = props.photosByCar.get(car.k) ?? [];
            const photo = photos[0];
            return (
              <div key={car.k} className="tile got">
                <button type="button" className="tp" onClick={() => props.onOpenCar(car.k)} aria-label={`Open ${car.n}`}>
                  {photo && photo.url ? (
                    <img src={photo.thumbUrl ?? photo.url} alt="" loading="lazy" decoding="async" className="tile-photo-img" />
                  ) : (
                    <span className="tile-placeholder" aria-hidden="true">
                      <img src={logoImg} alt="" className="tile-logo" />
                    </span>
                  )}
                  {photos.length > 1 && <b className="tn">📷 {photos.length}</b>}
                </button>
                <div className="tt" onClick={() => props.onOpenCar(car.k)}>{car.n}</div>
                <div className="tg2">
                  <span className="tag tag-fav">❤️ FAVORITE</span>
                  {st && st.count > 1 && <span className="tag tag-year">×{st.count}</span>}
                  {st?.isTh && <span className="tag tag-th">TREASURE HUNT</span>}
                  {st?.isSth && <span className="tag tag-sth">SUPER TREASURE HUNT</span>}
                  {tagsToChips(car.t, 3).map((c) => (
                    <span key={c.label} className={`tag ${c.cls}`}>{c.label}</span>
                  ))}
                </div>
                <div className="tb">
                  <button
                    type="button"
                    aria-label={`Remove ${car.n} from favorites`}
                    onClick={() => void props.onToggleFavorite(car.k, false)}
                    className="tg f f-wide on"
                  >
                    ❤️ Remove
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {ownedCars.length > 0 && (
        <section aria-label="Add favorites from your owned cars" className="pn mt-2">
          <h2 className="hw-h2">Add from your owned cars</h2>
          <label className="relative mt-1 block">
            <span className="sr-only">Search your owned cars</span>
            <input
              type="text"
              value={query}
              onChange={(e) => { setQuery(e.target.value); setAddLimit(30); }}
              placeholder="Search your owned cars…"
              aria-label="Search your owned cars"
              className="w-full rounded-[10px] border border-[var(--border)] bg-[var(--surface-2)] px-4 py-2.5 pr-11 text-base outline-none focus:border-[var(--accent)]"
            />
            {query && (
              <button
                type="button"
                aria-label="Clear search"
                onClick={() => { setQuery(""); setAddLimit(30); }}
                className="absolute top-1/2 right-2 flex h-8 w-8 -translate-y-1/2 items-center justify-center rounded-full bg-[var(--surface)] text-lg font-bold text-[var(--dim)]"
              >
                ×
              </button>
            )}
          </label>
          {addable.length === 0 ? (
            <p className="mut mt-3">
              {q
                ? "No other owned cars match that search."
                : "Every car you own is already a favorite. 🏆"}
            </p>
          ) : (
            <>
              <ul className="mt-2">
                {shownAddable.map((car) => {
                  const st = props.stateMap.get(car.k);
                  const photo = props.photosByCar.get(car.k)?.[0];
                  return (
                    <li key={car.k} className="flex items-center gap-3 border-b border-[var(--border)] py-2">
                      <button
                        type="button"
                        className="h-12 w-12 shrink-0 overflow-hidden rounded-[8px] bg-[#0e1738]"
                        onClick={() => props.onOpenCar(car.k)}
                        aria-label={`Open ${car.n}`}
                      >
                        {photo && photo.url ? (
                          <img src={photo.thumbUrl ?? photo.url} alt="" loading="lazy" className="h-full w-full object-cover" />
                        ) : (
                          <img src={logoImg} alt="" className="h-full w-full object-contain p-1.5 opacity-45 grayscale" />
                        )}
                      </button>
                      <div className="min-w-0 flex-1">
                        <p className="truncate font-semibold leading-tight">{car.n}</p>
                        <p className="text-xs text-[var(--dim)]">
                          Owned{st && st.count > 1 ? ` ×${st.count}` : ""}{st?.isTh ? " · Treasure Hunt" : ""}{car.x ? ` · ${car.x}` : ""}
                        </p>
                      </div>
                      <button
                        type="button"
                        aria-label={`Add ${car.n} to favorites`}
                        className="hw-btn shrink-0 px-3.5 py-2 text-sm font-bold"
                        onClick={() => void props.onToggleFavorite(car.k, true)}
                      >
                        ❤️ Add
                      </button>
                    </li>
                  );
                })}
              </ul>
              <p className="mut mt-2" role="status">
                Showing {shownAddable.length} of {addable.length} owned {addable.length === 1 ? "car" : "cars"} not yet favorited{q ? ` for “${query}”` : ""}.
              </p>
              {addable.length > addLimit && (
                <button
                  type="button"
                  className="hw-btn hw-btn-ghost mt-3 w-full py-3 font-bold"
                  onClick={() => setAddLimit((l) => l + 60)}
                >
                  Show more owned cars
                </button>
              )}
            </>
          )}
        </section>
      )}
    </div>
  );
}

function hasUsablePhoto(photos: State["photos"] | undefined): boolean {
  return (photos ?? []).some((p) => Boolean(p.url));
}

/* Photo proof gate: tapping OWN or TH to turn a mark on first asks for a
   photo of that exact casting. The photo is uploaded and attached to the
   car, and only then is the mark applied. Cancelling the picker (or the
   dialog) applies nothing — the file input simply never fires. */
function PhotoVerifyDialog(props: {
  car: DisplayCar;
  kind: "own" | "th";
  onClose: () => void;
  onToast: (msg: string) => void;
  applyMark: () => Promise<unknown>;
}) {
  const { car } = props;
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  const handleFile = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return; // Picker cancelled: no photo, no mark.
    setBusy(true);
    setError("");
    try {
      const photoRes = await api.addPhoto({ carKey: car.k, ...(await photoPayloadWithThumb(file)) });
      const markRes = await props.applyMark();
      // Both steps earn points (photo +5, the mark itself, and +25
      // more when this car was a hunt target) — the toast carries the
      // combined total so the reward is visible in this flow too.
      const markPoints = (markRes as { points?: PointsAward } | null | undefined)?.points;
      const earned = photoRes.points.awarded + (markPoints?.awarded ?? 0);
      const leveled = photoRes.points.leveledUp || Boolean(markPoints?.leveledUp);
      const levelName = markPoints?.levelName ?? photoRes.points.levelName;
      props.onToast(
        (props.kind === "own"
          ? `Photo added — “${car.n}” is owned and verified ✓`
          : `Photo added — “${car.n}” is a Treasure Hunt and verified ✓`) +
          (earned > 0 ? ` · +${earned} points ⭐` : "") +
          (leveled ? ` Level up — you're ${levelName} now!` : ""),
      );
      props.onClose();
    } catch {
      setError("That photo could not be added, so nothing was marked. Try a smaller image, or cancel if you don't have a photo yet.");
    } finally {
      setBusy(false);
      e.target.value = "";
    }
  };

  return (
    <div className="fixed inset-0 z-[75] flex items-end justify-center bg-black/55 p-4 sm:items-center" role="dialog" aria-modal="true" aria-label={`Photo required to verify ${car.n}`}>
      <div className="hw-dlg-box">
        <h2 className="hw-h2" style={{ fontSize: 19 }}>📷 Photo required</h2>
        <p className="mt-2 text-sm text-[var(--dim)]">
          To mark <b className="text-[var(--text)]">“{car.n}”</b>{" "}
          {props.kind === "own" ? "owned" : "as a Treasure Hunt"}, take or upload a photo of that exact casting first.
          The photo is attached to this car and shows in the Gallery, and the mark is only applied after the photo is added.
        </p>
        {error && <p role="alert" className="mt-2 text-sm font-semibold text-[var(--accent)]">{error}</p>}
        <label className={`hw-btn mt-4 block cursor-pointer px-4 py-3 text-center font-bold ${busy ? "opacity-60" : ""}`}>
          {busy ? "Adding photo…" : "Take or upload a photo"}
          <input type="file" accept="image/*" className="hidden" onChange={handleFile} disabled={busy} />
        </label>
        <button
          type="button"
          disabled={busy}
          className="hw-btn hw-btn-ghost mt-2 w-full py-3 font-semibold disabled:opacity-50"
          onClick={props.onClose}
        >
          Cancel — don&apos;t mark it
        </button>
        <p className="mut mt-3 text-center">If you cancel the photo picker, nothing is marked.</p>
      </div>
    </div>
  );
}

/* ---------------- Car sheet ---------------- */

function CarSheet(props: {
  car: DisplayCar;
  state?: CarState;
  photos: State["photos"];
  links: State["links"];
  // This month's target rows, so the sheet can show the add/remove state
  // for this car without going back to the Planner picker.
  targets: State["targets"];
  onClose: () => void;
  onToast: (msg: string) => void;
  onRefresh: () => void;
  onConfirm: (c: { title: string; body: string; label: string; run: () => Promise<unknown> | void }) => void;
}) {
  const { car } = props;
  const owned = Boolean(props.state?.owned);
  const isTh = Boolean(props.state?.isTh);
  const isSth = Boolean(props.state?.isSth);
  const count = props.state?.count ?? 0;
  const [askTh, setAskTh] = useState(false);
  const [note, setNote] = useState(props.state?.note ?? "");
  const [noteSaved, setNoteSaved] = useState(false);
  const [editing, setEditing] = useState(false);
  const [verifyReq, setVerifyReq] = useState<{
    kind: "own" | "th";
    apply: () => Promise<unknown>;
  } | null>(null);
  const hasPhoto = hasUsablePhoto(props.photos);
  const unverified = Boolean(props.state?.unverified);
  const [linkUrl, setLinkUrl] = useState("");
  const [linkLabel, setLinkLabel] = useState("");
  const [busy, setBusy] = useState(false);
  const [photoIndex, setPhotoIndex] = useState(0);
  const [coverBusy, setCoverBusy] = useState(false);
  const [targetBusy, setTargetBusy] = useState(false);
  const month = thisMonth();
  // The target row for this car in the current month, if any — matched
  // the same way as the Planner picker (by car key, or by name for a
  // target added as free text). Only the current month is used, so the
  // sheet adds to the target list the Planner opens on by default.
  const existingTarget =
    props.targets.find((t) => t.month === month && (t.carKey === car.k || t.text === car.n)) ?? null;

  // Photos in cover-first order; the selected index clamps when the list
  // shrinks (e.g. the viewed photo is removed) so it never points past
  // the last photo.
  const orderedPhotos = [...props.photos].sort((a, b) => a.position - b.position || a.id - b.id);
  const selectedIndex = Math.min(photoIndex, Math.max(0, orderedPhotos.length - 1));
  const selectedPhoto = orderedPhotos[selectedIndex];

  useEffect(() => {
    setNote(props.state?.note ?? "");
    setAskTh(false);
    setEditing(false);
    setVerifyReq(null);
    setPhotoIndex(0);
  }, [car.k, props.state?.note]);

  const patch = async (args: { owned?: boolean; isFavorite?: boolean; isTh?: boolean; isSth?: boolean; count?: number; note?: string }) => {
    const res = await api.setCarState({ carKey: car.k, ...args });
    // Points earned by this change (new car, extra copy, TH, STH,
    // target found) toast right away; saves that earn nothing (notes,
    // favorites, un-marking) stay silent.
    if (res.points.awarded > 0) props.onToast(pointsToastText(res.points));
    props.onRefresh();
    return res;
  };

  // One tap adds this missing car to the current month's hunt targets
  // (or removes it again when it is already one). This only writes a
  // target row: it never marks the car owned, so the photo-required
  // OWN/Treasure Hunt rule is untouched.
  const handleTargetToggle = async () => {
    if (targetBusy) return;
    setTargetBusy(true);
    try {
      if (existingTarget) {
        await api.removeTarget({ id: existingTarget.id });
        props.onToast("Removed from targets");
      } else {
        const res = await api.addTarget({ month, text: car.n, carKey: car.k });
        props.onToast(res.added ? `Added to ${monthLabel(month)} targets` : "Already on your target list");
      }
      props.onRefresh();
    } catch {
      props.onToast("That couldn't be saved. Please try again.");
    } finally {
      setTargetBusy(false);
    }
  };

  const handlePhoto = async (e: ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files ?? []);
    if (files.length === 0) return;
    setBusy(true);
    try {
      let added = 0;
      let earned = 0;
      for (const file of files) {
        const res = await api.addPhoto({ carKey: car.k, ...(await photoPayloadWithThumb(file)) });
        earned += res.points.awarded;
        added += 1;
      }
      // New photos append at the end of the list; show the last one
      // added, as in the original app.
      setPhotoIndex(orderedPhotos.length + added - 1);
      props.onToast(
        (added === 1 ? "Photo added" : `${added} photos added`) +
          (earned > 0 ? ` · +${earned} points ⭐` : ""),
      );
      props.onRefresh();
    } catch {
      props.onToast("That photo could not be added. Try a smaller image.");
    } finally {
      setBusy(false);
      e.target.value = "";
    }
  };

  const handleMakeCover = async () => {
    if (!selectedPhoto || coverBusy) return;
    setCoverBusy(true);
    try {
      await api.setCoverPhoto({ id: selectedPhoto.id });
      // The chosen photo moves to Photo 1; follow it there.
      setPhotoIndex(0);
      props.onToast("Cover photo updated");
      props.onRefresh();
    } catch {
      props.onToast("That photo could not be made the cover. Please try again.");
    } finally {
      setCoverBusy(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[60] flex items-end justify-center bg-black/55 sm:items-center" role="dialog" aria-modal="true" aria-label={car.n}>
      <div className="hw-sheet max-h-[92vh] w-full max-w-lg overflow-y-auto bg-[var(--surface)] p-5 pb-safe sm:rounded-3xl">
        <div className="flex items-start justify-between gap-3">
          <div>
            <h2 className="hw-h2" style={{ fontSize: 22 }}>{car.n}</h2>
            <div className="mt-1.5 flex flex-wrap gap-1.5">
              {tagsToChips(car.t, 8).map((c) => (
                <span key={c.label} className={`tag ${c.cls}`}>{c.label}</span>
              ))}
              {car.custom && <span className="tag tag-custom">MY ADD</span>}
              {owned && props.state?.isFavorite && <span className="tag tag-fav">❤️ FAVORITE</span>}
            </div>
          </div>
          <button type="button" aria-label="Close" className="shrink-0 rounded-full bg-[var(--surface-2)] px-3 py-1.5 text-lg font-bold" onClick={props.onClose}>
            ×
          </button>
        </div>
        {car.x && <p className="mt-2 text-sm text-[var(--dim)]">{car.x}</p>}

        {unverified && (
          <div className="mt-3 rounded-xl border-2 border-[var(--yellow)] p-3" role="alert">
            <p className="font-semibold">⚠️ Unverified — no photo yet</p>
            <p className="mt-1 text-sm text-[var(--dim)]">
              This car is marked {owned ? "owned" : ""}{owned && isTh ? " and " : ""}{isTh ? "a Treasure Hunt" : ""} but has no photo of the actual casting.
              Add a photo below to verify it.
            </p>
            <label className="hw-btn mt-3 inline-block cursor-pointer px-4 py-2 text-sm font-bold">
              {busy ? "Adding…" : "Add a photo to verify"}
              <input type="file" accept="image/*" className="hidden" onChange={handlePhoto} disabled={busy} />
            </label>
          </div>
        )}
        {!unverified && (owned || isTh) && hasPhoto && (
          <p className="mt-3 text-sm font-semibold text-[var(--green)]">✓ Verified with a photo</p>
        )}

        {orderedPhotos.length > 0 && selectedPhoto && (
          <div className="mt-3">
            {selectedPhoto.url ? (
              <img
                src={selectedPhoto.url}
                alt={`${car.n} photo ${selectedIndex + 1} of ${orderedPhotos.length}`}
                className="block w-full rounded-xl bg-[var(--surface-2)] object-contain"
                style={{ maxHeight: 240 }}
              />
            ) : (
              <div
                className="flex w-full items-center justify-center rounded-xl bg-[var(--surface-2)] px-2 text-center text-sm font-semibold text-[var(--dim)]"
                style={{ height: 240 }}
              >
                Photo unavailable
              </div>
            )}
            {orderedPhotos.length > 1 && (
              <div className="mt-2 flex gap-1.5 overflow-x-auto pb-1" role="group" aria-label={`Photos of ${car.n}`}>
                {orderedPhotos.map((p, i) => (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => setPhotoIndex(i)}
                    aria-label={`Show photo ${i + 1} of ${orderedPhotos.length}`}
                    aria-current={i === selectedIndex}
                    className="shrink-0 rounded-lg border-[3px] p-0"
                    style={{ borderColor: i === selectedIndex ? "var(--orange)" : "transparent" }}
                  >
                    {p.url ? (
                      <img src={p.thumbUrl ?? p.url} alt="" loading="lazy" decoding="async" className="block h-14 w-14 rounded-md object-cover" />
                    ) : (
                      <span className="flex h-14 w-14 items-center justify-center rounded-md bg-[var(--surface-2)] px-1 text-center text-[10px] font-semibold text-[var(--dim)]">
                        Unavailable
                      </span>
                    )}
                  </button>
                ))}
              </div>
            )}
            <p className="mut mt-1" aria-live="polite">
              Photo {selectedIndex + 1} of {orderedPhotos.length}
              {selectedIndex === 0 && orderedPhotos.length > 1 ? " · cover" : ""}
            </p>
            <div className="mt-2 flex flex-wrap gap-2">
              <label className="hw-btn hw-btn-ghost cursor-pointer px-4 py-2 text-sm font-semibold">
                {busy ? "Adding…" : "📷 Add photos"}
                <input type="file" accept="image/*" multiple className="hidden" onChange={handlePhoto} disabled={busy} />
              </label>
              <button
                type="button"
                className="hw-btn hw-btn-ghost px-4 py-2 text-sm font-semibold"
                onClick={() =>
                  props.onConfirm({
                    title: "Delete this photo?",
                    body: "The photo will be removed from this car and the gallery.",
                    label: "Delete photo",
                    run: async () => {
                      await api.deletePhoto({ id: selectedPhoto.id });
                      props.onToast("Photo deleted");
                      props.onRefresh();
                    },
                  })
                }
              >
                Remove this photo
              </button>
            </div>
            {orderedPhotos.length > 1 && selectedIndex > 0 && (
              <button
                type="button"
                className="hw-btn hw-btn-ghost mt-2 px-4 py-2 text-sm font-semibold"
                disabled={coverBusy}
                onClick={handleMakeCover}
              >
                ★ {coverBusy ? "Making cover…" : "Make cover photo"}
              </button>
            )}
          </div>
        )}

        <div className="mt-4 grid grid-cols-3 gap-2">
          <button
            type="button"
            aria-pressed={owned}
            onClick={() => {
              if (owned) {
                void patch({ owned: false, count: 0 });
              } else if (hasPhoto) {
                void patch({ owned: true, count: Math.max(1, count) });
              } else {
                setVerifyReq({
                  kind: "own",
                  apply: () => patch({ owned: true, count: Math.max(1, count) }),
                });
              }
            }}
            className={`hw-btn py-3 text-lg font-bold ${owned ? "" : "hw-btn-ghost"}`}
          >
            {owned ? "✓ OWN" : "OWN"}
          </button>
          <button
            type="button"
            aria-pressed={isTh}
            onClick={() => {
              if (!isTh) setAskTh(true);
              else void patch({ isTh: false, isSth: false });
            }}
            className={`hw-btn py-3 text-lg font-bold ${isTh ? "hw-btn-yellow" : "hw-btn-ghost"}`}
          >
            {isTh ? "★ TH" : "TH"}
          </button>
          <button
            type="button"
            aria-pressed={isSth}
            disabled={!isTh}
            onClick={() => patch({ isSth: !isSth })}
            className={`hw-btn py-3 text-lg font-bold disabled:opacity-40 ${isSth ? "" : "hw-btn-ghost"}`}
            style={isSth ? { backgroundColor: "var(--orange)" } : undefined}
          >
            STH
          </button>
        </div>

        {askTh && (
          <div className="mt-3 rounded-xl border-2 border-[var(--yellow)] p-3" role="alert">
            <p className="font-semibold">Do you actually have the Treasure Hunt version?</p>
            <p className="mt-1 text-sm text-[var(--dim)]">Only mark TH for the flame-circle Treasure Hunt release, not the regular casting.</p>
            <div className="mt-3 flex gap-2">
              <button
                type="button"
                className="flex-1 rounded-full bg-[var(--yellow)] py-2 text-sm font-bold text-black"
                onClick={() => {
                  setAskTh(false);
                  if (hasPhoto) {
                    void patch({ isTh: true });
                  } else {
                    setVerifyReq({ kind: "th", apply: () => patch({ isTh: true }) });
                  }
                }}
              >
                Yes, it is a TH
              </button>
              <button type="button" className="flex-1 rounded-full border border-[var(--border)] py-2 text-sm font-semibold" onClick={() => setAskTh(false)}>
                Not yet
              </button>
            </div>
          </div>
        )}

        <div className="mt-4">
          <p className="text-sm font-bold">How many do I have?</p>
          <div className="mt-1.5 flex items-center gap-3">
            <button
              type="button"
              aria-label="One fewer"
              className="hw-btn hw-btn-ghost h-11 w-11 rounded-full text-xl font-bold"
              onClick={() => {
                const next = Math.max(0, count - 1);
                patch({ count: next, owned: next > 0 ? true : owned && next > 0 });
              }}
            >
              −
            </button>
            <span className="font-display text-2xl font-bold" aria-live="polite">{owned ? Math.max(1, count) : 0}</span>
            <button
              type="button"
              aria-label="One more"
              className="hw-btn hw-btn-ghost h-11 w-11 rounded-full text-xl font-bold"
              onClick={() => {
                if (!owned && !hasPhoto) {
                  setVerifyReq({
                    kind: "own",
                    apply: () => patch({ count: Math.max(1, count) + 1, owned: true }),
                  });
                } else {
                  void patch({ count: Math.max(1, count) + 1, owned: true });
                }
              }}
            >
              +
            </button>
            <span className="text-sm text-[var(--dim)]">{owned ? "in the collection" : "not owned yet"}</span>
          </div>
        </div>

        <label className="mt-4 block">
          <span className="text-sm font-bold">Notes: where I found it, variant, condition…</span>
          <textarea
            value={note}
            onChange={(e) => { setNote(e.target.value); setNoteSaved(false); }}
            rows={3}
            className="mt-1.5 w-full rounded-xl border border-[var(--border)] bg-[var(--surface-2)] px-3 py-2 text-sm outline-none focus:border-[var(--accent)]"
            placeholder="Found at…, card condition…, variant notes…"
          />
        </label>
        <button
          type="button"
          className="hw-btn hw-btn-alt mt-2 px-4 py-2 text-sm font-bold"
          onClick={async () => {
            await patch({ note });
            setNoteSaved(true);
          }}
        >
          {noteSaved ? "Note saved ✓" : "Save note"}
        </button>

        <div className="mt-5 flex flex-wrap gap-2">
          <label className="hw-btn hw-btn-ghost cursor-pointer px-4 py-2 text-sm font-semibold">
            {busy ? "Adding…" : "Add a photo"}
            <input type="file" accept="image/*" multiple className="hidden" onChange={handlePhoto} disabled={busy} />
          </label>
          {owned && (
            <button
              type="button"
              aria-pressed={Boolean(props.state?.isFavorite)}
              aria-label={props.state?.isFavorite ? `Remove ${car.n} from favorites` : `Add ${car.n} to favorites`}
              className={`hw-btn px-4 py-2 text-sm font-semibold ${props.state?.isFavorite ? "" : "hw-btn-ghost"}`}
              style={props.state?.isFavorite ? { backgroundColor: "#d6336c" } : undefined}
              onClick={async () => {
                const fav = Boolean(props.state?.isFavorite);
                await patch({ isFavorite: !fav });
                props.onToast(fav ? "Removed from Favorites" : "Added to Favorites ❤️");
              }}
            >
              {props.state?.isFavorite ? "❤️ Favorite — remove" : "❤️ Add to Favorites"}
            </button>
          )}
          {!owned && (
            <button
              type="button"
              aria-label={existingTarget ? `Remove ${car.n} from hunt targets` : `Add ${car.n} as a hunt target`}
              className={`hw-btn px-4 py-2 text-sm font-semibold ${existingTarget ? "hw-btn-ghost" : ""}`}
              disabled={targetBusy}
              onClick={handleTargetToggle}
            >
              {existingTarget
                ? targetBusy
                  ? "Removing…"
                  : "✓ Target — remove"
                : targetBusy
                  ? "Adding…"
                  : "Add to hunt targets"}
            </button>
          )}
          {car.custom && !editing && (
            <button type="button" className="hw-btn hw-btn-ghost px-4 py-2 text-sm font-semibold" onClick={() => setEditing(true)}>
              Edit car
            </button>
          )}
          {car.custom && (
            <button
              type="button"
              className="hw-btn hw-btn-ghost px-4 py-2 text-sm font-bold text-[var(--accent)]"
              onClick={() =>
                props.onConfirm({
                  title: `Delete “${car.n}”?`,
                  body: "Its photos, notes, and counts are removed too. Catalog cars cannot be deleted.",
                  label: "Delete this car",
                  run: async () => {
                    await api.deleteCustomCar({ carKey: car.k });
                    props.onToast("Car deleted");
                    props.onClose();
                    props.onRefresh();
                  },
                })
              }
            >
              Delete car
            </button>
          )}
        </div>

        {car.custom && editing && (
          <CustomCarForm
            title="Edit car"
            initial={car}
            onClose={() => setEditing(false)}
            onSaved={() => {
              setEditing(false);
              props.onToast("Car updated");
              props.onRefresh();
            }}
          />
        )}

        <div className="mt-5 border-t border-[var(--border)] pt-4">
          <p className="text-sm font-bold">Links for this car</p>
          {props.links.length === 0 && <p className="mt-1 text-sm text-[var(--dim)]">No links yet.</p>}
          <ul className="mt-1 space-y-1">
            {props.links.map((l) => (
              <li key={l.id} className="flex items-center gap-2">
                <a href={l.url} target="_blank" rel="noreferrer" className="min-w-0 flex-1 truncate text-sm font-semibold text-[var(--accent)] underline">
                  {l.label}
                </a>
                <button
                  type="button"
                  aria-label={`Delete link ${l.label}`}
                  className="rounded-full bg-[var(--surface-2)] px-2.5 py-1 text-xs font-bold"
                  onClick={async () => { await api.deleteLink({ id: l.id }); props.onRefresh(); }}
                >
                  ×
                </button>
              </li>
            ))}
          </ul>
          <form
            className="mt-2 flex flex-col gap-2"
            onSubmit={async (e: FormEvent) => {
              e.preventDefault();
              if (!/^https?:\/\//i.test(linkUrl.trim())) {
                props.onToast("Paste a full link starting with http");
                return;
              }
              await api.addLink({ url: linkUrl.trim(), label: linkLabel.trim() || linkUrl.trim(), carKey: car.k });
              setLinkUrl("");
              setLinkLabel("");
              props.onToast("Link added");
              props.onRefresh();
            }}
          >
            <input aria-label="Link URL" type="url" value={linkUrl} onChange={(e) => setLinkUrl(e.target.value)} placeholder="https://…" className="w-full rounded-[10px] border border-[var(--border)] bg-[var(--surface-2)] px-3 py-2 text-sm" />
            <input aria-label="Link label" value={linkLabel} onChange={(e) => setLinkLabel(e.target.value)} placeholder="Label (optional)" className="w-full rounded-[10px] border border-[var(--border)] bg-[var(--surface-2)] px-3 py-2 text-sm" />
            <button type="submit" className="hw-btn hw-btn-alt self-start px-4 py-2 text-sm font-bold">Add link</button>
          </form>
        </div>

        <button type="button" className="hw-btn hw-btn-ghost mt-5 w-full py-3 font-bold" onClick={props.onClose}>
          Done
        </button>
      </div>

      {verifyReq && (
        <PhotoVerifyDialog
          car={car}
          kind={verifyReq.kind}
          onClose={() => setVerifyReq(null)}
          onToast={props.onToast}
          applyMark={verifyReq.apply}
        />
      )}
    </div>
  );
}

function CustomCarForm(props: {
  title: string;
  initial?: DisplayCar;
  onClose: () => void;
  onSaved: (name: string) => void;
}) {
  const opts = props.initial ? tagsToOpts(props.initial.t) : { fantasy: false, u1: false, u2: false, dlc: false, rush: false, year: "", sthRelease: false };
  const [name, setName] = useState(props.initial?.n ?? "");
  const [details, setDetails] = useState(props.initial?.x ?? "");
  const [fantasy, setFantasy] = useState(opts.fantasy);
  const [u1, setU1] = useState(opts.u1);
  const [u2, setU2] = useState(opts.u2);
  const [dlc, setDlc] = useState(opts.dlc);
  const [rush, setRush] = useState(opts.rush);
  const [year, setYear] = useState(opts.year);
  const [sthRelease, setSthRelease] = useState(opts.sthRelease);
  const [error, setError] = useState("");

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setError("Type the car name first.");
      return;
    }
    const tags = buildTags({ fantasy, u1, u2, dlc, rush, year, sthRelease });
    if (props.initial) {
      await api.updateCustomCar({ carKey: props.initial.k, name: name.trim(), details: details.trim(), tags });
    } else {
      await api.addCustomCar({ name: name.trim(), details: details.trim(), tags });
    }
    props.onSaved(name.trim());
  };

  return (
    <div className="fixed inset-0 z-[70] flex items-end justify-center bg-black/55 p-0 sm:items-center sm:p-4" role="dialog" aria-modal="true" aria-label={props.title}>
      <form onSubmit={submit} className="hw-sheet max-h-[92vh] w-full max-w-lg overflow-y-auto bg-[var(--surface)] p-5 pb-safe sm:rounded-3xl">
        <h2 className="hw-h2" style={{ fontSize: 22 }}>{props.title}</h2>
        {error && <p role="alert" className="mt-2 text-sm font-semibold text-[var(--accent)]">{error}</p>}
        <label className="mt-3 block">
          <span className="text-sm font-bold">Car name</span>
          <input autoFocus value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Twin Mill" className="mt-1 w-full rounded-xl border border-[var(--border)] bg-[var(--surface-2)] px-3 py-2.5 outline-none focus:border-[var(--accent)]" />
        </label>
        <label className="mt-3 block">
          <span className="text-sm font-bold">Details</span>
          <input value={details} onChange={(e) => setDetails(e.target.value)} placeholder="Year · color · series…" className="mt-1 w-full rounded-xl border border-[var(--border)] bg-[var(--surface-2)] px-3 py-2.5 outline-none focus:border-[var(--accent)]" />
        </label>
        <fieldset className="mt-3">
          <legend className="text-sm font-bold">Series</legend>
          <div className="mt-1.5 flex flex-wrap gap-2">
            {(
              [
                ["Fantasy casting", fantasy, setFantasy],
                ["Unleashed 1", u1, setU1],
                ["Unleashed 2", u2, setU2],
                ["DLC", dlc, setDlc],
                ["Infinite Rush", rush, setRush],
                ["Super Treasure Hunt release", sthRelease, setSthRelease],
              ] as [string, boolean, (v: boolean) => void][]
            ).map(([label, val, set]) => (
              <label key={label} className={`cursor-pointer rounded-full border px-3 py-1.5 text-sm font-semibold ${val ? "border-[var(--accent)] bg-[var(--accent)] text-white" : "border-[var(--border)]"}`}>
                <input type="checkbox" className="sr-only" checked={val} onChange={(e) => set(e.target.checked)} />
                {label}
              </label>
            ))}
          </div>
        </fieldset>
        <label className="mt-3 block">
          <span className="text-sm font-bold">Mainline year</span>
          <select value={year} onChange={(e) => setYear(e.target.value)} className="mt-1 w-full rounded-xl border border-[var(--border)] bg-[var(--surface-2)] px-3 py-2.5">
            <option value="">No year</option>
            {YEAR_CODES.map((code) => (
              <option key={code} value={code}>{YEAR_LABELS[code]}</option>
            ))}
          </select>
        </label>
        <div className="mt-5 flex gap-2">
          <button type="button" className="hw-btn hw-btn-ghost flex-1 py-2.5 font-semibold" onClick={props.onClose}>
            Cancel
          </button>
          <button type="submit" className="hw-btn flex-1 py-2.5 font-bold">
            Save car
          </button>
        </div>
      </form>
    </div>
  );
}

/* ---------------- Planner ---------------- */

// Generic hunt-prep items for a hunt day's checklist. No specific cars:
// the list is the same for every hunt day, and only the checked state is
// stored, per planner month + day (see the huntChecklist table). The
// server validates idx 0–5, matching this list.
const HUNT_CHECKLIST_ITEMS = [
  "Check your owned list for duplicates before you go",
  "Bring your phone for photo proof",
  "Check your hunt targets",
  "Set a budget",
  "Bring a bag for your finds",
  "Charge your phone before you go",
] as const;

// Picker groupings: the same series/game groupings the Cars tab already
// filters by (tag codes), plus an "All missing" group and a Mainline
// group that spans every mainline year code (a–m).
const PICKER_GROUPS: { code: string; label: string }[] = [
  { code: "all", label: "All missing" },
  { code: "1", label: "Unleashed 1" },
  { code: GAME_DLC_FILTERS["1"] ?? "1P", label: "Unleashed 1 DLC" },
  { code: "2", label: "Unleashed 2 Turbocharged" },
  { code: GAME_DLC_FILTERS["2"] ?? "2Q", label: "Unleashed 2 Turbocharged DLC" },
  { code: "R", label: "Infinite Rush" },
  { code: GAME_DLC_FILTERS.R ?? "RT", label: "Infinite Rush DLC" },
  { code: "F", label: "Fantasy" },
  { code: "D", label: "DLC" },
  { code: "mainline", label: "Mainline" },
  ...YEAR_CODES.map((code) => ({ code, label: YEAR_LABELS[code] ?? code })),
  { code: "S", label: "Super Treasure Hunts" },
  { code: "X", label: "Other 2026–27" },
];

function pickerGroupMatches(car: DisplayCar, code: string): boolean {
  if (code === "all") return true;
  if (code === "mainline") return car.t.includes("M") || YEAR_CODES.some((c) => car.t.includes(c));
  return carMatchesFilter(car, code);
}

function PlannerView(props: {
  data: State;
  all: DisplayCar[];
  stateMap: Map<string, CarState>;
  onToast: (msg: string) => void;
  onRefresh: () => void;
  onOpenCar: (key: string) => void;
}) {
  const [month, setMonth] = useState(thisMonth());
  const [pickedKey, setPickedKey] = useState<string | null>(null);
  const [targetText, setTargetText] = useState("");
  const [dayEdit, setDayEdit] = useState<number | null>(null);
  const [dayHunt, setDayHunt] = useState(false);
  const [dayNote, setDayNote] = useState("");

  const [y = 1970, m = 1] = month.split("-").map(Number);
  const firstWeekday = new Date(y, (m ?? 1) - 1, 1).getDay();
  const daysInMonth = new Date(y, m ?? 1, 0).getDate();
  const plan = props.data.monthPlans.find((p) => p.month === month);
  const [budget, setBudget] = useState(plan?.budget ?? "");
  const [spent, setSpent] = useState(plan?.spent ?? "");

  useEffect(() => {
    setBudget(plan?.budget ?? "");
    setSpent(plan?.spent ?? "");
    setDayEdit(null);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [month, props.data.monthPlans]);

  const dayMap = new Map(props.data.planDays.filter((d) => d.month === month).map((d) => [d.day, d]));
  const targets = props.data.targets.filter((t) => t.month === month);
  const huntDays = [...dayMap.values()].filter((d) => d.isHunt).length;
  const budgetNum = Number(budget);
  const spentNum = Number(spent);
  const remaining = Number.isFinite(budgetNum) && Number.isFinite(spentNum) && budget !== "" && spent !== "" ? budgetNum - spentNum : null;

  // Hunt-day checklist state for the day being edited (if any). Stored
  // per (month, day), so the Nov 14 checklist is independent of every
  // other hunt day. Toggling an item never touches the day's note.
  const editDayInfo = dayEdit !== null ? dayMap.get(dayEdit) : undefined;
  const editIsHuntDay = dayEdit !== null && (dayHunt || editDayInfo?.isHunt === true);
  const checklistChecked = new Map(
    (props.data.checklist ?? [])
      .filter((c) => c.month === month && c.day === dayEdit)
      .map((c) => [c.idx, c.checked]),
  );
  const checklistDone = HUNT_CHECKLIST_ITEMS.filter((_, i) => checklistChecked.get(i)).length;
  const huntDayInMonth = [...dayMap.values()].filter((d) => d.isHunt).sort((a, b) => a.day - b.day)[0];

  // Hunt-target picker: missing cars only, browsed by series/game
  // grouping. Adding one only writes a target row for the month being
  // viewed; it never marks a car owned, so the photo-required OWN rule
  // for marking a target owned later is untouched.
  const [pickerGroup, setPickerGroup] = useState("all");
  const [pickerQuery, setPickerQuery] = useState("");
  const [pickerShown, setPickerShown] = useState(30);
  const missingCars = useMemo(
    () => props.all.filter((c) => !props.stateMap.get(c.k)?.owned),
    [props.all, props.stateMap],
  );
  const pickerList = useMemo(() => {
    const q = pickerQuery.trim().toLowerCase();
    return missingCars.filter(
      (c) => pickerGroupMatches(c, pickerGroup) && (q === "" || c.n.toLowerCase().includes(q)),
    );
  }, [missingCars, pickerGroup, pickerQuery]);
  const pickerShownCars = pickerList.slice(0, pickerShown);
  const targetForCar = (car: DisplayCar) =>
    targets.find((t) => t.carKey === car.k || t.text === car.n) ?? null;

  const pick = () => {
    const missing = props.all.filter((c) => !props.stateMap.get(c.k)?.owned);
    if (missing.length === 0) {
      props.onToast("You own everything!");
      return;
    }
    const chosen = missing[Math.floor(Math.random() * missing.length)];
    setPickedKey(chosen?.k ?? null);
  };
  const picked = pickedKey ? props.all.find((c) => c.k === pickedKey) ?? null : null;

  const saveBudget = async () => {
    await api.setMonthPlan({ month, budget, spent });
    props.onRefresh();
  };

  return (
    <div>
      <section aria-label="Calendar" className="pn">
        <h1 className="hw-h2" style={{ fontSize: 20 }}>Hunt Planner</h1>
        <div className="flex items-center justify-between">
          <button type="button" aria-label="Previous month" className="hw-btn hw-btn-ghost px-3 py-1.5 text-lg font-bold" onClick={() => setMonth(shiftMonth(month, -1))}>‹</button>
          <button type="button" className="text-xl font-semibold" onClick={() => setMonth(thisMonth())}>
            {monthLabel(month)}
          </button>
          <button type="button" aria-label="Next month" className="hw-btn hw-btn-ghost px-3 py-1.5 text-lg font-bold" onClick={() => setMonth(shiftMonth(month, 1))}>›</button>
        </div>
        <div className="cal mt-3" role="grid" aria-label={`${monthLabel(month)} calendar`}>
          {["S", "M", "T", "W", "T", "F", "S"].map((d, i) => (
            <span key={`${d}-${i}`} className="w">{d}</span>
          ))}
          {Array.from({ length: firstWeekday }).map((_, i) => (
            <span key={`blank-${i}`} className="d e" />
          ))}
          {Array.from({ length: daysInMonth }).map((_, i) => {
            const day = i + 1;
            const info = dayMap.get(day);
            const isToday = month === thisMonth() && day === Number(chicagoToday().slice(8, 10));
            return (
              <button
                key={day}
                type="button"
                aria-label={`${monthLabel(month)} ${day}${info?.isHunt ? ", hunt day" : ""}${info?.note ? ", has a note" : ""}`}
                onClick={() => {
                  setDayEdit(day);
                  setDayHunt(info?.isHunt ?? false);
                  setDayNote(info?.note ?? "");
                }}
                className={`d ${info?.isHunt ? "h" : ""} ${isToday ? "td" : ""}`}
              >
                {day}
                {info?.note && <u aria-hidden="true">📝</u>}
              </button>
            );
          })}
        </div>
        <p className="mut mt-3">
          Tap a day to mark a hunt day and add notes. {huntDays} hunt {huntDays === 1 ? "day" : "days"} this month.
        </p>
      </section>

      {dayEdit !== null && (
        <section aria-label="Edit hunt day" className="pn">
          <h2 className="hw-h2">{monthLabel(month)} {dayEdit}</h2>
          <label className="mt-2 flex cursor-pointer items-center gap-3">
            <input type="checkbox" className="h-5 w-5 accent-[#e0191f]" checked={dayHunt} onChange={(e) => setDayHunt(e.target.checked)} />
            <span className="font-semibold">Hunt day</span>
          </label>
          <label className="mt-2 block">
            <span className="text-sm font-bold">Note</span>
            <input
              value={dayNote}
              onChange={(e) => setDayNote(e.target.value)}
              placeholder="Where are you hunting? What are you after?"
              className="mt-1 w-full rounded-xl border border-[var(--border)] bg-[var(--surface-2)] px-3 py-2.5 outline-none focus:border-[var(--accent)]"
            />
          </label>
          {editIsHuntDay && dayEdit !== null && (
            <>
              <h3 className="hw-h3">Hunt checklist</h3>
              <p className="mut" role="status">
                {checklistDone} of {HUNT_CHECKLIST_ITEMS.length} ready for this hunt day.
              </p>
              <ul className="mt-1 space-y-1">
                {HUNT_CHECKLIST_ITEMS.map((item, idx) => (
                  <li key={item}>
                    <label className="flex cursor-pointer items-center gap-3 rounded-xl bg-[var(--surface-2)] px-3 py-2.5">
                      <input
                        type="checkbox"
                        className="h-5 w-5 shrink-0 accent-[#e0191f]"
                        checked={checklistChecked.get(idx) ?? false}
                        onChange={async (e) => {
                          await api.setChecklistItem({ month, day: dayEdit, idx, checked: e.target.checked });
                          props.onRefresh();
                        }}
                      />
                      <span className={`text-sm ${checklistChecked.get(idx) ? "text-[var(--dim)] line-through" : "font-medium"}`}>{item}</span>
                    </label>
                  </li>
                ))}
              </ul>
              <h3 className="hw-h3">Hunt targets for this hunt</h3>
              {targets.length === 0 ? (
                <p className="mt-1 text-sm text-[var(--dim)]">
                  No targets for {monthLabel(month)} yet. Browse the missing cars below to add some.
                </p>
              ) : (
                <ul className="mt-1 space-y-1">
                  {targets.map((t) => (
                    <li key={t.id} className="flex items-center gap-2">
                      <label className="flex min-w-0 flex-1 cursor-pointer items-center gap-2 py-1">
                        <input
                          type="checkbox"
                          className="h-5 w-5 shrink-0 accent-[#e0191f]"
                          checked={t.done}
                          onChange={async (e) => {
                            await api.toggleTarget({ id: t.id, done: e.target.checked });
                            props.onRefresh();
                          }}
                        />
                        <span className={`truncate text-sm ${t.done ? "text-[var(--dim)] line-through" : "font-medium"}`}>{t.text}</span>
                      </label>
                      {t.carKey && (
                        <button type="button" className="text-xs font-bold text-[var(--accent)]" onClick={() => props.onOpenCar(t.carKey ?? "")}>
                          Open
                        </button>
                      )}
                      <button
                        type="button"
                        aria-label={`Remove target ${t.text}`}
                        className="rounded-full bg-[var(--surface-2)] px-2.5 py-1 text-xs font-bold"
                        onClick={async () => { await api.removeTarget({ id: t.id }); props.onRefresh(); }}
                      >
                        ×
                      </button>
                    </li>
                  ))}
                </ul>
              )}
              <button
                type="button"
                className="hw-btn hw-btn-ghost mt-3 px-4 py-2 text-sm font-bold"
                onClick={() => document.getElementById("hunt-target-picker")?.scrollIntoView({ behavior: "smooth", block: "start" })}
              >
                Browse missing cars to add
              </button>
            </>
          )}
          <div className="mt-3 flex gap-2">
            <button
              type="button"
              className="hw-btn flex-1 py-2.5 font-bold"
              onClick={async () => {
                await api.setPlanDay({ month, day: dayEdit, isHunt: dayHunt, note: dayNote.trim() });
                setDayEdit(null);
                props.onToast("Hunt day saved");
                props.onRefresh();
              }}
            >
              Save day
            </button>
            <button type="button" className="hw-btn hw-btn-ghost flex-1 py-2.5 font-semibold" onClick={() => setDayEdit(null)}>
              Cancel
            </button>
          </div>
        </section>
      )}

      <section aria-label="Target list" className="pn">
        <h2 className="hw-h2">Target list</h2>
        {targets.length === 0 ? (
          <p className="mt-1 text-sm text-[var(--dim)]">No targets this month yet. Add a car to hunt below, or pick one at random.</p>
        ) : (
          <ul className="mt-2 space-y-1">
            {targets.map((t) => (
              <li key={t.id} className="flex items-center gap-2">
                <label className="flex min-w-0 flex-1 cursor-pointer items-center gap-2 py-1">
                  <input
                    type="checkbox"
                    className="h-5 w-5 shrink-0 accent-[#e0191f]"
                    checked={t.done}
                    onChange={async (e) => {
                      await api.toggleTarget({ id: t.id, done: e.target.checked });
                      props.onRefresh();
                    }}
                  />
                  <span className={`truncate text-sm ${t.done ? "text-[var(--dim)] line-through" : "font-medium"}`}>{t.text}</span>
                </label>
                {t.carKey && (
                  <button type="button" className="text-xs font-bold text-[var(--accent)]" onClick={() => props.onOpenCar(t.carKey ?? "")}>
                    Open
                  </button>
                )}
                <button
                  type="button"
                  aria-label={`Remove target ${t.text}`}
                  className="rounded-full bg-[var(--surface-2)] px-2.5 py-1 text-xs font-bold"
                  onClick={async () => { await api.removeTarget({ id: t.id }); props.onRefresh(); }}
                >
                  ×
                </button>
              </li>
            ))}
          </ul>
        )}
        <form
          className="mt-3 flex gap-2"
          onSubmit={async (e: FormEvent) => {
            e.preventDefault();
            if (!targetText.trim()) return;
            const res = await api.addTarget({ month, text: targetText.trim(), carKey: null });
            if (!res.added) props.onToast("Already on your target list");
            setTargetText("");
            props.onRefresh();
          }}
        >
          <label className="flex-1">
            <span className="sr-only">Add a car to hunt</span>
            <input value={targetText} onChange={(e) => setTargetText(e.target.value)} placeholder="Add a car to hunt" className="w-full rounded-full border border-[var(--border)] bg-[var(--surface-2)] px-3 py-2.5 outline-none focus:border-[var(--accent)]" />
          </label>
          <button type="submit" className="hw-btn shrink-0 px-4 py-2.5 text-sm font-bold">Add</button>
        </form>
      </section>

      <section id="hunt-target-picker" aria-label="Hunt targets by series or game" className="pn">
        <h2 className="hw-h2">Hunt targets by series or game</h2>
        <p className="mut">
          Missing cars only. Adding one puts it on the {monthLabel(month)} target list
          {huntDayInMonth
            ? ` for your ${new Date(y, (m ?? 1) - 1, huntDayInMonth.day).toLocaleDateString(undefined, { weekday: "long", month: "long", day: "numeric" })} hunt.`
            : "."}
        </p>
        <div className="mt-3 flex flex-wrap gap-2" role="group" aria-label="Filter missing cars by series or game">
          {PICKER_GROUPS.map((g) => {
            const count = missingCars.filter((c) => pickerGroupMatches(c, g.code)).length;
            return (
              <button
                key={g.code}
                type="button"
                aria-pressed={pickerGroup === g.code}
                className={`chip ${pickerGroup === g.code ? "on" : ""}`}
                onClick={() => { setPickerGroup(g.code); setPickerShown(30); }}
              >
                {g.label} · {count}
              </button>
            );
          })}
        </div>
        <label className="mt-3 block">
          <span className="sr-only">Search missing cars by name</span>
          <input
            value={pickerQuery}
            onChange={(e) => { setPickerQuery(e.target.value); setPickerShown(30); }}
            placeholder="Search missing cars…"
            className="w-full rounded-full border border-[var(--border)] bg-[var(--surface-2)] px-3 py-2.5 outline-none focus:border-[var(--accent)]"
          />
        </label>
        <p className="mut mt-3" role="status">
          Showing {pickerShownCars.length} of {pickerList.length} missing {pickerList.length === 1 ? "car" : "cars"}.
        </p>
        {pickerList.length === 0 ? (
          <p className="mt-2 text-sm text-[var(--dim)]">
            {pickerQuery.trim()
              ? "No missing cars match that search in this group."
              : "No missing cars in this group — you own them all."}
          </p>
        ) : (
          <ul className="mt-2 space-y-2">
            {pickerShownCars.map((car) => {
              const existing = targetForCar(car);
              return (
                <li key={car.k} className="flex items-center gap-2 rounded-xl border border-[var(--border)] bg-[var(--surface-2)] px-3 py-2">
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-bold">{car.n}</p>
                    <div className="mt-0.5 flex flex-wrap gap-1">
                      {tagsToChips(car.t).map((c) => (
                        <span key={c.label} className={`tag ${c.cls}`}>{c.label}</span>
                      ))}
                    </div>
                  </div>
                  <button type="button" className="shrink-0 text-xs font-bold text-[var(--accent)]" onClick={() => props.onOpenCar(car.k)}>
                    Open
                  </button>
                  {existing ? (
                    <button
                      type="button"
                      aria-label={`Remove ${car.n} from hunt targets`}
                      className="hw-btn hw-btn-ghost shrink-0 px-3 py-2 text-xs font-bold"
                      onClick={async () => {
                        await api.removeTarget({ id: existing.id });
                        props.onToast("Removed from targets");
                        props.onRefresh();
                      }}
                    >
                      ✓ Target — remove
                    </button>
                  ) : (
                    <button
                      type="button"
                      aria-label={`Add ${car.n} as a hunt target`}
                      className="hw-btn shrink-0 px-3 py-2 text-xs font-bold"
                      onClick={async () => {
                        const res = await api.addTarget({ month, text: car.n, carKey: car.k });
                        props.onToast(res.added ? "Added to targets" : "Already on your target list");
                        props.onRefresh();
                      }}
                    >
                      Add as target
                    </button>
                  )}
                </li>
              );
            })}
          </ul>
        )}
        {pickerList.length > pickerShown && (
          <button type="button" className="hw-btn hw-btn-alt mt-3 px-4 py-2 text-sm font-bold" onClick={() => setPickerShown((n) => n + 30)}>
            Show more missing cars
          </button>
        )}
      </section>

      <section aria-label="Pick a car to hunt" className="pn" style={{ backgroundColor: "#14204a", color: "#fff" }}>
        <h2 className="hw-h2" style={{ color: "#ffd400" }}>Pick a car to hunt</h2>
        {picked ? (
          <div className="mt-2">
            <p className="font-display text-2xl font-bold leading-tight">{picked.n}</p>
            <div className="mt-1.5 flex flex-wrap gap-1.5">
              {tagsToChips(picked.t).map((c) => (
                <span key={c.label} className={`tag ${c.cls}`}>{c.label}</span>
              ))}
            </div>
            <div className="mt-3 flex gap-2">
              <button
                type="button"
                className="rounded-full bg-[var(--yellow)] px-4 py-2 text-sm font-bold text-black"
                onClick={async () => {
                  await api.addTarget({ month, text: picked.n, carKey: picked.k });
                  props.onToast("Added to targets");
                  props.onRefresh();
                }}
              >
                Add to targets
              </button>
              <button type="button" className="rounded-full border border-white/40 px-4 py-2 text-sm font-semibold" onClick={pick}>
                Another
              </button>
              <button type="button" className="rounded-full border border-white/40 px-4 py-2 text-sm font-semibold" onClick={() => props.onOpenCar(picked.k)}>
                Open
              </button>
            </div>
          </div>
        ) : (
          <button type="button" className="mt-2 rounded-full bg-[var(--yellow)] px-4 py-2.5 text-sm font-bold text-black" onClick={pick}>
            Pick a missing car
          </button>
        )}
      </section>

      <section aria-label="Budget" className="pn">
        <h2 className="hw-h2">Budget</h2>
        <div className="mt-2 flex gap-2">
          <label className="flex-1">
            <span className="text-sm font-bold">Budget $</span>
            <input inputMode="decimal" value={budget} onChange={(e) => setBudget(e.target.value)} onBlur={saveBudget} placeholder="Budget $" className="mt-1 w-full rounded-xl border border-[var(--border)] bg-[var(--surface-2)] px-3 py-2.5 outline-none focus:border-[var(--accent)]" />
          </label>
          <label className="flex-1">
            <span className="text-sm font-bold">Spent $</span>
            <input inputMode="decimal" value={spent} onChange={(e) => setSpent(e.target.value)} onBlur={saveBudget} placeholder="Spent $" className="mt-1 w-full rounded-xl border border-[var(--border)] bg-[var(--surface-2)] px-3 py-2.5 outline-none focus:border-[var(--accent)]" />
          </label>
        </div>
        {remaining !== null && (
          <p className="mt-2 text-sm font-semibold" role="status">
            {remaining >= 0 ? `$${remaining.toFixed(2)} left this month` : `$${Math.abs(remaining).toFixed(2)} over budget this month`}
          </p>
        )}
        <button type="button" className="hw-btn hw-btn-alt mt-3 px-4 py-2 text-sm font-bold" onClick={saveBudget}>
          Save budget
        </button>
      </section>
    </div>
  );
}

/* ---------------- Gallery ---------------- */

/* One framed card per car in the Photo Gallery: a large featured
   photo in a white frame, the car name with its photo count, and a
   thumbnail strip holding every photo of that car. Tapping a
   thumbnail swaps the featured photo; tapping the featured photo or
   the car name opens the car's sheet, where the full viewer, cover
   photo, and photo-required OWN/TH rule live. Each thumbnail carries
   its own delete control, so deleting one photo never touches the
   car's other photos. Photos with no car attached get one shared
   card and are not tappable through to a car.
   The same card renders in all three gallery layouts: `grid` is the
   framed card as it has always looked, `list` puts the framed photo on
   the left with the name, count, and thumbnail strip beside it, and
   `compact` shrinks everything down to a dense tile showing just the
   photo, name, and count. Only the CSS changes between layouts; the
   featured-photo swap, open-car taps, and per-photo delete are the
   same controls in each. */
function GalleryCarCard(props: {
  car: DisplayCar | undefined;
  photos: State["photos"];
  layout: State["gallerySettings"]["layout"];
  onOpenCar: (key: string) => void;
  onDeletePhoto: (photo: State["photos"][number]) => void;
}) {
  const [selectedIndex, setSelectedIndex] = useState(0);
  const selected = props.photos[Math.min(selectedIndex, Math.max(0, props.photos.length - 1))];
  if (!selected) return null;
  const car = props.car;
  const name = car ? car.n : "No car attached";
  const countLabel = props.photos.length === 1 ? "1 photo" : `${props.photos.length} photos`;
  const selectedNumber = Math.min(selectedIndex, Math.max(0, props.photos.length - 1)) + 1;
  return (
    <li className={`gallery-card gallery-card--${props.layout}`}>
      <div className="gallery-frame">
        {selected.url ? (
          car ? (
            <button type="button" onClick={() => props.onOpenCar(car.k)} aria-label={`Open ${name}`}>
              <img src={selected.url} alt={`${name} photo`} loading="lazy" decoding="async" />
            </button>
          ) : (
            <img src={selected.url} alt="Gallery photo" loading="lazy" decoding="async" />
          )
        ) : (
          <div className="gallery-frame-unavailable">Photo unavailable</div>
        )}
      </div>
      <div className="gallery-body">
        <div className="gallery-head">
          {car ? (
            <button type="button" className="gallery-name" onClick={() => props.onOpenCar(car.k)}>
              {name}
            </button>
          ) : (
            <span className="gallery-name">{name}</span>
          )}
          <span className="gallery-count">📷 {countLabel}</span>
        </div>
        <div className="gallery-flame" aria-hidden="true" />
        <p className="gallery-meta">
          Photo {selectedNumber} of {props.photos.length} · {new Date(selected.createdAt).toLocaleDateString()}
          {props.car ? " · Tap the photo or name to open the car" : ""}
        </p>
        {props.photos.length > 1 && (
          <ul className="gallery-thumbs" aria-label={`All photos of ${name}`}>
            {props.photos.map((p, i) => (
              <li key={p.id} className="gallery-thumb">
                <button
                  type="button"
                  className={`gallery-thumb-img ${i === selectedNumber - 1 ? "selected" : ""}`}
                  onClick={() => setSelectedIndex(i)}
                  aria-label={`Show photo ${i + 1} of ${props.photos.length} for ${name}`}
                  aria-pressed={i === selectedNumber - 1}
                >
                  {p.url ? (
                    // The strip shows each photo at ~56 px: the
                    // stored thumbnail is more than sharp enough
                    // there, and using it means opening the gallery
                    // no longer downloads every photo full-size
                    // (the featured frame still uses the full photo).
                    <img src={p.thumbUrl ?? p.url} alt="" loading="lazy" decoding="async" />
                  ) : (
                    <span className="flex h-full w-full items-center justify-center px-1 text-center text-[10px] font-semibold text-[#9fb0dc]">
                      Unavailable
                    </span>
                  )}
                </button>
                <button
                  type="button"
                  className="gallery-thumb-delete"
                  aria-label={`Delete photo ${i + 1} of ${props.photos.length} for ${name}`}
                  onClick={() => props.onDeletePhoto(p)}
                >
                  ×
                </button>
              </li>
            ))}
          </ul>
        )}
        {props.photos.length === 1 && (
          <button
            type="button"
            aria-label={`Delete photo for ${name}`}
            className="gallery-delete-one"
            onClick={() => props.onDeletePhoto(selected)}
          >
            Delete
          </button>
        )}
      </div>
    </li>
  );
}

function GalleryView(props: {
  data: State;
  byKey: Map<string, DisplayCar>;
  onToast: (msg: string) => void;
  onRefresh: () => void;
  onOpenCar: (key: string) => void;
  onConfirm: (c: { title: string; body: string; label: string; run: () => Promise<unknown> | void }) => void;
}) {
  const { data } = props;
  const [photoBusy, setPhotoBusy] = useState(false);
  const [videoBusy, setVideoBusy] = useState(false);
  const [linkUrl, setLinkUrl] = useState("");
  const [linkLabel, setLinkLabel] = useState("");

  // Gallery layout + tile size, persisted server-side with the rest of
  // the app data (see updateGallerySettings) so the gallery reopens
  // the way it was left. The local copy drives the layout instantly;
  // the server copy re-syncs it on refresh, like the music settings.
  type GallerySettings = State["gallerySettings"];
  const [gallerySettings, setGallerySettings] = useState<GallerySettings>(() => data.gallerySettings);
  useEffect(() => {
    setGallerySettings(data.gallerySettings);
  }, [data.gallerySettings]);
  const changeGallerySettings = (patch: Partial<GallerySettings>) => {
    const next = { ...gallerySettings, ...patch };
    setGallerySettings(next);
    void api
      .updateGallerySettings(patch)
      .then(() => props.onRefresh())
      .catch(() => props.onToast("That gallery setting could not be saved. Try again."));
  };

  const handlePhotoFile = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setPhotoBusy(true);
    try {
      const res = await api.addPhoto({ carKey: null, ...(await photoPayloadWithThumb(file)) });
      props.onToast(
        "Photo added to the gallery" + (res.points.awarded > 0 ? ` · +${res.points.awarded} points ⭐` : ""),
      );
      props.onRefresh();
    } catch {
      props.onToast("That photo could not be added. Try a smaller image.");
    } finally {
      setPhotoBusy(false);
      e.target.value = "";
    }
  };

  const handleVideoFile = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setVideoBusy(true);
    try {
      const { dataBase64, mimeType } = await fileToBase64(file);
      await api.addVideo({ carKey: null, name: file.name.replace(/\.[^.]+$/, ""), dataBase64, mimeType });
      props.onToast("Video added");
      props.onRefresh();
    } catch {
      props.onToast("That video could not be added. Try a shorter clip.");
    } finally {
      setVideoBusy(false);
      e.target.value = "";
    }
  };

  const deletePhoto = (p: State["photos"][number]) => {
    props.onConfirm({
      title: "Delete this photo?",
      body: "The photo will be removed from the gallery and from its car, if attached.",
      label: "Delete photo",
      run: async () => {
        await api.deletePhoto({ id: p.id });
        props.onToast("Photo deleted");
        props.onRefresh();
      },
    });
  };

  // Photos grouped by car, in the gallery's existing newest-first
  // order: groups appear in the order of each car's newest photo, and
  // every photo stays visible inside its car's card. Photos with no
  // car attached share one group at their newest-first position.
  const photoGroups = useMemo(() => {
    const groups: { key: string; car: DisplayCar | undefined; photos: State["photos"] }[] = [];
    const byKey = new Map<string, { key: string; car: DisplayCar | undefined; photos: State["photos"] }>();
    for (const p of data.photos) {
      const key = p.carKey ?? "";
      let group = byKey.get(key);
      if (!group) {
        group = { key, car: p.carKey ? props.byKey.get(p.carKey) : undefined, photos: [] };
        byKey.set(key, group);
        groups.push(group);
      }
      group.photos.push(p);
    }
    return groups;
  }, [data.photos, props.byKey]);
  const carsWithPhotos = photoGroups.filter((g) => g.car).length;
  const unattachedCount = photoGroups.find((g) => !g.car)?.photos.length ?? 0;

  return (
    <div>
      <section aria-label="Photos" className="pn">
        <div className="flex items-baseline justify-between">
          <h2 className="hw-h2">Photo Gallery</h2>
          <label className="hw-btn cursor-pointer px-4 py-2 text-sm font-bold">
            {photoBusy ? "Adding…" : "Add photo"}
            <input type="file" accept="image/*" className="hidden" onChange={handlePhotoFile} disabled={photoBusy} />
          </label>
        </div>
        <p className="mut">
          {data.photos.length} {data.photos.length === 1 ? "photo" : "photos"}
          {carsWithPhotos > 0 ? ` · ${carsWithPhotos} ${carsWithPhotos === 1 ? "car" : "cars"}` : ""}
          {unattachedCount > 0 ? ` · ${unattachedCount} without a car` : ""}. Tap a photo or car name to open the car.
        </p>
        {data.photos.length > 0 && (
          <div className="gallery-controls">
            <div className="gallery-switch" role="group" aria-label="Gallery layout">
              {(
                [
                  ["list", "☰", "List"],
                  ["grid", "▦", "Grid"],
                  ["compact", "▤", "Compact"],
                ] as const
              ).map(([value, icon, label]) => (
                <button
                  key={value}
                  type="button"
                  aria-pressed={gallerySettings.layout === value}
                  onClick={() => changeGallerySettings({ layout: value })}
                >
                  <span aria-hidden="true">{icon}</span> {label}
                </button>
              ))}
            </div>
            {gallerySettings.layout !== "list" && (
              <div className="gallery-switch gallery-switch--size" role="group" aria-label="Photo size">
                {(
                  [
                    ["small", "Small"],
                    ["medium", "Medium"],
                    ["large", "Large"],
                  ] as const
                ).map(([value, label]) => (
                  <button
                    key={value}
                    type="button"
                    aria-pressed={gallerySettings.size === value}
                    onClick={() => changeGallerySettings({ size: value })}
                  >
                    {label}
                  </button>
                ))}
              </div>
            )}
          </div>
        )}
        {data.photos.length === 0 ? (
          <p className="mut mt-2">
            No photos yet. Add one from a car&apos;s sheet to prove a find, or add a general photo here.
          </p>
        ) : gallerySettings.layout === "list" ? (
          <ul className="gallery-list">
            {photoGroups.map((g) => (
              <GalleryCarCard
                key={g.key || "unattached"}
                car={g.car}
                photos={g.photos}
                layout="list"
                onOpenCar={props.onOpenCar}
                onDeletePhoto={deletePhoto}
              />
            ))}
          </ul>
        ) : gallerySettings.layout === "compact" ? (
          <ul className={`gallery-compact gallery-compact--${gallerySettings.size}`}>
            {photoGroups.map((g) => (
              <GalleryCarCard
                key={g.key || "unattached"}
                car={g.car}
                photos={g.photos}
                layout="compact"
                onOpenCar={props.onOpenCar}
                onDeletePhoto={deletePhoto}
              />
            ))}
          </ul>
        ) : (
          <ul className={`gallery-groups gallery-groups--${gallerySettings.size}`}>
            {photoGroups.map((g) => (
              <GalleryCarCard
                key={g.key || "unattached"}
                car={g.car}
                photos={g.photos}
                layout="grid"
                onOpenCar={props.onOpenCar}
                onDeletePhoto={deletePhoto}
              />
            ))}
          </ul>
        )}
      </section>

      <section aria-label="Videos" className="pn">
        <div className="flex items-baseline justify-between">
          <h2 className="hw-h2">Videos ({data.videos.length})</h2>
          <label className="hw-btn hw-btn-alt cursor-pointer px-4 py-2 text-sm font-bold">
            {videoBusy ? "Adding…" : "Add video"}
            <input type="file" accept="video/*" className="hidden" onChange={handleVideoFile} disabled={videoBusy} />
          </label>
        </div>
        {data.videos.length === 0 ? (
          <p className="mut mt-2">No videos yet.</p>
        ) : (
          <ul className="mt-3 space-y-3">
            {data.videos.map((v) => {
              const car = v.carKey ? props.byKey.get(v.carKey) : undefined;
              return (
                <li key={v.id} className="gi p-1.5 text-left">
                  {v.url ? (
                    <video src={v.url} controls playsInline preload="metadata" className="max-h-[260px] w-full rounded-lg bg-black" />
                  ) : (
                    <div className="flex h-[120px] w-full items-center justify-center rounded-lg bg-black text-xs font-semibold text-[#9fb0dc]">
                      Video unavailable
                    </div>
                  )}
                  <div className="mt-2 flex items-center justify-between gap-2 px-1">
                    <div className="min-w-0">
                      <b className="block truncate text-sm">{v.name || "Video"}</b>
                      <small>
                        {new Date(v.createdAt).toLocaleDateString()}
                        {car ? ` · ${car.n}` : ""}
                      </small>
                    </div>
                    <button
                      type="button"
                      aria-label={`Delete video ${v.name || ""}`}
                      className="shrink-0 rounded-full bg-[var(--surface-2)] px-3 py-1.5 text-xs font-bold"
                      onClick={() =>
                        props.onConfirm({
                          title: "Delete this video?",
                          body: "The video will be removed from the gallery.",
                          label: "Delete video",
                          run: async () => {
                            await api.deleteVideo({ id: v.id });
                            props.onToast("Video deleted");
                            props.onRefresh();
                          },
                        })
                      }
                    >
                      Delete
                    </button>
                  </div>
                </li>
              );
            })}
          </ul>
        )}
      </section>

      <section aria-label="Saved links" className="pn">
        <h2 className="hw-h2">Saved links ({data.links.length})</h2>
        {data.links.length === 0 ? (
          <p className="mt-1 text-sm text-[var(--dim)]">No links saved yet.</p>
        ) : (
          <ul className="mt-2 space-y-1">
            {data.links.map((l) => (
              <li key={l.id} className="flex items-center gap-2 py-1">
                <a href={l.url} target="_blank" rel="noreferrer" className="min-w-0 flex-1 truncate text-sm font-semibold text-[var(--accent)] underline">
                  {l.label}
                </a>
                <button
                  type="button"
                  aria-label={`Delete link ${l.label}`}
                  className="rounded-full bg-[var(--surface-2)] px-2.5 py-1 text-xs font-bold"
                  onClick={async () => { await api.deleteLink({ id: l.id }); props.onRefresh(); }}
                >
                  ×
                </button>
              </li>
            ))}
          </ul>
        )}
        <form
          className="mt-3 flex flex-col gap-2"
          onSubmit={async (e: FormEvent) => {
            e.preventDefault();
            if (!/^https?:\/\//i.test(linkUrl.trim())) {
              props.onToast("Paste a full link starting with http");
              return;
            }
            await api.addLink({ url: linkUrl.trim(), label: linkLabel.trim() || linkUrl.trim(), carKey: null });
            setLinkUrl("");
            setLinkLabel("");
            props.onToast("Link added");
            props.onRefresh();
          }}
        >
          <input aria-label="Link URL" type="url" value={linkUrl} onChange={(e) => setLinkUrl(e.target.value)} placeholder="https://…" className="w-full rounded-full border border-[var(--border)] bg-[var(--surface-2)] px-3 py-2.5 text-sm outline-none focus:border-[var(--accent)]" />
          <input aria-label="Link label" value={linkLabel} onChange={(e) => setLinkLabel(e.target.value)} placeholder="Label (optional)" className="w-full rounded-full border border-[var(--border)] bg-[var(--surface-2)] px-3 py-2.5 text-sm outline-none focus:border-[var(--accent)]" />
          <button type="submit" className="hw-btn hw-btn-alt self-start px-4 py-2 text-sm font-bold">Add link</button>
        </form>
      </section>
    </div>
  );
}

/* ---------------- Video Feed ---------------- */

// Curated YouTube feed: real, existing Hot Wheels videos only. Every
// entry was verified against YouTube's own oEmbed endpoint at build
// time (title + channel name returned by YouTube for that exact video
// ID; see DATA-PLAN.md). Thumbnails are the videos' own YouTube
// thumbnails, copied into the app's assets at build time so the feed
// never hotlinks them. Playback uses YouTube's official /embed/{id}
// player, with the watch page linked on every card as the fallback.
const YOUTUBE_FEED: {
  id: string;
  title: string;
  channel: string;
  topic: string;
  thumb: string;
}[] = [
  {
    id: "WdUbe8SuHxo",
    title: "I Found a Super Treasure Hunt Ferrari F40 at Target! (2026 Mainline Unboxing)",
    channel: "Championdjk",
    topic: "Hunt",
    thumb: ytThumbWdUbe8SuHxo,
  },
  {
    id: "F3dD-zaxUTE",
    title: "Unboxing Hot Wheels 2026 K Case With The '94 Toyota Supra Super Treasure Hunt",
    channel: "MK Collectiverse",
    topic: "New releases",
    thumb: ytThumbF3dD,
  },
  {
    id: "gvWVPxJktMQ",
    title: "Hunting For Rare Hot Wheels In Walmart: Found Some Awesome Treasure Hunts!",
    channel: "Collecting Fast Diecast",
    topic: "Hunt",
    thumb: ytThumbGvWVP,
  },
  {
    id: "olwSbCSbPKk",
    title: "\"Manga Madness\" ft. Mad Manga | Hot Wheels Let's Race OFFICIAL MUSIC VIDEO!",
    channel: "Hot Wheels",
    topic: "Official Hot Wheels",
    thumb: ytThumbOlwSb,
  },
  {
    id: "Q17yQPEHuYI",
    title: "HOT WHEELS STUDIO TOUR 2026 🔥 How I Display & Store My Collection",
    channel: "The Wheel Collector",
    topic: "Collection showcase",
    thumb: ytThumbQ17yQ,
  },
  {
    id: "m1ParXbQqyc",
    title: "Unbelievable! Another Hot Wheels Super Treasure Hunt!",
    channel: "Mike's Hobby Planet",
    topic: "Hunt",
    thumb: ytThumbM1Par,
  },
  {
    id: "omifXx7MaCI",
    title: "Unboxing Hot Wheels 2026 Q Case With Another STH",
    channel: "MK Collectiverse",
    topic: "New releases",
    thumb: ytThumbOmifX,
  },
  {
    id: "9sj_gJAXmT4",
    title: "Inside a Legendary Hot Wheels Collection",
    channel: "Good Times Rolling",
    topic: "Collection showcase",
    thumb: ytThumb9sj,
  },
  {
    id: "j_NdN1Y8r2M",
    title: "Bigfoot vs. the GIANT SNAKE! | Hot Wheels Monster Trucks",
    channel: "Hot Wheels",
    topic: "Official Hot Wheels",
    thumb: ytThumbJNdn,
  },
  {
    id: "KfSg7W1Gqnw",
    title: "Gunkster's Biggest Treasure Hunt Ever! | Hot Wheels Monster Trucks",
    channel: "Hot Wheels",
    topic: "Official Hot Wheels",
    thumb: ytThumbKfSg7,
  },
];

function VideoFeedView(props: {
  data: State;
  byKey: Map<string, DisplayCar>;
  onToast: (msg: string) => void;
  onRefresh: () => void;
  onConfirm: (c: { title: string; body: string; label: string; run: () => Promise<unknown> | void }) => void;
}) {
  const { data } = props;
  const [feed, setFeed] = useState<"mine" | "youtube">("mine");
  const [videoBusy, setVideoBusy] = useState(false);
  const [playingId, setPlayingId] = useState<string | null>(null);

  // A playing YouTube video is an iframe, so pausing media elements
  // cannot reach it: when the app leaves the foreground, unmount the
  // player (back to its thumbnail) so its sound stops and it never
  // keeps playing in the background. His own videos are plain
  // <video> elements and are paused by the app-wide background
  // handler. Nothing restarts on return — he taps play himself.
  useEffect(() => {
    const stopForBackground = () => setPlayingId(null);
    const onVisibility = () => {
      if (document.hidden) stopForBackground();
    };
    document.addEventListener("visibilitychange", onVisibility);
    window.addEventListener("pagehide", stopForBackground);
    return () => {
      document.removeEventListener("visibilitychange", onVisibility);
      window.removeEventListener("pagehide", stopForBackground);
    };
  }, []);

  const handleVideoFiles = async (e: ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files ?? []);
    if (files.length === 0) return;
    setVideoBusy(true);
    let added = 0;
    try {
      for (const file of files) {
        const { dataBase64, mimeType } = await fileToBase64(file);
        await api.addVideo({ carKey: null, name: file.name.replace(/\.[^.]+$/, ""), dataBase64, mimeType });
        added += 1;
      }
      props.onToast(added === 1 ? "Video added" : `${added} videos added`);
      props.onRefresh();
    } catch {
      props.onToast(
        added > 0
          ? `Added ${added} — one video could not be added. Try a shorter clip.`
          : "That video could not be added. Try a shorter clip.",
      );
      if (added > 0) props.onRefresh();
    } finally {
      setVideoBusy(false);
      e.target.value = "";
    }
  };

  return (
    <div>
      <section aria-label="Video Feed" className="pn">
        <h1 className="hw-h2" style={{ fontSize: 20 }}>📺 Video Feed</h1>
        <div className="gallery-switch mt-3" role="group" aria-label="Video feed sections">
          <button type="button" aria-pressed={feed === "mine"} onClick={() => setFeed("mine")}>
            <span aria-hidden="true">🎬</span> My Videos
          </button>
          <button type="button" aria-pressed={feed === "youtube"} onClick={() => setFeed("youtube")}>
            <span aria-hidden="true">▶️</span> YouTube
          </button>
        </div>

        {feed === "mine" ? (
          <>
            <div className="mt-3 flex items-baseline justify-between">
              <h2 className="hw-h2" style={{ fontSize: 17 }}>My Videos ({data.videos.length})</h2>
              <label className="hw-btn hw-btn-alt cursor-pointer px-4 py-2 text-sm font-bold">
                {videoBusy ? "Adding…" : "Add videos"}
                <input type="file" accept="video/*" multiple className="hidden" onChange={handleVideoFiles} disabled={videoBusy} />
              </label>
            </div>
            {data.videos.length === 0 ? (
              <p className="mut mt-2">
                No videos yet. Tap “Add videos” to pick clips from your phone — they stay saved here and play
                right in the app.
              </p>
            ) : (
              <ul className="mt-3 space-y-3">
                {data.videos.map((v) => {
                  const car = v.carKey ? props.byKey.get(v.carKey) : undefined;
                  return (
                    <li key={v.id} className="gi p-1.5 text-left">
                      {v.url ? (
                        <video src={v.url} controls playsInline preload="metadata" className="max-h-[260px] w-full rounded-lg bg-black" />
                      ) : (
                        <div className="flex h-[120px] w-full items-center justify-center rounded-lg bg-black text-xs font-semibold text-[#9fb0dc]">
                          Video unavailable
                        </div>
                      )}
                      <div className="mt-2 flex items-center justify-between gap-2 px-1">
                        <div className="min-w-0">
                          <b className="block truncate text-sm">{v.name || "Video"}</b>
                          <small>
                            {new Date(v.createdAt).toLocaleDateString()}
                            {car ? ` · ${car.n}` : ""}
                          </small>
                        </div>
                        <button
                          type="button"
                          aria-label={`Delete video ${v.name || ""}`}
                          className="shrink-0 rounded-full bg-[var(--surface-2)] px-3 py-1.5 text-xs font-bold"
                          onClick={() =>
                            props.onConfirm({
                              title: "Delete this video?",
                              body: "The video will be removed from your feed and the gallery.",
                              label: "Delete video",
                              run: async () => {
                                await api.deleteVideo({ id: v.id });
                                props.onToast("Video deleted");
                                props.onRefresh();
                              },
                            })
                          }
                        >
                          Delete
                        </button>
                      </div>
                    </li>
                  );
                })}
              </ul>
            )}
          </>
        ) : (
          <>
            <p className="mut mt-3">
              Hot Wheels hunts, new releases, and collection showcases from YouTube. Tap a video to play it
              right here.
            </p>
            <ul className="yt-list">
              {YOUTUBE_FEED.map((v) => {
                const watchUrl = `https://www.youtube.com/watch?v=${v.id}`;
                const playing = playingId === v.id;
                return (
                  <li key={v.id} className="yt-card">
                    <div className="yt-frame">
                      {playing ? (
                        <iframe
                          src={`https://www.youtube.com/embed/${v.id}?autoplay=1&rel=0`}
                          title={v.title}
                          sandbox="allow-scripts allow-same-origin allow-popups allow-popups-to-escape-sandbox"
                          // YouTube's player refuses to configure itself (Error 153)
                          // when the embed request arrives with no Referer header,
                          // which is what referrerPolicy="no-referrer" produced.
                          // Send the origin so the player can validate the embed.
                          referrerPolicy="strict-origin-when-cross-origin"
                          loading="lazy"
                          allow="accelerometer; autoplay; encrypted-media; picture-in-picture"
                          allowFullScreen
                        />
                      ) : (
                        <button
                          type="button"
                          className="yt-thumb-btn"
                          aria-label={`Play video: ${v.title}`}
                          onClick={() => setPlayingId(v.id)}
                        >
                          <img src={v.thumb} alt="" />
                          <span className="yt-play" aria-hidden="true">▶</span>
                        </button>
                      )}
                    </div>
                    <div className="yt-meta">
                      <b>{v.title}</b>
                      <small>
                        {v.channel} · {v.topic}
                      </small>
                      <a className="yt-watch" href={watchUrl} target="_blank" rel="noopener noreferrer">
                        Watch on YouTube
                      </a>
                    </div>
                  </li>
                );
              })}
            </ul>
          </>
        )}
      </section>
    </div>
  );
}

/* ---------------- Music ---------------- */

type MusicTrack = State["tracks"][number];

function formatTrackTime(seconds: number): string {
  if (!Number.isFinite(seconds) || seconds < 0) return "0:00";
  const total = Math.floor(seconds);
  return `${Math.floor(total / 60)}:${String(total % 60).padStart(2, "0")}`;
}

function songDisplayName(fileName: string): string {
  const base = fileName.replace(/\.[^.]+$/, "").trim();
  return base || fileName;
}

/* ---- Embedded cover art (ID3 picture frames) ---- */

type EmbeddedCover = {
  dataBase64: string;
  mimeType: "image/jpeg" | "image/png" | "image/webp" | "image/gif";
  picType: number;
};

function imageMimeFromMagic(bytes: Uint8Array, at: number): EmbeddedCover["mimeType"] | null {
  if (bytes[at] === 0xff && bytes[at + 1] === 0xd8 && bytes[at + 2] === 0xff) return "image/jpeg";
  if (bytes[at] === 0x89 && bytes[at + 1] === 0x50 && bytes[at + 2] === 0x4e && bytes[at + 3] === 0x47) {
    return "image/png";
  }
  if (bytes[at] === 0x47 && bytes[at + 1] === 0x49 && bytes[at + 2] === 0x46) return "image/gif";
  if (
    bytes[at] === 0x52 && bytes[at + 1] === 0x49 && bytes[at + 2] === 0x46 && bytes[at + 3] === 0x46 &&
    bytes[at + 8] === 0x57 && bytes[at + 9] === 0x45 && bytes[at + 10] === 0x42 && bytes[at + 11] === 0x50
  ) {
    return "image/webp";
  }
  return null;
}

// The picture data in an APIC frame follows: text encoding byte, MIME
// string, picture-type byte, description string. The description's
// terminator depends on the encoding (one NUL byte, or two for UTF-16),
// so after skipping it the image start is confirmed by its magic bytes
// — a short forward scan covers descriptions that end unexpectedly,
// and the declared MIME is only a fallback, never trusted over the
// bytes themselves.
function coverFromApic(payload: Uint8Array): EmbeddedCover | null {
  if (payload.length < 4) return null;
  const encoding = payload[0] ?? 0;
  let i = 1;
  const mimeStart = i;
  while (i < payload.length && payload[i] !== 0) i += 1;
  const mimeText = Array.from(payload.slice(mimeStart, i), (b) => String.fromCharCode(b)).join("");
  i += 1;
  if (i >= payload.length) return null;
  const picType = payload[i] ?? 0;
  i += 1;
  if (encoding === 1 || encoding === 2) {
    while (i + 1 < payload.length && !(payload[i] === 0 && payload[i + 1] === 0)) i += 2;
    i += 2;
  } else {
    while (i < payload.length && payload[i] !== 0) i += 1;
    i += 1;
  }
  if (i >= payload.length) return null;
  let start = i;
  let mime = imageMimeFromMagic(payload, start);
  if (!mime) {
    for (let j = i; j < Math.min(payload.length, i + 128); j += 1) {
      const found = imageMimeFromMagic(payload, j);
      if (found) {
        start = j;
        mime = found;
        break;
      }
    }
  }
  if (!mime) {
    const declared = mimeText.trim().toLowerCase();
    if (declared === "image/jpeg" || declared === "image/jpg") mime = "image/jpeg";
    else if (declared === "image/png") mime = "image/png";
    else if (declared === "image/gif") mime = "image/gif";
    else if (declared === "image/webp") mime = "image/webp";
    else return null;
  }
  const image = payload.slice(start);
  // Bound the cover so one oversized picture can never swallow the
  // upload cap; the song itself still adds without a cover.
  if (image.length < 64 || image.length > 2_200_000) return null;
  return { dataBase64: bytesToBase64(image), mimeType: mime, picType };
}

function asciiAt(bytes: Uint8Array, at: number, length: number): string {
  return Array.from(bytes.slice(at, at + length), (b) => String.fromCharCode(b)).join("");
}

// Best-effort: reads only the ID3v2 tag at the head of the file (the
// tag size in its header bounds the read), finds the first picture
// frame, and prefers a front-cover frame (type 3) when one is present.
// Any parse failure returns null — the song is added without a cover
// and the playlist shows its placeholder instead.
async function extractEmbeddedCover(file: File): Promise<EmbeddedCover | null> {
  try {
    const headBuf = await file.slice(0, 10).arrayBuffer();
    const head = new Uint8Array(headBuf);
    if (head.length < 10 || head[0] !== 0x49 || head[1] !== 0x44 || head[2] !== 0x33) return null;
    const version = head[3] ?? 0;
    if (version < 2 || version > 4) return null;
    const flags = head[5] ?? 0;
    const tagSize =
      ((head[6] ?? 0) << 21) | ((head[7] ?? 0) << 14) | ((head[8] ?? 0) << 7) | (head[9] ?? 0);
    if (tagSize <= 0) return null;
    const total = 10 + tagSize + (flags & 0x10 ? 10 : 0);
    const buf = await file.slice(0, Math.min(total, 8_000_000, file.size)).arrayBuffer();
    const bytes = new Uint8Array(buf);
    let offset = 10;
    if (flags & 0x40) {
      // Extended header: a size field (synchsafe in v2.4) plus flags.
      if (offset + 4 > bytes.length) return null;
      const extSize =
        version === 4
          ? ((bytes[offset] ?? 0) << 21) | ((bytes[offset + 1] ?? 0) << 14) | ((bytes[offset + 2] ?? 0) << 7) | (bytes[offset + 3] ?? 0)
          : ((bytes[offset] ?? 0) << 24) | ((bytes[offset + 1] ?? 0) << 16) | ((bytes[offset + 2] ?? 0) << 8) | (bytes[offset + 3] ?? 0);
      offset += 4 + extSize;
    }
    let first: EmbeddedCover | null = null;
    if (version === 2) {
      // ID3v2.2: 6-byte frame headers, 3-letter ids, 3-byte sizes; the
      // picture frame is PIC (format is a 3-letter code, JPG or PNG).
      while (offset + 6 <= bytes.length) {
        const id = asciiAt(bytes, offset, 3);
        if (id === "\0\0\0") break;
        const size = ((bytes[offset + 3] ?? 0) << 16) | ((bytes[offset + 4] ?? 0) << 8) | (bytes[offset + 5] ?? 0);
        if (size <= 0 || offset + 6 + size > bytes.length) break;
        if (id === "PIC") {
          const payload = bytes.slice(offset + 6, offset + 6 + size);
          const format = asciiAt(payload, 1, 3).toUpperCase();
          const picType = payload[4] ?? 0;
          let start = 5;
          while (start < payload.length && payload[start] !== 0) start += 1;
          start += 1;
          const image = payload.slice(start);
          const mime = imageMimeFromMagic(image, 0) ??
            (format === "JPG" ? "image/jpeg" : format === "PNG" ? "image/png" : null);
          if (mime && image.length >= 64 && image.length <= 2_200_000) {
            const cover = { dataBase64: bytesToBase64(image), mimeType: mime, picType };
            if (picType === 3) return cover;
            first ??= cover;
          }
        }
        offset += 6 + size;
      }
      return first;
    }
    while (offset + 10 <= bytes.length) {
      const id = asciiAt(bytes, offset, 4);
      if (id === "\0\0\0\0" || (bytes[offset] ?? 0) === 0) break;
      const size =
        version === 4
          ? ((bytes[offset + 4] ?? 0) << 21) | ((bytes[offset + 5] ?? 0) << 14) | ((bytes[offset + 6] ?? 0) << 7) | (bytes[offset + 7] ?? 0)
          : ((bytes[offset + 4] ?? 0) << 24) | ((bytes[offset + 5] ?? 0) << 16) | ((bytes[offset + 6] ?? 0) << 8) | (bytes[offset + 7] ?? 0);
      if (size <= 0 || offset + 10 + size > bytes.length) break;
      if (id === "APIC") {
        const cover = coverFromApic(bytes.slice(offset + 10, offset + 10 + size));
        if (cover) {
          if (cover.picType === 3) return cover;
          first ??= cover;
        }
      }
      offset += 10 + size;
    }
    return first;
  } catch {
    return null;
  }
}

function MusicView(props: {
  data: State;
  onToast: (msg: string) => void;
  onRefresh: () => void;
  onConfirm: (c: { title: string; body: string; label: string; run: () => Promise<unknown> | void }) => void;
}) {
  const { data } = props;
  const tracks = useMemo(
    () => [...data.tracks].sort((a, b) => a.position - b.position || a.id - b.id),
    [data.tracks],
  );
  const audioRef = useRef<HTMLAudioElement | null>(null);
  // Second audio element for crossfades: while one song fades out on
  // one element, the next song fades in on the other, so the two
  // overlap instead of the single element cutting from one to the
  // next. Only one element is ever the "active" one the progress
  // bar, seek, and play/pause state follow.
  const fadeAudioRef = useRef<HTMLAudioElement | null>(null);
  const activeSlotRef = useRef<0 | 1>(0);
  const gainsRef = useRef<[number, number]>([1, 0]);
  const volumeRef = useRef(0.8);
  const fadeAnimRef = useRef<number | null>(null);
  // The track id an end-of-song crossfade has already started for,
  // so the time-update check fires once per song, not once per tick.
  const autoFadeForRef = useRef<number | null>(null);
  // Hot Wheels Music settings (see the settings panel below): persisted
  // server-side in the `meta` table, so they survive reopening like the
  // playlist does. The local copy is the live one the player reads;
  // saving is debounced for sliders and immediate for toggles/pickers,
  // and the server copy re-syncs it on refresh.
  type MusicSettings = State["musicSettings"];
  const [settings, setSettings] = useState<MusicSettings>(() => data.musicSettings);
  const settingsRef = useRef(settings);
  settingsRef.current = settings;
  useEffect(() => {
    setSettings(data.musicSettings);
  }, [data.musicSettings]);
  const saveTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const persistSettings = useCallback(
    (next: MusicSettings, immediate: boolean) => {
      if (saveTimerRef.current !== null) clearTimeout(saveTimerRef.current);
      const save = () => {
        saveTimerRef.current = null;
        void api
          .updateMusicSettings({ ...next })
          .then(() => props.onRefresh())
          .catch(() => props.onToast("Your music settings could not be saved. Try again."));
      };
      if (immediate) save();
      else saveTimerRef.current = setTimeout(save, 400);
    },
    [props],
  );
  // Crossfade is on whenever its length is above 0 seconds; 0 means
  // the old hard cut. This replaces the fixed 3-second on/off toggle.
  const crossfadeSeconds = settings.crossfadeSeconds;
  const crossfadeEnabled = crossfadeSeconds > 0;
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [sleepPickerOpen, setSleepPickerOpen] = useState(false);
  const [queuePickerOpen, setQueuePickerOpen] = useState(false);
  const playlistAnchorRef = useRef<HTMLDivElement | null>(null);
  // One-time migration for the old localStorage crossfade toggle: if
  // Anthony had turned the blend off, keep it off (0 seconds) instead
  // of silently restoring the 2-second default.
  const migratedCrossfadeRef = useRef(false);
  useEffect(() => {
    if (migratedCrossfadeRef.current) return;
    migratedCrossfadeRef.current = true;
    try {
      if (window.localStorage.getItem("hunt-book-crossfade") === "0") {
        const next: MusicSettings = { ...data.musicSettings, crossfadeSeconds: 0 };
        setSettings(next);
        persistSettings(next, true);
      }
    } catch {
      // Blocked storage: nothing to migrate.
    }
    // Runs once on mount only.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  // Playback follows a track id, not its position in the list, so
  // dragging a song to a new spot never retargets the song that is
  // playing and next/previous follow the list's current order.
  const [currentTrackId, setCurrentTrackId] = useState<number | null>(null);
  const [playing, setPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(0.8);
  const [adding, setAdding] = useState(false);
  // "Add folder" state: while a picked folder's files are being added,
  // `folderProgress` counts how many of its files have been processed,
  // and afterwards `folderResult` holds the summary shown in the panel
  // under the player header (added / skipped as duplicates / skipped
  // because not MP3) until Anthony dismisses it.
  const [addingFolder, setAddingFolder] = useState(false);
  const [folderProgress, setFolderProgress] = useState<{ done: number; total: number } | null>(null);
  const [folderResult, setFolderResult] = useState<{
    added: number;
    duplicates: number;
    skipped: number;
    failed: boolean;
  } | null>(null);
  // While a drag is in progress (or its save is still landing),
  // `dragOrder` is the preview order shown in the list; it clears
  // once the server's saved order matches it, so the list never snaps
  // back to the old order while the save is in flight.
  const [dragOrder, setDragOrder] = useState<number[] | null>(null);
  const [draggingId, setDraggingId] = useState<number | null>(null);
  const [savingOrder, setSavingOrder] = useState(false);
  const listRef = useRef<HTMLUListElement | null>(null);
  const dragStateRef = useRef<{ id: number; order: number[]; moved: boolean } | null>(null);

  const orderedTracks = useMemo(() => {
    if (!dragOrder) return tracks;
    const byId = new Map(tracks.map((t) => [t.id, t]));
    const ordered = dragOrder
      .map((id) => byId.get(id))
      .filter((t): t is MusicTrack => t !== undefined);
    for (const t of tracks) if (!dragOrder.includes(t.id)) ordered.push(t);
    return ordered;
  }, [tracks, dragOrder]);

  const currentIndex =
    currentTrackId === null
      ? null
      : (() => {
          const idx = orderedTracks.findIndex((t) => t.id === currentTrackId);
          return idx >= 0 ? idx : null;
        })();

  const currentTrack: MusicTrack | undefined =
    currentIndex !== null ? orderedTracks[currentIndex] : undefined;

  // ---- Crossfade plumbing ----
  // Each element's real volume is the slider volume times its fade
  // gain (1 for the song in front, 0 for the idle element, ramping
  // between the two during a blend), so the volume slider keeps
  // working exactly as before while a fade is running.
  const audioForSlot = (slot: 0 | 1): HTMLAudioElement | null =>
    slot === 0 ? audioRef.current : fadeAudioRef.current;

  const applyVolumes = useCallback(() => {
    for (const slot of [0, 1] as const) {
      const audio = audioForSlot(slot);
      if (audio) {
        audio.volume = Math.max(0, Math.min(1, volumeRef.current * (gainsRef.current[slot] ?? 0)));
      }
    }
  }, []);

  const cancelFade = useCallback(() => {
    if (fadeAnimRef.current !== null) {
      cancelAnimationFrame(fadeAnimRef.current);
      fadeAnimRef.current = null;
    }
  }, []);

  // Ramps the incoming element 0 → full while the outgoing element
  // (when there is one) ramps full → 0 over the crossfade length,
  // then pauses the outgoing element so it never reaches its own
  // `ended` event and advance twice. With no outgoing element this
  // is a plain fade-in from silence.
  const runFade = useCallback(
    (outgoingSlot: 0 | 1 | null, incomingSlot: 0 | 1) => {
      cancelFade();
      const startedAt = performance.now();
      const totalMs = crossfadeSeconds * 1000;
      // Start from the gains in force now, so interrupting one blend
      // with another (tapping Next twice quickly) ramps smoothly
      // from the current volume instead of jumping back to full.
      const fromOutgoing = outgoingSlot !== null ? gainsRef.current[outgoingSlot] : 0;
      const step = (now: number) => {
        const p = Math.min(1, Math.max(0, (now - startedAt) / totalMs));
        if (outgoingSlot !== null) gainsRef.current[outgoingSlot] = fromOutgoing * (1 - p);
        gainsRef.current[incomingSlot] = p;
        applyVolumes();
        if (p < 1) {
          fadeAnimRef.current = requestAnimationFrame(step);
        } else {
          fadeAnimRef.current = null;
          if (outgoingSlot !== null) {
            gainsRef.current[outgoingSlot] = 0;
            applyVolumes();
            audioForSlot(outgoingSlot)?.pause();
          }
          gainsRef.current[incomingSlot] = 1;
          applyVolumes();
        }
      };
      fadeAnimRef.current = requestAnimationFrame(step);
    },
    [applyVolumes, cancelFade, crossfadeSeconds],
  );

  // Stops any blend in progress and leaves the active element at
  // full volume with the other element silent and paused — used
  // when the user pauses, turns crossfade off, or a hard cut takes
  // over, so playback never stays stuck half-faded.
  const settleFade = useCallback(() => {
    cancelFade();
    const active = activeSlotRef.current;
    const idle = (1 - active) as 0 | 1;
    gainsRef.current[active] = 1;
    gainsRef.current[idle] = 0;
    applyVolumes();
    audioForSlot(idle)?.pause();
  }, [applyVolumes, cancelFade]);

  // One place every settings control writes through: the local copy
  // updates at once (so sliders and toggles respond immediately), the
  // save is debounced for sliders and immediate for the rest, and
  // sliding crossfade to 0 settles any blend in progress at once.
  const changeSettings = useCallback(
    (patch: Partial<MusicSettings>, immediate = false) => {
      const next: MusicSettings = { ...settingsRef.current, ...patch };
      setSettings(next);
      settingsRef.current = next;
      if (patch.crossfadeSeconds === 0) settleFade();
      persistSettings(next, immediate);
    },
    [persistSettings, settleFade],
  );

  // ---- Sleep timer ----
  // Wall-clock countdown from the moment a duration is picked. When
  // it runs out, playback pauses and the timer resets itself to Off,
  // like Samsung Music. It is session-scoped: leaving Music clears it.
  const [sleepEndsAt, setSleepEndsAt] = useState<number | null>(null);
  const [sleepNow, setSleepNow] = useState(() => Date.now());
  useEffect(() => {
    if (settings.sleepTimerMinutes > 0) {
      setSleepEndsAt(Date.now() + settings.sleepTimerMinutes * 60_000);
    } else {
      setSleepEndsAt(null);
    }
  }, [settings.sleepTimerMinutes]);
  useEffect(() => {
    if (sleepEndsAt === null) return;
    // The countdown only ticks while the app is on screen: leaving
    // the app clears the interval entirely (no once-a-second wake-ups
    // in the background), and coming back restarts it and re-reads
    // the clock at once, so a timer that ran out while he was away
    // still finishes the moment he returns.
    let tick: number | null = null;
    const start = () => {
      if (tick === null) tick = window.setInterval(() => setSleepNow(Date.now()), 1000);
    };
    const stop = () => {
      if (tick !== null) {
        window.clearInterval(tick);
        tick = null;
      }
    };
    const onVisibility = () => {
      if (document.hidden) stop();
      else {
        setSleepNow(Date.now());
        start();
      }
    };
    if (!document.hidden) start();
    document.addEventListener("visibilitychange", onVisibility);
    return () => {
      stop();
      document.removeEventListener("visibilitychange", onVisibility);
    };
  }, [sleepEndsAt]);
  useEffect(() => {
    if (sleepEndsAt === null || sleepNow < sleepEndsAt) return;
    settleFade();
    audioRef.current?.pause();
    fadeAudioRef.current?.pause();
    setPlaying(false);
    setSleepEndsAt(null);
    changeSettings({ sleepTimerMinutes: 0 }, true);
    props.onToast("Sleep timer finished — music paused.");
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sleepNow, sleepEndsAt]);
  const sleepRemainingMs = sleepEndsAt !== null ? Math.max(0, sleepEndsAt - sleepNow) : null;

  // ---- Play speed ----
  // Both elements run at the chosen rate, including the idle one, so
  // a song fading in never starts at the wrong speed.
  useEffect(() => {
    for (const slot of [0, 1] as const) {
      const audio = audioForSlot(slot);
      if (audio) audio.playbackRate = settings.playbackRate;
    }
  }, [settings.playbackRate]);

  // ---- Lock-screen controls (Media Session) ----
  // Where the browser supports it, the lock screen / notification
  // shade shows the current song with play/pause/previous/next and
  // seek controls. Turning the setting off clears the handlers and
  // the metadata so nothing is offered from this player.
  useEffect(() => {
    const nav = navigator as Navigator & {
      mediaSession?: {
        metadata: MediaMetadata | null;
        playbackState: string;
        setActionHandler: (action: string, handler: (() => void) | null) => void;
      };
    };
    if (!("mediaSession" in navigator) || !nav.mediaSession) return;
    if (!settings.lockScreen) {
      for (const action of ["play", "pause", "previoustrack", "nexttrack", "seekto"]) {
        try {
          nav.mediaSession.setActionHandler(action, null);
        } catch {
          // A browser that rejects clearing a handler keeps the old
          // one; playback itself is unaffected.
        }
      }
      nav.mediaSession.metadata = null;
      return;
    }
    try {
      nav.mediaSession.metadata = currentTrack
        ? new MediaMetadata({
            title: currentTrack.name,
            artist: "Hot Wheels Hunt Book",
            artwork: currentTrack.coverUrl
              ? [{ src: currentTrack.coverUrl, sizes: "512x512", type: currentTrack.coverContentType ?? "image/jpeg" }]
              : [],
          })
        : null;
      nav.mediaSession.playbackState = playing ? "playing" : "paused";
      nav.mediaSession.setActionHandler("play", () => void togglePlay());
      nav.mediaSession.setActionHandler("pause", () => void togglePlay());
      nav.mediaSession.setActionHandler("previoustrack", () => void playPrevious());
      nav.mediaSession.setActionHandler("nexttrack", () => void playNext());
      nav.mediaSession.setActionHandler("seekto", (details: { seekTime?: number }) => {
        if (typeof details.seekTime === "number") handleSeek(details.seekTime);
      });
    } catch {
      // Media Session is best-effort; playback itself is unaffected.
    }
    // togglePlay/playPrevious/playNext/handleSeek are stable enough
    // through the component's callbacks for this effect's purpose.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [settings.lockScreen, currentTrack, playing]);

  // ---- Skip silence ----
  // When on, the active element is tapped through a Web Audio
  // analyser (best-effort: any failure leaves playback untouched and
  // the setting still saves). A quiet stretch is only skipped after
  // sound has already been heard in the song, so a quiet intro is
  // never mistaken for the end; at the very start, silence is
  // skipped forward in 1-second steps, at most 5 seconds in.
  const silenceCtxRef = useRef<AudioContext | null>(null);
  const silenceAnalysersRef = useRef<(AnalyserNode | null)[]>([null, null]);
  const silenceSourcesRef = useRef<boolean[]>([false, false]);
  const silenceStateRef = useRef<{ silentPolls: number; heardSound: boolean; skips: number }>({
    silentPolls: 0,
    heardSound: false,
    skips: 0,
  });
  useEffect(() => {
    silenceStateRef.current = { silentPolls: 0, heardSound: false, skips: 0 };
  }, [currentTrackId]);
  const ensureSilenceMonitor = useCallback((): boolean => {
    if (!settingsRef.current.skipSilence) return false;
    try {
      const Ctor =
        window.AudioContext ??
        (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (!Ctor) return false;
      silenceCtxRef.current ??= new Ctor();
      const ctx = silenceCtxRef.current;
      if (ctx.state === "suspended") void ctx.resume();
      for (const slot of [0, 1] as const) {
        const audio = audioForSlot(slot);
        if (!audio || silenceSourcesRef.current[slot]) continue;
        const source = ctx.createMediaElementSource(audio);
        const analyser = ctx.createAnalyser();
        analyser.fftSize = 512;
        source.connect(analyser);
        analyser.connect(ctx.destination);
        silenceAnalysersRef.current[slot] = analyser;
        silenceSourcesRef.current[slot] = true;
      }
      return silenceAnalysersRef.current[activeSlotRef.current] !== null;
    } catch {
      return false;
    }
  }, []);

  // A new song means a new end-of-song blend may start for it.
  useEffect(() => {
    autoFadeForRef.current = null;
  }, [currentTrackId]);

  // Leaving Music stops any blend and both elements, so a song never
  // keeps fading in the background after the view is gone.
  useEffect(
    () => () => {
      cancelFade();
      audioRef.current?.pause();
      fadeAudioRef.current?.pause();
    },
    [cancelFade],
  );

  // Leaving the app entirely (switching apps, locking the phone, or
  // moving to another Muse view while this page stays alive) stops
  // the music the same way: settle any crossfade, pause both
  // elements, and suspend the skip-silence monitor's audio context.
  // Playback never resumes by itself when he comes back — the player
  // stays paused until he taps Play.
  useEffect(() => {
    const stopForBackground = () => {
      settleFade();
      audioRef.current?.pause();
      fadeAudioRef.current?.pause();
      setPlaying(false);
      const ctx = silenceCtxRef.current;
      if (ctx && ctx.state === "running") void ctx.suspend();
    };
    const onVisibility = () => {
      if (document.hidden) stopForBackground();
    };
    document.addEventListener("visibilitychange", onVisibility);
    window.addEventListener("pagehide", stopForBackground);
    return () => {
      document.removeEventListener("visibilitychange", onVisibility);
      window.removeEventListener("pagehide", stopForBackground);
    };
  }, [settleFade]);

  // Once the saved order catches up with the drag preview, drop the
  // preview: the server order now renders the same list.
  useEffect(() => {
    if (draggingId === null && dragOrder && tracks.map((t) => t.id).join(",") === dragOrder.join(",")) {
      setDragOrder(null);
    }
  }, [draggingId, dragOrder, tracks]);

  // Keep both elements' volume in step with the slider (each times
  // its fade gain), including after a new track is loaded.
  useEffect(() => {
    volumeRef.current = volume;
    applyVolumes();
  }, [volume, currentTrackId, applyVolumes]);

  // If the playlist shrinks under the current track (a removal), stop
  // rather than pointing at a different song.
  useEffect(() => {
    if (currentTrackId !== null && !orderedTracks.some((t) => t.id === currentTrackId)) {
      cancelFade();
      audioRef.current?.pause();
      fadeAudioRef.current?.pause();
      setCurrentTrackId(null);
      setPlaying(false);
      setCurrentTime(0);
      setDuration(0);
    }
  }, [orderedTracks, currentTrackId, cancelFade]);

  const playIndex = useCallback(
    async (index: number, opts?: { fadeIn?: boolean }) => {
      const track = orderedTracks[index];
      if (!track) return;
      if (!track.url) {
        props.onToast("That song file is unavailable. Remove it and pick it again.");
        return;
      }
      const outgoingSlot = activeSlotRef.current;
      const outgoing = audioForSlot(outgoingSlot);
      const wasPlaying = !!outgoing && !outgoing.paused && !outgoing.ended;
      // A song change while one is playing, with crossfade on, blends:
      // the next song starts on the idle element at silence and ramps
      // up while the current song ramps down on its own element, so
      // the two overlap for a few seconds instead of cutting.
      if (crossfadeEnabled && wasPlaying && currentTrackId !== null && currentTrackId !== track.id) {
        const incomingSlot = (1 - outgoingSlot) as 0 | 1;
        const incoming = audioForSlot(incomingSlot);
        if (incoming && outgoing) {
          cancelFade();
          setCurrentTrackId(track.id);
          setCurrentTime(0);
          setDuration(0);
          activeSlotRef.current = incomingSlot;
          gainsRef.current[incomingSlot] = 0;
          applyVolumes();
          incoming.src = track.url;
          incoming.playbackRate = settingsRef.current.playbackRate;
          incoming.load();
          try {
            await incoming.play();
          } catch {
            // The browser blocked the incoming song: hand control
            // back to the song that is still playing instead of
            // leaving the player pointing at a silent track.
            activeSlotRef.current = outgoingSlot;
            gainsRef.current[incomingSlot] = 0;
            gainsRef.current[outgoingSlot] = 1;
            applyVolumes();
            setPlaying(false);
            return;
          }
          runFade(outgoingSlot, incomingSlot);
          return;
        }
      }
      // Hard cut (crossfade off, paused, first song, or the same
      // element has to be reused), optionally fading in from silence
      // when a song ended naturally and the blend could not overlap.
      settleFade();
      setCurrentTrackId(track.id);
      setCurrentTime(0);
      setDuration(0);
      const audio = audioForSlot(activeSlotRef.current);
      if (!audio) return;
      audio.src = track.url;
      audio.playbackRate = settingsRef.current.playbackRate;
      audio.load();
      if (crossfadeEnabled && opts?.fadeIn) {
        gainsRef.current[activeSlotRef.current] = 0;
        applyVolumes();
      }
      try {
        await audio.play();
        if (crossfadeEnabled && opts?.fadeIn) runFade(null, activeSlotRef.current);
      } catch {
        // The browser blocked playback (for example, before any tap in
        // this session): stay on the track, paused, so a tap on Play
        // starts it. The play/pause state follows the element events.
        if (crossfadeEnabled && opts?.fadeIn) {
          gainsRef.current[activeSlotRef.current] = 1;
          applyVolumes();
        }
        setPlaying(false);
      }
    },
    [orderedTracks, props, crossfadeEnabled, currentTrackId, applyVolumes, cancelFade, runFade, settleFade],
  );

  const togglePlay = useCallback(async () => {
    const audio = audioForSlot(activeSlotRef.current);
    if (!audio) return;
    if (currentIndex === null) {
      await playIndex(0);
      return;
    }
    if (playing) {
      // Pausing settles any blend first, so resuming later starts
      // the current song at full volume instead of half-faded.
      settleFade();
      audio.pause();
    } else {
      gainsRef.current[activeSlotRef.current] = 1;
      applyVolumes();
      try {
        await audio.play();
      } catch {
        props.onToast("Playback was blocked. Tap Play again.");
      }
    }
  }, [currentIndex, playing, playIndex, props, applyVolumes, settleFade]);

  const playNext = useCallback(async () => {
    if (orderedTracks.length === 0) return;
    const next = currentIndex === null ? 0 : (currentIndex + 1) % orderedTracks.length;
    await playIndex(next);
  }, [orderedTracks.length, currentIndex, playIndex]);

  const playPrevious = useCallback(async () => {
    if (orderedTracks.length === 0) return;
    const prev =
      currentIndex === null ? 0 : (currentIndex - 1 + orderedTracks.length) % orderedTracks.length;
    await playIndex(prev);
  }, [orderedTracks.length, currentIndex, playIndex]);

  const handleEnded = useCallback(() => {
    // Advance automatically, but stop at the end of the playlist instead
    // of looping back to the first song unasked, and stop after the
    // current song when the queue is set to play one track. With
    // crossfade on, a song that reaches its end without the early
    // blend (a very short song, or one whose length was not known in
    // time) still fades the next song in from silence instead of
    // cutting to it.
    if (settingsRef.current.queueMode === "all" && currentIndex !== null && currentIndex < orderedTracks.length - 1) {
      void playIndex(currentIndex + 1, crossfadeEnabled ? { fadeIn: true } : undefined);
    } else {
      setPlaying(false);
      setCurrentTime(0);
    }
  }, [currentIndex, orderedTracks.length, playIndex, crossfadeEnabled]);

  // Time updates from the idle (fading-out) element are ignored: the
  // progress bar follows the song fading in. In the last few seconds
  // of a song, with crossfade on, the next song starts early so the
  // two overlap — this is what makes a song ending blend instead of
  // stopping and then starting the next one.
  const handleTimeUpdate = (e: SyntheticEvent<HTMLAudioElement>) => {
    const audio = e.currentTarget;
    if (audio !== audioForSlot(activeSlotRef.current)) return;
    setCurrentTime(audio.currentTime);
    if (
      crossfadeEnabled &&
      playing &&
      settingsRef.current.queueMode === "all" &&
      currentIndex !== null &&
      currentIndex < orderedTracks.length - 1 &&
      autoFadeForRef.current !== currentTrackId &&
      Number.isFinite(audio.duration) &&
      audio.duration > crossfadeSeconds + 0.5
    ) {
      const remaining = audio.duration - audio.currentTime;
      if (remaining <= crossfadeSeconds && remaining > 0) {
        autoFadeForRef.current = currentTrackId;
        void playIndex(currentIndex + 1);
      }
    }
  };

  const handleSeek = (value: number) => {
    const audio = audioForSlot(activeSlotRef.current);
    if (!audio) return;
    audio.currentTime = value;
    setCurrentTime(value);
    // Seeking back before the blend window re-arms the end-of-song
    // blend, so it can still happen when the song reaches its end.
    if (duration - value > crossfadeSeconds) autoFadeForRef.current = null;
  };

  // Silence polling lives here, after playIndex exists: it reads the
  // active element's analyser (set up by ensureSilenceMonitor above)
  // while a song plays and skips a sustained quiet stretch, as
  // described at the silence refs above.
  useEffect(() => {
    if (!settings.skipSilence || !playing || !currentTrack) return;
    if (!ensureSilenceMonitor()) return;
    const probe = window.setInterval(() => {
      const audio = audioForSlot(activeSlotRef.current);
      const analyser = silenceAnalysersRef.current[activeSlotRef.current];
      const ctx = silenceCtxRef.current;
      if (!audio || !analyser || !ctx || ctx.state !== "running") return;
      if (!Number.isFinite(audio.duration) || audio.duration <= 0) return;
      const data = new Uint8Array(analyser.fftSize);
      analyser.getByteTimeDomainData(data);
      let sum = 0;
      for (const v of data) {
        const centred = (v - 128) / 128;
        sum += centred * centred;
      }
      const rms = Math.sqrt(sum / data.length);
      const state = silenceStateRef.current;
      if (rms < 0.008) state.silentPolls += 1;
      else {
        state.silentPolls = 0;
        state.heardSound = true;
      }
      const remaining = audio.duration - audio.currentTime;
      if (state.heardSound && state.silentPolls >= 4 && audio.currentTime > 3 && remaining > crossfadeSeconds + 1) {
        state.silentPolls = 0;
        if (settingsRef.current.queueMode === "all" && currentIndex !== null && currentIndex < orderedTracks.length - 1) {
          void playIndex(currentIndex + 1);
        } else {
          audio.currentTime = Math.max(0, audio.duration - 0.05);
        }
      } else if (!state.heardSound && state.silentPolls >= 3 && audio.currentTime < 5 && state.skips < 5) {
        state.silentPolls = 0;
        state.skips += 1;
        audio.currentTime = Math.min(5, audio.currentTime + 1);
      }
    }, 300);
    return () => window.clearInterval(probe);
  }, [settings.skipSilence, playing, currentTrack, currentIndex, orderedTracks.length, crossfadeSeconds, playIndex, ensureSilenceMonitor]);

  // Shared add core for both pickers ("Add songs" and "Add folder"):
  // walks the picked files in order, adds each MP3 that is not already
  // in the playlist, and reports how many were added, how many were
  // skipped as duplicates, and how many were skipped because they are
  // not MP3s. A file that fails to save stops the batch (failed: true)
  // but keeps the counts gathered so far. `onProgress` fires after
  // each file so a big folder add can show how far along it is.
  const addSongFiles = async (
    files: File[],
    onProgress?: (done: number, total: number) => void,
  ): Promise<{ added: number; duplicates: number; skipped: number; failed: boolean }> => {
    let added = 0;
    let skipped = 0;
    let duplicates = 0;
    let failed = false;
    // Names already in the playlist (plus ones added in this same
    // batch), compared case-insensitively: with "Don't allow duplicate
    // songs" on, picking one of them again skips it instead of
    // storing a second copy.
    const seenNames = new Set(tracks.map((t) => t.name.trim().toLowerCase()));
    try {
      for (let i = 0; i < files.length; i += 1) {
        const file = files[i];
        if (!file) continue;
        // Only MP3s enter the playlist: anything else picked is
        // skipped, never stored and never converted.
        if (!/\.mp3$/i.test(file.name)) {
          skipped += 1;
          onProgress?.(i + 1, files.length);
          continue;
        }
        const displayName = songDisplayName(file.name);
        if (settingsRef.current.dontAllowDuplicates && seenNames.has(displayName.trim().toLowerCase())) {
          duplicates += 1;
          onProgress?.(i + 1, files.length);
          continue;
        }
        const { dataBase64, mimeType } = await fileToBase64(file);
        const mime = /^audio\/(mpeg|mp3|x-mp3|x-mpeg)$/.test(mimeType) ? mimeType : "audio/mpeg";
        // The cover art embedded in the MP3 (its ID3 picture frame) is
        // pulled out here and sent with the song; a file with no
        // embedded picture simply adds without one, and the playlist
        // shows its placeholder. Extraction never blocks the add.
        const cover = await extractEmbeddedCover(file);
        await api.addTrack({
          name: displayName,
          dataBase64,
          mimeType: mime,
          ...(cover && cover.dataBase64.length <= 3_000_000
            ? { coverDataBase64: cover.dataBase64, coverMimeType: cover.mimeType }
            : {}),
        });
        seenNames.add(displayName.trim().toLowerCase());
        added += 1;
        onProgress?.(i + 1, files.length);
      }
    } catch {
      failed = true;
    }
    return { added, duplicates, skipped, failed };
  };

  const handleFiles = async (e: ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files ?? []);
    if (files.length === 0) return;
    setAdding(true);
    const { added, duplicates, skipped, failed } = await addSongFiles(files);
    setAdding(false);
    e.target.value = "";
    if (failed) {
      props.onToast("A song could not be added. Try a smaller MP3 file.");
    }
    if (added > 0) {
      props.onToast(added === 1 ? "Song added to your playlist" : `${added} songs added to your playlist`);
      props.onRefresh();
    }
    if (duplicates > 0) {
      props.onToast(
        duplicates === 1
          ? "That song is already in your playlist, so it was skipped."
          : `${duplicates} songs were already in your playlist, so they were skipped.`,
      );
    }
    if (skipped > 0) {
      props.onToast(
        skipped === 1
          ? "Only MP3 files can be added to the playlist."
          : `${skipped} files were skipped — only MP3 files can be added.`,
      );
    }
  };

  // "Add folder": Anthony picks one folder himself in the system
  // folder picker (nothing is scanned without that pick), and every
  // file in it — subfolders included, where the browser returns them —
  // goes through the same add core as "Add songs", in folder-path
  // order so the playlist order follows the folder layout. The result
  // stays on screen in a summary panel instead of a vanishing toast,
  // because a folder add can skip a lot of files and the counts
  // (added / duplicates / not MP3) are the point of the feature.
  const handleFolderFiles = async (e: ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files ?? []);
    e.target.value = "";
    if (files.length === 0) return;
    files.sort((a, b) =>
      (a.webkitRelativePath || a.name).localeCompare(b.webkitRelativePath || b.name),
    );
    setAddingFolder(true);
    setFolderResult(null);
    setFolderProgress({ done: 0, total: files.length });
    const result = await addSongFiles(files, (done, total) => setFolderProgress({ done, total }));
    setAddingFolder(false);
    setFolderProgress(null);
    setFolderResult(result);
    if (result.added > 0) props.onRefresh();
  };

  // Saves one playlist order. The preview order stays on screen until
  // the refetched server order matches it (see the effect above); on a
  // failed save the preview is dropped so the list shows the saved order.
  const commitOrder = useCallback(
    async (order: number[]) => {
      const serverOrder = tracks.map((t) => t.id);
      if (order.join(",") === serverOrder.join(",")) return;
      setSavingOrder(true);
      try {
        await api.reorderTracks({ orderedIds: order });
        props.onRefresh();
      } catch {
        setDragOrder(null);
        props.onToast("The new song order could not be saved. Try again.");
        props.onRefresh();
      } finally {
        setSavingOrder(false);
      }
    },
    [tracks, props],
  );

  // Moves the dragged song in the preview order to the row whose
  // midpoint the pointer has crossed. The list re-renders in preview
  // order as the pointer moves, so the song visibly follows the drag.
  const moveDraggedTo = useCallback((targetIndex: number) => {
    const state = dragStateRef.current;
    if (!state) return;
    const order = [...state.order];
    const from = order.indexOf(state.id);
    if (from < 0) return;
    const clamped = Math.max(0, Math.min(order.length - 1, targetIndex));
    if (from === clamped) return;
    order.splice(from, 1);
    order.splice(clamped, 0, state.id);
    state.order = order;
    state.moved = true;
    setDragOrder(order);
  }, []);

  // Pointer-based dragging (not HTML5 drag-and-drop, which does not
  // fire for touch on phones): the grip handle starts the drag, window
  // listeners track the pointer wherever it goes, and releasing the
  // pointer commits the preview order. A tap without movement saves
  // nothing, and playback keeps following the dragged track by id.
  const startDrag = useCallback(
    (trackId: number) => {
      if (savingOrder || dragStateRef.current) return;
      // Build on the order currently on screen (which may be a preview
      // whose save is still landing), not the stale server order.
      const baseOrder = orderedTracks.map((t) => t.id);
      dragStateRef.current = { id: trackId, order: baseOrder, moved: false };
      setDraggingId(trackId);
      setDragOrder(baseOrder);
      const onMove = (e: PointerEvent) => {
        const state = dragStateRef.current;
        if (!state) return;
        if (e.cancelable) e.preventDefault();
        const items = Array.from(
          listRef.current?.querySelectorAll<HTMLElement>("[data-track-id]") ?? [],
        );
        if (items.length === 0) return;
        let target = items.length - 1;
        for (let i = 0; i < items.length; i += 1) {
          const rect = items[i]?.getBoundingClientRect();
          if (!rect) continue;
          if (e.clientY < rect.top + rect.height / 2) {
            target = i;
            break;
          }
        }
        moveDraggedTo(target);
      };
      const onUp = () => {
        window.removeEventListener("pointermove", onMove);
        window.removeEventListener("pointerup", onUp);
        window.removeEventListener("pointercancel", onUp);
        const state = dragStateRef.current;
        dragStateRef.current = null;
        setDraggingId(null);
        if (state?.moved) void commitOrder(state.order);
      };
      window.addEventListener("pointermove", onMove, { passive: false });
      window.addEventListener("pointerup", onUp);
      window.addEventListener("pointercancel", onUp);
    },
    [orderedTracks, savingOrder, moveDraggedTo, commitOrder],
  );

  // Keyboard equivalent of a drag: with the grip focused, ArrowUp /
  // ArrowDown moves the song one spot and saves the new order.
  const moveTrackBy = useCallback(
    async (track: MusicTrack, delta: -1 | 1) => {
      if (savingOrder) return;
      const order = orderedTracks.map((t) => t.id);
      const from = order.indexOf(track.id);
      const to = from + delta;
      if (from < 0 || to < 0 || to >= order.length) return;
      order.splice(from, 1);
      order.splice(to, 0, track.id);
      setDragOrder(order);
      await commitOrder(order);
    },
    [orderedTracks, savingOrder, commitOrder],
  );

  // "Manage playlists" in the settings panel: back to the player and
  // scrolled to the playlist itself, with the list focused so its
  // position is clear.
  const openPlaylist = () => {
    setSettingsOpen(false);
    setSleepPickerOpen(false);
    setQueuePickerOpen(false);
    window.requestAnimationFrame(() => {
      playlistAnchorRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
      const focusable = playlistAnchorRef.current?.querySelector<HTMLElement>("ul, p");
      if (focusable) {
        focusable.setAttribute("tabindex", "-1");
        focusable.focus({ preventScroll: true });
      }
    });
  };

  const removeTrack = (track: MusicTrack) => {
    props.onConfirm({
      title: "Remove this song?",
      body: `“${track.name}” will be removed from your playlist.`,
      label: "Remove song",
      run: async () => {
        if (track.id === currentTrackId) {
          cancelFade();
          audioRef.current?.pause();
          fadeAudioRef.current?.pause();
          setCurrentTrackId(null);
          setPlaying(false);
          setCurrentTime(0);
          setDuration(0);
        }
        await api.deleteTrack({ id: track.id });
        props.onToast("Song removed from your playlist");
        props.onRefresh();
      },
    });
  };

  return (
    <div>
      <section aria-label="Music player" className="pn">
        <div className="flex flex-wrap items-baseline justify-between gap-2">
          <h1 className="hw-h2" style={{ fontSize: 20 }}>🎵 Music</h1>
          <div className="flex flex-wrap items-center justify-end gap-2">
            <button
              type="button"
              className="hw-btn hw-btn-alt px-4 py-2 text-sm font-bold"
              onClick={() => setSettingsOpen(true)}
              aria-label="Open Music settings"
            >
              ⚙ Settings
            </button>
            <label className="hw-btn cursor-pointer px-4 py-2 text-sm font-bold">
              {adding ? "Adding…" : "Add songs"}
              <input
                type="file"
                accept=".mp3,audio/mpeg,audio/mp3,audio/x-mp3"
                multiple
                className="hidden"
                onChange={handleFiles}
                disabled={adding || addingFolder}
                aria-label="Add MP3 songs to your playlist"
              />
            </label>
            <label className="hw-btn hw-btn-alt cursor-pointer px-4 py-2 text-sm font-bold">
              {addingFolder
                ? folderProgress
                  ? `Adding ${folderProgress.done}/${folderProgress.total}…`
                  : "Adding…"
                : "📁 Add folder"}
              <input
                ref={(el) => {
                  // Folder picker: `webkitdirectory` is the attribute
                  // Android/Chrome uses to offer a whole folder (with
                  // subfolders) instead of individual files. It is set
                  // as an attribute rather than a JSX prop because it
                  // is not part of React's typed input props. No
                  // `accept` filter on purpose: every file in the
                  // folder comes back so non-MP3 files can be counted
                  // and reported as skipped, not silently dropped.
                  el?.setAttribute("webkitdirectory", "");
                }}
                type="file"
                multiple
                className="hidden"
                onChange={handleFolderFiles}
                disabled={adding || addingFolder}
                aria-label="Add all MP3 songs from a folder to your playlist"
              />
            </label>
          </div>
        </div>
        <p className="mut">
          {tracks.length === 0
            ? "No songs yet."
            : `${tracks.length} ${tracks.length === 1 ? "song" : "songs"} in your playlist.`}{" "}
          Pick MP3 files from your phone, or use “Add folder” to bring in a whole folder of MP3s at once — they stay saved here, and only songs you pick are added.
        </p>

        {folderResult && (
          <div
            role="status"
            className="mt-3 flex items-start justify-between gap-3 rounded-[var(--radius)] border border-[var(--border)] bg-[var(--surface)] p-3"
          >
            <p className="text-sm" style={{ margin: 0 }}>
              <strong>Folder done.</strong>{" "}
              {folderResult.added === 1
                ? "1 song added to your playlist. "
                : `${folderResult.added} songs added to your playlist. `}
              {folderResult.duplicates === 1
                ? "1 skipped — already in your playlist. "
                : folderResult.duplicates > 1
                  ? `${folderResult.duplicates} skipped — already in your playlist. `
                  : ""}
              {folderResult.skipped === 1
                ? "1 skipped — not an MP3. "
                : folderResult.skipped > 1
                  ? `${folderResult.skipped} skipped — not MP3 files. `
                  : ""}
              {folderResult.failed ? "One song could not be added, so the rest of the folder was not checked. " : ""}
            </p>
            <button
              type="button"
              className="hw-btn hw-btn-ghost shrink-0 px-2 py-1 text-sm font-bold"
              onClick={() => setFolderResult(null)}
              aria-label="Dismiss folder result"
            >
              ×
            </button>
          </div>
        )}

        {/* Two audio elements so a crossfade can overlap two songs:
            the handlers only follow the active element, so the song
            fading out never moves the progress bar or ends the
            playlist early. */}
        <audio
          ref={audioRef}
          preload="metadata"
          onTimeUpdate={handleTimeUpdate}
          onLoadedMetadata={(e) => {
            if (e.currentTarget === audioForSlot(activeSlotRef.current)) setDuration(e.currentTarget.duration);
          }}
          onDurationChange={(e) => {
            if (e.currentTarget === audioForSlot(activeSlotRef.current)) setDuration(e.currentTarget.duration);
          }}
          onPlay={(e) => {
            if (e.currentTarget === audioForSlot(activeSlotRef.current)) setPlaying(true);
          }}
          onPause={(e) => {
            if (e.currentTarget === audioForSlot(activeSlotRef.current)) setPlaying(false);
          }}
          onEnded={(e) => {
            if (e.currentTarget === audioForSlot(activeSlotRef.current)) handleEnded();
          }}
        />
        <audio
          ref={fadeAudioRef}
          preload="metadata"
          onTimeUpdate={handleTimeUpdate}
          onLoadedMetadata={(e) => {
            if (e.currentTarget === audioForSlot(activeSlotRef.current)) setDuration(e.currentTarget.duration);
          }}
          onDurationChange={(e) => {
            if (e.currentTarget === audioForSlot(activeSlotRef.current)) setDuration(e.currentTarget.duration);
          }}
          onPlay={(e) => {
            if (e.currentTarget === audioForSlot(activeSlotRef.current)) setPlaying(true);
          }}
          onPause={(e) => {
            if (e.currentTarget === audioForSlot(activeSlotRef.current)) setPlaying(false);
          }}
          onEnded={(e) => {
            if (e.currentTarget === audioForSlot(activeSlotRef.current)) handleEnded();
          }}
        />

        {settingsOpen && (
          <div aria-label="Hot Wheels Music settings">
            <div className="mt-3 flex items-center gap-2">
              <button
                type="button"
                className="hw-btn hw-btn-ghost shrink-0 px-3 py-2 text-sm font-bold"
                onClick={() => setSettingsOpen(false)}
                aria-label="Back to Music"
              >
                ← Music
              </button>
              <h2 className="hw-h2" style={{ fontSize: 20, margin: 0 }}>
                Hot Wheels Music settings
              </h2>
            </div>
            <p className="mut mt-1">Settings for how your music plays. They save automatically.</p>

            <h3 className="music-settings-heading">Playback</h3>
            <div className="music-settings-group" role="group" aria-label="Playback settings">
              <button
                type="button"
                className="music-settings-row"
                onClick={() => {
                  setSleepPickerOpen(!sleepPickerOpen);
                  setQueuePickerOpen(false);
                }}
                aria-expanded={sleepPickerOpen}
                aria-label="Sleep timer"
              >
                <span className="music-settings-row-main">
                  <span className="music-settings-title">Sleep timer</span>
                  <span className="music-settings-sub">
                    {sleepRemainingMs !== null
                      ? `${settings.sleepTimerMinutes} minutes · ${formatTrackTime(Math.ceil(sleepRemainingMs / 1000))} left`
                      : settings.sleepTimerMinutes === 0
                        ? "Off"
                        : `${settings.sleepTimerMinutes} minutes`}
                  </span>
                </span>
                <span className="music-settings-chevron" aria-hidden="true">›</span>
              </button>
              {sleepPickerOpen && (
                <div className="music-settings-options" role="group" aria-label="Sleep timer options">
                  {[0, 5, 10, 15, 30, 45, 60, 90].map((minutes) => (
                    <button
                      key={minutes}
                      type="button"
                      className="music-settings-option"
                      aria-pressed={settings.sleepTimerMinutes === minutes}
                      onClick={() => {
                        changeSettings({ sleepTimerMinutes: minutes as MusicSettings["sleepTimerMinutes"] }, true);
                        setSleepPickerOpen(false);
                      }}
                    >
                      <span>{minutes === 0 ? "Off" : `${minutes} minutes`}</span>
                      {settings.sleepTimerMinutes === minutes && (
                        <span className="music-settings-check" aria-hidden="true">✓</span>
                      )}
                    </button>
                  ))}
                </div>
              )}

              <div className="music-settings-slider-row">
                <span className="music-settings-title">Play speed</span>
                <span className="music-settings-value">{settings.playbackRate.toFixed(1)}x</span>
                <input
                  type="range"
                  className="music-settings-slider"
                  min={0.5}
                  max={2}
                  step={0.1}
                  value={settings.playbackRate}
                  onChange={(e) => changeSettings({ playbackRate: Number(e.target.value) })}
                  aria-label="Play speed"
                />
                <span className="music-settings-range-ends" aria-hidden="true">
                  <span>0.5x</span>
                  <span>2.0x</span>
                </span>
              </div>

              <div className="music-settings-slider-row">
                <span className="music-settings-title">Crossfade between tracks</span>
                <span className="music-settings-value">
                  {crossfadeSeconds === 0
                    ? "Off"
                    : crossfadeSeconds === 1
                      ? "1 second"
                      : `${crossfadeSeconds} seconds`}
                </span>
                <input
                  type="range"
                  className="music-settings-slider"
                  min={0}
                  max={10}
                  step={1}
                  value={crossfadeSeconds}
                  onChange={(e) => changeSettings({ crossfadeSeconds: Number(e.target.value) })}
                  aria-label="Crossfade between tracks"
                />
                <span className="music-settings-range-ends" aria-hidden="true">
                  <span>Off</span>
                  <span>10 seconds</span>
                </span>
                {crossfadeSeconds === 0 && (
                  <span className="music-settings-sub">Songs cut cleanly instead of blending.</span>
                )}
              </div>

              <div className="music-settings-row">
                <span className="music-settings-row-main">
                  <span className="music-settings-title">Skip silence between tracks</span>
                  <span className="music-settings-sub">Skips quiet gaps at the start and end of songs.</span>
                </span>
                <button
                  type="button"
                  role="switch"
                  aria-checked={settings.skipSilence}
                  aria-label="Skip silence between tracks"
                  className="music-switch"
                  onClick={() => changeSettings({ skipSilence: !settings.skipSilence }, true)}
                >
                  <span aria-hidden="true" />
                </button>
              </div>

              <div className="music-settings-row">
                <span className="music-settings-row-main">
                  <span className="music-settings-title">Control music from Lock screen</span>
                  <span className="music-settings-sub">Lock-screen controls, where your browser supports them.</span>
                </span>
                <button
                  type="button"
                  role="switch"
                  aria-checked={settings.lockScreen}
                  aria-label="Control music from Lock screen"
                  className="music-switch"
                  onClick={() => changeSettings({ lockScreen: !settings.lockScreen }, true)}
                >
                  <span aria-hidden="true" />
                </button>
              </div>
            </div>

            <h3 className="music-settings-heading">Playlists</h3>
            <div className="music-settings-group" role="group" aria-label="Playlist settings">
              <button
                type="button"
                className="music-settings-row"
                onClick={() => {
                  setQueuePickerOpen(!queuePickerOpen);
                  setSleepPickerOpen(false);
                }}
                aria-expanded={queuePickerOpen}
                aria-label="Queue settings"
              >
                <span className="music-settings-row-main">
                  <span className="music-settings-title">Queue settings</span>
                  <span className="music-settings-sub">
                    {settings.queueMode === "all" ? "Play all tracks" : "Play one track"}
                  </span>
                </span>
                <span className="music-settings-chevron" aria-hidden="true">›</span>
              </button>
              {queuePickerOpen && (
                <div className="music-settings-options" role="group" aria-label="Queue options">
                  <button
                    type="button"
                    className="music-settings-option"
                    aria-pressed={settings.queueMode === "all"}
                    onClick={() => {
                      changeSettings({ queueMode: "all" }, true);
                      setQueuePickerOpen(false);
                    }}
                  >
                    <span>
                      Play all tracks
                      <span className="music-settings-option-note">Plays through the whole playlist.</span>
                    </span>
                    {settings.queueMode === "all" && (
                      <span className="music-settings-check" aria-hidden="true">✓</span>
                    )}
                  </button>
                  <button
                    type="button"
                    className="music-settings-option"
                    aria-pressed={settings.queueMode === "single"}
                    onClick={() => {
                      changeSettings({ queueMode: "single" }, true);
                      setQueuePickerOpen(false);
                    }}
                  >
                    <span>
                      Play one track
                      <span className="music-settings-option-note">Stops after the current song.</span>
                    </span>
                    {settings.queueMode === "single" && (
                      <span className="music-settings-check" aria-hidden="true">✓</span>
                    )}
                  </button>
                </div>
              )}

              <div className="music-settings-row">
                <span className="music-settings-row-main">
                  <span className="music-settings-title">Don&apos;t allow duplicate songs</span>
                  <span className="music-settings-sub">Don&apos;t allow duplicates in queue.</span>
                </span>
                <button
                  type="button"
                  role="switch"
                  aria-checked={settings.dontAllowDuplicates}
                  aria-label="Don't allow duplicate songs"
                  className="music-switch"
                  onClick={() => changeSettings({ dontAllowDuplicates: !settings.dontAllowDuplicates }, true)}
                >
                  <span aria-hidden="true" />
                </button>
              </div>

              <button type="button" className="music-settings-row" onClick={openPlaylist} aria-label="Manage playlists">
                <span className="music-settings-row-main">
                  <span className="music-settings-title">Manage playlists</span>
                  <span className="music-settings-sub">
                    {tracks.length === 0
                      ? "No songs yet"
                      : `${tracks.length} ${tracks.length === 1 ? "song" : "songs"} in your playlist`}
                  </span>
                </span>
                <span className="music-settings-chevron" aria-hidden="true">›</span>
              </button>
            </div>
          </div>
        )}

        {!settingsOpen && tracks.length > 0 && (
          <>
            <div className="music-now">
              <div className="music-now-head">
                <span className="music-track-cover music-now-cover" aria-hidden="true">
                  <span>🔥</span>
                  {currentTrack?.coverUrl && (
                    <img
                      src={currentTrack.coverUrl}
                      alt=""
                      onError={(e) => {
                        e.currentTarget.remove();
                      }}
                    />
                  )}
                </span>
                <div className="music-now-titles">
                  <span className="music-now-label">
                    {currentTrack ? (playing ? "▶ Now playing" : "⏸ Paused") : "Nothing playing"}
                  </span>
                  <p className="music-now-name">{currentTrack?.name ?? "Pick a song below to play it."}</p>
                </div>
              </div>
              <div className="music-seek">
                <span>{formatTrackTime(currentTime)}</span>
                <input
                  type="range"
                  min={0}
                  max={duration > 0 ? duration : 0}
                  step={0.1}
                  value={duration > 0 ? Math.min(currentTime, duration) : 0}
                  onChange={(e) => handleSeek(Number(e.target.value))}
                  disabled={!currentTrack || duration <= 0}
                  aria-label="Seek in current song"
                />
                <span>{formatTrackTime(duration)}</span>
              </div>
              <div className="music-controls">
                <button type="button" className="hw-btn hw-btn-alt music-control" onClick={() => void playPrevious()} disabled={tracks.length === 0} aria-label="Previous song">
                  ⏮ Previous
                </button>
                <button type="button" className="hw-btn music-control music-control-play" onClick={() => void togglePlay()} disabled={tracks.length === 0} aria-label={currentTrack && playing ? `Pause ${currentTrack.name}` : currentTrack ? `Play ${currentTrack.name}` : "Play first song"}>
                  {playing ? "⏸ Pause" : "▶ Play"}
                </button>
                <button type="button" className="hw-btn hw-btn-alt music-control" onClick={() => void playNext()} disabled={tracks.length === 0} aria-label="Next song">
                  Next ⏭
                </button>
              </div>
              <div className="music-volume">
                <span aria-hidden="true">🔊</span>
                <input
                  type="range"
                  min={0}
                  max={1}
                  step={0.05}
                  value={volume}
                  onChange={(e) => setVolume(Number(e.target.value))}
                  aria-label="Volume"
                />
                <span>{Math.round(volume * 100)}%</span>
              </div>
            </div>

            <div ref={playlistAnchorRef}>
              <p className="mut music-reorder-hint">
                Drag the ⠿ handle beside a song to move it up or down — the new order saves
                automatically and plays in that order.
              </p>
            <ul ref={listRef} className="music-list" aria-label="Playlist">
              {orderedTracks.map((track, index) => {
                const isCurrent = track.id === currentTrackId;
                const isDragging = track.id === draggingId;
                return (
                  <li
                    key={track.id}
                    data-track-id={track.id}
                    className={`music-track ${isCurrent ? "music-track-current" : ""} ${isDragging ? "music-track-dragging" : ""}`}
                  >
                    <button
                      type="button"
                      className="music-track-handle"
                      onPointerDown={(e) => {
                        e.preventDefault();
                        startDrag(track.id);
                      }}
                      onKeyDown={(e) => {
                        if (e.key === "ArrowUp") {
                          e.preventDefault();
                          void moveTrackBy(track, -1);
                        } else if (e.key === "ArrowDown") {
                          e.preventDefault();
                          void moveTrackBy(track, 1);
                        }
                      }}
                      disabled={savingOrder}
                      aria-label={`Reorder ${track.name}. Drag up or down, or press arrow up or down to move it.`}
                    >
                      <span aria-hidden="true">⠿</span>
                    </button>
                    <button
                      type="button"
                      className="music-track-play"
                      onClick={() => {
                        if (isCurrent) void togglePlay();
                        else void playIndex(index);
                      }}
                      disabled={!track.url}
                      aria-label={isCurrent && playing ? `Pause ${track.name}` : `Play ${track.name}`}
                    >
                      {isCurrent && playing ? "⏸" : "▶"}
                    </button>
                    <button
                      type="button"
                      className="music-track-cover"
                      onClick={() => {
                        if (isCurrent) void togglePlay();
                        else void playIndex(index);
                      }}
                      disabled={!track.url}
                      aria-label={isCurrent && playing ? `Pause ${track.name}` : `Play ${track.name}`}
                    >
                      <span aria-hidden="true">🔥</span>
                      {track.coverUrl && (
                        <img
                          src={track.coverUrl}
                          alt=""
                          onError={(e) => {
                            e.currentTarget.remove();
                          }}
                        />
                      )}
                    </button>
                    <button
                      type="button"
                      className="music-track-name"
                      onClick={() => {
                        if (isCurrent) void togglePlay();
                        else void playIndex(index);
                      }}
                      disabled={!track.url}
                      aria-label={isCurrent && playing ? `Pause ${track.name}` : `Play ${track.name}`}
                    >
                      <span className="music-track-title">{track.name}</span>
                      <span className="music-track-sub">
                        {isCurrent ? (playing ? "Now playing" : "Paused") : track.url ? `Song ${index + 1}` : "Song file unavailable"}
                      </span>
                    </button>
                    <button
                      type="button"
                      className="music-track-remove"
                      onClick={() => removeTrack(track)}
                      aria-label={`Remove ${track.name} from playlist`}
                    >
                      ×
                    </button>
                  </li>
                );
              })}
            </ul>
            </div>
          </>
        )}

        {!settingsOpen && tracks.length === 0 && (
          <div ref={playlistAnchorRef}>
            <p className="mut mt-2">
              Use “Add songs” above to pick one or more MP3 files at once, or “Add folder” to bring in a whole folder of MP3s in one go. Your playlist is saved in the app, so it is still here when you reopen it.
            </p>
          </div>
        )}
      </section>
    </div>
  );
}

/* ---------------- Chat with Hot Wheels Manager ---------------- */

type ChatMessage = ApiResponse<typeof api, "getChatHistory">["messages"][number];

function ChatView(props: {
  data: State;
  byKey: Map<string, DisplayCar>;
  onOpenCar: (key: string) => void;
  onGoCars: () => void;
  onGoPlanner: () => void;
  onRefresh: () => void;
  onConfirm: (c: { title: string; body: string; label: string; run: () => Promise<unknown> | void }) => void;
}) {
  const queryClient = useQueryClient();
  const [draft, setDraft] = useState("");
  const [recipient, setRecipient] = useState<"manager" | "fun">("manager");
  const [pendingText, setPendingText] = useState<string | null>(null);
  const [pendingRecipient, setPendingRecipient] = useState<"manager" | "fun">("manager");
  const [sendError, setSendError] = useState("");
  const bottomRef = useRef<HTMLDivElement | null>(null);

  const chatQuery = useQuery({
    queryKey: ["chat-history"],
    queryFn: () => api.getChatHistory({}),
  });

  const send = useMutation({
    mutationFn: (args: { message: string; recipient: "manager" | "fun" }) =>
      api.sendChatMessage({ message: args.message, recipient: args.recipient }),
    onSuccess: () => {
      setPendingText(null);
      setSendError("");
      queryClient.invalidateQueries({ queryKey: ["chat-history"] });
      props.onRefresh();
    },
    onError: () => {
      setSendError("That message didn't go through. Your text is still in the box below — try sending it again.");
      setDraft(pendingText ?? draft);
      setPendingText(null);
    },
  });

  const messages: ChatMessage[] = chatQuery.data?.messages ?? [];
  const sending = send.isPending;

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ block: "end" });
  }, [messages.length, sending, pendingText]);

  const submit = (e: FormEvent) => {
    e.preventDefault();
    const text = draft.trim();
    if (!text || sending) return;
    setSendError("");
    setPendingText(text);
    setPendingRecipient(recipient);
    setDraft("");
    send.mutate({ message: text, recipient });
  };

  const sendChip = (text: string) => {
    if (sending) return;
    setSendError("");
    setPendingText(text);
    setPendingRecipient(recipient);
    setDraft("");
    send.mutate({ message: text, recipient });
  };

  const carOfDay = props.data.carOfDayKey ? props.byKey.get(props.data.carOfDayKey) ?? null : null;
  const monthTargets = props.data.targets.filter((t) => t.month === thisMonth() && !t.done).length;
  const chips: { label: string; message: string }[] = [
    { label: "What should I hunt next?", message: "What should I hunt next?" },
    { label: "How many Treasure Hunts do I own?", message: "How many Treasure Hunts do I own?" },
    { label: "How close am I to my next badge?", message: "How close am I to my next badge?" },
    { label: "What are my targets this month?", message: "What are my targets this month?" },
  ];
  if (carOfDay) {
    chips.push({ label: `I found ${carOfDay.n}`, message: `I found ${carOfDay.n} — mark it owned` });
  }

  return (
    <div>
      <section aria-label="Chat with Hot Wheels Manager" className="pn">
        <div className="flex items-start justify-between gap-3">
          <div className="flex min-w-0 flex-1 items-center gap-3">
            <span className="flex h-11 w-11 shrink-0 items-center justify-center overflow-hidden rounded-full bg-[#16224d]">
              <img src={logoImg} alt="" className="h-7 w-auto object-contain" />
            </span>
            <div className="min-w-0">
              <h1 className="hw-h2" style={{ fontSize: 20, margin: 0, lineHeight: 1.2 }}>Chat with Hot Wheels Manager</h1>
              <p className="mut">Your Hot Wheels Manager, inside the Hunt Book</p>
            </div>
          </div>
          {messages.length > 0 && (
            <button
              type="button"
              className="shrink-0 rounded-full border border-[var(--border)] px-3 py-1.5 text-xs font-bold"
              onClick={() =>
                props.onConfirm({
                  title: "Clear this chat?",
                  body: "Your chat history with Hot Wheels Manager and Hot Wheels Guru will be deleted. Your cars, photos, and planner stay exactly as they are.",
                  label: "Clear chat",
                  run: async () => {
                    await api.clearChat({});
                    queryClient.invalidateQueries({ queryKey: ["chat-history"] });
                  },
                })
              }
            >
              Clear chat
            </button>
          )}
        </div>
        <p className="mut mt-2">
          Three in this chat: you, Hot Wheels Manager, and Hot Wheels Guru. Hot Wheels Manager answers from this Hunt Book only — your cars,
          targets, and hunt days. It can&apos;t check prices or store stock, and when you ask it to mark a car owned or add a target, it
          changes this same collection. Hot Wheels Guru is just for fun — jokes, hype, and hunt excitement — and never changes your cars,
          photos, targets, planner, badges, or streak. Pick who you&apos;re talking to with the selector above the message box.
          Cars marked owned or TH need a photo of the car to be verified: in the app, tapping OWN or TH asks for a photo first, and cars
          without one are flagged UNVERIFIED until you add a photo of them.
        </p>
        <div className="chat-participants" aria-label="Chat participants">
          <span>👤 Anthony (you)</span>
          <span>
            <img src={logoImg} alt="" className="h-3.5 w-auto object-contain" /> Hot Wheels Manager
          </span>
          <span className="participant-fun">🏎️ Hot Wheels Guru</span>
        </div>
      </section>

      {chatQuery.isPending ? (
        <div className="pn p-6 text-center">
          <p className="font-semibold">Loading your chat…</p>
        </div>
      ) : chatQuery.error ? (
        <div className="pn p-6 text-center">
          <p className="font-semibold">Couldn&apos;t load the chat.</p>
          <button type="button" className="hw-btn mt-3 px-4 py-2 text-sm font-bold" onClick={() => chatQuery.refetch()}>
            Try again
          </button>
        </div>
      ) : (
        <>
          <div className="pn chat-log" role="log" aria-label="Chat messages">
            {messages.length === 0 && !pendingText ? (
              <div className="py-2 text-center">
                <p className="text-base font-bold">Hey, I&apos;m Hot Wheels Manager. 🏁</p>
                <p className="mut mx-auto mt-1 max-w-sm">
                  You own {props.data.stats.owned} of {props.data.stats.total} cars, with {props.data.stats.th} Treasure Hunts
                  and a {props.data.streak.current}-day streak. Ask me what&apos;s missing, what to hunt next, or tell me about a
                  find{monthTargets > 0 ? ` — you have ${monthTargets} targets left this month` : ""}. Or pick Hot Wheels Guru below
                  for jokes, hype, and hunt excitement — Hot Wheels Guru never changes your collection.
                </p>
                <div className="mt-4 flex flex-wrap justify-center gap-2">
                  {chips.map((chip) => (
                    <button
                      key={chip.label}
                      type="button"
                      className="chip"
                      disabled={sending}
                      onClick={() => sendChip(chip.message)}
                    >
                      {chip.label}
                    </button>
                  ))}
                </div>
              </div>
            ) : (
              <ul className="space-y-3">
                {messages.map((m) => {
                  const car = m.carKey ? props.byKey.get(m.carKey) ?? null : null;
                  const isUser = m.role === "user";
                  const isFun = !isUser && m.bot === "fun";
                  return (
                    <li key={m.id} className={`flex gap-2 ${isUser ? "justify-end" : "justify-start"}`}>
                      {!isUser && (
                        isFun ? (
                          <span className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-[#f57c00] text-base" aria-hidden="true">
                            🏎️
                          </span>
                        ) : (
                          <span className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center overflow-hidden rounded-full bg-[#16224d]" aria-hidden="true">
                            <img src={logoImg} alt="" className="h-5 w-auto object-contain" />
                          </span>
                        )
                      )}
                      <div className={`max-w-[82%] ${isUser ? "chat-bubble-user" : isFun ? "chat-bubble-fun" : "chat-bubble-muse"}`}>
                        {!isUser && (
                          <span className="chat-speaker">{isFun ? "🏎️ Hot Wheels Guru" : "Hot Wheels Manager"}</span>
                        )}
                        <p className="whitespace-pre-wrap text-sm leading-relaxed">{m.content}</p>
                        {car && (
                          <button
                            type="button"
                            className="mt-2 rounded-full bg-white/15 px-3 py-1.5 text-xs font-bold text-inherit underline"
                            onClick={() => props.onOpenCar(car.k)}
                          >
                            Open {car.n}
                          </button>
                        )}
                        <p className={`mt-1.5 text-[11px] ${isUser ? "text-white/75" : isFun ? "text-white/80" : "text-[var(--dim)]"}`}>
                          {new Date(m.createdAt).toLocaleTimeString(undefined, { hour: "numeric", minute: "2-digit" })}
                        </p>
                      </div>
                    </li>
                  );
                })}
                {pendingText !== null && (
                  <li className="flex justify-end">
                    <div className="chat-bubble-user max-w-[82%] opacity-80">
                      <p className="whitespace-pre-wrap text-sm leading-relaxed">{pendingText}</p>
                    </div>
                  </li>
                )}
                {sending && (
                  <li className="flex gap-2" aria-live="polite">
                    {pendingRecipient === "fun" ? (
                      <span className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-[#f57c00] text-base" aria-hidden="true">
                        🏎️
                      </span>
                    ) : (
                      <span className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center overflow-hidden rounded-full bg-[#16224d]" aria-hidden="true">
                        <img src={logoImg} alt="" className="h-5 w-auto object-contain" />
                      </span>
                    )}
                    <div className={pendingRecipient === "fun" ? "chat-bubble-fun" : "chat-bubble-muse"}>
                      <p className="text-sm font-semibold">{pendingRecipient === "fun" ? "Hot Wheels Guru is revving up…" : "Hot Wheels Manager is thinking…"}</p>
                    </div>
                  </li>
                )}
              </ul>
            )}
            <div ref={bottomRef} />
          </div>

          {sendError && (
            <p role="alert" className="mt-2 px-1 text-sm font-semibold text-[var(--accent)]">{sendError}</p>
          )}

          <div className="chat-recipient" role="group" aria-label="Choose who to talk to">
            <button
              type="button"
              className="recipient-manager"
              aria-pressed={recipient === "manager"}
              onClick={() => setRecipient("manager")}
            >
              <span className="recipient-icon" aria-hidden="true">
                <img src={logoImg} alt="" />
              </span>
              Hot Wheels Manager
            </button>
            <button
              type="button"
              className="recipient-fun"
              aria-pressed={recipient === "fun"}
              onClick={() => setRecipient("fun")}
            >
              <span className="recipient-icon" aria-hidden="true">🏎️</span>
              Hot Wheels Guru
            </button>
          </div>
          <p className="chat-recipient-note mt-1.5 px-1 text-center text-[12px]">
            {recipient === "manager"
              ? "Hot Wheels Manager can check your collection and mark cars or add targets."
              : "Hot Wheels Guru is just for fun — jokes and hype. It never changes your collection."}
          </p>

          <form className="chat-composer" onSubmit={submit} aria-label={recipient === "fun" ? "Send a message to Hot Wheels Guru" : "Send a message to Hot Wheels Manager"}>
            <label className="flex-1">
              <span className="sr-only">{recipient === "fun" ? "Message Hot Wheels Guru" : "Message Hot Wheels Manager"}</span>
              <input
                value={draft}
                onChange={(e) => setDraft(e.target.value)}
                placeholder={recipient === "fun" ? "Chat with Hot Wheels Guru — jokes, hype & hunt excitement…" : "Ask Hot Wheels Manager about your collection…"}
                autoComplete="off"
                disabled={sending}
                className="w-full rounded-full border border-[var(--border)] bg-[var(--surface-2)] px-4 py-3 text-base outline-none focus:border-[var(--accent)] disabled:opacity-60"
              />
            </label>
            <button
              type="submit"
              disabled={!draft.trim() || sending}
              className="hw-btn shrink-0 px-5 py-3 text-sm font-bold disabled:opacity-50"
            >
              Send
            </button>
          </form>
          <p className="mut mt-2 px-1 text-center">
            {recipient === "manager"
              ? "Tip: try “I found Twin Mill” or “add Bone Shaker to my targets.”"
              : "Tip: try “Tell me a Hot Wheels joke” or “Hype me up for the Nov 14 hunt.”"}{" "}
            <button type="button" className="font-bold text-[var(--accent)] underline" onClick={props.onGoCars}>
              Browse cars
            </button>{" "}
            ·{" "}
            <button type="button" className="font-bold text-[var(--accent)] underline" onClick={props.onGoPlanner}>
              Hunt planner
            </button>
          </p>
        </>
      )}
    </div>
  );
}

/* ---------------- Backup downloads ---------------- */

// Triggers a file download for bytes the app generated (a backup JSON,
// a progress spreadsheet, or a photos zip). The anchor is created and
// clicked from the tap handler's call chain, so the download is the
// direct result of tapping the button.
function downloadFile(blob: Blob, filename: string): void {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 5000);
}

function backupFileStamp(date = new Date()): string {
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`;
}

function csvField(value: string | number): string {
  const s = String(value);
  return /[",\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

// Human-readable series/game labels for the spreadsheet, from the
// same tag decoding the Cars list uses (short tile labels plus the
// full filter names), de-duplicated in tag order.
function seriesLabels(tags: string): string {
  const labels: string[] = [];
  for (const ch of tags) {
    const leg = TAG_LEGEND[ch];
    if (leg && !labels.includes(leg[0])) labels.push(leg[0]);
    const filterLabel = FILTER_LABEL_BY_CODE.get(ch);
    if (filterLabel && !labels.includes(filterLabel)) labels.push(filterLabel);
  }
  return labels.join("; ");
}

function extensionFor(contentType: string, fallback: string): string {
  const map: Record<string, string> = {
    "image/jpeg": "jpg",
    "image/png": "png",
    "image/webp": "webp",
    "image/gif": "gif",
    "video/mp4": "mp4",
    "video/webm": "webm",
    "video/quicktime": "mov",
    "video/x-m4v": "m4v",
  };
  return map[contentType] ?? fallback;
}

// Zip-safe file stem: letters and digits only, everything else a
// dash, so names stay ASCII and readable in any unzip tool.
function zipSafeStem(name: string, fallback: string): string {
  const stem = name.replace(/[^A-Za-z0-9]+/g, "-").replace(/^-+|-+$/g, "");
  return stem || fallback;
}

// CRC-32 (IEEE) for the stored (uncompressed) zip entries: the zip
// below stores photo bytes as-is, so no compression library is
// needed, but every entry still needs a correct checksum or unzip
// tools reject the file.
const ZIP_CRC_TABLE: number[] = (() => {
  const table: number[] = [];
  for (let n = 0; n < 256; n += 1) {
    let c = n;
    for (let k = 0; k < 8; k += 1) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    table.push(c >>> 0);
  }
  return table;
})();

function zipCrc32(bytes: Uint8Array): number {
  let crc = 0xffffffff;
  for (const b of bytes) {
    const entry = ZIP_CRC_TABLE[(crc ^ b) & 0xff];
    crc = (entry ?? 0) ^ (crc >>> 8);
  }
  return (crc ^ 0xffffffff) >>> 0;
}

function concatParts(parts: Uint8Array[]): Uint8Array {
  const total = parts.reduce((sum, p) => sum + p.byteLength, 0);
  const out = new Uint8Array(total);
  let at = 0;
  for (const p of parts) {
    out.set(p, at);
    at += p.byteLength;
  }
  return out;
}

// Builds a valid zip with stored (method 0) entries: a local header
// + bytes per file, then a central directory, then the end record.
// DOS date/time come from the current time; sizes and offsets are
// the real ones, so the file opens in the system unzip tool and in
// Python's zipfile alike.
function buildZipBlob(files: { name: string; data: Uint8Array }[]): Blob {
  const encoder = new TextEncoder();
  const now = new Date();
  const dosTime = ((now.getHours() & 0x1f) << 11) | ((now.getMinutes() & 0x3f) << 5) | (Math.floor(now.getSeconds() / 2) & 0x1f);
  const dosDate = (((now.getFullYear() - 1980) & 0x7f) << 9) | (((now.getMonth() + 1) & 0x0f) << 5) | (now.getDate() & 0x1f);
  const localParts: Uint8Array[] = [];
  const centralParts: Uint8Array[] = [];
  let offset = 0;
  for (const file of files) {
    const nameBytes = encoder.encode(file.name);
    const crc = zipCrc32(file.data);
    const header = new DataView(new ArrayBuffer(30));
    header.setUint32(0, 0x04034b50, true);
    header.setUint16(4, 20, true);
    header.setUint16(6, 0x0800, true);
    header.setUint16(8, 0, true);
    header.setUint16(10, dosTime, true);
    header.setUint16(12, dosDate, true);
    header.setUint32(14, crc, true);
    header.setUint32(18, file.data.byteLength, true);
    header.setUint32(22, file.data.byteLength, true);
    header.setUint16(26, nameBytes.byteLength, true);
    header.setUint16(28, 0, true);
    localParts.push(new Uint8Array(header.buffer), nameBytes, file.data);
    const central = new DataView(new ArrayBuffer(46));
    central.setUint32(0, 0x02014b50, true);
    central.setUint16(4, 20, true);
    central.setUint16(6, 20, true);
    central.setUint16(8, 0x0800, true);
    central.setUint16(10, 0, true);
    central.setUint16(12, dosTime, true);
    central.setUint16(14, dosDate, true);
    central.setUint32(16, crc, true);
    central.setUint32(20, file.data.byteLength, true);
    central.setUint32(24, file.data.byteLength, true);
    central.setUint16(28, nameBytes.byteLength, true);
    central.setUint16(30, 0, true);
    central.setUint16(32, 0, true);
    central.setUint16(34, 0, true);
    central.setUint16(36, 0, true);
    central.setUint32(38, 0, true);
    central.setUint32(42, offset, true);
    centralParts.push(new Uint8Array(central.buffer), nameBytes);
    offset += 30 + nameBytes.byteLength + file.data.byteLength;
  }
  const body = concatParts(localParts);
  const centralDir = concatParts(centralParts);
  const end = new DataView(new ArrayBuffer(22));
  end.setUint32(0, 0x06054b50, true);
  end.setUint16(4, 0, true);
  end.setUint16(6, 0, true);
  end.setUint16(8, files.length, true);
  end.setUint16(10, files.length, true);
  end.setUint32(12, centralDir.byteLength, true);
  end.setUint32(16, body.byteLength, true);
  end.setUint16(20, 0, true);
  return new Blob([concatParts([body, centralDir, new Uint8Array(end.buffer)])], { type: "application/zip" });
}

/* ---------------- Profile & Backup ---------------- */

/* ---------------- Rewards & Points ----------------
   The points page: current level with progress to the next, the
   level ladder and what each level unlocks, the titles and frames
   Anthony can wear on his profile, the Rewards Shop (spendable
   points only — buying never touches lifetime points or the level),
   how points are earned, and the recent activity log. Everything
   renders from data.points in the loaded state; buys and equips go
   through the buyRewardItem / equipReward actions. */
function RewardsView(props: {
  data: State;
  onToast: (msg: string) => void;
  onRefresh: () => void;
}) {
  const pts = props.data.points;
  const [buying, setBuying] = useState<string | null>(null);
  const [equipping, setEquipping] = useState<string | null>(null);

  const curLevel = pts.levels.find((l) => l.level === pts.level);
  const levelStart = curLevel?.at ?? 0;
  const progressPct = pts.nextLevel
    ? Math.min(100, Math.max(0, ((pts.lifetime - levelStart) / (pts.nextLevel.at - levelStart)) * 100))
    : 100;
  const toNext = pts.nextLevel ? pts.nextLevel.at - pts.lifetime : 0;

  const buy = async (item: Points["shop"][number]) => {
    if (buying) return;
    setBuying(item.id);
    try {
      const res = await api.buyRewardItem({ itemId: item.id });
      if (res.ok) {
        props.onToast(`Unlocked: ${item.name}! 🎉`);
        props.onRefresh();
      } else {
        props.onToast(res.error ?? "That reward could not be bought.");
      }
    } catch {
      props.onToast("That reward could not be bought. Try again.");
    } finally {
      setBuying(null);
    }
  };

  const equip = async (kind: "title" | "frame", itemId: string | null, name: string) => {
    if (equipping) return;
    setEquipping(itemId ?? `none-${kind}`);
    try {
      await api.equipReward({ kind, itemId });
      props.onToast(
        itemId === null
          ? kind === "title"
            ? "Title reset to your level title"
            : "Frame removed"
          : kind === "title"
            ? `Title set: ${name}`
            : `Frame set: ${name}`,
      );
      props.onRefresh();
    } catch {
      props.onToast("That could not be set. It may not be unlocked yet.");
    } finally {
      setEquipping(null);
    }
  };

  const kindLabel = (kind: "title" | "frame" | "badge") =>
    kind === "title" ? "Profile title" : kind === "frame" ? "Profile frame" : "Special badge";

  return (
    <div className="space-y-5">
      <section aria-label="Your points" className="pn pn-premium">
        <span className="show-kicker">⭐ Points &amp; Rewards</span>
        <div className="mt-3 flex items-center gap-4">
          <span className="next-badge-icon" style={{ fontSize: 44 }} aria-hidden="true">{pts.levelIcon}</span>
          <div className="min-w-0 flex-1">
            <p className="text-xl font-black leading-tight">Level {pts.level} · {pts.levelName}</p>
            <p className="text-sm text-[var(--dim)]">{pts.lifetime} lifetime points</p>
          </div>
          <div className="text-right">
            <p className="font-display text-3xl font-black leading-none" style={{ color: "var(--gold)" }}>{pts.balance}</p>
            <p className="mt-1 text-xs font-bold uppercase tracking-wide text-[var(--dim)]">to spend</p>
          </div>
        </div>
        <div className="bar mt-3" aria-hidden="true">
          <i style={{ width: `${progressPct}%` }} />
        </div>
        <p className="mt-2 text-sm font-semibold text-[var(--dim)]">
          {pts.nextLevel
            ? `${toNext} points to Level ${pts.nextLevel.level} · ${pts.nextLevel.name}`
            : "Top level reached — you're a Hot Wheels Legend! 🏆"}
        </p>
        <p className="mt-1 text-sm text-[var(--dim)]">
          Spending points in the shop never lowers your level — levels run on lifetime points.
        </p>
      </section>

      <section aria-label="Level ladder" className="pn">
        <h2 className="hw-h2">🏁 Level ladder</h2>
        <ul className="mt-2 space-y-2">
          {pts.levels.map((l) => {
            const isCurrent = l.level === pts.level;
            return (
              <li
                key={l.level}
                className={`rounded-xl border p-3 ${isCurrent ? "gold-ring" : ""}`}
                style={{
                  borderColor: isCurrent ? "transparent" : "var(--border)",
                  background: "var(--surface-2)",
                  opacity: l.unlocked ? 1 : 0.75,
                }}
              >
                <div className="flex items-center gap-3">
                  <span className="text-2xl" aria-hidden="true">{l.icon}</span>
                  <div className="min-w-0 flex-1">
                    <p className="font-bold leading-tight">
                      Level {l.level} · {l.name}
                      {isCurrent && <span className="tag tag-th ml-2">YOU ARE HERE</span>}
                    </p>
                    <p className="text-xs text-[var(--dim)]">{l.at} lifetime points</p>
                  </div>
                  <span className="text-sm font-black" style={{ color: l.unlocked ? "var(--green)" : "var(--dim)" }}>
                    {l.unlocked ? "✓ Unlocked" : `🔒 ${l.at - pts.lifetime} to go`}
                  </span>
                </div>
                <ul className="mt-2 space-y-0.5 pl-11 text-sm text-[var(--dim)]">
                  {l.unlocks.map((u) => (
                    <li key={u}>{l.unlocked ? "✓" : "•"} {u}</li>
                  ))}
                </ul>
              </li>
            );
          })}
        </ul>
      </section>

      <section aria-label="Your look" className="pn">
        <h2 className="hw-h2">🎨 Your look</h2>
        <div className="mt-3 flex items-center gap-3">
          <div
            className={`flex h-16 w-16 shrink-0 items-center justify-center overflow-hidden rounded-full border-[3px] bg-[#16224d] text-lg font-bold text-white ${pts.equippedFrameClass ?? ""}`}
            style={pts.equippedFrameClass ? undefined : { borderColor: "#ff7a00" }}
          >
            {props.data.profile.photoUrl ? (
              <img src={props.data.profile.photoUrl} alt="" className="h-full w-full object-cover" />
            ) : (
              <span aria-hidden="true">{(props.data.profile.name.trim()[0] ?? "C").toUpperCase()}</span>
            )}
          </div>
          <div className="min-w-0">
            <p className="font-bold leading-tight">{props.data.profile.name.trim() || "Collector"}</p>
            <p className="reward-title-line">{pts.equippedTitle}</p>
            <p className="text-xs text-[var(--dim)]">Shown on your profile</p>
          </div>
        </div>

        <p className="mt-4 text-sm font-bold">Profile title</p>
        <ul className="mt-1.5 space-y-1.5">
          {pts.titles.map((t) => (
            <li key={t.id} className="flex items-center gap-2">
              <span className="min-w-0 flex-1 truncate text-sm font-semibold">
                {t.name}
                <span className="ml-2 text-xs font-semibold text-[var(--dim)]">
                  {t.source === "level" ? "Level unlock" : "Shop"}
                </span>
              </span>
              {!t.owned ? (
                <span className="text-xs font-bold text-[var(--dim)]">🔒 Locked</span>
              ) : t.equipped ? (
                <span className="tag tag-th">USING</span>
              ) : (
                <button
                  type="button"
                  className="hw-btn hw-btn-ghost px-3 py-1.5 text-xs font-bold"
                  disabled={equipping !== null}
                  onClick={() => void equip("title", t.id, t.name)}
                >
                  {equipping === t.id ? "Setting…" : "Use"}
                </button>
              )}
            </li>
          ))}
        </ul>

        <p className="mt-4 text-sm font-bold">Profile photo frame</p>
        <ul className="mt-1.5 space-y-1.5">
          {pts.frames.map((f) => (
            <li key={f.id} className="flex items-center gap-2">
              <span className={`reward-frame-preview ${f.frameClass}`} aria-hidden="true">HW</span>
              <span className="min-w-0 flex-1 truncate text-sm font-semibold">
                {f.name}
                <span className="ml-2 text-xs font-semibold text-[var(--dim)]">
                  {f.source === "level" ? "Level unlock" : "Shop"}
                </span>
              </span>
              {!f.owned ? (
                <span className="text-xs font-bold text-[var(--dim)]">🔒 Locked</span>
              ) : f.equipped ? (
                <span className="tag tag-th">USING</span>
              ) : (
                <button
                  type="button"
                  className="hw-btn hw-btn-ghost px-3 py-1.5 text-xs font-bold"
                  disabled={equipping !== null}
                  onClick={() => void equip("frame", f.id, f.name)}
                >
                  {equipping === f.id ? "Setting…" : "Use"}
                </button>
              )}
            </li>
          ))}
          {pts.equippedFrameClass && (
            <li className="flex items-center gap-2">
              <span className="reward-frame-preview" aria-hidden="true">HW</span>
              <span className="min-w-0 flex-1 text-sm font-semibold">No frame</span>
              <button
                type="button"
                className="hw-btn hw-btn-ghost px-3 py-1.5 text-xs font-bold"
                disabled={equipping !== null}
                onClick={() => void equip("frame", null, "")}
              >
                Remove frame
              </button>
            </li>
          )}
        </ul>
      </section>

      <section aria-label="Rewards Shop" className="pn">
        <h2 className="hw-h2">🛒 Rewards Shop</h2>
        <p className="mt-1 text-sm text-[var(--dim)]">
          Spend your <b className="text-[var(--text)]">{pts.balance} points</b> on in-app unlocks. Buying never lowers
          your lifetime points or your level.
        </p>
        <div className="mt-3 grid grid-cols-2 gap-2.5">
          {pts.shop.map((item) => (
            <div key={item.id} className="reward-shop-card">
              <span className="text-3xl" aria-hidden="true">{item.icon}</span>
              {item.kind === "frame" && item.frameClass && (
                <span className={`reward-frame-preview ${item.frameClass}`} aria-hidden="true">HW</span>
              )}
              <p className="mt-1.5 text-sm font-bold leading-tight">{item.name}</p>
              <p className="text-xs font-semibold text-[var(--dim)]">{kindLabel(item.kind)}</p>
              <div className="mt-2">
                {item.owned ? (
                  item.kind === "badge" ? (
                    <span className="tag tag-th">✓ OWNED</span>
                  ) : item.equipped ? (
                    <span className="tag tag-th">✓ USING</span>
                  ) : (
                    <button
                      type="button"
                      className="hw-btn hw-btn-ghost w-full px-3 py-2 text-xs font-bold"
                      disabled={equipping !== null}
                      onClick={() => void equip(item.kind === "title" ? "title" : "frame", item.id, item.name)}
                    >
                      ✓ Owned — use it
                    </button>
                  )
                ) : (
                  <button
                    type="button"
                    className="hw-btn w-full px-3 py-2 text-xs font-bold disabled:opacity-50"
                    disabled={buying !== null || pts.balance < item.cost}
                    onClick={() => void buy(item)}
                    aria-label={`Buy ${item.name} for ${item.cost} points`}
                  >
                    {buying === item.id ? "Buying…" : pts.balance < item.cost ? `⭐ ${item.cost} — need ${item.cost - pts.balance} more` : `Buy · ⭐ ${item.cost}`}
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      </section>

      <section aria-label="How points are earned" className="pn">
        <h2 className="hw-h2">⭐ How points are earned</h2>
        <ul className="mt-2 space-y-1.5 text-sm">
          <li>🚗 New car you don&apos;t own yet — <b>+10</b></li>
          <li>📦 Extra copy of a car you own — <b>+2</b></li>
          <li>⭐ Treasure Hunt — <b>+50</b></li>
          <li>🌟 Super Treasure Hunt — <b>+100</b></li>
          <li>📷 Adding a photo — <b>+5</b></li>
          <li>🎯 Finding a hunt target — <b>+25</b></li>
          <li>🔥 Daily visit, keeping the streak going — <b>+5</b> a day</li>
        </ul>
      </section>

      <section aria-label="Recent points activity" className="pn">
        <h2 className="hw-h2">🧾 Recent activity</h2>
        {pts.activity.length === 0 ? (
          <p className="mt-1 text-sm text-[var(--dim)]">No points yet — mark a car owned or add a photo to start earning.</p>
        ) : (
          <ul className="mt-1">
            {pts.activity.map((a) => (
              <li key={a.id} className="flex items-baseline gap-3 border-b border-[var(--border)] py-2 last:border-b-0">
                <span className="min-w-0 flex-1">
                  <span className="block text-sm font-semibold leading-snug">{a.label}</span>
                  <span className="text-xs text-[var(--dim)]">
                    {new Date(a.createdAt).toLocaleDateString(undefined, { month: "short", day: "numeric" })}
                    {" · "}
                    {new Date(a.createdAt).toLocaleTimeString(undefined, { hour: "numeric", minute: "2-digit" })}
                  </span>
                </span>
                <span
                  className="shrink-0 font-display text-base font-black"
                  style={{ color: a.points >= 0 ? "var(--green)" : "var(--accent)" }}
                >
                  {a.points >= 0 ? `+${a.points}` : a.points}
                </span>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}

/* ---------------- Performance Test ----------------
   On-demand, read-only speed check inside Diagnostics. Nothing runs
   until Anthony taps Run, and the test never writes: it renders the
   real Cars list and Photo Gallery once, off-screen (fixed position
   far left, visibility hidden — never display:none, which would skip
   the layout and paint work being measured), times them, and takes
   them away again. The Cars probe is handed a photo map whose
   missing thumbnails are filled in with the photo's own URL, so the
   tiles render the exact same picture while the Cars list's
   thumbnail-backfill effect (which saves thumbnails for shown cars)
   sees nothing to do and cannot write during the test. Cold-load and
   Home-settle come from this open's real boot marks (see bootMarks
   above), not re-measured; Home-settle is the settle time AFTER the
   intro splash leaves, so the time the splash spends waiting for
   his Press Start tap is never counted as slowness. Results live
   in a module variable so they survive switching tabs; only a
   reload or a new run replaces them. */

type PerfGrade = "fast" | "ok" | "slow";

interface PerfResult {
  ranAt: string;
  coldLoadMs: number | null;
  homeSettledMs: number | null;
  serverMs: number | null;
  carsMs: number;
  carsShown: number;
  carsTotal: number;
  searchTerm: string;
  searchMatches: number;
  searchMs: number;
  galleryMs: number;
  galleryImages: number;
  galleryCapped: boolean;
  missingThumbs: number;
  photosWithUrl: number;
  resourceCount: number;
  largestFileName: string | null;
  largestFileKb: number | null;
  pageImages: number;
  mediaCount: number;
  heapMb: number | null;
  dragLine: string;
}

let lastPerfResult: PerfResult | null = null;

function perfGrade(ms: number, fastUnder: number, okUnder: number): PerfGrade {
  return ms < fastUnder ? "fast" : ms < okUnder ? "ok" : "slow";
}

const PERF_GRADE_WORD: Record<PerfGrade, string> = { fast: "Fast", ok: "OK", slow: "Slow" };

function fmtPerfMs(ms: number): string {
  if (ms < 1000) return `${Math.max(1, Math.round(ms))} ms`;
  return `${(ms / 1000).toFixed(2)} s`;
}

function perfResourceName(url: string): string {
  if (url.startsWith("blob:")) return "a photo or video from your book";
  try {
    const parsed = new URL(url);
    // The book's own photos, videos, and songs are served from
    // /blobs/<opaque id> paths — the id names nothing to a reader,
    // so call them what they are.
    if (parsed.pathname.includes("/blobs/")) return "a photo or video from your book";
    const parts = parsed.pathname.split("/").filter(Boolean);
    const last = parts[parts.length - 1];
    return last ? decodeURIComponent(last) : parsed.hostname;
  } catch {
    return "a file";
  }
}

const perfRaf = () =>
  new Promise<void>((resolve) => {
    requestAnimationFrame(() => resolve());
  });
const perfTwoFrames = () =>
  new Promise<void>((resolve) => {
    requestAnimationFrame(() => {
      requestAnimationFrame(() => resolve());
    });
  });
const perfSleep = (ms: number) =>
  new Promise<void>((resolve) => {
    window.setTimeout(() => resolve(), ms);
  });

function PerfBadge(props: { grade: PerfGrade; word?: string }) {
  return (
    <span className={`perf-badge perf-badge--${props.grade}`}>
      {props.word ?? PERF_GRADE_WORD[props.grade]}
    </span>
  );
}

function PerformanceTest(props: {
  data: State;
  all: DisplayCar[];
  byKey: Map<string, DisplayCar>;
  stateMap: Map<string, CarState>;
  photosByCar: Map<string, State["photos"]>;
  onToast: (msg: string) => void;
}) {
  const { data, all } = props;
  const [running, setRunning] = useState(false);
  const [stageLabel, setStageLabel] = useState("");
  const [error, setError] = useState("");
  const [result, setResult] = useState<PerfResult | null>(() => lastPerfResult);
  const [probe, setProbe] = useState<"cars" | "gallery" | null>(null);
  const probeRef = useRef<HTMLDivElement | null>(null);
  const runIdRef = useRef(0);
  const mountedRef = useRef(true);

  useEffect(() => {
    mountedRef.current = true;
    return () => {
      mountedRef.current = false;
      runIdRef.current += 1;
    };
  }, []);

  // Probe-only photo map: identical pictures, but every photo claims
  // a thumbnail (its own URL), which keeps the Cars list's backfill
  // effect from saving anything while the probe is on screen.
  const probePhotosByCar = useMemo(() => {
    const map = new Map<string, State["photos"]>();
    for (const [key, list] of props.photosByCar) {
      map.set(
        key,
        list.map((p) => (p.thumbUrl || !p.url ? p : { ...p, thumbUrl: p.url })),
      );
    }
    return map;
  }, [props.photosByCar]);

  const waitForProbe = async (kind: "cars" | "gallery", id: number): Promise<HTMLDivElement | null> => {
    for (let i = 0; i < 300; i += 1) {
      if (runIdRef.current !== id) return null;
      const el = probeRef.current;
      if (el && el.dataset.probe === kind) return el;
      await perfRaf();
    }
    return null;
  };

  const runTest = async () => {
    if (running) return;
    const id = runIdRef.current + 1;
    runIdRef.current = id;
    setRunning(true);
    setError("");
    const alive = () => mountedRef.current && runIdRef.current === id;
    try {
      // Pick the search term from the real catalog: a first word of a
      // car name that plenty of cars share, whose real match count
      // (through the same haystack the Cars list searches) lands near
      // a typical result set — so the test searches the way Anthony
      // would, for something that truly matches.
      const haystacks = all.map((c) => carSearchHaystack(c));
      const wordCounts = new Map<string, number>();
      for (const c of all) {
        const w = c.n.toLowerCase().match(/[a-z]{4,}/)?.[0];
        if (w) wordCounts.set(w, (wordCounts.get(w) ?? 0) + 1);
      }
      let searchTerm = "";
      let searchMatches = 0;
      let bestScore = Number.POSITIVE_INFINITY;
      for (const [word, count] of wordCounts) {
        if (count < 15) continue;
        const m = haystacks.reduce((acc, h) => acc + (h.includes(word) ? 1 : 0), 0);
        const score = Math.abs(m - 150);
        if (score < bestScore) {
          bestScore = score;
          searchTerm = word;
          searchMatches = m;
        }
      }
      if (!searchTerm) {
        searchTerm = "hot";
        searchMatches = haystacks.reduce((acc, h) => acc + (h.includes(searchTerm) ? 1 : 0), 0);
      }

      // --- All Cars: render the real list off-screen and time it. ---
      setStageLabel("Opening All Cars…");
      const carsStart = performance.now();
      setProbe("cars");
      const carsEl = await waitForProbe("cars", id);
      if (!alive()) return;
      if (!carsEl) throw new Error("cars probe did not mount");
      await perfTwoFrames();
      if (!alive()) return;
      const carsMs = performance.now() - carsStart;
      const carsShown = carsEl.querySelectorAll(".tp").length;

      // --- Search: type the term into the probe's real search box. ---
      setStageLabel(`Searching for “${searchTerm}”…`);
      const input = carsEl.querySelector<HTMLInputElement>(
        'input[aria-label="Search cars by name or series"]',
      );
      if (!input) throw new Error("cars search box not found");
      const setter = Object.getOwnPropertyDescriptor(
        window.HTMLInputElement.prototype,
        "value",
      )?.set;
      const searchStart = performance.now();
      if (setter) setter.call(input, searchTerm);
      else input.value = searchTerm;
      input.dispatchEvent(new Event("input", { bubbles: true }));
      await perfTwoFrames();
      if (!alive()) return;
      const searchMs = performance.now() - searchStart;

      // --- Photo Gallery: render it off-screen, wait for its photos. ---
      setStageLabel("Loading the Photo Gallery…");
      const galleryStart = performance.now();
      setProbe("gallery");
      const galleryEl = await waitForProbe("gallery", id);
      if (!alive()) return;
      if (!galleryEl) throw new Error("gallery probe did not mount");
      let galleryCapped = false;
      for (;;) {
        if (!alive()) return;
        let pending = 0;
        galleryEl.querySelectorAll("img").forEach((img) => {
          if (!img.complete) pending += 1;
        });
        if (pending === 0) break;
        if (performance.now() - galleryStart >= 8000) {
          galleryCapped = true;
          break;
        }
        await perfSleep(100);
      }
      const galleryMs = performance.now() - galleryStart;
      const galleryImages = galleryEl.querySelectorAll("img").length;
      setProbe(null);
      await perfTwoFrames();
      if (!alive()) return;

      // --- Counts: thumbnails, files, page weight. ---
      setStageLabel("Counting files…");
      const missingThumbs = data.photos.filter((p) => p.url && !p.thumbUrl).length;
      const photosWithUrl = data.photos.filter((p) => p.url).length;
      let resourceCount = 0;
      let largestFileName: string | null = null;
      let largestFileKb: number | null = null;
      let serverMs: number | null = null;
      try {
        const entries = performance.getEntriesByType("resource") as PerformanceResourceTiming[];
        resourceCount = entries.length;
        let bestSize = 0;
        for (const entry of entries) {
          const size = entry.transferSize || entry.decodedBodySize || entry.encodedBodySize || 0;
          if (size > bestSize) {
            bestSize = size;
            largestFileName = perfResourceName(entry.name);
          }
        }
        if (bestSize > 0) largestFileKb = Math.round(bestSize / 1024);
        const nav = performance.getEntriesByType("navigation")[0] as
          | PerformanceNavigationTiming
          | undefined;
        if (nav && nav.responseEnd > 0) serverMs = nav.responseEnd;
      } catch {
        // Resource timing is a nice-to-have; its absence is reported
        // as zero files rather than failing the whole test.
      }
      const heapRaw = (
        performance as unknown as { memory?: { usedJSHeapSize?: number } }
      ).memory?.usedJSHeapSize;

      const coldLoadMs = bootMarks.dataReadyMs;
      const homeSettledMs = bootMarks.homeSettledMs;
      const grades: { name: string; grade: PerfGrade; reason: string }[] = [];
      if (coldLoadMs !== null) {
        grades.push({
          name: "opening the app",
          grade: perfGrade(coldLoadMs, 3000, 5500),
          reason: "your book's data takes a while to arrive",
        });
      }
      grades.push(
        {
          name: "opening All Cars",
          grade: perfGrade(carsMs, 400, 1000),
          reason: `the ${all.length.toLocaleString()}-car catalog takes a moment to lay out`,
        },
        {
          name: "searching",
          grade: perfGrade(searchMs, 150, 400),
          reason: `searching all ${all.length.toLocaleString()} cars takes a moment`,
        },
        {
          name: "the Photo Gallery",
          grade: perfGrade(galleryMs, 1500, 4000),
          reason: "it loads every photo full-size",
        },
      );
      const worst = grades.some((g) => g.grade === "slow")
        ? grades.find((g) => g.grade === "slow")
        : grades.find((g) => g.grade === "ok");
      let dragLine: string;
      if (worst && worst.grade === "slow") {
        dragLine = `Biggest drag: ${worst.name} — ${worst.reason}.`;
      } else if (worst) {
        dragLine = `Nothing is truly slow. The heaviest part is ${worst.name} — ${worst.reason}.`;
      } else {
        dragLine = "Everything measured fast — the app is in good shape.";
      }
      if (missingThumbs > 0) {
        dragLine += ` Also, ${missingThumbs} ${missingThumbs === 1 ? "photo has" : "photos have"} no thumbnail yet, so lists load ${missingThumbs === 1 ? "it" : "those"} full-size — the app makes thumbnails for all of them in the background while you use it, so this fixes itself shortly after opening.`;
      }

      const res: PerfResult = {
        ranAt: new Date().toLocaleTimeString(undefined, {
          hour: "numeric",
          minute: "2-digit",
          second: "2-digit",
        }),
        coldLoadMs,
        homeSettledMs,
        serverMs,
        carsMs,
        carsShown,
        carsTotal: all.length,
        searchTerm,
        searchMatches,
        searchMs,
        galleryMs,
        galleryImages,
        galleryCapped,
        missingThumbs,
        photosWithUrl,
        resourceCount,
        largestFileName,
        largestFileKb,
        pageImages: document.images.length,
        mediaCount: document.querySelectorAll("audio, video").length,
        heapMb:
          typeof heapRaw === "number" && heapRaw > 0
            ? Math.round((heapRaw / (1024 * 1024)) * 10) / 10
            : null,
        dragLine,
      };
      lastPerfResult = res;
      setResult(res);
      props.onToast("Performance test done");
    } catch {
      if (alive()) {
        setError("The test hit a snag before it finished — tap Run to try again.");
      }
    } finally {
      if (alive()) {
        setProbe(null);
        setStageLabel("");
        setRunning(false);
      }
    }
  };

  const PRow = (rowProps: { label: string; value: string; grade?: PerfGrade; badgeWord?: string }) => (
    <div className="diag-row">
      <span className="diag-label">{rowProps.label}</span>
      <span className="diag-value">
        {rowProps.value}
        {rowProps.grade ? <PerfBadge grade={rowProps.grade} word={rowProps.badgeWord} /> : null}
      </span>
    </div>
  );

  const thumbGrade: PerfGrade | undefined =
    result === null || result.photosWithUrl === 0
      ? undefined
      : result.missingThumbs === 0
        ? "fast"
        : result.missingThumbs / result.photosWithUrl <= 0.05
          ? "ok"
          : "slow";
  const thumbWord =
    thumbGrade === "fast" ? "Great" : thumbGrade === "ok" ? "Fine" : "Worth fixing";

  return (
    <section aria-label="Performance test" className="pn">
      <h2 className="hw-h2">Performance Test</h2>
      <p className="mut mt-1">
        Times how fast the app really opens, searches, and loads your photos — measured live on
        this device, only when you tap Run. It changes nothing and saves nothing.
      </p>
      <button
        type="button"
        className="hw-btn mt-3 px-5 py-2.5 text-sm font-bold disabled:opacity-60"
        onClick={() => void runTest()}
        disabled={running}
      >
        {running ? "Testing…" : result ? "Run again" : "Run performance test"}
      </button>
      {running && (
        <p className="mut mt-2" role="status">
          {stageLabel || "Testing…"}
        </p>
      )}
      {error && (
        <p className="mt-2 text-sm font-semibold" role="alert">
          {error}
        </p>
      )}
      {result && !running && (
        <div className="mt-2">
          <PRow label="Last run" value={result.ranAt} />
          <PRow
            label="Cold load — open to your book ready (this open)"
            value={result.coldLoadMs !== null ? fmtPerfMs(result.coldLoadMs) : "Not measured"}
            grade={
              result.coldLoadMs !== null ? perfGrade(result.coldLoadMs, 3000, 5500) : undefined
            }
          />
          <PRow
            label="Home settled, after the intro (this open)"
            value={result.homeSettledMs !== null ? fmtPerfMs(result.homeSettledMs) : "Not measured"}
            grade={
              result.homeSettledMs !== null ? perfGrade(result.homeSettledMs, 750, 2000) : undefined
            }
          />
          {result.serverMs !== null && (
            <PRow label="Server's first answer (this open)" value={fmtPerfMs(result.serverMs)} />
          )}
          <PRow
            label={`All Cars — first screen (${result.carsShown} of ${result.carsTotal.toLocaleString()} cars)`}
            value={fmtPerfMs(result.carsMs)}
            grade={perfGrade(result.carsMs, 400, 1000)}
          />
          <PRow
            label={`Search “${result.searchTerm}” (${result.searchMatches.toLocaleString()} matches)`}
            value={fmtPerfMs(result.searchMs)}
            grade={perfGrade(result.searchMs, 150, 400)}
          />
          <PRow
            label={`Photo Gallery — ${result.galleryImages} photo images`}
            value={`${fmtPerfMs(result.galleryMs)}${result.galleryCapped ? " (hit the 8 s cap)" : ""}`}
            grade={perfGrade(result.galleryMs, 1500, 4000)}
          />
          <PRow
            label="Photos without a thumbnail"
            value={`${result.missingThumbs} of ${result.photosWithUrl}`}
            grade={thumbGrade}
            badgeWord={thumbGrade ? thumbWord : undefined}
          />
          <PRow label="Files loaded this session" value={String(result.resourceCount)} />
          {result.largestFileName && result.largestFileKb !== null && (
            <PRow label="Largest file" value={`${result.largestFileName} · ${result.largestFileKb} KB`} />
          )}
          <PRow label="Pictures on this page right now" value={String(result.pageImages)} />
          <PRow label="Sound / video players on this page" value={String(result.mediaCount)} />
          <PRow
            label="App memory"
            value={result.heapMb !== null ? `${result.heapMb} MB` : "Not reported by this browser"}
          />
          <p className="mt-2 text-sm font-semibold">{result.dragLine}</p>
          <p className="mut mt-1">
            The Home settle clock starts when the intro splash leaves — the time the splash
            spends waiting for Press Start is not counted.
          </p>
        </div>
      )}
      {probe && (
        <div ref={probeRef} data-probe={probe} className="perf-probe" aria-hidden="true">
          {probe === "cars" ? (
            <CarsView
              data={data}
              all={all}
              stateMap={props.stateMap}
              photosByCar={probePhotosByCar}
              filter="all"
              onFilterChange={() => undefined}
              onSelect={() => undefined}
              onToggleOwn={async () => undefined}
              onToggleTh={async () => undefined}
              onToggleFavorite={async () => undefined}
              onToast={() => undefined}
              onRefresh={() => undefined}
            />
          ) : (
            <GalleryView
              data={data}
              byKey={props.byKey}
              onToast={() => undefined}
              onRefresh={() => undefined}
              onOpenCar={() => undefined}
              onConfirm={() => undefined}
            />
          )}
        </div>
      )}
    </section>
  );
}

/* ---------------- Diagnostics ----------------
   Read-only live health page: every number below is drawn straight
   from the loaded Hunt Book state (the same getState data every other
   view renders), so it can never disagree with Home, Cars, Planner,
   Music, or Rewards. The only control is Refresh, which re-reads that
   state; nothing here writes, deletes, or resets anything. */
function DiagnosticsView(props: {
  data: State;
  all: DisplayCar[];
  byKey: Map<string, DisplayCar>;
  stateMap: Map<string, CarState>;
  photosByCar: Map<string, State["photos"]>;
  onRefresh: () => Promise<unknown>;
  onToast: (msg: string) => void;
}) {
  const { data } = props;
  const [lastChecked, setLastChecked] = useState(() => new Date());
  const [refreshing, setRefreshing] = useState(false);

  // Background & Performance rows are a live scan of the page
  // itself (scanBackgroundActivity), re-read whenever this view
  // mounts, whenever the app comes back to the foreground, and on
  // Refresh — so "nothing playing" is measured, not assumed.
  const [bgScan, setBgScan] = useState(() => scanBackgroundActivity());
  useEffect(() => {
    const rescan = () => setBgScan(scanBackgroundActivity());
    rescan();
    document.addEventListener("visibilitychange", rescan);
    return () => document.removeEventListener("visibilitychange", rescan);
  }, []);

  const pts = data.points;
  const toNext = pts.nextLevel ? Math.max(0, pts.nextLevel.at - pts.lifetime) : 0;

  const formatMoney = (raw: string | undefined): string => {
    if (raw === undefined || raw.trim() === "") return "$0";
    // Planner amounts are stored as free-form dollar text and may
    // already carry the "$" (the live November plan stores "$68.57"
    // / "$0"), so strip it before parsing or the label doubles it.
    const cleaned = raw.trim().replace(/^\$/, "").replace(/,/g, "");
    const n = Number(cleaned);
    if (!Number.isFinite(n)) return raw.trim().startsWith("$") ? raw.trim() : `$${raw.trim()}`;
    return n % 1 === 0 && !cleaned.includes(".") ? `$${n}` : `$${n.toFixed(2)}`;
  };

  // Next hunt, derived the same way the server derives
  // stats.nextHunt: the earliest hunt day on or after today
  // (Chicago), so budget / spent / checklist all come from that
  // hunt's own month and day.
  const todayStr = chicagoToday();
  const huntCandidates = data.planDays
    .filter((d) => d.isHunt)
    .map((d) => ({
      month: d.month,
      day: d.day,
      dateStr: `${d.month}-${String(d.day).padStart(2, "0")}`,
      note: d.note,
    }))
    .filter((d) => d.dateStr >= todayStr)
    .sort((a, b) => (a.dateStr < b.dateStr ? -1 : a.dateStr > b.dateStr ? 1 : 0));
  const nextHuntDay = huntCandidates[0] ?? null;
  const nextHuntLabel = nextHuntDay
    ? (() => {
        const [hy = 1970, hm = 1] = nextHuntDay.month.split("-").map(Number);
        return new Date(hy, (hm ?? 1) - 1, nextHuntDay.day).toLocaleDateString(undefined, {
          weekday: "long",
          month: "long",
          day: "numeric",
          year: "numeric",
        });
      })()
    : (data.stats.nextHunt ?? "No upcoming hunt marked");
  const huntPlan = nextHuntDay ? data.monthPlans.find((p) => p.month === nextHuntDay.month) : undefined;
  const huntChecklist = nextHuntDay
    ? data.checklist.filter((c) => c.month === nextHuntDay.month && c.day === nextHuntDay.day)
    : [];
  const huntChecklistDone = huntChecklist.filter((c) => c.checked).length;

  const handleRefresh = async () => {
    if (refreshing) return;
    setRefreshing(true);
    try {
      await props.onRefresh();
      setLastChecked(new Date());
      setBgScan(scanBackgroundActivity());
      props.onToast("Diagnostics refreshed");
    } catch {
      props.onToast("Diagnostics could not refresh — try again.");
    } finally {
      setRefreshing(false);
    }
  };

  const Row = (rowProps: { label: string; value: string }) => (
    <div className="diag-row">
      <span className="diag-label">{rowProps.label}</span>
      <span className="diag-value">{rowProps.value}</span>
    </div>
  );

  return (
    <div>
      <section aria-label="Diagnostics" className="pn pn-premium">
        <span className="show-kicker">★ Ultimate Edition</span>
        <h1 className="hw-h2 mt-3" style={{ fontSize: 20 }}>Diagnostics</h1>
        <p className="mt-1 text-sm text-[var(--dim)]">
          Read-only — live numbers from your saved Hunt Book data.
        </p>
        <div className="mt-2">
          <Row label="App" value="Hot Wheels Hunt Book" />
          <Row label="Edition" value="Ultimate Edition" />
          <Row label="Catalog" value={`${data.stats.total.toLocaleString()} cars`} />
        </div>
      </section>

      <section aria-label="Collection counts" className="pn">
        <h2 className="hw-h2">Collection</h2>
        <Row label="Owned" value={`${data.stats.owned} distinct / ${data.stats.copies} copies`} />
        <Row label="Treasure Hunts" value={String(data.stats.th)} />
        <Row label="Super Treasure Hunt" value={String(data.stats.sth)} />
        <Row label="Custom cars" value={String(data.customCars.length)} />
        <Row label="Photos" value={String(data.stats.photoCount)} />
        <Row label="Favorites" value={String(data.stats.favorites)} />
        <Row label="Hunt targets" value={String(data.targets.length)} />
        <Row label="Needs a photo" value={String(data.stats.unverified)} />
      </section>

      <section aria-label="Streak and points" className="pn">
        <h2 className="hw-h2">Streak &amp; Points</h2>
        <Row label="Streak" value={`Current ${data.streak.current} · Best ${data.streak.best}`} />
        <Row label="Lifetime points" value={pts.lifetime.toLocaleString()} />
        <Row label="Spendable points" value={pts.balance.toLocaleString()} />
        <Row
          label="Level"
          value={`Level ${pts.level} ${pts.levelName}`}
        />
        <Row
          label="Next level"
          value={pts.nextLevel ? `${toNext.toLocaleString()} points to ${pts.nextLevel.name}` : "Top level reached"}
        />
      </section>

      <section aria-label="Next hunt" className="pn">
        <h2 className="hw-h2">Next hunt</h2>
        <Row label="Next hunt" value={nextHuntLabel} />
        {nextHuntDay?.note.trim() ? <Row label="Hunt note" value={nextHuntDay.note.trim()} /> : null}
        {nextHuntDay ? (
          <>
            <Row label="Budget" value={huntPlan && huntPlan.budget.trim() ? formatMoney(huntPlan.budget) : "Not set"} />
            <Row label="Spent" value={formatMoney(huntPlan?.spent)} />
            <Row label="Checklist" value={`${huntChecklistDone} of ${HUNT_CHECKLIST_ITEMS.length}`} />
          </>
        ) : (
          <Row label="Checklist" value="No hunt day marked" />
        )}
      </section>

      <section aria-label="Music and videos" className="pn">
        <h2 className="hw-h2">Music &amp; Videos</h2>
        <Row label="Music tracks" value={String(data.tracks.length)} />
        <Row label="Saved videos" value={String(data.videos.length)} />
      </section>

      <section aria-label="Background and performance" className="pn">
        <h2 className="hw-h2">Background &amp; Performance</h2>
        <Row label="App right now" value={bgScan.hidden ? "In the background" : "On screen — in use"} />
        <Row
          label="Sound / video playing"
          value={bgScan.playing === 0 ? "None ✓" : bgScan.playing === 1 ? "1 playing" : `${bgScan.playing} playing`}
        />
        <Row label="YouTube player" value={bgScan.youtubeOpen ? "Open" : "Closed ✓"} />
        <Row label="Background protection" value="On — sound & video pause when you leave" />
        <Row label="Animations in background" value="Paused" />
        <Row label="App timers in background" value="Paused — no auto-refresh or polling" />
        <p className="mut mt-2">
          Try it: leave the app, come back, and tap Refresh below — sound / video should read “None”.
        </p>
      </section>

      <PerformanceTest
        data={data}
        all={props.all}
        byKey={props.byKey}
        stateMap={props.stateMap}
        photosByCar={props.photosByCar}
        onToast={props.onToast}
      />

      <section aria-label="Storage and data health" className="pn">
        <h2 className="hw-h2">Storage / Data health</h2>
        <Row label="Saved data" value="Loaded OK ✓" />
        <Row label="Catalog loaded" value={`${data.stats.total.toLocaleString()} cars`} />
        <Row
          label="Last checked"
          value={lastChecked.toLocaleTimeString(undefined, { hour: "numeric", minute: "2-digit", second: "2-digit" })}
        />
        <button
          type="button"
          className="hw-btn mt-3 px-5 py-2.5 text-sm font-bold disabled:opacity-60"
          onClick={() => void handleRefresh()}
          disabled={refreshing}
        >
          {refreshing ? "Refreshing…" : "Refresh"}
        </button>
        <p className="mut mt-2">Refresh re-reads your live Hunt Book data and updates the numbers above.</p>
      </section>
    </div>
  );
}

function ProfileView(props: {
  data: State;
  onToast: (msg: string) => void;
  onRefresh: () => void;
  onConfirm: (c: { title: string; body: string; label: string; run: () => Promise<unknown> | void }) => void;
  onToggleTheme: () => void;
}) {
  const { data } = props;
  const [name, setName] = useState(data.profile.name);
  const [bio, setBio] = useState(data.profile.bio);
  const [favorite, setFavorite] = useState(data.profile.favorite);
  const [saved, setSaved] = useState(false);
  const [photoBusy, setPhotoBusy] = useState(false);
  const [exportJson, setExportJson] = useState("");
  const [importText, setImportText] = useState("");
  const [importResult, setImportResult] = useState("");
  const [importError, setImportError] = useState("");
  const [downloadBusy, setDownloadBusy] = useState<"all" | "photos" | "phone" | null>(null);
  const [restoreBusy, setRestoreBusy] = useState(false);
  const [updateBusy, setUpdateBusy] = useState(false);
  const [showVideoDownloads, setShowVideoDownloads] = useState(false);
  const restoreFileRef = useRef<HTMLInputElement>(null);
  const earned = data.badges.filter((b) => b.earned);
  const carNameByKey = new Map<string, string>();
  for (const c of CATALOG) carNameByKey.set(c.k, c.n);
  for (const c of data.customCars) carNameByKey.set(c.carKey, c.name);

  const handleProfilePhoto = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setPhotoBusy(true);
    try {
      const { dataBase64, mimeType } = await fileToBase64(file);
      await api.setProfilePhoto({ dataBase64, mimeType });
      props.onToast("Profile photo updated");
      props.onRefresh();
    } catch {
      props.onToast("That photo could not be added. Try a smaller image.");
    } finally {
      setPhotoBusy(false);
      e.target.value = "";
    }
  };

  const handleImportFile = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const text = await file.text();
    setImportText(text);
    setImportError("");
    e.target.value = "";
  };

  // Shared restore path for the pasted text and for a chosen backup
  // file: the server action merges by car key and never deletes
  // existing rows, so restoring can only add to what is here.
  const doImportFromText = async (text: string): Promise<boolean> => {
    if (!text.trim()) {
      setImportError("Paste a backup first, or choose a backup file.");
      return false;
    }
    setImportError("");
    setImportResult("");
    let res;
    try {
      res = await api.importBackup({ json: text.trim() });
    } catch {
      setImportError("That backup could not be restored. Try again.");
      return false;
    }
    if (!res.ok) {
      setImportError(res.error ?? "That backup could not be restored.");
      return false;
    }
    setImportResult(
      `Restored: ${res.owned} owned, ${res.th} Treasure Hunts, ${res.custom} custom cars, ${res.targets} targets, ${res.planMonths} planner months, ${res.photos} photos${res.skippedPhotos > 0 ? ` (${res.skippedPhotos} photos skipped — too large or not in the backup)` : ""}, ${res.visits} visit days.`,
    );
    props.onToast("Backup restored");
    props.onRefresh();
    return true;
  };

  const doImport = async () => {
    if (await doImportFromText(importText)) setImportText("");
  };

  // "Update to current build" (Settings): Anthony asked for a way
  // to pull the current build onto his phone himself — a running
  // page does not swap its bundle when a new build publishes, and
  // his web view has been caught still showing a pre-fix page
  // minutes after a fix landed (the "I still see it" DLC row,
  // 2026-11-12). The button reloads THIS page as cache-free as the
  // web view allows: it stashes this build's stamp for the
  // post-reload confirmation in App, clears the Cache Storage and
  // any service-worker registrations (best effort — this app ships
  // neither, but a shell-level cache is out of the page's sight),
  // then replaces the page with the same address plus a one-off
  // query marker the gateway has never served this page under, so
  // the fresh HTML and bundle are fetched instead of replayed from
  // an HTTP cache. His data is untouched: the collection, photos,
  // music, and settings all live server-side, and localStorage
  // (theme, splash marks) is deliberately left alone — only the
  // page itself is reloaded.
  const updateBuild = async () => {
    setUpdateBusy(true);
    try {
      window.sessionStorage.setItem("hw-update-check", SPLASH_BUILD_STAMP);
    } catch {
      // Storage blocked: the reload still happens; only the
      // confirmation toast is lost.
    }
    try {
      if ("caches" in window) {
        const keys = await caches.keys();
        await Promise.all(keys.map((k) => caches.delete(k)));
      }
    } catch {
      // Best effort only — the cache-busting reload below is the
      // load-bearing step.
    }
    try {
      if ("serviceWorker" in navigator) {
        const regs = await navigator.serviceWorker.getRegistrations();
        await Promise.all(regs.map((r) => r.unregister()));
      }
    } catch {
      // Same best-effort note as above.
    }
    try {
      const url = new URL(window.location.href);
      url.searchParams.set("hw_update", String(Date.now()));
      window.location.replace(url.toString());
    } catch {
      window.location.reload();
    }
  };

  // "Restore from a backup file": the chosen file is restored right
  // away (the paste box below keeps the older load-then-restore flow
  // for text backups). Errors also land in importError, so opening
  // the Copy / paste section shows the detail after the toast.
  const handleRestoreFile = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    setRestoreBusy(true);
    try {
      const ok = await doImportFromText(await file.text());
      if (!ok) props.onToast("That backup could not be restored.");
    } catch {
      setImportError("That backup file could not be read.");
      props.onToast("That backup file could not be read.");
    } finally {
      setRestoreBusy(false);
    }
  };

  // Download everything: the server's progress JSON, plus every photo
  // fetched from its stored URL and embedded as a data URI under
  // `imgs` (the shape importBackup reads), in position order per car.
  // Photos that cannot be read are skipped and counted in the toast
  // instead of failing the whole download; the progress JSON alone
  // is still a valid, restorable backup.
  const downloadEverything = async () => {
    if (downloadBusy) return;
    setDownloadBusy("all");
    try {
      const res = await api.exportBackup({});
      let parsed: Record<string, unknown>;
      try {
        parsed = JSON.parse(res.json) as Record<string, unknown>;
      } catch {
        props.onToast("Full backup download failed — try again.");
        return;
      }
      const imgs: Record<string, string[]> = {};
      let included = 0;
      let skipped = 0;
      const orderedPhotos = [...data.photos].sort((a, b) => a.position - b.position || a.id - b.id);
      for (const photo of orderedPhotos) {
        if (!photo.url || !photo.carKey) {
          skipped += 1;
          continue;
        }
        try {
          const resp = await fetch(photo.url);
          if (!resp.ok) throw new Error("Photo could not be read");
          const bytes = new Uint8Array(await resp.arrayBuffer());
          const list = imgs[photo.carKey] ?? [];
          list.push(`data:${photo.contentType};base64,${bytesToBase64(bytes)}`);
          imgs[photo.carKey] = list;
          included += 1;
        } catch {
          skipped += 1;
        }
      }
      parsed.imgs = imgs;
      downloadFile(
        new Blob([JSON.stringify(parsed)], { type: "application/json" }),
        `hunt-book-backup-${backupFileStamp()}.json`,
      );
      props.onToast(
        skipped === 0
          ? "Full backup downloaded"
          : `Full backup downloaded — ${included} of ${orderedPhotos.length} photos included`,
      );
    } catch {
      props.onToast("Full backup download failed — try again.");
    } finally {
      setDownloadBusy(null);
    }
  };

  // Download progress: one spreadsheet row per catalog car plus each
  // car Anthony added, with the live owned / TH / STH state, count,
  // note, and series labels. No server call is needed — everything
  // is already in the loaded state.
  const downloadProgressCsv = () => {
    if (downloadBusy) return;
    const stateByKey = new Map(data.carStates.map((s) => [s.carKey, s]));
    const rows = [
      ...CATALOG.map((c) => ({ n: c.n, k: c.k, t: c.t, x: c.x, custom: false })),
      ...data.customCars.map((c) => ({ n: c.name, k: c.carKey, t: c.tags, x: c.details, custom: true })),
    ].sort(compareCars);
    const lines = ["Name,Details,Series / game,Owned,Treasure Hunt,Super Treasure Hunt,Count,Note,Added by you"];
    for (const car of rows) {
      const st = stateByKey.get(car.k);
      lines.push(
        [
          car.n,
          car.x ?? "",
          seriesLabels(car.t),
          st?.owned ? "Yes" : "No",
          st?.isTh ? "Yes" : "No",
          st?.isSth ? "Yes" : "No",
          st?.count ?? 0,
          st?.note ?? "",
          car.custom ? "Yes" : "No",
        ]
          .map(csvField)
          .join(","),
      );
    }
    downloadFile(
      new Blob([lines.join("\r\n")], { type: "text/csv" }),
      `hunt-book-progress-${backupFileStamp()}.csv`,
    );
    props.onToast("Progress spreadsheet downloaded");
  };

  // Download photos: every stored photo fetched from its URL and
  // packed into one zip, named per car in position order. Photos
  // that cannot be read are skipped and counted in the toast.
  const downloadPhotosZip = async () => {
    if (downloadBusy) return;
    if (data.photos.length === 0) {
      props.onToast("No photos to download yet.");
      return;
    }
    setDownloadBusy("photos");
    try {
      const ordered = [...data.photos].sort(
        (a, b) => (a.carKey ?? "").localeCompare(b.carKey ?? "") || a.position - b.position || a.id - b.id,
      );
      const files: { name: string; data: Uint8Array }[] = [];
      const perCarCount = new Map<string, number>();
      const usedNames = new Set<string>();
      let skipped = 0;
      for (const photo of ordered) {
        if (!photo.url) {
          skipped += 1;
          continue;
        }
        try {
          const resp = await fetch(photo.url);
          if (!resp.ok) throw new Error("Photo could not be read");
          const bytes = new Uint8Array(await resp.arrayBuffer());
          const carKey = photo.carKey ?? "gallery";
          const next = (perCarCount.get(carKey) ?? 0) + 1;
          perCarCount.set(carKey, next);
          const stem = zipSafeStem(carNameByKey.get(carKey) ?? "gallery-photo", "photo");
          const ext = extensionFor(photo.contentType, "jpg");
          let name = `${stem}-${next}.${ext}`;
          let suffix = 2;
          while (usedNames.has(name)) {
            name = `${stem}-${next}-${suffix}.${ext}`;
            suffix += 1;
          }
          usedNames.add(name);
          files.push({ name, data: bytes });
        } catch {
          skipped += 1;
        }
      }
      if (files.length === 0) {
        props.onToast("Photos could not be downloaded — try again.");
        return;
      }
      downloadFile(buildZipBlob(files), `hunt-book-photos-${backupFileStamp()}.zip`);
      props.onToast(
        skipped === 0
          ? `All ${files.length} photos downloaded`
          : `${files.length} photos downloaded (${skipped} could not be read)`,
      );
    } catch {
      props.onToast("Photos download failed — try again.");
    } finally {
      setDownloadBusy(null);
    }
  };

  // Download videos: one file at a time, as the button says — tapping
  // it opens the per-video download list below the grid instead of
  // packing videos into a file. With no videos there is nothing to list.
  const toggleVideoDownloads = () => {
    if (data.videos.length === 0) {
      props.onToast("No videos saved yet.");
      return;
    }
    setShowVideoDownloads((v) => !v);
  };

  // Download phone copy: the bundled self-contained phone HTML file
  // (the overhauled phone version of the Hunt Book). The bundled asset
  // is served as a bare .htm page, and saving it by pointing an anchor
  // straight at that URL silently does nothing in the app's web view
  // (no file ever reaches the phone). Instead fetch the exact same
  // bytes and save them through downloadFile — the same Blob path the
  // backup / spreadsheet / photos downloads above use — under the
  // phone filename. The toast only claims success once the file has
  // been read and handed over; a failed read says so.
  const downloadPhoneCopy = async () => {
    if (downloadBusy) return;
    setDownloadBusy("phone");
    try {
      const resp = await fetch(phoneCopyUrl);
      if (!resp.ok) throw new Error("Phone copy could not be read");
      const bytes = await resp.arrayBuffer();
      if (bytes.byteLength === 0) throw new Error("Phone copy was empty");
      downloadFile(
        new Blob([bytes], { type: "text/html" }),
        "hot-wheels-hunt-book-phone.html",
      );
      props.onToast("Phone copy downloaded");
    } catch {
      props.onToast("Phone copy download failed — try again.");
    } finally {
      setDownloadBusy(null);
    }
  };

  const pct = data.stats.total > 0 ? Math.round((data.stats.owned / data.stats.total) * 100) : 0;
  return (
    <div>
      <section aria-label="Profile" className="pn" style={{ textAlign: "center" }}>
        <div className="flex flex-col items-center gap-2">
          <div
            className={`flex h-24 w-24 shrink-0 items-center justify-center overflow-hidden rounded-full border-[3px] bg-[#16224d] text-2xl font-bold text-white ${data.points.equippedFrameClass ?? ""}`}
            style={data.points.equippedFrameClass ? undefined : { borderColor: "#ff7a00" }}
          >
            {data.profile.photoUrl ? (
              <img src={data.profile.photoUrl} alt="Collector profile" className="h-full w-full object-cover" />
            ) : (
              <span aria-hidden="true">{(data.profile.name.trim()[0] ?? "C").toUpperCase()}</span>
            )}
          </div>
          <div>
            <h2 className="text-2xl font-bold leading-tight" style={{ margin: "8px 0 0" }}>{data.profile.name.trim() || "Collector"}</h2>
            <p className="reward-title-line">{data.points.levelIcon} {data.points.equippedTitle}</p>
            <p className="mut">{data.profile.bio.trim() || "Hot Wheels collector"}</p>
            <p className="mut text-sm">
              Level {data.points.level} · {data.points.lifetime} lifetime points · ⭐ {data.points.balance} to spend
            </p>
            {data.profile.favorite.trim() && (
              <p className="mt-0.5 text-sm">Favorite: <b>{data.profile.favorite}</b></p>
            )}
          </div>
        </div>
        <div className="stats mt-3">
          <span>{data.stats.owned} owned</span>
          <span>{data.stats.th} TH</span>
          <span>{pct}%</span>
        </div>
        <div className="bar">
          <i style={{ width: `${pct}%` }} />
        </div>
        <div className="mt-2 flex flex-wrap justify-center gap-2 text-sm font-semibold">
          <span className="rounded-full bg-[var(--surface-2)] px-3 py-1.5">{data.stats.sth} STH</span>
          <span className="rounded-full bg-[var(--surface-2)] px-3 py-1.5">{earned.length}/{data.badges.length} badges</span>
          <span className="rounded-full bg-[var(--surface-2)] px-3 py-1.5">Best streak {data.streak.best} days</span>
        </div>
        <label className="chip mt-4 inline-block cursor-pointer">
          {photoBusy ? "Adding…" : "Change profile photo"}
          <input type="file" accept="image/*" className="hidden" onChange={handleProfilePhoto} disabled={photoBusy} />
        </label>
      </section>

      <section aria-label="Edit profile" className="pn">
        <h2 className="hw-h2">Edit profile</h2>
        <form
          className="mt-2 space-y-3"
          onSubmit={async (e: FormEvent) => {
            e.preventDefault();
            await api.setProfile({ name: name.trim(), bio: bio.trim(), favorite: favorite.trim() });
            setSaved(true);
            props.onToast("Profile saved");
            props.onRefresh();
          }}
        >
          <label className="block">
            <span className="text-sm font-bold">Name</span>
            <input value={name} onChange={(e) => { setName(e.target.value); setSaved(false); }} placeholder="Your collector name" className="mt-1 w-full rounded-xl border border-[var(--border)] bg-[var(--surface-2)] px-3 py-2.5 outline-none focus:border-[var(--accent)]" />
          </label>
          <label className="block">
            <span className="text-sm font-bold">Bio</span>
            <input value={bio} onChange={(e) => { setBio(e.target.value); setSaved(false); }} placeholder="Hot Wheels collector" className="mt-1 w-full rounded-xl border border-[var(--border)] bg-[var(--surface-2)] px-3 py-2.5 outline-none focus:border-[var(--accent)]" />
          </label>
          <label className="block">
            <span className="text-sm font-bold">Favorite car</span>
            <input value={favorite} onChange={(e) => { setFavorite(e.target.value); setSaved(false); }} placeholder="e.g. Twin Mill" className="mt-1 w-full rounded-xl border border-[var(--border)] bg-[var(--surface-2)] px-3 py-2.5 outline-none focus:border-[var(--accent)]" />
          </label>
          <button type="submit" className="hw-btn px-5 py-2.5 text-sm font-bold">
            {saved ? "Saved ✓" : "Save profile"}
          </button>
        </form>
      </section>

      <section aria-label="Badges" className="pn">
        <h2 className="hw-h2">Badges · {earned.length}/{data.badges.length}</h2>
        <ul className="mt-2 space-y-2">
          {data.badges.map((b) => (
            <li key={b.id} className={`flex items-center gap-3 rounded-xl p-2 ${b.earned ? "bg-[var(--surface-2)]" : ""}`}>
              <span className="text-2xl" aria-hidden="true">{b.icon}</span>
              <div className="min-w-0 flex-1">
                <p className="text-sm font-semibold">{b.name} {b.earned && <span className="text-[var(--green)]">· earned</span>}</p>
                <p className="text-xs text-[var(--dim)]">{b.desc}</p>
                <div className="bar">
                  <i style={{ width: `${Math.min(100, (b.progress / b.goal) * 100)}%` }} />
                </div>
              </div>
              <span className="shrink-0 text-xs font-bold text-[var(--dim)]">{Math.min(b.progress, b.goal)}/{b.goal}</span>
            </li>
          ))}
        </ul>
      </section>

      <section aria-label="Backup and download" className="pn">
        <h2 className="hw-h2">Backup &amp; Download</h2>
        <p className="mt-1 text-sm text-[var(--dim)]">
          Download your data to keep it safe or move it to another phone. Right now you have <b>{data.stats.owned}</b> owned cars,{" "}
          <b>{data.stats.photoCount}</b> photos and <b>{data.customCars.length}</b> cars you added.
        </p>
        <div className="backup-grid">
          <button type="button" className="hw-btn backup-btn" disabled={downloadBusy !== null} onClick={downloadEverything}>
            <span className="backup-btn-title">⬇️ Download everything</span>
            <span className="backup-btn-sub">{downloadBusy === "all" ? "Preparing…" : "Progress + photos (.json)"}</span>
          </button>
          <button type="button" className="hw-btn hw-btn-alt backup-btn" disabled={downloadBusy !== null} onClick={downloadProgressCsv}>
            <span className="backup-btn-title">📊 Download progress</span>
            <span className="backup-btn-sub">Spreadsheet (.csv)</span>
          </button>
          <button type="button" className="hw-btn hw-btn-alt backup-btn" disabled={downloadBusy !== null} onClick={downloadPhotosZip}>
            <span className="backup-btn-title">🖼️ Download photos</span>
            <span className="backup-btn-sub">{downloadBusy === "photos" ? "Preparing…" : "All photos (.zip)"}</span>
          </button>
          <button
            type="button"
            className="hw-btn hw-btn-alt backup-btn"
            aria-expanded={showVideoDownloads}
            onClick={toggleVideoDownloads}
          >
            <span className="backup-btn-title">🎬 Download videos</span>
            <span className="backup-btn-sub">One file at a time</span>
          </button>
          <button type="button" className="hw-btn hw-btn-alt backup-btn backup-btn-wide" disabled={downloadBusy !== null} onClick={downloadPhoneCopy}>
            <span className="backup-btn-title">📱 Download phone copy</span>
            <span className="backup-btn-sub">{downloadBusy === "phone" ? "Preparing…" : "Phone HTML file (.html)"}</span>
          </button>
        </div>
        <p className="mt-2 text-sm text-[var(--dim)]">
          Saves to your phone and works offline. Changes you make in this phone copy do not sync back to the Muse app — message
          Muse or send a backup to sync them.
        </p>
        {showVideoDownloads && data.videos.length > 0 && (
          <ul className="backup-video-list">
            {data.videos.map((v) => (
              <li key={v.id} className="backup-video-row">
                <span className="backup-video-name">
                  {v.name || "Video"}
                  {v.carKey && carNameByKey.get(v.carKey) && <small>{carNameByKey.get(v.carKey)}</small>}
                </span>
                {v.url ? (
                  <a
                    className="backup-video-link"
                    href={v.url}
                    download={`${zipSafeStem(v.name || "video", "video")}.${extensionFor(v.contentType, "mp4")}`}
                  >
                    Download
                  </a>
                ) : (
                  <span className="mut">Unavailable</span>
                )}
              </li>
            ))}
          </ul>
        )}
        <p className="backup-last">Last full backup: 11/3/2026</p>

        <h3 className="hw-h3">Restore</h3>
        <button
          type="button"
          className="hw-btn hw-btn-alt backup-restore-btn"
          disabled={restoreBusy}
          onClick={() => restoreFileRef.current?.click()}
        >
          📁 {restoreBusy ? "Restoring…" : "Restore from a backup file"}
        </button>
        <input
          ref={restoreFileRef}
          type="file"
          accept=".json,.txt,application/json,text/plain"
          className="hidden"
          onChange={handleRestoreFile}
          aria-label="Choose a backup file to restore"
        />
        <p className="mt-2 text-sm text-[var(--dim)]">
          Restoring replaces what&apos;s on this device with the backup. Videos are downloaded separately and aren&apos;t part of the backup file.
          In this app, restoring adds the backup&apos;s cars, photos, targets, and planner entries to what&apos;s already here and never deletes anything.
        </p>
      </section>

      <details className="pn backup-details">
        <summary>Copy / paste backup (text)</summary>
        <div className="mt-3">
          <p className="text-sm text-[var(--dim)]">
            Your collection is saved here, on Muse&apos;s side, so it stays in sync between you and Muse. Copy a backup to keep a copy
            elsewhere, or restore one from the original Hunt Book app.
          </p>

          <h3 className="hw-h3">Copy a backup</h3>
          <button
            type="button"
            className="hw-btn hw-btn-alt mt-1.5 px-4 py-2 text-sm font-bold"
            onClick={async () => {
              const res = await api.exportBackup({});
              setExportJson(res.json);
            }}
          >
            Show backup
          </button>
          {exportJson && (
            <div className="mt-2">
              <label>
                <span className="sr-only">Backup JSON</span>
                <textarea readOnly value={exportJson} rows={6} className="w-full rounded-xl border border-[var(--border)] bg-[var(--surface-2)] px-3 py-2 font-mono text-xs" />
              </label>
              <button
                type="button"
                className="mt-2 rounded-full border border-[var(--border)] px-4 py-2 text-sm font-semibold"
                onClick={async () => {
                  try {
                    await navigator.clipboard.writeText(exportJson);
                    props.onToast("Backup copied");
                  } catch {
                    props.onToast("Copy failed — select the text and copy it manually.");
                  }
                }}
              >
                Copy backup
              </button>
            </div>
          )}

          <h3 className="hw-h3">Restore a backup</h3>
          <label>
            <span className="sr-only">Paste a backup</span>
            <textarea
              value={importText}
              onChange={(e) => { setImportText(e.target.value); setImportError(""); }}
              rows={4}
              placeholder="Paste a backup here to restore it"
              className="mt-1.5 w-full rounded-xl border border-[var(--border)] bg-[var(--surface-2)] px-3 py-2 text-sm outline-none focus:border-[var(--accent)]"
            />
          </label>
          <div className="mt-2 flex flex-wrap gap-2">
            <button type="button" className="hw-btn px-4 py-2 text-sm font-bold" onClick={doImport}>
              Restore backup
            </button>
            <label className="cursor-pointer rounded-full border border-[var(--border)] px-4 py-2 text-sm font-semibold">
              Choose a backup file
              <input type="file" accept=".json,.txt,application/json,text/plain" className="hidden" onChange={handleImportFile} />
            </label>
          </div>
          {importError && <p role="alert" className="mt-2 text-sm font-semibold text-[var(--accent)]">{importError}</p>}
          {importResult && <p role="status" className="mt-2 text-sm font-semibold text-[var(--green)]">{importResult}</p>}
        </div>
      </details>

      <section aria-label="Settings" className="pn">
        <h2 className="hw-h2">Settings</h2>
        <div className="settings-grid">
          <button type="button" className="hw-btn hw-btn-alt px-4 py-3 text-sm font-bold" onClick={props.onToggleTheme}>
            Light / dark
          </button>
          <button
            type="button"
            className="hw-btn hw-btn-alt px-4 py-3 text-sm font-bold"
            onClick={() =>
              props.onConfirm({
                title: "Reset everything?",
                body: "This erases all owned marks, notes, photos, videos, targets, hunt days, and your profile from this Hunt Book. The catalog stays. This cannot be undone — copy a backup first if you want to keep a copy.",
                label: "Reset everything",
                run: async () => {
                  await api.resetAll({});
                  props.onToast("Hunt Book reset");
                  props.onRefresh();
                },
              })
            }
          >
            Reset everything
          </button>
        </div>
        <div className="build-update">
          <p className="text-sm text-[var(--dim)]">
            This phone is running <b className="text-[var(--text)]">{buildLabel(SPLASH_BUILD_STAMP)}</b>.
          </p>
          <button
            type="button"
            className="hw-btn build-update-btn"
            disabled={updateBusy}
            onClick={() => void updateBuild()}
          >
            {updateBusy ? "Updating…" : "⬆️ Update to current build"}
          </button>
          <p className="mt-2 text-sm text-[var(--dim)]">
            Reloads the app fresh so this phone picks up the newest build Muse published. Your collection, photos,
            music, and settings are saved on Muse&apos;s side — updating never touches them.
          </p>
        </div>
      </section>

      <section aria-label="About" className="pn">
        <h2 className="hw-h2">About</h2>
        <p className="mt-1 text-sm text-[var(--dim)]">
          OWN means you have the regular version. TH means you have the Treasure Hunt or Super Treasure Hunt version. Marking a car OWN or TH
          in the app asks for a photo of that casting first, so the photo verifies it; cars marked without a photo show as UNVERIFIED until a
          photo of the car is added. Tags: U1 / U2 are
          Unleashed 1 / 2, DLC is downloadable content — each game's DLC cars also sit in their own DLC list under that game in the
          sidebar — FC is a fantasy casting, RUSH is Hot Wheels Infinite Rush, and the year tags are
          mainline years. The checklist holds {CATALOG.length} catalog cars, plus any you add yourself.
        </p>
        <p className="mt-1 text-sm text-[var(--dim)]">
          The three game DLC lists hold the full researched rosters — Unleashed 1: 90 cars, Unleashed 2: 69 cars, Infinite Rush: 27
          named cars plus announced packs — filled in from the Hot Wheels Wiki's DLC tables and checked against the official
          PlayStation, Xbox, Steam, and Milestone listings. Infinite Rush entries marked “names TBA” are announced packs whose
          individual car names are not published yet — the F1 Car Collection Pack (22 cars, March 2027) and eight Vehicle Pass packs
          (32 cars) — so each sits in the list as one pack entry until its car names land. The 24 Unleashed 1 Racing Season cars in
          its DLC list were free, timed rewards and are no longer obtainable.
        </p>
      </section>
    </div>
  );
}
