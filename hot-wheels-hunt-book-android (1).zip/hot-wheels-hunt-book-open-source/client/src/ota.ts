// In-app updates from your own GitHub repo (Android app only).
//
// How it works
//   1. The "Build Android APK" workflow publishes a GitHub Release for
//      every build. The release has two files: app-debug.apk and
//      bundle.json (the app's web files, base64 inside one JSON file).
//   2. Settings -> "Update from GitHub" asks GitHub for the latest
//      release, compares its build number with the one this phone runs,
//      and (if newer) downloads bundle.json straight to the phone and
//      unpacks it into the app's private storage (hw-ota/<build>/).
//   3. On the next start the app points its web view at that folder
//      instead of the files packed inside the APK. Your data lives in
//      the same web storage as before, so nothing is touched.
//   4. Safety net: the new build must prove it started (its screen drew
//      for a few seconds). If it did not, the next start drops back to
//      the build packed in the APK and never retries that build.
//
// Changes to the native shell (new permissions or plugins) cannot be
// delivered this way; for those the release's APK is installed instead
// (it updates over the old app and keeps your data, because every build
// is signed with the same key).

import { Capacitor, CapacitorHttp, registerPlugin } from "@capacitor/core";
import { Directory, Filesystem } from "@capacitor/filesystem";
import { SHELL_VERSION, SPLASH_BUILD_STAMP } from "./build-stamp";

const K_SETTINGS = "hw-gh-settings";
const K_OTA = "hw-ota"; // { stamp, dir } the build to run
const K_OK = "hw-ota-ok"; // stamp that was confirmed running
const K_TRY = "hw-ota-try"; // stamp last switched to
const K_BAD = "hw-ota-bad"; // stamp that failed to start
const OTA_ROOT = "hw-ota";

interface WebViewPlugin {
  setServerBasePath(options: { path: string }): Promise<void>;
}
const WebView = registerPlugin<WebViewPlugin>("WebView");

export interface GithubSettings {
  /** "owner/repo", e.g. "anthony/hunt-book". */
  repo: string;
  /** Optional personal access token (only needed for a private repo). */
  token: string;
}

export interface UpdateInfo {
  tag: string;
  label: string;
  newer: boolean;
  /** True when the bundle can be loaded in-app (same native shell). */
  inApp: boolean;
  bundle?: { id: number; name: string; url: string };
  apk?: { id: number; name: string; url: string };
  pageUrl: string;
}

export function isNative(): boolean {
  return Capacitor.isNativePlatform();
}

export function versionOf(stamp: string): number {
  const m = /^v(\d+)/.exec(stamp);
  return m ? Number(m[1]) : 0;
}

export function loadGithubSettings(): GithubSettings {
  try {
    const raw = JSON.parse(localStorage.getItem(K_SETTINGS) ?? "{}") as Partial<GithubSettings>;
    return { repo: String(raw.repo ?? ""), token: String(raw.token ?? "") };
  } catch {
    return { repo: "", token: "" };
  }
}

export function saveGithubSettings(s: GithubSettings): void {
  localStorage.setItem(K_SETTINGS, JSON.stringify({ repo: s.repo.trim(), token: s.token.trim() }));
}

function cleanRepo(repo: string): string {
  const m = /(?:github\.com\/)?([\w.-]+\/[\w.-]+?)(?:\.git)?\/?$/.exec(repo.trim());
  if (!m || !m[1]) throw new Error('Enter the repo as "owner/name", for example myname/hunt-book.');
  return m[1];
}

function apiHeaders(token: string, accept = "application/vnd.github+json"): Record<string, string> {
  const h: Record<string, string> = { Accept: accept, "User-Agent": "HuntBookApp" };
  if (token) h.Authorization = `Bearer ${token}`;
  return h;
}

interface GhAsset {
  id: number;
  name: string;
  url: string;
  browser_download_url: string;
}

/** Asks GitHub for the repo's latest release and compares it with this build. */
export async function checkForUpdate(settings: GithubSettings): Promise<UpdateInfo> {
  const repo = cleanRepo(settings.repo);
  const res = await CapacitorHttp.get({
    url: `https://api.github.com/repos/${repo}/releases/latest`,
    headers: apiHeaders(settings.token.trim()),
    connectTimeout: 15000,
    readTimeout: 30000,
    responseType: "json",
  });
  if (res.status === 404) {
    throw new Error(
      settings.token.trim()
        ? "No release found. Check the repo name, that the token can read it, and that the workflow has run once."
        : "No release found. If the repo is private, add a token below. Also check that the workflow has run once.",
    );
  }
  if (res.status === 401) throw new Error("GitHub rejected the token. Check it and try again.");
  if (res.status === 403) throw new Error("GitHub refused the request (rate limit or token permissions). Try again later.");
  if (res.status !== 200 || typeof res.data !== "object" || res.data === null) {
    throw new Error(`GitHub answered with status ${res.status}.`);
  }
  const rel = res.data as { tag_name?: string; body?: string; html_url?: string; assets?: GhAsset[] };
  const tag = String(rel.tag_name ?? "");
  if (!versionOf(tag)) throw new Error("The latest release is not named like a build (v52-...).");
  const assets = rel.assets ?? [];
  const pick = (test: (n: string) => boolean): UpdateInfo["bundle"] => {
    const a = assets.find((x) => test(x.name));
    if (!a) return undefined;
    return {
      id: a.id,
      name: a.name,
      // A private repo needs the API address plus an octet-stream Accept header.
      url: settings.token.trim() ? a.url : a.browser_download_url,
    };
  };
  const shellMatch = /shell=(\d+)/.exec(rel.body ?? "");
  const shell = shellMatch ? Number(shellMatch[1]) : SHELL_VERSION;
  const bundle = pick((n) => n === "bundle.json");
  const apk = pick((n) => n.toLowerCase().endsWith(".apk"));
  return {
    tag,
    label: tag.replace(/^v(\d+)-(\d{4})-(\d{2})-(\d{2}).*$/, "Build v$1 \u00b7 $2-$3-$4"),
    newer: versionOf(tag) > versionOf(SPLASH_BUILD_STAMP),
    inApp: Boolean(bundle) && shell === SHELL_VERSION,
    bundle,
    apk,
    pageUrl: rel.html_url ?? `https://github.com/${repo}/releases/latest`,
  };
}

function stripFileScheme(uri: string): string {
  return uri.replace(/^file:\/\//, "");
}

/** Downloads and unpacks the release's bundle. Reload afterwards to switch. */
export async function installUpdate(info: UpdateInfo, settings: GithubSettings, onStatus: (msg: string) => void): Promise<void> {
  if (!info.bundle) throw new Error("This release has no bundle.json file.");
  const stamp = info.tag;
  const tmpPath = `${OTA_ROOT}-download/bundle.json`;

  onStatus("Downloading the new build…");
  const headers = apiHeaders(settings.token.trim(), settings.token.trim() ? "application/octet-stream" : "*/*");
  await Filesystem.downloadFile({ url: info.bundle.url, path: tmpPath, directory: Directory.Data, recursive: true, headers });
  const tmpUri = (await Filesystem.getUri({ path: tmpPath, directory: Directory.Data })).uri;

  onStatus("Reading it…");
  // Read through the web view's own file server so a multi-megabyte file
  // never has to cross the plugin bridge.
  const resp = await fetch(Capacitor.convertFileSrc(tmpUri));
  if (!resp.ok) throw new Error("Could not read the downloaded file.");
  const bundle = (await resp.json()) as { stamp?: string; files?: { path: string; b64: string }[] };
  if (bundle.stamp !== stamp || !Array.isArray(bundle.files) || !bundle.files.some((f) => f.path === "index.html")) {
    throw new Error("The downloaded build looks incomplete, so it was not installed.");
  }

  const base = `${OTA_ROOT}/${stamp}`;
  try {
    await Filesystem.rmdir({ path: base, directory: Directory.Data, recursive: true });
  } catch {
    // nothing there yet
  }
  let n = 0;
  for (const f of bundle.files) {
    if (f.path.includes("..") || f.path.startsWith("/")) throw new Error("Unexpected file name in the build.");
    n += 1;
    onStatus(`Unpacking ${n} / ${bundle.files.length}…`);
    await Filesystem.writeFile({ path: `${base}/${f.path}`, data: f.b64, directory: Directory.Data, recursive: true });
  }
  try {
    await Filesystem.rmdir({ path: `${OTA_ROOT}-download`, directory: Directory.Data, recursive: true });
  } catch {
    // leftover temp file is harmless
  }

  const dirUri = (await Filesystem.getUri({ path: base, directory: Directory.Data })).uri;
  localStorage.setItem(K_OTA, JSON.stringify({ stamp, dir: stripFileScheme(dirUri) }));
  localStorage.removeItem(K_BAD);
}

/**
 * Runs first thing at start-up. Returns true when it handed the web view
 * to a newer downloaded build (the page is reloading; the caller must not
 * start the app). Returns false to carry on with this build.
 */
export async function bootOta(): Promise<boolean> {
  if (!isNative()) return false;
  try {
    const raw = localStorage.getItem(K_OTA);
    if (!raw) return false;
    const want = JSON.parse(raw) as { stamp?: string; dir?: string };
    if (!want.stamp || !want.dir) {
      localStorage.removeItem(K_OTA);
      return false;
    }
    const mine = SPLASH_BUILD_STAMP;
    if (want.stamp === mine) return false; // already running it
    if (versionOf(want.stamp) < versionOf(mine)) {
      // A newer APK was installed since; the old download is stale.
      localStorage.removeItem(K_OTA);
      return false;
    }
    if (localStorage.getItem(K_BAD) === want.stamp) return false;
    if (localStorage.getItem(K_TRY) === want.stamp && localStorage.getItem(K_OK) !== want.stamp) {
      // Last time we switched to it, it never confirmed it was running.
      localStorage.setItem(K_BAD, want.stamp);
      localStorage.removeItem(K_OTA);
      return false;
    }
    localStorage.setItem(K_TRY, want.stamp);
    await WebView.setServerBasePath({ path: want.dir });
    return true;
  } catch {
    // Could not switch: stay on this build.
    return false;
  }
}

/**
 * Called after the app starts. If this page is a downloaded build and its
 * screen has drawn after a few seconds, mark it good and delete older
 * downloads.
 */
export function confirmOtaSoon(): void {
  if (!isNative()) return;
  window.setTimeout(() => {
    void (async () => {
      try {
        const raw = localStorage.getItem(K_OTA);
        if (!raw) return;
        const want = JSON.parse(raw) as { stamp?: string };
        if (want.stamp !== SPLASH_BUILD_STAMP) return;
        const root = document.querySelector("[data-generated-space-root]");
        if (!root || root.childElementCount === 0) return; // nothing drew: do not confirm
        localStorage.setItem(K_OK, SPLASH_BUILD_STAMP);
        const list = await Filesystem.readdir({ path: OTA_ROOT, directory: Directory.Data });
        for (const entry of list.files) {
          if (entry.name !== SPLASH_BUILD_STAMP) {
            await Filesystem.rmdir({ path: `${OTA_ROOT}/${entry.name}`, directory: Directory.Data, recursive: true }).catch(() => {});
          }
        }
      } catch {
        // best effort
      }
    })();
  }, 4000);
}

/** True when this page is running from a downloaded build. */
export function runningDownloadedBuild(): boolean {
  try {
    const raw = localStorage.getItem(K_OTA);
    return raw ? (JSON.parse(raw) as { stamp?: string }).stamp === SPLASH_BUILD_STAMP : false;
  } catch {
    return false;
  }
}
