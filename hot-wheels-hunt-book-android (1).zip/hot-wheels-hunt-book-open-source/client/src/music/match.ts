// Background job: finds each song of the library on Deezer (cover picture,
// artist, album, link). Runs one song at a time, politely, and can be
// stopped and resumed; matches are saved as it goes.
import { useSyncExternalStore } from "react";
import { findOnDeezer } from "./deezer";
import { getMusicSnapshot, setMetaBulk, type TrackMeta } from "./store";

export interface MatchState {
  busy: boolean;
  done: number;
  total: number;
  found: number;
  error: string;
}
let st: MatchState = { busy: false, done: 0, total: 0, found: 0, error: "" };
const listeners = new Set<() => void>();
function set(p: Partial<MatchState>) {
  st = { ...st, ...p };
  listeners.forEach((l) => l());
}
export function useMatchJob(): MatchState {
  return useSyncExternalStore(
    (cb) => {
      listeners.add(cb);
      return () => listeners.delete(cb);
    },
    () => st,
  );
}

let stopFlag = false;
export function stopMatching() {
  stopFlag = true;
}

const THIRTY_DAYS = 30 * 24 * 3600 * 1000;

export function pendingMatchCount(): number {
  const s = getMusicSnapshot();
  return s.tracks.filter((t) => {
    const m = s.meta[t.id];
    return !m?.dz && !(m?.dzMissAt && Date.now() - m.dzMissAt < THIRTY_DAYS);
  }).length;
}

export async function startMatching() {
  if (st.busy) return;
  const s = getMusicSnapshot();
  const todo = s.tracks.filter((t) => {
    const m = s.meta[t.id];
    return !m?.dz && !(m?.dzMissAt && Date.now() - m.dzMissAt < THIRTY_DAYS);
  });
  stopFlag = false;
  set({ busy: true, done: 0, total: todo.length, found: 0, error: "" });
  let batch: Record<string, Partial<TrackMeta>> = {};
  let found = 0;
  let failures = 0;
  for (let i = 0; i < todo.length; i++) {
    if (stopFlag) break;
    const t = todo[i]!;
    try {
      const r = await findOnDeezer(t);
      failures = 0;
      if (r) {
        found += 1;
        batch[t.id] = { dz: { id: r.id, title: r.title, artist: r.artist, artistId: r.artistId, album: r.album, albumId: r.albumId, cover: r.cover, at: Date.now() } };
      } else {
        batch[t.id] = { dzMissAt: Date.now() };
      }
    } catch (e) {
      failures += 1;
      if (failures >= 3) {
        set({ error: e instanceof Error ? e.message : "Deezer could not be reached." });
        break;
      }
    }
    if ((i + 1) % 10 === 0) {
      setMetaBulk(batch);
      batch = {};
    }
    set({ done: i + 1, found });
  }
  setMetaBulk(batch);
  set({ busy: false });
}
