// The Music library lives in the web view's IndexedDB (not the Hunt Book
// database), so a 5,000-song library never slows the collection down.
import { useSyncExternalStore } from "react";
import type { LibTrack } from "./native";

export interface DzInfo {
  id: number;
  title: string;
  artist: string;
  artistId: number;
  album: string;
  albumId: number;
  cover: string;
  at: number;
}
export interface TrackMeta {
  dz?: DzInfo;
  dzMissAt?: number; // searched on Deezer and nothing matched (retry after 30 days)
  plays?: number;
  lastPlayed?: number;
}
export interface DzTrack {
  id: number;
  title: string;
  artist: string;
  artistId: number;
  album: string;
  albumId: number;
  cover: string;
  durationSec: number;
  link: string;
  preview?: string;
}
export type PlaylistItem = { kind: "local"; id: string } | { kind: "dz"; track: DzTrack };
export interface Playlist {
  id: string;
  name: string;
  createdAt: number;
  items: PlaylistItem[];
  fromDeezer?: number; // Deezer playlist id it was imported from
}
export interface MusicSettings {
  dzUser: string;
}

interface Snapshot {
  ready: boolean;
  tracks: LibTrack[];
  meta: Record<string, TrackMeta>;
  playlists: Playlist[];
  wishlist: DzTrack[];
  settings: MusicSettings;
  scannedAt: number;
}

let snap: Snapshot = { ready: false, tracks: [], meta: {}, playlists: [], wishlist: [], settings: { dzUser: "" }, scannedAt: 0 };
const listeners = new Set<() => void>();
function emit(patch: Partial<Snapshot>) {
  snap = { ...snap, ...patch };
  listeners.forEach((l) => l());
}

// ---- tiny IndexedDB key/value ----
const DB = "hw-music-v1";
function open(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB, 1);
    req.onupgradeneeded = () => req.result.createObjectStore("kv");
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}
async function kvGet<T>(key: string): Promise<T | undefined> {
  const db = await open();
  return new Promise((resolve, reject) => {
    const r = db.transaction("kv").objectStore("kv").get(key);
    r.onsuccess = () => resolve(r.result as T | undefined);
    r.onerror = () => reject(r.error);
  });
}
async function kvSet(key: string, value: unknown): Promise<void> {
  const db = await open();
  return new Promise((resolve, reject) => {
    const tx = db.transaction("kv", "readwrite");
    tx.objectStore("kv").put(value, key);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

let loading: Promise<void> | null = null;
export function loadMusicStore(): Promise<void> {
  if (!loading) {
    loading = (async () => {
      try {
        const [tracks, meta, playlists, wishlist, settings, scannedAt] = await Promise.all([
          kvGet<LibTrack[]>("tracks"),
          kvGet<Record<string, TrackMeta>>("meta"),
          kvGet<Playlist[]>("playlists"),
          kvGet<DzTrack[]>("wishlist"),
          kvGet<MusicSettings>("settings"),
          kvGet<number>("scannedAt"),
        ]);
        emit({
          ready: true,
          tracks: tracks ?? [],
          meta: meta ?? {},
          playlists: playlists ?? [],
          wishlist: wishlist ?? [],
          settings: { dzUser: settings?.dzUser ?? "" },
          scannedAt: scannedAt ?? 0,
        });
      } catch {
        emit({ ready: true });
      }
    })();
  }
  return loading;
}

export function useMusicStore(): Snapshot {
  return useSyncExternalStore(
    (cb) => {
      listeners.add(cb);
      return () => listeners.delete(cb);
    },
    () => snap,
  );
}
export function getMusicSnapshot(): Snapshot {
  return snap;
}

const timers = new Map<string, number>();
function saveSoon(key: string, get: () => unknown, delay = 800) {
  const t = timers.get(key);
  if (t) window.clearTimeout(t);
  timers.set(
    key,
    window.setTimeout(() => {
      timers.delete(key);
      void kvSet(key, get()).catch(() => {});
    }, delay),
  );
}

/** Replaces the song list with a fresh scan; extra info for songs still there is kept. */
export function setScan(tracks: LibTrack[]) {
  const keep: Record<string, TrackMeta> = {};
  for (const t of tracks) {
    const m = snap.meta[t.id];
    if (m) keep[t.id] = m;
  }
  emit({ tracks, meta: keep, scannedAt: Date.now() });
  void kvSet("tracks", tracks).catch(() => {});
  void kvSet("scannedAt", snap.scannedAt).catch(() => {});
  saveSoon("meta", () => snap.meta, 100);
}

export function setMeta(id: string, patch: Partial<TrackMeta>, delay = 3000) {
  emit({ meta: { ...snap.meta, [id]: { ...snap.meta[id], ...patch } } });
  saveSoon("meta", () => snap.meta, delay);
}
export function setMetaBulk(patches: Record<string, Partial<TrackMeta>>) {
  const next = { ...snap.meta };
  for (const [id, p] of Object.entries(patches)) next[id] = { ...next[id], ...p };
  emit({ meta: next });
  saveSoon("meta", () => snap.meta, 1500);
}

export function setPlaylists(playlists: Playlist[]) {
  emit({ playlists });
  saveSoon("playlists", () => snap.playlists, 200);
}
export function setWishlist(wishlist: DzTrack[]) {
  emit({ wishlist });
  saveSoon("wishlist", () => snap.wishlist, 200);
}
export function setMusicSettings(settings: MusicSettings) {
  emit({ settings });
  saveSoon("settings", () => snap.settings, 200);
}
export function newId(): string {
  return `${Date.now().toString(36)}${Math.floor(Math.random() * 1e6).toString(36)}`;
}

export function clearDeezerMeta() {
  const next: Record<string, TrackMeta> = {};
  for (const [id, m] of Object.entries(snap.meta)) {
    const { dz: _dz, dzMissAt: _miss, ...rest } = m;
    next[id] = rest;
  }
  emit({ meta: next });
  saveSoon("meta", () => snap.meta, 200);
}
