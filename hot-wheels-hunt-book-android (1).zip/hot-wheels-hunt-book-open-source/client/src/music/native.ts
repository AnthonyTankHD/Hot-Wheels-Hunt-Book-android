// Wrapper around the native "MusicLibrary" plugin (Android only): reads the
// phone's music list from MediaStore and saves small cover pictures.
import { Capacitor, registerPlugin } from "@capacitor/core";

export interface LibTrack {
  id: string; // MediaStore id (stable while the file stays on the phone)
  uri: string; // content:// address, played in place
  title: string;
  artist: string;
  album: string;
  albumId: string;
  durationMs: number;
  trackNo: number; // 1001 means disc 1 track 1 on some files
  year: number;
  addedAt: number; // seconds since 1970
  size: number;
  mime: string;
}

interface MusicLibraryPlugin {
  checkAccess(): Promise<{ granted: boolean }>;
  requestAccess(): Promise<{ granted: boolean }>;
  scan(o: { offset: number; limit: number }): Promise<{ total: number; items: LibTrack[] }>;
  getArt(o: { uri: string; key: string; size: number }): Promise<{ path?: string }>;
  setPlaying(o: { playing: boolean; title: string; artist: string }): Promise<void>;
  requestNotifications(): Promise<{ granted: boolean }>;
}

const Native = registerPlugin<MusicLibraryPlugin>("MusicLibrary");

export function musicNativeAvailable(): boolean {
  return Capacitor.isNativePlatform() && Capacitor.isPluginAvailable("MusicLibrary");
}

export async function ensureMusicAccess(): Promise<boolean> {
  const have = await Native.checkAccess();
  if (have.granted) return true;
  return (await Native.requestAccess()).granted;
}

/** Reads the whole music list from the phone, page by page. */
export async function scanPhone(onProgress?: (done: number, total: number) => void): Promise<LibTrack[]> {
  const out: LibTrack[] = [];
  const PAGE = 500;
  let total = 0;
  for (let offset = 0; ; offset += PAGE) {
    const page = await Native.scan({ offset, limit: PAGE });
    total = page.total;
    for (const t of page.items) {
      out.push({
        ...t,
        trackNo: Number(t.trackNo) || 0,
        year: Number(t.year) || 0,
        durationMs: Number(t.durationMs) || 0,
        addedAt: Number(t.addedAt) || 0,
        size: Number(t.size) || 0,
      });
    }
    onProgress?.(out.length, total);
    if (page.items.length === 0 || out.length >= total) break;
  }
  return out;
}

/** The address a web-view <audio> tag can play for a song on the phone. */
export function playableUrl(uri: string): string {
  return Capacitor.convertFileSrc(uri);
}

// ---- cover pictures: at most two native requests at a time ----
const artCache = new Map<string, Promise<string | null>>();
let active = 0;
const waiting: Array<() => void> = [];

function slot(): Promise<void> {
  if (active < 2) {
    active += 1;
    return Promise.resolve();
  }
  return new Promise((resolve) => waiting.push(() => { active += 1; resolve(); }));
}
function release() {
  active -= 1;
  const next = waiting.shift();
  if (next) next();
}

/** Cover picture for a song, cached per album. Resolves null when there is none. */
export function nativeArt(track: Pick<LibTrack, "uri" | "albumId" | "id">): Promise<string | null> {
  const key = track.albumId && track.albumId !== "0" ? `a${track.albumId}` : `t${track.id}`;
  let p = artCache.get(key);
  if (!p) {
    p = (async () => {
      await slot();
      try {
        const r = await Native.getArt({ uri: track.uri, key, size: 320 });
        return r.path ? Capacitor.convertFileSrc(r.path) : null;
      } catch {
        return null;
      } finally {
        release();
      }
    })();
    artCache.set(key, p);
  }
  return p;
}

/** Starts/stops the "music playing" notification that lets music continue when the app is minimized. */
export async function setBackgroundPlaying(playing: boolean, title = "", artist = ""): Promise<void> {
  try {
    if (!Capacitor.isNativePlatform() || !Capacitor.isPluginAvailable("MusicLibrary")) return;
    await Native.setPlaying({ playing, title, artist });
  } catch {
    // older app shell without background support: music still plays while the app is open
  }
}
export async function askNotifications(): Promise<void> {
  try {
    if (Capacitor.isNativePlatform() && Capacitor.isPluginAvailable("MusicLibrary")) await Native.requestNotifications();
  } catch {
    // ignore
  }
}
