// One audio engine for the whole app (so music keeps playing while you move
// between tabs). Plays songs on the phone in place, and Deezer songs as
// 30-second previews. Sound still stops when the app leaves the screen;
// that is an app-wide rule in App.tsx.
import { useSyncExternalStore } from "react";
import { askNotifications, playableUrl, setBackgroundPlaying } from "./native";
import { getTrack } from "./deezer";
import { getMusicSnapshot, setMeta } from "./store";

export interface QItem {
  key: string;
  title: string;
  artist: string;
  album?: string;
  localId?: string;
  localUri?: string;
  albumId?: string;
  dzId?: number;
  cover?: string;
  link?: string;
  durationSec?: number;
  previewUrl?: string;
  previewAt?: number;
}

export interface PlayerState {
  queue: QItem[];
  index: number; // position in `queue` of the song in front, -1 when none
  playing: boolean;
  loading: boolean;
  position: number;
  duration: number;
  shuffle: boolean;
  repeat: "off" | "all" | "one";
  rate: number;
  sleepAt: number | null;
  error: string;
  nowOpen: boolean;
  preview: boolean; // current song is a 30-second Deezer preview
  bgPlay: boolean; // keep playing when the app is minimized
}

function readBgPref(): boolean {
  try {
    return localStorage.getItem("hw-bg-play") !== "0";
  } catch {
    return true;
  }
}

let state: PlayerState = {
  queue: [],
  index: -1,
  playing: false,
  loading: false,
  position: 0,
  duration: 0,
  shuffle: false,
  repeat: "off",
  rate: 1,
  sleepAt: null,
  error: "",
  nowOpen: false,
  preview: false,
  bgPlay: readBgPref(),
};
const listeners = new Set<() => void>();
function set(patch: Partial<PlayerState>) {
  state = { ...state, ...patch };
  listeners.forEach((l) => l());
}
export function usePlayer(): PlayerState {
  return useSyncExternalStore(
    (cb) => {
      listeners.add(cb);
      return () => listeners.delete(cb);
    },
    () => state,
  );
}
export function getPlayerState(): PlayerState {
  return state;
}

let audio: HTMLAudioElement | null = null;
let order: number[] = [];
let cursor = 0;
let loadToken = 0;
let lastTick = 0;
let sleepTimer: number | null = null;

function ensureAudio(): HTMLAudioElement {
  if (audio) return audio;
  const a = document.createElement("audio");
  a.preload = "auto";
  a.style.display = "none";
  a.setAttribute("data-keep-playing", state.bgPlay ? "true" : "false");
  document.body.appendChild(a); // in the page, so the app-wide "pause everything" rule reaches it
  a.addEventListener("timeupdate", () => {
    const now = Date.now();
    if (now - lastTick < 250) return;
    lastTick = now;
    set({ position: a.currentTime });
  });
  a.addEventListener("durationchange", () => set({ duration: Number.isFinite(a.duration) ? a.duration : 0 }));
  a.addEventListener("play", () => {
    set({ playing: true });
    syncBackground();
  });
  a.addEventListener("pause", () => {
    set({ playing: false });
    void setBackgroundPlaying(false);
  });
  a.addEventListener("playing", () => set({ loading: false, error: "" }));
  a.addEventListener("waiting", () => set({ loading: true }));
  a.addEventListener("ended", () => advance(true));
  a.addEventListener("error", () => {
    if (!a.getAttribute("src")) return;
    set({ loading: false, playing: false, error: "That song could not be played." });
    window.setTimeout(() => {
      if (state.error && state.queue.length > 1) advance(true);
    }, 1200);
  });
  audio = a;
  setupMediaSession();
  return a;
}

function shuffled(n: number, first: number): number[] {
  const rest = Array.from({ length: n }, (_, i) => i).filter((i) => i !== first);
  for (let i = rest.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [rest[i], rest[j]] = [rest[j]!, rest[i]!];
  }
  return first >= 0 ? [first, ...rest] : rest;
}
function buildOrder(startIndex: number) {
  const n = state.queue.length;
  order = state.shuffle ? shuffled(n, startIndex) : Array.from({ length: n }, (_, i) => i);
  cursor = state.shuffle ? 0 : Math.max(0, startIndex);
}

async function load(autoplay = true) {
  const item = state.queue[order[cursor] ?? -1];
  if (!item) return;
  const a = ensureAudio();
  const token = ++loadToken;
  set({ index: order[cursor]!, loading: true, error: "", position: 0, duration: item.durationSec ?? 0 });
  try {
    let src = "";
    let preview = false;
    if (item.localUri) {
      src = playableUrl(item.localUri);
    } else if (item.dzId) {
      preview = true;
      let url = item.previewUrl;
      if (!url || Date.now() - (item.previewAt ?? 0) > 10 * 60 * 1000) {
        const fresh = await getTrack(item.dzId);
        url = fresh.preview;
        item.previewUrl = url;
        item.previewAt = Date.now();
      }
      if (!url) throw new Error("Deezer has no preview for this song. Open it in Deezer instead.");
      src = url;
    } else {
      throw new Error("Nothing to play.");
    }
    if (token !== loadToken) return;
    a.src = src;
    a.playbackRate = state.rate;
    set({ preview });
    updateMediaSession(item);
    if (!a.paused) syncBackground();
    if (item.localId) {
      const m = getMusicSnapshot().meta[item.localId];
      setMeta(item.localId, { plays: (m?.plays ?? 0) + 1, lastPlayed: Date.now() });
    }
    if (autoplay) await a.play();
  } catch (e) {
    if (token !== loadToken) return;
    set({ loading: false, playing: false, error: e instanceof Error ? e.message : "That song could not be played." });
  }
}

function advance(auto: boolean) {
  if (state.queue.length === 0) return;
  if (auto && state.repeat === "one") {
    const a = ensureAudio();
    a.currentTime = 0;
    void a.play().catch(() => {});
    return;
  }
  if (cursor + 1 < order.length) {
    cursor += 1;
    void load();
    return;
  }
  if (state.repeat === "all") {
    if (state.shuffle) buildOrder(-1);
    else cursor = 0;
    void load();
    return;
  }
  // end of the queue
  const a = ensureAudio();
  a.pause();
  a.currentTime = 0;
  set({ playing: false, position: 0 });
}

// ---- public controls ----
export function playQueue(items: QItem[], startIndex: number) {
  if (items.length === 0) return;
  state = { ...state, queue: items };
  buildOrder(Math.min(Math.max(0, startIndex), items.length - 1));
  void load();
}
export function toggle() {
  const a = ensureAudio();
  if (state.index < 0) return;
  if (a.paused) {
    if (!a.getAttribute("src")) void load();
    else void a.play().catch(() => {});
  } else a.pause();
}
export function next() {
  advance(false);
}
export function prev() {
  const a = ensureAudio();
  if (a.currentTime > 3 || cursor === 0) {
    a.currentTime = 0;
    return;
  }
  cursor -= 1;
  void load();
}
export function seek(sec: number) {
  const a = ensureAudio();
  if (Number.isFinite(sec)) {
    a.currentTime = Math.max(0, sec);
    set({ position: a.currentTime });
  }
}
export function setRate(rate: number) {
  const a = ensureAudio();
  a.playbackRate = rate;
  set({ rate });
}
export function setShuffle(on: boolean) {
  state = { ...state, shuffle: on };
  if (state.index >= 0) buildOrder(state.index);
  set({ shuffle: on });
}
export function cycleRepeat() {
  set({ repeat: state.repeat === "off" ? "all" : state.repeat === "all" ? "one" : "off" });
}
export function jumpTo(queueIndex: number) {
  const at = order.indexOf(queueIndex);
  if (at < 0) return;
  cursor = at;
  void load();
}
export function enqueue(item: QItem, playNext = false) {
  if (state.queue.length === 0) {
    playQueue([item], 0);
    return;
  }
  const queue = [...state.queue, item];
  const qi = queue.length - 1;
  state = { ...state, queue };
  if (playNext) order.splice(cursor + 1, 0, qi);
  else order.push(qi);
  set({ queue });
}
export function removeAt(queueIndex: number) {
  if (queueIndex === state.index) return;
  const queue = state.queue.filter((_, i) => i !== queueIndex);
  order = order.filter((i) => i !== queueIndex).map((i) => (i > queueIndex ? i - 1 : i));
  const index = state.index > queueIndex ? state.index - 1 : state.index;
  cursor = Math.max(0, order.indexOf(index));
  set({ queue, index });
}
export function stopAll() {
  loadToken += 1;
  if (audio) {
    audio.pause();
    audio.removeAttribute("src");
    audio.load();
  }
  order = [];
  cursor = 0;
  set({ queue: [], index: -1, playing: false, loading: false, position: 0, duration: 0, error: "", nowOpen: false, preview: false });
  void setBackgroundPlaying(false);
}
export function openNow(open: boolean) {
  set({ nowOpen: open });
}
export function setSleep(minutes: number | null) {
  if (sleepTimer) window.clearTimeout(sleepTimer);
  sleepTimer = null;
  if (!minutes) {
    set({ sleepAt: null });
    return;
  }
  const at = Date.now() + minutes * 60_000;
  set({ sleepAt: at });
  sleepTimer = window.setTimeout(() => {
    sleepTimer = null;
    if (audio) audio.pause();
    set({ sleepAt: null });
  }, minutes * 60_000);
}

// ---- lock screen / notification controls where the web view supports them ----
function setupMediaSession() {
  try {
    const ms = navigator.mediaSession;
    if (!ms) return;
    ms.setActionHandler("play", () => toggle());
    ms.setActionHandler("pause", () => toggle());
    ms.setActionHandler("previoustrack", () => prev());
    ms.setActionHandler("nexttrack", () => next());
    ms.setActionHandler("seekto", (d) => {
      if (typeof d.seekTime === "number") seek(d.seekTime);
    });
  } catch {
    // not supported here
  }
}
function updateMediaSession(item: QItem) {
  try {
    if (!navigator.mediaSession) return;
    navigator.mediaSession.metadata = new MediaMetadata({
      title: item.title,
      artist: item.artist,
      album: item.album ?? "",
      artwork: item.cover ? [{ src: item.cover }] : [],
    });
  } catch {
    // not supported here
  }
}

/** The play order (indices into the queue). */
export function getOrder(): number[] {
  return order;
}


// ---- keep playing when the app is minimized ----
let askedNotif = false;
function syncBackground() {
  if (!audio) return;
  audio.setAttribute("data-keep-playing", state.bgPlay ? "true" : "false");
  const item = state.queue[state.index];
  if (state.bgPlay && item) {
    if (!askedNotif) {
      askedNotif = true;
      void askNotifications();
    }
    void setBackgroundPlaying(true, item.title, item.artist);
  } else {
    void setBackgroundPlaying(false);
  }
}
export function setBackgroundPref(on: boolean) {
  try {
    localStorage.setItem("hw-bg-play", on ? "1" : "0");
  } catch {
    // not saved
  }
  set({ bgPlay: on });
  if (audio) {
    if (!audio.paused) syncBackground();
    else audio.setAttribute("data-keep-playing", on ? "true" : "false");
  }
}
