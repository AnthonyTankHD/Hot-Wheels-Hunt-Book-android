// The new Music screen: songs found on the phone, albums, artists, your own
// playlists, and Deezer (search, charts, public playlists, covers, previews).
import { Component, useEffect, useMemo, useState } from "react";
import type { ReactNode } from "react";
import { ensureMusicAccess, musicNativeAvailable, scanPhone, type LibTrack } from "./native";
import {
  clearDeezerMeta, loadMusicStore, newId, setMeta, setMusicSettings, setPlaylists, setScan, setWishlist, useMusicStore,
  type DzTrack, type Playlist, type PlaylistItem,
} from "./store";
import {
  albumTracks, artistTop, chartTracks, findOnDeezer, getPlaylist, getTrack, matchKey, norm, parseDeezerInput, searchTracks, userPlaylists,
  type DzPlaylist, type DzPlaylistInfo,
} from "./deezer";
import { enqueue, playQueue, setShuffle, usePlayer } from "./player";
import { startMatching, stopMatching, useMatchJob } from "./match";
import { ArtImg, RowList, dzToQ, localToQ, type Row } from "./ui";
import "./music.css";

class Boundary extends Component<{ fallback: ReactNode; children: ReactNode }, { failed: boolean }> {
  state = { failed: false };
  static getDerivedStateFromError() {
    return { failed: true };
  }
  componentDidCatch(e: unknown) {
    console.error("Music screen crashed", e);
  }
  render() {
    return this.state.failed ? this.props.fallback : this.props.children;
  }
}

/** Falls back to the saved-songs player if the new screen ever crashes. */
export function MusicHub(props: { renderClassic: () => ReactNode; onToast: (m: string) => void }) {
  return (
    <Boundary fallback={props.renderClassic()}>
      <Hub {...props} />
    </Boundary>
  );
}

type Sub = "songs" | "albums" | "artists" | "playlists" | "deezer" | "saved";
type Detail = { t: "album" | "artist"; key: string } | { t: "playlist"; id: string } | { t: "wishlist" } | null;
type MenuTarget = { kind: "local"; track: LibTrack } | { kind: "dz"; track: DzTrack; fromPlaylist?: string; fromWishlist?: boolean };

const SUBS: [Sub, string][] = [
  ["songs", "Songs"], ["albums", "Albums"], ["artists", "Artists"], ["playlists", "Playlists"], ["deezer", "Deezer"], ["saved", "Saved"],
];

function ago(ms: number): string {
  if (!ms) return "never";
  const m = Math.round((Date.now() - ms) / 60000);
  if (m < 1) return "just now";
  if (m < 60) return `${m} min ago`;
  const h = Math.round(m / 60);
  return h < 48 ? `${h} h ago` : `${Math.round(h / 24)} days ago`;
}
const stripPreview = (t: DzTrack): DzTrack => ({ ...t, preview: undefined });

function Hub(props: { renderClassic: () => ReactNode; onToast: (m: string) => void }) {
  const snap = useMusicStore();
  const player = usePlayer();
  const toast = props.onToast;
  const nativeOk = musicNativeAvailable();
  const [sub, setSub] = useState<Sub>("songs");
  const [detail, setDetail] = useState<Detail>(null);
  const [query, setQuery] = useState("");
  const [sort, setSort] = useState<"title" | "artist" | "recent" | "plays">("title");
  const [menu, setMenu] = useState<MenuTarget | null>(null);
  const [pick, setPick] = useState(false);
  const [newName, setNewName] = useState("");
  const [scanBusy, setScanBusy] = useState(false);
  const [scanMsg, setScanMsg] = useState("");

  useEffect(() => {
    void loadMusicStore();
  }, []);

  const runScan = async (silent = false) => {
    if (!nativeOk) {
      setScanMsg("This version of the app cannot read the phone's music. Install the newest APK from your GitHub release.");
      return;
    }
    setScanBusy(true);
    setScanMsg(silent ? "" : "Looking for music…");
    try {
      const ok = await ensureMusicAccess();
      if (!ok) {
        setScanMsg("Music access was not allowed. In Android Settings > Apps > Hot Wheels Hunt Book > Permissions, allow Music and audio, then scan again.");
        return;
      }
      const list = await scanPhone((d, t) => !silent && setScanMsg(`Reading ${d} of ${t}…`));
      setScan(list);
      setScanMsg("");
      if (!silent) toast(`Found ${list.length} songs on your phone`);
    } catch (e) {
      setScanMsg(e instanceof Error ? e.message : "The scan failed.");
    } finally {
      setScanBusy(false);
    }
  };

  // Quietly refresh the list when it is more than 6 hours old.
  useEffect(() => {
    if (snap.ready && nativeOk && snap.tracks.length > 0 && Date.now() - snap.scannedAt > 6 * 3600 * 1000) void runScan(true);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [snap.ready]);

  const index = useMemo(() => {
    const byId = new Map<string, LibTrack>();
    const byDz = new Map<number, LibTrack>();
    const byKey = new Map<string, LibTrack>();
    for (const t of snap.tracks) {
      byId.set(t.id, t);
      const dz = snap.meta[t.id]?.dz;
      if (dz) byDz.set(dz.id, t);
      byKey.set(matchKey(t.title, t.artist), t);
    }
    return { byId, byDz, byKey };
  }, [snap.tracks, snap.meta]);

  const localRow = (t: LibTrack): Row => {
    const m = snap.meta[t.id];
    const q = localToQ(t, m);
    return {
      key: q.key, title: t.title, sub: [q.artist, t.album].filter(Boolean).join(" \u00b7 "), cover: m?.dz?.cover,
      uri: t.uri, albumId: t.albumId, id: t.id, durationSec: t.durationMs / 1000, q,
      onMenu: () => { setPick(false); setMenu({ kind: "local", track: t }); },
    };
  };
  const dzRow = (d: DzTrack, extra: { fromPlaylist?: string; fromWishlist?: boolean } = {}): Row => {
    const onMenu = () => { setPick(false); setMenu({ kind: "dz", track: d, ...extra }); };
    const local = index.byDz.get(d.id) ?? index.byKey.get(matchKey(d.title, d.artist));
    if (local) return { ...localRow(local), badge: "On phone", onMenu };
    const q = dzToQ(d);
    return { key: q.key, title: d.title, sub: [d.artist, d.album].filter(Boolean).join(" \u00b7 "), cover: d.cover, durationSec: d.durationSec, badge: "Preview", q, onMenu };
  };
  const playRows = (rows: Row[], i: number) => playQueue(rows.map((r) => r.q), i);
  const shuffleRows = (rows: Row[]) => {
    if (rows.length === 0) return;
    setShuffle(true);
    playQueue(rows.map((r) => r.q), Math.floor(Math.random() * rows.length));
  };
  const currentKey = player.queue[player.index]?.key ?? "";

  // ---- songs ----
  const songRows = useMemo(() => {
    const q = query.trim().toLowerCase();
    let list = snap.tracks;
    if (q) list = list.filter((t) => `${t.title} ${t.artist} ${t.album}`.toLowerCase().includes(q));
    const sorted = [...list];
    if (sort === "title") sorted.sort((a, b) => a.title.localeCompare(b.title));
    else if (sort === "artist") sorted.sort((a, b) => a.artist.localeCompare(b.artist) || a.album.localeCompare(b.album) || a.trackNo - b.trackNo);
    else if (sort === "recent") sorted.sort((a, b) => b.addedAt - a.addedAt);
    else sorted.sort((a, b) => (snap.meta[b.id]?.plays ?? 0) - (snap.meta[a.id]?.plays ?? 0));
    return sorted.map(localRow);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [snap.tracks, snap.meta, query, sort]);

  // ---- albums / artists ----
  const albums = useMemo(() => {
    const m = new Map<string, { key: string; album: string; artist: string; tracks: LibTrack[] }>();
    for (const t of snap.tracks) {
      const key = t.albumId && t.albumId !== "0" ? t.albumId : `x${norm(t.album)}`;
      const g = m.get(key) ?? { key, album: t.album || "Unknown album", artist: t.artist, tracks: [] };
      g.tracks.push(t);
      m.set(key, g);
    }
    return [...m.values()].sort((a, b) => a.album.localeCompare(b.album));
  }, [snap.tracks]);
  const artists = useMemo(() => {
    const m = new Map<string, { key: string; name: string; tracks: LibTrack[] }>();
    for (const t of snap.tracks) {
      const name = t.artist && t.artist !== "<unknown>" ? t.artist : "Unknown artist";
      const key = norm(name) || "unknown";
      const g = m.get(key) ?? { key, name, tracks: [] };
      g.tracks.push(t);
      m.set(key, g);
    }
    return [...m.values()].sort((a, b) => a.name.localeCompare(b.name));
  }, [snap.tracks]);

  // ---- playlists ----
  const addToPlaylist = (pl: Playlist, item: PlaylistItem) => {
    const same = (x: PlaylistItem) => (x.kind === "local" && item.kind === "local" ? x.id === item.id : x.kind === "dz" && item.kind === "dz" ? x.track.id === item.track.id : false);
    if (pl.items.some(same)) {
      toast(`Already in ${pl.name}`);
      return;
    }
    setPlaylists(snap.playlists.map((p) => (p.id === pl.id ? { ...p, items: [...p.items, item] } : p)));
    toast(`Added to ${pl.name}`);
  };
  const createPlaylist = (name: string): Playlist | null => {
    const n = name.trim();
    if (!n) return null;
    const pl: Playlist = { id: newId(), name: n, createdAt: Date.now(), items: [] };
    setPlaylists([...snap.playlists, pl]);
    return pl;
  };
  const playlistRows = (pl: Playlist): Row[] => {
    const rows: Row[] = [];
    for (const it of pl.items) {
      if (it.kind === "local") {
        const t = index.byId.get(it.id);
        if (t) rows.push({ ...localRow(t), onMenu: () => { setPick(false); setMenu({ kind: "local", track: t }); } });
      } else rows.push(dzRow(it.track, { fromPlaylist: pl.id }));
    }
    return rows;
  };

  // ---- one song's action sheet ----
  const menuQ = menu ? (menu.kind === "local" ? localToQ(menu.track, snap.meta[menu.track.id]) : dzRow(menu.track).q) : null;
  const menuItem: PlaylistItem | null = menu ? (menu.kind === "local" ? { kind: "local", id: menu.track.id } : { kind: "dz", track: stripPreview(menu.track) }) : null;
  const menuDz = menu && menu.kind === "local" ? snap.meta[menu.track.id]?.dz : undefined;
  const menuLink = menu ? (menu.kind === "dz" ? menu.track.link : menuDz ? `https://www.deezer.com/track/${menuDz.id}` : "") : "";

  const findOne = async (t: LibTrack) => {
    setMenu(null);
    toast("Searching Deezer…");
    try {
      const r = await findOnDeezer(t);
      if (r) {
        setMeta(t.id, { dz: { id: r.id, title: r.title, artist: r.artist, artistId: r.artistId, album: r.album, albumId: r.albumId, cover: r.cover, at: Date.now() }, dzMissAt: undefined }, 500);
        toast(`Linked to ${r.title} by ${r.artist}`);
      } else {
        setMeta(t.id, { dzMissAt: Date.now() }, 500);
        toast("No match found on Deezer");
      }
    } catch (e) {
      toast(e instanceof Error ? e.message : "Deezer could not be reached");
    }
  };

  const openPlaylist = snap.playlists.find((p) => detail?.t === "playlist" && p.id === detail.id);

  // ---------- render ----------
  const nav = (
    <div className="mh-nav" role="tablist" aria-label="Music sections">
      {SUBS.map(([id, label]) => (
        <button key={id} type="button" role="tab" aria-selected={sub === id} className={sub === id ? "mh-pill mh-pill-on" : "mh-pill"} onClick={() => { setSub(id); setDetail(null); }}>
          {label}
        </button>
      ))}
    </div>
  );

  if (sub === "saved") {
    return (
      <>
        <section className="pn" aria-label="Music">
          <h2 className="hw-h2">🎵 Music</h2>
          {nav}
          <p className="mut mt-2">Songs you added to the app earlier (copied into it). They play with the original player below.</p>
        </section>
        {props.renderClassic()}
      </>
    );
  }

  const back = (label = "Back") => (
    <button type="button" className="mh-back" onClick={() => setDetail(null)}>← {label}</button>
  );
  const playBar = (rows: Row[]) => (
    <div className="mh-actions">
      <button type="button" className="hw-btn px-4 py-2 text-sm font-bold" onClick={() => playRows(rows, 0)} disabled={rows.length === 0}>▶ Play</button>
      <button type="button" className="hw-btn hw-btn-alt px-4 py-2 text-sm font-bold" onClick={() => shuffleRows(rows)} disabled={rows.length === 0}>🔀 Shuffle</button>
    </div>
  );

  let body: ReactNode = null;
  if (!snap.ready) {
    body = <p className="mut mt-3">Loading your music…</p>;
  } else if (detail && (detail.t === "album" || detail.t === "artist")) {
    const g = detail.t === "album" ? albums.find((a) => a.key === detail.key) : artists.find((a) => a.key === detail.key);
    const tracks = [...(g?.tracks ?? [])].sort((a, b) => (detail.t === "album" ? a.trackNo - b.trackNo : a.album.localeCompare(b.album) || a.trackNo - b.trackNo) || a.title.localeCompare(b.title));
    const rows = tracks.map(localRow);
    const title = detail.t === "album" ? (g as { album: string } | undefined)?.album : (g as { name: string } | undefined)?.name;
    body = (
      <>
        {back(detail.t === "album" ? "Albums" : "Artists")}
        <h3 className="mh-h3">{title ?? "Not found"}</h3>
        <p className="mut">{rows.length} songs</p>
        {playBar(rows)}
        <RowList rows={rows} currentKey={currentKey} onPlayAt={(i) => playRows(rows, i)} />
      </>
    );
  } else if (detail?.t === "wishlist") {
    const rows = snap.wishlist.map((d) => dzRow(d, { fromWishlist: true }));
    body = (
      <>
        {back("Playlists")}
        <h3 className="mh-h3">♡ Deezer wishlist</h3>
        <p className="mut">Songs you want to get. Tap one to hear a 30-second preview; the menu opens it in Deezer.</p>
        {playBar(rows)}
        <RowList rows={rows} currentKey={currentKey} onPlayAt={(i) => playRows(rows, i)} empty={<p className="mut mt-3">Empty. Use a song's menu in the Deezer tab to add one.</p>} />
      </>
    );
  } else if (detail?.t === "playlist" && openPlaylist) {
    const rows = playlistRows(openPlaylist);
    body = (
      <>
        {back("Playlists")}
        <h3 className="mh-h3">{openPlaylist.name}</h3>
        <p className="mut">{rows.length} songs{openPlaylist.fromDeezer ? " · from Deezer (plays your copy when you have one, a 30-second preview otherwise)" : ""}</p>
        {playBar(rows)}
        <RowList rows={rows} currentKey={currentKey} onPlayAt={(i) => playRows(rows, i)} empty={<p className="mut mt-3">No songs yet. Use a song's menu to add it here.</p>} />
        <button type="button" className="hw-btn hw-btn-alt mt-4 px-4 py-2 text-sm font-bold" onClick={() => { setPlaylists(snap.playlists.filter((p) => p.id !== openPlaylist.id)); setDetail(null); toast("Playlist deleted"); }}>
          Delete this playlist
        </button>
      </>
    );
  } else if (sub === "songs") {
    body =
      snap.tracks.length === 0 ? (
        <div className="mh-empty">
          <p>No songs yet. Scan your phone and they all show up here; nothing is copied, songs play right where they are.</p>
          <button type="button" className="hw-btn px-5 py-3 text-base font-bold" disabled={scanBusy} onClick={() => void runScan()}>
            {scanBusy ? "Scanning…" : "🔍 Scan my phone for music"}
          </button>
        </div>
      ) : (
        <>
          <div className="mh-tools">
            <input className="mh-input" type="search" placeholder="Search songs, artists, albums…" value={query} onChange={(e) => setQuery(e.target.value)} aria-label="Search songs" />
            <select className="mh-input mh-select" value={sort} onChange={(e) => setSort(e.target.value as typeof sort)} aria-label="Sort songs">
              <option value="title">A–Z</option><option value="artist">Artist</option><option value="recent">Newest</option><option value="plays">Most played</option>
            </select>
          </div>
          {playBar(songRows)}
          <RowList rows={songRows} currentKey={currentKey} onPlayAt={(i) => playRows(songRows, i)} empty={<p className="mut mt-3">No songs match that search.</p>} />
        </>
      );
  } else if (sub === "albums") {
    body = (
      <div className="mh-grid">
        {albums.map((a) => (
          <button key={a.key} type="button" className="mh-card" onClick={() => setDetail({ t: "album", key: a.key })}>
            <ArtImg uri={a.tracks[0]?.uri} albumId={a.tracks[0]?.albumId} id={a.tracks[0]?.id} cover={snap.meta[a.tracks[0]?.id ?? ""]?.dz?.cover} className="mh-card-art" />
            <span className="mh-row-title">{a.album}</span>
            <span className="mh-row-sub">{a.artist || "Unknown artist"} · {a.tracks.length}</span>
          </button>
        ))}
        {albums.length === 0 && <p className="mut">Scan your phone first (Songs tab).</p>}
      </div>
    );
  } else if (sub === "artists") {
    body = (
      <ul className="mh-list">
        {artists.map((a) => (
          <li key={a.key} className="mh-row">
            <button type="button" className="mh-row-main" onClick={() => setDetail({ t: "artist", key: a.key })}>
              <ArtImg uri={a.tracks[0]?.uri} albumId={a.tracks[0]?.albumId} id={a.tracks[0]?.id} cover={snap.meta[a.tracks[0]?.id ?? ""]?.dz?.cover} />
              <span className="mh-row-text"><span className="mh-row-title">{a.name}</span><span className="mh-row-sub">{a.tracks.length} songs</span></span>
            </button>
          </li>
        ))}
        {artists.length === 0 && <p className="mut">Scan your phone first (Songs tab).</p>}
      </ul>
    );
  } else if (sub === "playlists") {
    body = (
      <>
        <div className="mh-tools">
          <input className="mh-input" placeholder="New playlist name" value={newName} onChange={(e) => setNewName(e.target.value)} aria-label="New playlist name" />
          <button type="button" className="hw-btn px-4 py-2 text-sm font-bold" onClick={() => { const pl = createPlaylist(newName); if (pl) { setNewName(""); setDetail({ t: "playlist", id: pl.id }); } }}>Create</button>
        </div>
        <ul className="mh-list">
          <li className="mh-row"><button type="button" className="mh-row-main" onClick={() => setDetail({ t: "wishlist" })}><span className="mh-art"><span>♡</span></span><span className="mh-row-text"><span className="mh-row-title">Deezer wishlist</span><span className="mh-row-sub">{snap.wishlist.length} songs to get</span></span></button></li>
          {snap.playlists.map((p) => (
            <li key={p.id} className="mh-row">
              <button type="button" className="mh-row-main" onClick={() => setDetail({ t: "playlist", id: p.id })}>
                <span className="mh-art"><span>🎶</span></span>
                <span className="mh-row-text"><span className="mh-row-title">{p.name}</span><span className="mh-row-sub">{p.items.length} songs{p.fromDeezer ? " · Deezer" : ""}</span></span>
              </button>
            </li>
          ))}
        </ul>
      </>
    );
  } else if (sub === "deezer") {
    body = <DeezerPanel dzRow={dzRow} playRows={playRows} currentKey={currentKey} toast={toast} snapTracks={snap.tracks.length} matched={Object.values(snap.meta).filter((m) => m.dz).length} />;
  }

  return (
    <>
      <section className="pn" aria-label="Music">
        <div className="mh-head">
          <h2 className="hw-h2">🎵 Music</h2>
          {nativeOk && (
            <button type="button" className="hw-btn hw-btn-alt px-3 py-2 text-sm font-bold" disabled={scanBusy} onClick={() => void runScan()}>
              {scanBusy ? "Scanning…" : snap.tracks.length ? "Rescan" : "Scan"}
            </button>
          )}
        </div>
        <p className="mut">{snap.tracks.length ? `${snap.tracks.length} songs on this phone · scanned ${ago(snap.scannedAt)}` : "Your phone's music, plus Deezer."}</p>
        {scanMsg && <p role="status" className="mh-note">{scanMsg}</p>}
        {nav}
        {body}
      </section>

      {menu && menuQ && menuItem && (
        <div className="mh-sheet-back" onClick={() => setMenu(null)}>
          <div className="mh-sheet" role="dialog" aria-label="Song options" onClick={(e) => e.stopPropagation()}>
            <p className="mh-sheet-title">{menuQ.title}<br /><span className="mh-row-sub">{menuQ.artist}</span></p>
            {!pick ? (
              <>
                <button type="button" onClick={() => { enqueue(menuQ, true); toast("Playing next"); setMenu(null); }}>Play next</button>
                <button type="button" onClick={() => { enqueue(menuQ); toast("Added to the queue"); setMenu(null); }}>Add to queue</button>
                <button type="button" onClick={() => setPick(true)}>Add to playlist…</button>
                {menu.kind === "local" && !menuDz && <button type="button" onClick={() => void findOne(menu.track)}>Find on Deezer</button>}
                {menu.kind === "dz" && !menu.fromWishlist && !snap.wishlist.some((w) => w.id === menu.track.id) && (
                  <button type="button" onClick={() => { setWishlist([...snap.wishlist, stripPreview(menu.track)]); toast("Added to your Deezer wishlist"); setMenu(null); }}>♡ Add to wishlist</button>
                )}
                {menu.kind === "dz" && menu.fromWishlist && (
                  <button type="button" onClick={() => { setWishlist(snap.wishlist.filter((w) => w.id !== menu.track.id)); setMenu(null); }}>Remove from wishlist</button>
                )}
                {menu.kind === "dz" && menu.fromPlaylist && (
                  <button type="button" onClick={() => { const pid = menu.fromPlaylist; setPlaylists(snap.playlists.map((p) => (p.id === pid ? { ...p, items: p.items.filter((x) => !(x.kind === "dz" && x.track.id === menu.track.id)) } : p))); setMenu(null); }}>Remove from this playlist</button>
                )}
                {detail?.t === "playlist" && menu.kind === "local" && (
                  <button type="button" onClick={() => { const pid = detail.id; const tid = menu.track.id; setPlaylists(snap.playlists.map((p) => (p.id === pid ? { ...p, items: p.items.filter((x) => !(x.kind === "local" && x.id === tid)) } : p))); setMenu(null); }}>Remove from this playlist</button>
                )}
                {menuLink && <a href={menuLink} target="_blank" rel="noreferrer" onClick={() => setMenu(null)}>Open in Deezer</a>}
                <button type="button" className="mh-sheet-cancel" onClick={() => setMenu(null)}>Close</button>
              </>
            ) : (
              <>
                {snap.playlists.map((p) => (
                  <button key={p.id} type="button" onClick={() => { addToPlaylist(p, menuItem); setMenu(null); }}>{p.name}</button>
                ))}
                <div className="mh-tools">
                  <input className="mh-input" placeholder="New playlist name" value={newName} onChange={(e) => setNewName(e.target.value)} aria-label="New playlist name" />
                  <button type="button" className="hw-btn px-3 py-2 text-sm font-bold" onClick={() => { const pl = createPlaylist(newName); if (pl) { setNewName(""); addToPlaylist({ ...pl, items: [] }, menuItem); setMenu(null); } }}>Create + add</button>
                </div>
                <button type="button" className="mh-sheet-cancel" onClick={() => setPick(false)}>Back</button>
              </>
            )}
          </div>
        </div>
      )}
    </>
  );
}

// ---------------- Deezer tab ----------------
let chartCache: DzTrack[] | null = null;

function DeezerPanel(props: {
  dzRow: (d: DzTrack) => Row;
  playRows: (rows: Row[], i: number) => void;
  currentKey: string;
  toast: (m: string) => void;
  snapTracks: number;
  matched: number;
}) {
  const snap = useMusicStore();
  const job = useMatchJob();
  const [q, setQ] = useState("");
  const [results, setResults] = useState<DzTrack[] | null>(null);
  const [resultsTitle, setResultsTitle] = useState("");
  const [chart, setChart] = useState<DzTrack[] | null>(chartCache);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const [link, setLink] = useState(snap.settings.dzUser);
  const [pl, setPl] = useState<DzPlaylist | null>(null);
  const [userView, setUserView] = useState<{ name: string; playlists: DzPlaylistInfo[] } | null>(null);

  useEffect(() => {
    if (chartCache) return;
    let alive = true;
    chartTracks(40).then((c) => { chartCache = c; if (alive) setChart(c); }).catch(() => {});
    return () => { alive = false; };
  }, []);

  const run = async (fn: () => Promise<void>) => {
    setBusy(true);
    setErr("");
    try { await fn(); } catch (e) { setErr(e instanceof Error ? e.message : "Something went wrong."); } finally { setBusy(false); }
  };
  const search = () => {
    const text = q.trim();
    if (!text) return;
    void run(async () => { setPl(null); setUserView(null); setResults(await searchTracks(text, 30)); setResultsTitle(`Results for "${text}"`); });
  };
  const openPlaylist = (id: number) =>
    run(async () => { setUserView(null); setResults(null); setPl(await getPlaylist(id)); });
  const doImport = () =>
    run(async () => {
      const found = await parseDeezerInput(link);
      if (!found) throw new Error("That doesn't look like a Deezer link. Paste a playlist or profile link, or a profile number.");
      setPl(null); setUserView(null); setResults(null);
      if (found.kind === "playlist") setPl(await getPlaylist(found.id));
      else if (found.kind === "user") {
        setUserView(await userPlaylists(found.id));
        setMusicSettings({ dzUser: String(found.id) });
      } else if (found.kind === "track") { setResults([await getTrack(found.id)]); setResultsTitle("Song"); }
      else if (found.kind === "artist") { setResults(await artistTop(found.id)); setResultsTitle("Artist's top songs"); }
      else { setResults(await albumTracks(found.id)); setResultsTitle("Album"); }
    });

  const plRows = pl ? pl.tracks.map(props.dzRow) : [];
  const onPhone = plRows.filter((r) => r.badge === "On phone").length;
  const listRows = (results ?? chart ?? []).map(props.dzRow);

  return (
    <>
      <div className="mh-card-wide">
        <h3 className="mh-h3">Link your library with Deezer</h3>
        <p className="mut">{props.snapTracks === 0 ? "Scan your phone first." : `${props.matched} of ${props.snapTracks} songs linked. Linking adds covers and a Deezer link to your songs.`}</p>
        {job.busy ? (
          <>
            <progress className="mh-progress" value={job.done} max={Math.max(1, job.total)} />
            <p className="mut">Checking {job.done} of {job.total} · {job.found} found. Keep the app open.</p>
            <button type="button" className="hw-btn hw-btn-alt px-4 py-2 text-sm font-bold" onClick={stopMatching}>Pause</button>
          </>
        ) : (
          <button type="button" className="hw-btn px-4 py-2 text-sm font-bold" disabled={props.snapTracks === 0} onClick={() => void startMatching()}>
            {props.matched > 0 ? "Continue linking" : "Start linking"}
          </button>
        )}
        {job.error && <p className="mh-note">{job.error}</p>}
      </div>

      <div className="mh-tools">
        <input className="mh-input" type="search" placeholder="Search Deezer…" value={q} onChange={(e) => setQ(e.target.value)} onKeyDown={(e) => e.key === "Enter" && search()} aria-label="Search Deezer" />
        <button type="button" className="hw-btn px-4 py-2 text-sm font-bold" disabled={busy} onClick={search}>Go</button>
      </div>
      <div className="mh-tools">
        <input className="mh-input" placeholder="Deezer playlist link or profile number" value={link} onChange={(e) => setLink(e.target.value)} aria-label="Deezer link" autoCapitalize="none" autoCorrect="off" />
        <button type="button" className="hw-btn hw-btn-alt px-4 py-2 text-sm font-bold" disabled={busy || !link.trim()} onClick={doImport}>Open</button>
      </div>
      <p className="mut">Sign-in is not possible (Deezer is not accepting new apps), but any public playlist or profile works.</p>
      {err && <p role="alert" className="mh-note">{err}</p>}
      {busy && <p className="mut">Loading…</p>}

      {userView && (
        <>
          <h3 className="mh-h3">{userView.name}'s playlists</h3>
          <ul className="mh-list">
            {userView.playlists.map((p) => (
              <li key={p.id} className="mh-row">
                <button type="button" className="mh-row-main" onClick={() => void openPlaylist(p.id)}>
                  <ArtImg cover={p.cover} />
                  <span className="mh-row-text"><span className="mh-row-title">{p.title}</span><span className="mh-row-sub">{p.count} songs</span></span>
                </button>
              </li>
            ))}
            {userView.playlists.length === 0 && <p className="mut">No public playlists.</p>}
          </ul>
        </>
      )}

      {pl && (
        <>
          <h3 className="mh-h3">{pl.title}</h3>
          <p className="mut">{pl.creator ? `by ${pl.creator} · ` : ""}{pl.tracks.length} songs · {onPhone} already on your phone</p>
          <div className="mh-actions">
            <button type="button" className="hw-btn px-4 py-2 text-sm font-bold" onClick={() => props.playRows(plRows, 0)}>▶ Play</button>
            <button
              type="button"
              className="hw-btn hw-btn-alt px-4 py-2 text-sm font-bold"
              onClick={() => {
                setPlaylists([...snap.playlists, { id: newId(), name: pl.title, createdAt: Date.now(), items: pl.tracks.map((t) => ({ kind: "dz" as const, track: stripPreview(t) })), fromDeezer: pl.id }]);
                props.toast("Saved to your playlists");
              }}
            >
              Save to my playlists
            </button>
          </div>
          <RowList rows={plRows} currentKey={props.currentKey} onPlayAt={(i) => props.playRows(plRows, i)} />
        </>
      )}

      {!pl && !userView && (
        <>
          <h3 className="mh-h3">{results ? resultsTitle : "Top songs on Deezer"}</h3>
          <RowList rows={listRows} currentKey={props.currentKey} onPlayAt={(i) => props.playRows(listRows, i)} empty={<p className="mut mt-3">{results ? "Nothing found." : "Loading the charts…"}</p>} />
        </>
      )}

      <p className="mut mt-4">Songs that are not on your phone play as 30-second previews; use a song's menu to open the full song in Deezer.</p>
      {props.matched > 0 && (
        <button type="button" className="hw-btn hw-btn-alt mt-2 px-4 py-2 text-sm font-bold" onClick={() => { clearDeezerMeta(); props.toast("Deezer links cleared"); }}>
          Clear Deezer links
        </button>
      )}
    </>
  );
}
