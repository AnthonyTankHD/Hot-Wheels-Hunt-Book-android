// Small shared pieces for the Music screens.
import { useEffect, useRef, useState } from "react";
import type { ReactNode } from "react";
import { nativeArt, type LibTrack } from "./native";
import type { DzTrack, TrackMeta } from "./store";
import type { QItem } from "./player";

export function fmtTime(sec: number): string {
  if (!Number.isFinite(sec) || sec < 0) return "0:00";
  const s = Math.floor(sec);
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;
}

export function localToQ(t: LibTrack, meta?: TrackMeta): QItem {
  return {
    key: `l${t.id}`,
    title: t.title,
    artist: t.artist && t.artist !== "<unknown>" ? t.artist : "Unknown artist",
    album: t.album,
    localId: t.id,
    localUri: t.uri,
    albumId: t.albumId,
    cover: meta?.dz?.cover,
    dzId: meta?.dz?.id,
    link: meta?.dz ? `https://www.deezer.com/track/${meta.dz.id}` : undefined,
    durationSec: t.durationMs / 1000,
  };
}
export function dzToQ(d: DzTrack): QItem {
  return {
    key: `d${d.id}`,
    title: d.title,
    artist: d.artist,
    album: d.album,
    dzId: d.id,
    cover: d.cover,
    link: d.link,
    durationSec: d.durationSec,
    previewUrl: d.preview,
    previewAt: d.preview ? Date.now() : undefined,
  };
}

export interface Row {
  key: string;
  title: string;
  sub: string;
  cover?: string;
  uri?: string;
  albumId?: string;
  id?: string;
  durationSec?: number;
  badge?: string;
  q: QItem;
  onMenu?: () => void;
}

/** Cover picture that loads only when it scrolls into view. */
export function ArtImg(props: { cover?: string; uri?: string; albumId?: string; id?: string; className?: string }) {
  const ref = useRef<HTMLDivElement | null>(null);
  const [src, setSrc] = useState<string | null>(null);
  const [seen, setSeen] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el || seen) return;
    if (typeof IntersectionObserver === "undefined") {
      setSeen(true);
      return;
    }
    const io = new IntersectionObserver((entries) => {
      if (entries.some((e) => e.isIntersecting)) {
        setSeen(true);
        io.disconnect();
      }
    });
    io.observe(el);
    return () => io.disconnect();
  }, [seen]);
  useEffect(() => {
    if (!seen) return;
    let alive = true;
    if (props.uri && props.id) {
      void nativeArt({ uri: props.uri, albumId: props.albumId ?? "0", id: props.id }).then((p) => {
        if (alive) setSrc(p ?? props.cover ?? null);
      });
    } else {
      setSrc(props.cover ?? null);
    }
    return () => {
      alive = false;
    };
  }, [seen, props.uri, props.id, props.albumId, props.cover]);
  return (
    <div ref={ref} className={`mh-art ${props.className ?? ""}`}>
      {src ? <img src={src} alt="" loading="lazy" onError={() => setSrc(null)} /> : <span aria-hidden="true">🎵</span>}
    </div>
  );
}

export function SongRow(props: { row: Row; active: boolean; onPlay: () => void }) {
  const { row } = props;
  return (
    <li className={`mh-row${props.active ? " mh-row-on" : ""}`}>
      <button type="button" className="mh-row-main" onClick={props.onPlay}>
        <ArtImg cover={row.cover} uri={row.uri} albumId={row.albumId} id={row.id} />
        <span className="mh-row-text">
          <span className="mh-row-title">{row.title}</span>
          <span className="mh-row-sub">
            {row.badge ? <b className="mh-badge">{row.badge}</b> : null}
            {row.sub}
          </span>
        </span>
        <span className="mh-row-time">{row.durationSec ? fmtTime(row.durationSec) : ""}</span>
      </button>
      {row.onMenu && (
        <button type="button" className="mh-row-more" aria-label={`More for ${row.title}`} onClick={row.onMenu}>
          ⋮
        </button>
      )}
    </li>
  );
}

/** Renders rows 60 at a time, loading more as the end scrolls into view. */
export function RowList(props: { rows: Row[]; currentKey: string; onPlayAt: (index: number) => void; empty?: ReactNode }) {
  const [limit, setLimit] = useState(60);
  const endRef = useRef<HTMLDivElement | null>(null);
  useEffect(() => setLimit(60), [props.rows]);
  useEffect(() => {
    const el = endRef.current;
    if (!el || typeof IntersectionObserver === "undefined") return;
    const io = new IntersectionObserver((e) => {
      if (e.some((x) => x.isIntersecting)) setLimit((l) => l + 60);
    }, { rootMargin: "400px" });
    io.observe(el);
    return () => io.disconnect();
  }, [props.rows, limit]);
  if (props.rows.length === 0) return <>{props.empty ?? <p className="mut mt-3">Nothing here yet.</p>}</>;
  return (
    <>
      <ul className="mh-list">
        {props.rows.slice(0, limit).map((r, i) => (
          <SongRow key={r.key + i} row={r} active={r.q.key === props.currentKey} onPlay={() => props.onPlayAt(i)} />
        ))}
      </ul>
      {limit < props.rows.length && (
        <div ref={endRef}>
          <button type="button" className="hw-btn hw-btn-alt mt-2 px-4 py-2 text-sm font-bold" onClick={() => setLimit((l) => l + 60)}>
            Show more ({props.rows.length - limit} left)
          </button>
        </div>
      )}
    </>
  );
}
