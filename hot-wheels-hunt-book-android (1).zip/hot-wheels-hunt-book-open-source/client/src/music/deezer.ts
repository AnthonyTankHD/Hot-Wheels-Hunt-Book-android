// Deezer's public API, no login needed. (Deezer is not accepting new
// developer apps, so "sign in with Deezer" is not possible; everything here
// works from public data: search, charts, public playlists, covers, and
// 30-second previews. Full songs open in the Deezer app.)
import { CapacitorHttp } from "@capacitor/core";
import type { DzTrack } from "./store";
import type { LibTrack } from "./native";

const API = "https://api.deezer.com";

// Deezer allows about 50 requests per 5 seconds; stay well under it.
let chain: Promise<unknown> = Promise.resolve();
let lastAt = 0;
function throttled<T>(fn: () => Promise<T>): Promise<T> {
  const run = chain.then(async () => {
    const wait = Math.max(0, lastAt + 130 - Date.now());
    if (wait) await new Promise((r) => setTimeout(r, wait));
    lastAt = Date.now();
    return fn();
  });
  chain = run.catch(() => undefined);
  return run;
}

async function get(path: string, params: Record<string, string | number> = {}): Promise<any> {
  const qs = Object.entries(params)
    .map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(String(v))}`)
    .join("&");
  const url = `${API}${path}${qs ? `?${qs}` : ""}`;
  for (let attempt = 0; attempt < 3; attempt++) {
    const res = await throttled(() =>
      CapacitorHttp.get({ url, headers: { Accept: "application/json" }, connectTimeout: 12000, readTimeout: 20000, responseType: "json" }),
    );
    if (res.status !== 200) throw new Error(`Deezer answered with status ${res.status}.`);
    const data = typeof res.data === "string" ? JSON.parse(res.data) : res.data;
    if (data && data.error) {
      const code = Number(data.error.code);
      if (code === 4 && attempt < 2) {
        await new Promise((r) => setTimeout(r, 5000)); // quota: wait and retry
        continue;
      }
      if (code === 800) throw new Error("Deezer has no result for that.");
      throw new Error(String(data.error.message || "Deezer returned an error."));
    }
    return data;
  }
  throw new Error("Deezer is busy. Try again in a minute.");
}

export function mapTrack(t: any): DzTrack {
  return {
    id: Number(t.id),
    title: String(t.title_short || t.title || ""),
    artist: String(t.artist?.name ?? ""),
    artistId: Number(t.artist?.id ?? 0),
    album: String(t.album?.title ?? ""),
    albumId: Number(t.album?.id ?? 0),
    cover: String(t.album?.cover_medium || t.album?.cover_big || t.album?.cover || ""),
    durationSec: Number(t.duration ?? 0),
    link: String(t.link || `https://www.deezer.com/track/${t.id}`),
    preview: t.preview ? String(t.preview) : undefined,
  };
}

export async function searchTracks(q: string, limit = 25): Promise<DzTrack[]> {
  const d = await get("/search/track", { q, limit });
  return (d.data ?? []).map(mapTrack);
}
export async function chartTracks(limit = 40): Promise<DzTrack[]> {
  const d = await get("/chart/0/tracks", { limit });
  return (d.data ?? []).map(mapTrack);
}
/** A fresh track record. Preview addresses expire, so ask right before playing. */
export async function getTrack(id: number): Promise<DzTrack> {
  return mapTrack(await get(`/track/${id}`));
}
export async function artistTop(artistId: number, limit = 25): Promise<DzTrack[]> {
  const d = await get(`/artist/${artistId}/top`, { limit });
  return (d.data ?? []).map(mapTrack);
}

export interface DzPlaylist {
  id: number;
  title: string;
  creator: string;
  cover: string;
  count: number;
  tracks: DzTrack[];
}
export async function getPlaylist(id: number, max = 400): Promise<DzPlaylist> {
  const head = await get(`/playlist/${id}`);
  const tracks: DzTrack[] = [];
  for (let index = 0; index < max; index += 100) {
    const page = await get(`/playlist/${id}/tracks`, { index, limit: 100 });
    const rows: any[] = page.data ?? [];
    for (const r of rows) tracks.push(mapTrack(r));
    if (rows.length < 100) break;
  }
  return {
    id,
    title: String(head.title ?? "Deezer playlist"),
    creator: String(head.creator?.name ?? ""),
    cover: String(head.picture_medium || head.picture || ""),
    count: Number(head.nb_tracks ?? tracks.length),
    tracks,
  };
}
export interface DzPlaylistInfo {
  id: number;
  title: string;
  count: number;
  cover: string;
}
export async function userPlaylists(userId: number): Promise<{ name: string; playlists: DzPlaylistInfo[] }> {
  const user = await get(`/user/${userId}`);
  const d = await get(`/user/${userId}/playlists`, { limit: 100 });
  return {
    name: String(user.name ?? `User ${userId}`),
    playlists: (d.data ?? []).map((p: any) => ({
      id: Number(p.id),
      title: String(p.title ?? ""),
      count: Number(p.nb_tracks ?? 0),
      cover: String(p.picture_medium || p.picture || ""),
    })),
  };
}

export type DzLink = { kind: "playlist" | "user" | "track" | "album" | "artist"; id: number };
/** Understands deezer.com links, short links, or a bare profile number. */
export async function parseDeezerInput(text: string): Promise<DzLink | null> {
  const raw = text.trim();
  if (/^\d+$/.test(raw)) return { kind: "user", id: Number(raw) };
  const direct = /deezer\.com\/(?:[a-z]{2}(?:-[a-z]{2})?\/)?(playlist|profile|user|track|album|artist)\/(\d+)/i.exec(raw);
  if (direct) {
    const k = direct[1]!.toLowerCase();
    return { kind: (k === "profile" ? "user" : k) as DzLink["kind"], id: Number(direct[2]) };
  }
  if (/(deezer\.page\.link|link\.deezer\.com|dzr\.page\.link)/i.test(raw)) {
    try {
      const res = await CapacitorHttp.get({ url: raw.startsWith("http") ? raw : `https://${raw}`, connectTimeout: 10000, readTimeout: 15000, responseType: "text" });
      const finalUrl = String((res as { url?: string }).url ?? "");
      if (finalUrl && finalUrl !== raw) return parseDeezerInput(finalUrl);
      const m = /deezer\.com\/(?:[a-z]{2}(?:-[a-z]{2})?\/)?(playlist|track|album|artist)\/(\d+)/i.exec(String(res.data ?? ""));
      if (m) return { kind: m[1]!.toLowerCase() as DzLink["kind"], id: Number(m[2]) };
    } catch {
      // fall through
    }
  }
  return null;
}

// ---- matching a song on the phone to a Deezer track ----
export function norm(s: string): string {
  return s
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/\(.*?\)|\[.*?\]/g, " ")
    .replace(/\s[-\u2013]\s.*$/, " ") // "- Remastered 2011", "- Radio Edit"
    .replace(/\b(feat|ft|featuring)\b.*$/, " ")
    .replace(/&/g, " and ")
    .replace(/[^a-z0-9]+/g, " ")
    .trim();
}
export function matchKey(title: string, artist: string): string {
  return `${norm(title)}|${norm(artist)}`;
}
function cleanForQuery(s: string): string {
  return s.replace(/["“”]/g, " ").replace(/\s+/g, " ").trim();
}
function knownArtist(a: string): boolean {
  const n = norm(a);
  return n !== "" && n !== "unknown" && n !== "unknown artist" && n !== "unknown artist";
}

/** Finds the Deezer track for a song on the phone, or null. */
export async function findOnDeezer(t: Pick<LibTrack, "title" | "artist" | "durationMs">): Promise<DzTrack | null> {
  const title = cleanForQuery(t.title);
  if (!title) return null;
  const hasArtist = knownArtist(t.artist);
  const q = hasArtist ? `artist:"${cleanForQuery(t.artist)}" track:"${title}"` : `track:"${title}"`;
  let results = await searchTracks(q, 8);
  if (results.length === 0 && hasArtist) results = await searchTracks(`${cleanForQuery(t.artist)} ${title}`, 8);
  const wantTitle = norm(t.title);
  const wantArtist = norm(t.artist);
  const sec = t.durationMs / 1000;
  let best: { r: DzTrack; score: number } | null = null;
  for (const r of results) {
    let score = 0;
    const rt = norm(r.title);
    if (rt === wantTitle) score += 3;
    else if (rt && (rt.startsWith(wantTitle) || wantTitle.startsWith(rt))) score += 1;
    else continue;
    const ra = norm(r.artist);
    if (hasArtist) {
      if (ra === wantArtist) score += 3;
      else if (ra.includes(wantArtist) || wantArtist.includes(ra)) score += 2;
      else continue;
    }
    if (sec > 0 && r.durationSec > 0 && Math.abs(sec - r.durationSec) <= 3) score += 2;
    if (!hasArtist && score < 5) continue; // title alone needs a matching length too
    if (!best || score > best.score) best = { r, score };
  }
  return best ? best.r : null;
}

export async function albumTracks(albumId: number): Promise<DzTrack[]> {
  const head = await get(`/album/${albumId}`);
  const cover = String(head.cover_medium || head.cover_big || head.cover || "");
  const d = await get(`/album/${albumId}/tracks`, { limit: 100 });
  return (d.data ?? []).map((t: any) => {
    const m = mapTrack(t);
    return { ...m, album: m.album || String(head.title ?? ""), albumId: m.albumId || albumId, cover: m.cover || cover };
  });
}
