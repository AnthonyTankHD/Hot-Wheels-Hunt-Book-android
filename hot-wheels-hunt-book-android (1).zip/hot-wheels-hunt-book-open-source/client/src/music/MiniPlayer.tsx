// Always-visible mini player (bottom of the app) and the full Now Playing
// sheet. Lives in App so music keeps playing while you browse cars.
import { useState } from "react";
import { ArtImg, fmtTime } from "./ui";
import {
  cycleRepeat, getOrder, jumpTo, next, openNow, prev, removeAt, seek, setBackgroundPref, setRate, setShuffle, setSleep, stopAll, toggle, usePlayer,
} from "./player";

const RATES = [0.75, 1, 1.25, 1.5, 2];
const SLEEPS: (number | null)[] = [null, 15, 30, 60];

export function MiniPlayer(props: { onOpenMusic: () => void }) {
  const p = usePlayer();
  const item = p.queue[p.index];
  const [showQueue, setShowQueue] = useState(false);
  const [sleepChoice, setSleepChoice] = useState<number | null>(null);
  if (!item) return null;

  const sleepMin = p.sleepAt ? Math.max(1, Math.round((p.sleepAt - Date.now()) / 60000)) : null;
  const upNext = getOrder().slice(0).map((qi) => ({ qi, it: p.queue[qi] })).filter((x) => x.it);
  const here = upNext.findIndex((x) => x.qi === p.index);

  return (
    <>
      <div className="mp-spacer" aria-hidden="true" />
      <div className="mp-bar" role="region" aria-label="Now playing">
        <button type="button" className="mp-open" onClick={() => openNow(true)} aria-label="Open the player">
          <ArtImg cover={item.cover} uri={item.localUri} albumId={item.albumId} id={item.localId} className="mp-art" />
          <span className="mh-row-text">
            <span className="mh-row-title">{item.title}</span>
            <span className="mh-row-sub">{p.error || (p.loading ? "Loading…" : item.artist)}</span>
          </span>
        </button>
        <button type="button" className="mp-btn" onClick={toggle} aria-label={p.playing ? "Pause" : "Play"}>
          {p.playing ? "⏸" : "▶"}
        </button>
        <button type="button" className="mp-btn" onClick={next} aria-label="Next song">⏭</button>
        <div className="mp-progress" style={{ width: `${p.duration ? Math.min(100, (p.position / p.duration) * 100) : 0}%` }} />
      </div>

      {p.nowOpen && (
        <div className="np" role="dialog" aria-label="Now playing">
          <div className="np-top">
            <button type="button" className="np-close" onClick={() => openNow(false)} aria-label="Close the player">⌄</button>
            <span className="np-label">{p.preview ? "30-second preview" : "Now playing"}</span>
            <button type="button" className="np-close" onClick={() => { openNow(false); props.onOpenMusic(); }} aria-label="Open Music">♫</button>
          </div>

          {!showQueue ? (
            <>
              <ArtImg cover={item.cover} uri={item.localUri} albumId={item.albumId} id={item.localId} className="np-art" />
              <h2 className="np-title">{item.title}</h2>
              <p className="np-artist">{item.artist}{item.album ? ` · ${item.album}` : ""}</p>
              {p.error && <p className="np-error">{p.error}</p>}
            </>
          ) : (
            <ul className="np-queue">
              {upNext.slice(Math.max(0, here), Math.max(0, here) + 60).map((x, i) => (
                <li key={`${x.qi}-${i}`} className={x.qi === p.index ? "np-queue-on" : ""}>
                  <button type="button" onClick={() => jumpTo(x.qi)}>
                    <span className="mh-row-title">{x.it!.title}</span>
                    <span className="mh-row-sub">{x.it!.artist}</span>
                  </button>
                  {x.qi !== p.index && (
                    <button type="button" className="mh-row-more" aria-label={`Remove ${x.it!.title}`} onClick={() => removeAt(x.qi)}>✕</button>
                  )}
                </li>
              ))}
            </ul>
          )}

          <div className="np-seek">
            <span>{fmtTime(p.position)}</span>
            <input
              type="range"
              min={0}
              max={Math.max(1, Math.floor(p.duration || item.durationSec || 1))}
              value={Math.floor(p.position)}
              onChange={(e) => seek(Number(e.target.value))}
              aria-label="Seek"
            />
            <span>{fmtTime(p.duration || item.durationSec || 0)}</span>
          </div>

          <div className="np-controls">
            <button type="button" className={p.shuffle ? "np-on" : ""} onClick={() => setShuffle(!p.shuffle)} aria-label="Shuffle">🔀</button>
            <button type="button" onClick={prev} aria-label="Previous">⏮</button>
            <button type="button" className="np-play" onClick={toggle} aria-label={p.playing ? "Pause" : "Play"}>{p.playing ? "⏸" : "▶"}</button>
            <button type="button" onClick={next} aria-label="Next">⏭</button>
            <button type="button" className={p.repeat !== "off" ? "np-on" : ""} onClick={cycleRepeat} aria-label="Repeat">
              {p.repeat === "one" ? "🔂" : "🔁"}
            </button>
          </div>

          <div className="np-extras">
            <button type="button" onClick={() => setRate(RATES[(RATES.indexOf(p.rate) + 1) % RATES.length] ?? 1)}>{p.rate}x</button>
            <button
              type="button"
              onClick={() => {
                const nextChoice = SLEEPS[(SLEEPS.indexOf(p.sleepAt ? sleepChoice : null) + 1) % SLEEPS.length] ?? null;
                setSleepChoice(nextChoice);
                setSleep(nextChoice);
              }}
            >
              😴 {sleepMin ? `${sleepMin} min` : "Sleep"}
            </button>
            <button type="button" className={p.bgPlay ? "np-on-pill" : ""} onClick={() => setBackgroundPref(!p.bgPlay)}>
              🔒 Background {p.bgPlay ? "on" : "off"}
            </button>
            <button type="button" onClick={() => setShowQueue((v) => !v)}>{showQueue ? "Cover" : "Queue"}</button>
            {item.link ? (
              <a href={item.link} target="_blank" rel="noreferrer">Open in Deezer</a>
            ) : (
              <button type="button" onClick={() => { stopAll(); }}>Stop</button>
            )}
          </div>
        </div>
      )}
    </>
  );
}
