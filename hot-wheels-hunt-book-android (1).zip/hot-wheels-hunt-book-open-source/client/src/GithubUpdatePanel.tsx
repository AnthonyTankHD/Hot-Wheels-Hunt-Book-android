// Settings block (Android app): update the app from your own GitHub repo.
// The logic lives in ./ota.ts.
import { useState } from "react";
import { SPLASH_BUILD_STAMP } from "./build-stamp";
import {
  checkForUpdate,
  installUpdate,
  loadGithubSettings,
  runningDownloadedBuild,
  saveGithubSettings,
  type GithubSettings,
  type UpdateInfo,
} from "./ota";

function buildLabelOf(stamp: string): string {
  const m = /^v(\d+)-(\d{4})-(\d{2})-(\d{2})/.exec(stamp);
  return m ? `Build v${m[1]} \u00b7 ${m[2]}-${m[3]}-${m[4]}` : stamp;
}

export function GithubUpdatePanel() {
  const [settings, setSettings] = useState<GithubSettings>(() => loadGithubSettings());
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState("");
  const [error, setError] = useState("");
  const [info, setInfo] = useState<UpdateInfo | null>(null);
  const [ready, setReady] = useState(false);

  const check = async () => {
    setBusy(true);
    setError("");
    setMsg("Checking GitHub…");
    setInfo(null);
    setReady(false);
    try {
      saveGithubSettings(settings);
      const found = await checkForUpdate(settings);
      setInfo(found);
      setMsg(found.newer ? `New build available: ${found.label}` : "You're on the newest build.");
    } catch (e) {
      setMsg("");
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setBusy(false);
    }
  };

  const install = async () => {
    if (!info) return;
    setBusy(true);
    setError("");
    try {
      await installUpdate(info, settings, setMsg);
      setMsg("Downloaded. Tap Restart to switch to it.");
      setReady(true);
    } catch (e) {
      setMsg("");
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="build-update">
      <p className="text-sm text-[var(--dim)]">
        This phone is running <b className="text-[var(--text)]">{buildLabelOf(SPLASH_BUILD_STAMP)}</b>
        {runningDownloadedBuild() ? " (downloaded from GitHub)" : ""}.
      </p>
      <label className="mt-2 block text-sm font-semibold" htmlFor="gh-repo">
        GitHub repo (owner/name)
      </label>
      <input
        id="gh-repo"
        className="mt-1 w-full rounded-[10px] border border-[var(--border)] bg-[var(--surface-2)] px-4 py-2.5 text-base outline-none focus:border-[var(--accent)]"
        placeholder="yourname/hunt-book"
        autoCapitalize="none"
        autoCorrect="off"
        value={settings.repo}
        onChange={(e) => setSettings({ ...settings, repo: e.target.value })}
      />
      <label className="mt-2 block text-sm font-semibold" htmlFor="gh-token">
        Access token (only for a private repo)
      </label>
      <input
        id="gh-token"
        className="mt-1 w-full rounded-[10px] border border-[var(--border)] bg-[var(--surface-2)] px-4 py-2.5 text-base outline-none focus:border-[var(--accent)]"
        type="password"
        placeholder="optional"
        autoCapitalize="none"
        autoCorrect="off"
        value={settings.token}
        onChange={(e) => setSettings({ ...settings, token: e.target.value })}
      />
      <button type="button" className="hw-btn build-update-btn mt-3" disabled={busy || !settings.repo.trim()} onClick={() => void check()}>
        {busy && !info ? "Working…" : "\u2b06\ufe0f Check GitHub for updates"}
      </button>
      {msg && (
        <p role="status" className="mt-2 text-sm font-semibold text-[var(--green)]">
          {msg}
        </p>
      )}
      {error && (
        <p role="alert" className="mt-2 text-sm font-semibold text-[var(--accent)]">
          {error}
        </p>
      )}
      {info?.newer && info.inApp && !ready && (
        <button type="button" className="hw-btn build-update-btn mt-2" disabled={busy} onClick={() => void install()}>
          {busy ? "Updating…" : `Update now to ${info.label}`}
        </button>
      )}
      {ready && (
        <button type="button" className="hw-btn build-update-btn mt-2" onClick={() => window.location.reload()}>
          Restart into the new build
        </button>
      )}
      {info?.newer && !info.inApp && (
        <p className="mt-2 text-sm text-[var(--dim)]">
          This update changes the app itself, so it has to be installed as an APK. Open the release page, download{" "}
          <b>app-debug.apk</b>, and open it; it installs over this app and keeps your data.
        </p>
      )}
      {info?.newer && (
        <p className="mt-2 text-sm">
          <a className="underline" href={info.pageUrl} target="_blank" rel="noreferrer">
            Open the release page (download the APK)
          </a>
        </p>
      )}
      <p className="mt-2 text-sm text-[var(--dim)]">
        Gets the newest build you published to your own GitHub repo. Your collection, photos, music and settings stay on this phone
        and are not touched by updating. If a new build fails to start, the next launch goes back to the previous one by itself.
      </p>
    </div>
  );
}
