// Adds the native Android project (first run) and patches it:
//   - camera permission, so "take a photo / record a video" works
//   - launcher icon generated from assets/icon.png
// Run after `bun run build:android`:
//   node scripts/prepare-android.mjs
import { execSync } from "node:child_process";
import { copyFileSync, existsSync, mkdirSync, readFileSync, writeFileSync } from "node:fs";

const run = (cmd) => execSync(cmd, { stdio: "inherit" });

if (!existsSync("android")) {
  run("npx cap add android");
}
run("npx cap sync android");

const manifestPath = "android/app/src/main/AndroidManifest.xml";
let manifest = readFileSync(manifestPath, "utf8");
if (!manifest.includes("android.permission.CAMERA")) {
  const perms =
    '    <uses-permission android:name="android.permission.CAMERA" />\n' +
    '    <uses-feature android:name="android.hardware.camera" android:required="false" />\n';
  const marker = /(\s*<uses-permission android:name="android.permission.INTERNET" \/>)/;
  if (marker.test(manifest)) {
    manifest = manifest.replace(marker, `$1\n${perms.trimEnd()}`);
  } else {
    manifest = manifest.replace("</manifest>", `${perms}</manifest>`);
  }
  writeFileSync(manifestPath, manifest);
  console.log("patched AndroidManifest.xml (camera)");
}

// Launcher icon: customize/icon.png, background color from customize/app.json.
const appConfig = JSON.parse(readFileSync("customize/app.json", "utf8"));
const iconBg = appConfig.iconBackground || "#0b3d91";
mkdirSync("assets", { recursive: true });
copyFileSync("customize/icon.png", "assets/icon.png");
try {
  run(`npx --yes @capacitor/assets generate --android --iconBackgroundColor '${iconBg}' --iconBackgroundColorDark '${iconBg}'`);
} catch {
  console.warn("icon generation failed — the APK will use the default Capacitor icon");
}

// Sign every build with the same key (scripts/hunt-book.keystore). Without
// this each cloud build gets a brand-new random debug key, and Android
// refuses to install a build over the one already on the phone.
const gradlePath = "android/app/build.gradle";
let gradle = readFileSync(gradlePath, "utf8");
if (!gradle.includes("hunt-book.keystore")) {
  copyFileSync("scripts/hunt-book.keystore", "android/app/hunt-book.keystore");
  const signing =
    "    signingConfigs {\n" +
    "        debug {\n" +
    "            storeFile file('hunt-book.keystore')\n" +
    "            storePassword 'huntbook-key'\n" +
    "            keyAlias 'huntbook'\n" +
    "            keyPassword 'huntbook-key'\n" +
    "            storeType 'pkcs12'\n" +
    "        }\n" +
    "    }\n";
  if (!/\n\s*android\s*\{/.test(gradle)) throw new Error("could not find the android { block in android/app/build.gradle");
  gradle = gradle.replace(/(\n\s*android\s*\{\n)/, `$1${signing}`);
  writeFileSync(gradlePath, gradle);
  console.log("patched build.gradle (fixed signing key)");
}

// Native music scanner (reads the phone's music list) + the permissions it
// needs. MainActivity registers the plugin so the web code can call it.
{
  const pkgDir = "android/app/src/main/java/com/huntbook/hotwheels";
  mkdirSync(pkgDir, { recursive: true });
  copyFileSync("scripts/android-native/MusicLibraryPlugin.java", `${pkgDir}/MusicLibraryPlugin.java`);
  copyFileSync("scripts/android-native/MusicKeepAliveService.java", `${pkgDir}/MusicKeepAliveService.java`);
  copyFileSync("scripts/android-native/MainActivity.java", `${pkgDir}/MainActivity.java`);
  let m = readFileSync(manifestPath, "utf8");
  if (!m.includes("READ_MEDIA_AUDIO")) {
    const perms =
      '    <uses-permission android:name="android.permission.READ_MEDIA_AUDIO" />\n' +
      '    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" android:maxSdkVersion="32" />\n';
    m = m.replace("</manifest>", `${perms}</manifest>`);
    writeFileSync(manifestPath, m);
    console.log("patched AndroidManifest.xml (music access)");
  }
  // Background playback: the notification service and its permissions.
  m = readFileSync(manifestPath, "utf8");
  if (!m.includes("MusicKeepAliveService")) {
    const perms =
      '    <uses-permission android:name="android.permission.FOREGROUND_SERVICE" />\n' +
      '    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK" />\n' +
      '    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />\n';
    const service = '        <service android:name=".MusicKeepAliveService" android:exported="false" android:foregroundServiceType="mediaPlayback" />\n';
    if (!m.includes("</application>")) throw new Error("no </application> in AndroidManifest.xml");
    m = m.replace("</application>", `${service}    </application>`).replace("</manifest>", `${perms}</manifest>`);
    writeFileSync(manifestPath, m);
    console.log("patched AndroidManifest.xml (background music service)");
  }
}
