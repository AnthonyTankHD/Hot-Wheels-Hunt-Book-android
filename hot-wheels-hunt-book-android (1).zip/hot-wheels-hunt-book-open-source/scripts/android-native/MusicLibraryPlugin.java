package com.huntbook.hotwheels;

import android.Manifest;
import android.content.ContentUris;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore;
import android.util.Size;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.PermissionState;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;

import java.io.File;
import java.io.FileOutputStream;

/**
 * Reads the phone's music list from Android's media database (MediaStore).
 * Nothing is copied: the app keeps the list and plays the files in place.
 */
@CapacitorPlugin(
    name = "MusicLibrary",
    permissions = {
        @Permission(alias = "audio13", strings = { Manifest.permission.READ_MEDIA_AUDIO }),
        @Permission(alias = "audioLegacy", strings = { Manifest.permission.READ_EXTERNAL_STORAGE }),
        @Permission(alias = "notifications", strings = { Manifest.permission.POST_NOTIFICATIONS })
    }
)
public class MusicLibraryPlugin extends Plugin {

    /** True while music is playing and should keep going with the app minimized. */
    public static volatile boolean keepAlive = false;

    private String alias() {
        return Build.VERSION.SDK_INT >= 33 ? "audio13" : "audioLegacy";
    }

    private boolean hasAccess() {
        return getPermissionState(alias()) == PermissionState.GRANTED;
    }

    private Uri collection() {
        if (Build.VERSION.SDK_INT >= 29) {
            return MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL);
        }
        return MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
    }

    @PluginMethod
    public void checkAccess(PluginCall call) {
        JSObject res = new JSObject();
        res.put("granted", hasAccess());
        call.resolve(res);
    }

    @PluginMethod
    public void requestAccess(PluginCall call) {
        if (hasAccess()) {
            JSObject res = new JSObject();
            res.put("granted", true);
            call.resolve(res);
            return;
        }
        requestPermissionForAlias(alias(), call, "accessCallback");
    }

    @PermissionCallback
    private void accessCallback(PluginCall call) {
        JSObject res = new JSObject();
        res.put("granted", hasAccess());
        call.resolve(res);
    }

    /** Returns one page of songs: { total, items: [...] }. */
    @PluginMethod
    public void scan(PluginCall call) {
        if (!hasAccess()) {
            call.reject("Music access was not allowed.");
            return;
        }
        int offset = call.getInt("offset", 0);
        int limit = call.getInt("limit", 500);
        Uri base = collection();
        String[] projection = new String[] {
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.TRACK,
            MediaStore.Audio.Media.YEAR,
            MediaStore.Audio.Media.DATE_ADDED,
            MediaStore.Audio.Media.SIZE,
            MediaStore.Audio.Media.MIME_TYPE,
            MediaStore.Audio.Media.DISPLAY_NAME
        };
        String selection = MediaStore.Audio.Media.IS_MUSIC + " != 0";
        Cursor c = null;
        try {
            c = getContext().getContentResolver().query(
                base, projection, selection, null, MediaStore.Audio.Media._ID + " ASC");
            JSArray items = new JSArray();
            int total = 0;
            if (c != null) {
                total = c.getCount();
                if (offset < total && c.moveToPosition(offset)) {
                    int n = 0;
                    do {
                        long id = c.getLong(0);
                        JSObject o = new JSObject();
                        o.put("id", String.valueOf(id));
                        o.put("uri", ContentUris.withAppendedId(base, id).toString());
                        String name = c.getString(11);
                        String title = c.getString(1);
                        o.put("title", title != null ? title : (name != null ? name : ""));
                        o.put("artist", c.getString(2) != null ? c.getString(2) : "");
                        o.put("album", c.getString(3) != null ? c.getString(3) : "");
                        o.put("albumId", String.valueOf(c.getLong(4)));
                        o.put("durationMs", c.getLong(5));
                        o.put("trackNo", c.getInt(6));
                        o.put("year", c.getInt(7));
                        o.put("addedAt", c.getLong(8));
                        o.put("size", c.getLong(9));
                        o.put("mime", c.getString(10) != null ? c.getString(10) : "");
                        items.put(o);
                        n++;
                    } while (n < limit && c.moveToNext());
                }
            }
            JSObject res = new JSObject();
            res.put("total", total);
            res.put("items", items);
            call.resolve(res);
        } catch (Exception e) {
            call.reject("Could not read the music list: " + e.getMessage());
        } finally {
            if (c != null) {
                c.close();
            }
        }
    }

    /**
     * Saves a small cover picture for a song into the app's cache and
     * returns its file path ({} when the song has no cover).
     */
    @PluginMethod
    public void getArt(PluginCall call) {
        String uriStr = call.getString("uri");
        String key = call.getString("key");
        int size = call.getInt("size", 256);
        JSObject res = new JSObject();
        if (uriStr == null || key == null || Build.VERSION.SDK_INT < 29) {
            call.resolve(res);
            return;
        }
        try {
            File dir = new File(getContext().getCacheDir(), "music-art");
            dir.mkdirs();
            String safe = key.replaceAll("[^A-Za-z0-9_-]", "_");
            File out = new File(dir, safe + ".jpg");
            File none = new File(dir, safe + ".none");
            if (out.exists() && out.length() > 0) {
                res.put("path", out.getAbsolutePath());
                call.resolve(res);
                return;
            }
            if (none.exists()) {
                call.resolve(res);
                return;
            }
            try {
                Bitmap bmp = getContext().getContentResolver().loadThumbnail(Uri.parse(uriStr), new Size(size, size), null);
                FileOutputStream fos = new FileOutputStream(out);
                try {
                    bmp.compress(Bitmap.CompressFormat.JPEG, 85, fos);
                } finally {
                    fos.close();
                }
                res.put("path", out.getAbsolutePath());
            } catch (Exception e) {
                none.createNewFile();
            }
        } catch (Exception ignored) {
            // no cover: resolve with an empty result
        }
        call.resolve(res);
    }

    /** Starts or stops the "music playing" notification that keeps playback alive in the background. */
    @PluginMethod
    public void setPlaying(PluginCall call) {
        boolean playing = Boolean.TRUE.equals(call.getBoolean("playing", false));
        String title = call.getString("title", "");
        String artist = call.getString("artist", "");
        Intent svc = new Intent(getContext(), MusicKeepAliveService.class);
        try {
            if (playing) {
                keepAlive = true;
                svc.putExtra("title", title);
                svc.putExtra("artist", artist);
                if (Build.VERSION.SDK_INT >= 26) {
                    getContext().startForegroundService(svc);
                } else {
                    getContext().startService(svc);
                }
            } else {
                keepAlive = false;
                getContext().stopService(svc);
            }
        } catch (Exception ignored) {
            // the music still plays while the app is open
        }
        call.resolve();
    }

    @PluginMethod
    public void requestNotifications(PluginCall call) {
        if (Build.VERSION.SDK_INT < 33 || getPermissionState("notifications") == PermissionState.GRANTED) {
            JSObject res = new JSObject();
            res.put("granted", true);
            call.resolve(res);
            return;
        }
        requestPermissionForAlias("notifications", call, "notifCallback");
    }

    @PermissionCallback
    private void notifCallback(PluginCall call) {
        JSObject res = new JSObject();
        res.put("granted", getPermissionState("notifications") == PermissionState.GRANTED);
        call.resolve(res);
    }
}
