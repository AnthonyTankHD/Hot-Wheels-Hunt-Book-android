// Packs client/dist-android/ into one JSON file (bundle.json) that the
// app downloads from a GitHub Release to update itself in place.
//   node scripts/make-ota-bundle.mjs <output.json>
import { readFileSync, readdirSync, statSync, writeFileSync } from "node:fs";
import { join, relative, sep } from "node:path";

const root = "client/dist-android";
const out = process.argv[2] || "bundle.json";

const stampSrc = readFileSync("client/src/build-stamp.ts", "utf8");
const stamp = /SPLASH_BUILD_STAMP\s*=\s*"([^"]+)"/.exec(stampSrc)?.[1];
const shell = /SHELL_VERSION\s*=\s*(\d+)/.exec(stampSrc)?.[1];
if (!stamp || !shell) throw new Error("could not read the build stamp / shell version from client/src/build-stamp.ts");

const files = [];
const walk = (dir) => {
  for (const name of readdirSync(dir)) {
    const full = join(dir, name);
    if (statSync(full).isDirectory()) walk(full);
    else files.push({ path: relative(root, full).split(sep).join("/"), b64: readFileSync(full).toString("base64") });
  }
};
walk(root);
if (!files.some((f) => f.path === "index.html")) throw new Error("no index.html in " + root);

writeFileSync(out, JSON.stringify({ stamp, shell: Number(shell), files }));
console.log(`bundle ${stamp} (shell ${shell}): ${files.length} files -> ${out}`);
